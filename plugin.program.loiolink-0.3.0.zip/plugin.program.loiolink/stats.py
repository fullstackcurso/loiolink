# loiolink - Copyright (C) 2026 RubénSDFA1laberot (github.com/loioloio)
# Consulta el archivo LICENSE para mas detalles.
"""Telemetria anonima: contador global de instalaciones.

Envia un unico ping por instalacion a Supabase sin transmitir ningun
identificador. El servidor acumula un total global; los registros con
mas de 30 dias se eliminan automaticamente via politica de retencion.
La dedup vive en el cliente (stats.json), que nunca se transmite.
"""
import base64
import json
import os
import threading
import time

import xbmcaddon
import xbmcvfs

from lib import log

_API_URL = "https://gpcbfvgxwesvlezaning.supabase.co"
_API_KEY = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW1kd1kySm1kbWQ0ZDJWemRteGxlbUZ1YVc1bklpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzTnpNME9EUTFNallzSW1WNGNDSTZNakE0T1RBMk1EVXlObjAuaXBuWGxyZXozeUE2Q1dyaXF3SlU0T3pWUlluMm5OaWNwT1FTdXpwQnktdw==").decode()
_TABLE = "pings"
_PING_INTERVAL_HOURS = 24
_DATA_FILE = 'stats.json'


def _data_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, _DATA_FILE)


def _load_data():
    path = _data_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_data(data):
    path = _data_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError as e:
        # No critico: si no se guarda, el proximo arranque reenvia el ping.
        log.warning(f'stats: no se pudo guardar {_DATA_FILE}: {e}')


def _send_ping(kind):
    """POST un ping anonimo a Supabase. True si el servidor lo acepto."""
    import requests

    headers = {
        'apikey': _API_KEY,
        'Authorization': f'Bearer {_API_KEY}',
        'Content-Type': 'application/json',
        # La tabla no tiene policy de SELECT: pedir la fila insertada de
        # vuelta fallaria con RLS. return=minimal evita ese reread.
        'Prefer': 'return=minimal',
    }
    payload = {
        'addon': xbmcaddon.Addon().getAddonInfo('id'),
        'kind': kind,
    }
    resp = requests.post(
        f'{_API_URL}/rest/v1/{_TABLE}',
        headers=headers,
        json=payload,
        timeout=10,
    )
    if resp.status_code in (200, 201, 204):
        return True
    log.warning(f'stats: ping {kind} rechazado: HTTP {resp.status_code}')
    return False


def _do_pings():
    try:
        data = _load_data()

        # Se guarda tras cada ping con exito: si el siguiente falla, lo ya
        # enviado queda registrado y no se reenvia (evita sobrecuenta).
        if not data.get('install_sent') and _send_ping('install'):
            data['install_sent'] = True
            _save_data(data)

        hours_since = (time.time() - data.get('last_ping', 0)) / 3600
        if hours_since >= _PING_INTERVAL_HOURS and _send_ping('daily'):
            data['last_ping'] = time.time()
            _save_data(data)
    except Exception as e:
        # Thread daemon: ningun fallo (red, addon) debe propagarse.
        log.warning(f'stats: ping fallido: {e}')


def ping():
    """Lanza en segundo plano los pings pendientes. No bloquea al llamador."""
    try:
        threading.Thread(target=_do_pings, daemon=True).start()
    except RuntimeError as e:
        log.warning(f'stats: no se pudo lanzar el thread de ping: {e}')
