"""Item de menú contextual: pega el portapapeles interno en el cuadro de
búsqueda enfocado vía Input.SendText JSON-RPC.

La lógica anti-race (detección de teclado + busydialog + Input.SendText)
vive en `lib.remote.keyboard_input`. Aquí solo se queda el flujo específico
del menú contextual: leer clipboard, validar item, lanzar el plugin y
disparar la inyección en thread.
"""
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui

import clipboard
from lib import accessibility
from lib.remote import keyboard_input
from lib.ui_select import confirm

ADDON = xbmcaddon.Addon()

LOG_PREFIX = '[loiolink.context]'
_DEFAULT_SEARCH_KEYWORDS = (
    'buscar', 'búsqueda', 'busqueda',
    'search', 'find', 'query', 'encontrar',
)


def _get_search_keywords():
    """Palabras configurables (setting 'paste.search_keywords', separadas por |).

    Permite a usuarios en otros idiomas (portugués, francés, italiano...)
    adaptar la detección sin tocar el código.
    """
    try:
        raw = ADDON.getSetting('paste.search_keywords') or ''
    except (TypeError, RuntimeError):
        raw = ''
    parts = tuple(kw.strip().lower() for kw in raw.split('|') if kw.strip())
    return parts or _DEFAULT_SEARCH_KEYWORDS


# Re-exports desde keyboard_input para compatibilidad con tests existentes
# y para que cualquier código que importe estas constantes desde context
# siga funcionando. La fuente de verdad es lib.remote.keyboard_input.
WAIT_INTERVAL_MS = keyboard_input.WAIT_INTERVAL_MS
POST_KB_DETECT_DELAY_MS = keyboard_input.POST_KB_DETECT_DELAY_MS
BUSY_WAIT_MAX_MS = keyboard_input.BUSY_WAIT_MAX_MS
MUTEX_PROP = keyboard_input.MUTEX_PROP
MUTEX_STALE_SECONDS = keyboard_input.MUTEX_STALE_SECONDS

busy_dialog_active = keyboard_input.is_busy_dialog_active
wait_busy_clear = keyboard_input.wait_for_busy_clear
_mutex_acquire = keyboard_input._mutex_acquire
_mutex_release = keyboard_input._mutex_release


def _wait_max_iter():
    try:
        secs = int(ADDON.getSetting('keyboard_wait_seconds') or '8')
    except (TypeError, ValueError):
        secs = 8
    secs = max(2, min(30, secs))
    return int(secs * 1000 / WAIT_INTERVAL_MS)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{LOG_PREFIX} {msg}', level)


def is_search_item(label):
    label_lc = (label or '').lower()
    return any(kw in label_lc for kw in _get_search_keywords())


def get_listitem_url():
    """Cadena de fallback: sys.listitem.getPath() -> getProperty('Path') -> infolabel."""
    url = ''
    if hasattr(sys, 'listitem') and sys.listitem:
        try:
            url = sys.listitem.getPath() or ''
        except (AttributeError, RuntimeError) as e:
            log(f'getPath error: {e}', xbmc.LOGDEBUG)
            url = ''
        if not url:
            try:
                url = sys.listitem.getProperty('Path') or ''
            except (AttributeError, RuntimeError) as e:
                log(f'getProperty error: {e}', xbmc.LOGDEBUG)
                url = ''
    if not url:
        url = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    return url


def is_runnable_plugin_url(url):
    return isinstance(url, str) and url.startswith('plugin://')


def _is_folder_item():
    """Determina si el item es folder (devuelve listado) para elegir
    Container.Update vs RunPlugin.

    `xbmc.getInfoLabel('ListItem.IsFolder')` desde un context menu handler
    suele devolver '' (no 'true'/'false'/'1'/'0'), comprobado en
    atresdaily, kodi 21+. Por eso NO podemos requerir un valor afirmativo.

    Como el caller (context.py) ya filtra por `is_search_item()` (label
    contiene 'buscar'/'search'/...), los items que llegan aquí son
    búsquedas, y las búsquedas son folder items (devuelven resultados).
    Asumimos True por defecto; solo retornamos False si IsFolder es
    EXPLÍCITAMENTE 'false' o '0'.
    """
    val = (xbmc.getInfoLabel('ListItem.IsFolder') or '').strip().lower()
    is_folder = val not in ('false', '0')
    log(f'_is_folder_item: ListItem.IsFolder={val!r} → {is_folder}',
        xbmc.LOGDEBUG)
    return is_folder


def send_text_jsonrpc(text, done):
    """Wrapper sobre Input.SendText. Para tests y compat; la lógica
    completa (con anti-race) vive en keyboard_input.send_text."""
    import json
    payload = {
        'jsonrpc': '2.0',
        'method': 'Input.SendText',
        'params': {'text': text, 'done': done},
        'id': 1,
    }
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    return raw or ''


def wait_keyboard_and_send(text, done):
    """Espera al teclado virtual e inyecta el texto en una sola llamada
    Input.SendText con done=True.

    La rama two-phase (Input.SendText(done=False) + delay + done=True)
    dispara un bug en Kodi 21+ con addons cuyo teclado abre con foco en
    "Aceptar" (espadaily, atresdaily, ...): el done=False cierra el
    diálogo prematuramente con buffer vacío y la búsqueda no corre.
    Single done=True evita el bug porque set+commit es atómico.

    Como consecuencia, `done` (de auto_confirm_search) y
    paste.preview_delay_s ya no se honoran. Para confirmación previa, el
    usuario tiene confirm_before_paste (diálogo ANTES de abrir el teclado).

    El mutex YA está adquirido por main() (protege también la fase de
    yesno/RunPlugin previa al thread). Aquí se libera al terminar.
    """
    wait_ms = _wait_max_iter() * WAIT_INTERVAL_MS
    monitor = xbmc.Monitor()
    try:
        ok = keyboard_input.send_text(
            text, done=True,
            wait_appear_ms=wait_ms, preview_delay_ms=0,
            monitor=monitor, acquire_mutex=False,
        )
        if ok:
            # Toast post-inyección con lo que se pegó. Es seguro (notify es
            # un overlay independiente, no toca el flujo del keyboard ni
            # dispara SendText extra).
            accessibility.notify(f'Pegado: {text[:60]}', ms=2500)
        elif not monitor.abortRequested():
            # Causa más común: el item es un folder navegacional (ej:
            # /search en elementum, que solo lista sub-tipos de búsqueda),
            # no un item que abra teclado al activarse. Otras causas: busy
            # bloqueando indefinidamente, kb cerrado a mitad, SendText
            # rechazado por RPC.
            accessibility.notify(
                'No se abrió teclado. ¿Es un item de búsqueda real?',
                xbmcgui.NOTIFICATION_WARNING, 3500,
            )
    finally:
        _mutex_release()


def main():
    # Red de seguridad por si el filtro <visible> del addon.xml deja pasar algo.
    label = xbmc.getInfoLabel('ListItem.Label')
    if ADDON.getSettingBool('only_on_search_items') and not is_search_item(label):
        accessibility.notify('No parece un item de busqueda')
        return

    text = clipboard.get()
    if not text:
        # Antes solo se notificaba "vacío" y el usuario tenía que ir manualmente
        # al addon a abrir el servidor de recepción. Ofrecemos hacer el viaje
        # de un golpe. No abrimos el servidor desde aquí porque romperíamos el
        # flujo del teclado virtual (ver plan, sección "Respuesta al punto 5").
        if confirm(
            'No hay nada en el portapapeles del addon.\n\n'
            '¿Abrir loiolink para recibir texto desde el móvil?',
            title='loiolink', default_no=False,
        ):
            xbmc.executebuiltin('RunAddon(plugin.program.loiolink)')
        return

    if ADDON.getSettingBool('confirm_before_paste'):
        if not confirm(
            f'Pegar este texto?\n\n[B]{text[:200]}[/B]',
            title='loiolink', default_no=False,
        ):
            return

    url = get_listitem_url()
    if not url:
        accessibility.notify('Sin URL del item', xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    if not is_runnable_plugin_url(url):
        log(f'URL no plugin://, abortando: {url[:200]}', xbmc.LOGWARNING)
        accessibility.notify('Item no ejecutable como plugin', xbmcgui.NOTIFICATION_WARNING, 2500)
        return

    # Adquirimos el mutex AQUÍ (no antes): yesno() puede tardar minutos y
    # abriría ventana de race entre check y set.
    if not _mutex_acquire():
        log('invocacion previa activa, abortando', xbmc.LOGWARNING)
        accessibility.notify('Operacion previa en curso')
        return

    done = ADDON.getSettingBool('auto_confirm_search')
    # Container.Update para folder items (búsquedas que devuelven resultados):
    # RunPlugin ejecuta el plugin pero los items de endOfDirectory no
    # actualizan ningún container visible, así que aunque el teclado abra y
    # el texto se inyecte, los resultados no aparecen en pantalla.
    # Container.Update navega el container actual al URL del plugin y los
    # resultados sí se muestran. Para items no-folder (scripts, playables),
    # RunPlugin sigue siendo lo correcto.
    builtin = (
        f'Container.Update({url})'
        if _is_folder_item()
        else f'RunPlugin({url})'
    )
    log(f'lanzando {builtin[:100]!r} + inject thread, done={done}, '
        f'text_preview={text[:40]!r}')

    try:
        threading.Thread(
            target=wait_keyboard_and_send,
            args=(text, done),
            daemon=True,
            name='loiolink-inject',
        ).start()
        xbmc.executebuiltin(builtin)
    except Exception as e:
        _mutex_release()
        log(f'error lanzando: {e}', xbmc.LOGERROR)
        raise


if __name__ == '__main__':
    main()
