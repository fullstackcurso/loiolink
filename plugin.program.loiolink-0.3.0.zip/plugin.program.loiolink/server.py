# Adaptado de StreamNinja (RubénSDFA1laberot)
"""Servidor HTTP efímero para recibir texto o un archivo desde móvil/PC en LAN.

Lifecycle (single-shot): receive_payload() levanta el servidor, espera a que
llegue UN payload (o timeout), cierra. Devuelve dict {kind, ...} o None si
timeout/cancelado.

Tipos de payload:
- {'kind': 'text', 'text': '...'}     : texto plano, clipboard interno.
- {'kind': 'magnet', 'uri': '...'}    : magnet URI, Elementum (gestionado
                                         por service.py via cola).
- {'kind': 'upload', 'entry': {...}}  : archivo subido al perfil, dialog
                                         post-transfer (service.py via cola).

Backward compat: received_text y text_event se mantienen (los usan
ui_dialog y tests existentes). received_payload es la nueva fuente de verdad.
"""
import json
import os
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import xbmc
import xbmcaddon
import xbmcgui

import ui_dialog
from lib.ui_select import info


_PORT_DEFAULT = 8090
_PORT_RANGE = 10
_TIMEOUT_SECONDS_DEFAULT = 300
_TIMEOUT_MIN, _TIMEOUT_MAX = 30, 1800
_MAX_BODY_BYTES = 100_000
_LOG_PREFIX = '[loiolink.server]'


class _LimitedReader:
    """Limita lecturas de rfile a exactamente limit bytes.

    El rfile del HTTP handler es un socket sin EOF implícito: leer más allá
    del body bloquearía esperando el siguiente request. Esta clase devuelve
    b'' en cuanto se agotan los bytes declarados en Content-Length, señalando
    EOF al parser multipart sin bloquear.
    """
    def __init__(self, rfile, limit):
        self._rfile = rfile
        self._remaining = limit

    def read(self, n=-1):
        if self._remaining <= 0:
            return b''
        if n < 0 or n > self._remaining:
            n = self._remaining
        data = self._rfile.read(n)
        self._remaining -= len(data)
        return data


def _get_timeout_seconds():
    try:
        val = xbmcaddon.Addon().getSetting('server_timeout_seconds')
        if val:
            secs = int(val)
            if _TIMEOUT_MIN <= secs <= _TIMEOUT_MAX:
                return secs
    except (ValueError, RuntimeError):
        pass
    return _TIMEOUT_SECONDS_DEFAULT


def _get_upload_max_bytes():
    try:
        val = xbmcaddon.Addon().getSetting('transfer_max_size_gb')
        return int(float(val) * 1024 * 1024 * 1024) if val else 2 * 1024**3
    except (ValueError, RuntimeError):
        return 2 * 1024**3


_HTML_FORM = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>loiolink</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2358a6ff'><path fill-rule='evenodd' d='M12 1a11 11 0 0 1 0 22A11 11 0 0 1 12 1zM12 7a5 5 0 0 1 0 10A5 5 0 0 1 12 7zM12 2L14.5 7H9.5zM12 22L9.5 17H14.5zM2 12L7 9.5V14.5zM22 12L17 14.5V9.5zM12 8.5a3.5 3.5 0 0 1 0 7A3.5 3.5 0 0 1 12 8.5z'/></svg>">
<style>
:root{
  --bg:#0d1117; --fg:#c9d1d9; --muted:#8b949e;
  --accent:#58a6ff; --success:#238636; --success-hover:#2ea043;
  --success-active:#1f6f2e; --disabled:#30363d;
  --card-bg:#161b22; --card-bd:#30363d;
  --input-bg:#0d1117; --ok:#3fb950; --err:#f85149;
}
@media (prefers-color-scheme: light){
  :root{
    --bg:#f6f8fa; --fg:#1f2328; --muted:#6e7781;
    --accent:#0969da; --success:#1f883d; --success-hover:#1a7f37;
    --success-active:#127031; --disabled:#d0d7de;
    --card-bg:#ffffff; --card-bd:#d1d9e0;
    --input-bg:#ffffff; --ok:#1a7f37; --err:#cf222e;
  }
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
     background:var(--bg);color:var(--fg);
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px}
.card{background:var(--card-bg);border:1px solid var(--card-bd);border-radius:12px;
      padding:28px 24px;max-width:520px;width:100%;
      box-shadow:0 8px 32px rgba(0,0,0,.15)}
h1{color:var(--accent);font-size:1.4em;margin:0 0 6px 0;text-align:center;font-weight:600}
.sub{color:var(--muted);font-size:.85em;text-align:center;margin-bottom:18px}
textarea{width:100%;min-height:110px;background:var(--input-bg);color:var(--fg);
         border:1px solid var(--card-bd);border-radius:8px;padding:12px;
         font:inherit;font-size:.95em;resize:vertical;box-sizing:border-box}
textarea:focus{outline:0;border-color:var(--accent)}
button{width:100%;margin-top:14px;padding:14px;background:var(--success);color:#fff;
       border:0;border-radius:8px;font-size:1em;font-weight:600;cursor:pointer}
button:hover{background:var(--success-hover)}
button:active{background:var(--success-active)}
button:disabled{background:var(--disabled);cursor:not-allowed}
button.stop{background:transparent;color:var(--muted);border:1px solid var(--card-bd);
            margin-top:32px;font-size:.88em;font-weight:500;
            display:flex;align-items:center;justify-content:center;gap:8px;
            transition:background .15s,border-color .15s,color .15s}
button.stop:hover{background:rgba(248,81,73,.08);color:var(--err);border-color:rgba(248,81,73,.4)}
button.stop:active{filter:brightness(.85)}
button.stop:disabled{opacity:.4;cursor:not-allowed;background:transparent;
                     color:var(--muted);border-color:var(--card-bd)}
.status{text-align:center;color:var(--muted);font-size:.85em;margin-top:14px;min-height:1.4em}
.status.ok{color:var(--ok)}
.status.err{color:var(--err)}
.upbar{display:none;height:6px;background:var(--card-bd);border-radius:3px;margin-top:10px;overflow:hidden}
.upbar.show{display:block}
.upbar div{height:100%;background:var(--accent);width:0%;transition:width .1s}
.drop-zone{display:flex;flex-direction:column;align-items:center;gap:4px;
           border:2px dashed var(--card-bd);border-radius:8px;
           padding:22px 16px 18px;margin-top:8px;
           transition:border-color .15s,background .15s;cursor:pointer;text-align:center}
.drop-zone input[type=file]{display:none}
.drop-zone:hover,.drop-zone.over{border-color:var(--accent)}
.drop-zone.over{background:rgba(88,166,255,.07)}
.drop-icon{width:30px;height:30px;stroke:var(--muted);fill:none;stroke-width:1.5;
           stroke-linecap:round;stroke-linejoin:round;margin-bottom:2px;transition:stroke .15s}
.drop-zone:hover .drop-icon,.drop-zone.over .drop-icon{stroke:var(--accent)}
.drop-main{font-size:.88em;font-weight:600;color:var(--fg);pointer-events:none;user-select:none}
.drop-hint{font-size:.78em;color:var(--muted);pointer-events:none;user-select:none}
.drop-btn{display:inline-block;margin-top:8px;padding:4px 14px;border-radius:6px;
          background:var(--card-bd);color:var(--fg);font-size:.82em;font-weight:500;
          border:1px solid var(--card-bd);transition:background .12s,border-color .12s;
          pointer-events:none;user-select:none}
.drop-zone:hover .drop-btn,.drop-zone.over .drop-btn{border-color:var(--accent)}
.drop-filename{font-size:.8em;color:var(--accent);max-width:90%;white-space:nowrap;
               overflow:hidden;text-overflow:ellipsis;pointer-events:none;user-select:none;
               display:none}
.drop-filename.has-file{display:block}
</style>
</head>
<body>
<div class="card">
  <h1>loiolink</h1>
  <p class="sub">Envía texto al portapapeles, o directo al teclado de Kodi si lo tienes abierto</p>

  <textarea id="t" placeholder="Texto, URL, magnet:?..."></textarea>
  <button id="b" onclick="sendText()">Enviar texto</button>

  <hr style="border:0;border-top:1px solid var(--card-bd);margin:18px 0">
  <p class="sub">O sube un archivo</p>
  <label class="drop-zone" id="drop-zone">
    <input type="file" id="upfile" accept=".torrent,video/*,audio/*" onchange="uploadFile()">
    <svg class="drop-icon" viewBox="0 0 24 24" aria-hidden="true">
      <polyline points="16 16 12 12 8 16"/>
      <line x1="12" y1="12" x2="12" y2="21"/>
      <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
    </svg>
    <span class="drop-main">Arrastra un archivo aquí</span>
    <span class="drop-hint">o haz clic para seleccionar</span>
    <span class="drop-btn">Seleccionar archivo</span>
    <span class="drop-filename" id="drop-filename"></span>
  </label>
  <div class="upbar" id="upbar"><div></div></div>

  <button class="stop" id="stop-btn" onclick="stopServer()">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round"
         style="width:15px;height:15px;flex-shrink:0">
      <path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>
    </svg>
    Apagar servidor de recepción
  </button>

  <div class="status" id="s"></div>
</div>
<script>
const EPHEMERAL_MODE={{EPHEMERAL_MODE_JSON}};
const s=document.getElementById('s');
function setStatus(msg,cls){s.textContent=msg; s.className='status'+(cls?' '+cls:'');}
function setStatusHTML(html,cls){s.innerHTML=html; s.className='status'+(cls?' '+cls:'');}

async function sendText(){
  const ta=document.getElementById('t');
  const btn=document.getElementById('b');
  const text=ta.value.trim();
  if(!text){setStatus('El texto esta vacio','err'); return;}
  btn.disabled=true; setStatus('Enviando...');
  try{
    const r=await fetch('/text',{method:'POST',headers:{'Content-Type':'application/json'},
                                 body:JSON.stringify({text:text})});
    if(r.ok){
      const d=await r.json();
      const m={text:'Texto enviado',magnet:'Magnet enviado, abriendo en Kodi...'}[d.kind]||'Enviado';
      setStatus(m,'ok'); ta.value='';
    } else setStatus('Error '+r.status,'err');
  }catch(e){setStatusHTML('No se pudo enviar el texto.<br><small style="opacity:.8">Causas habituales: el servidor no está activo en Kodi &middot; usas una VPN (bloquea el tráfico de red local) &middot; el móvil y Kodi están en redes WiFi distintas &middot; un firewall bloquea el puerto &middot; Kodi se cerró mientras esperaba.</small>','err');}
  finally{btn.disabled=false;}
}

document.getElementById('t').addEventListener('keydown',function(e){
  if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){sendText();}
});

function uploadFile(){
  const f=document.getElementById('upfile').files[0];
  if(f) _doUpload(f);
}

function _doUpload(f){
  const fn=document.getElementById('drop-filename');
  if(fn){fn.textContent=f.name; fn.classList.add('has-file');}
  const bar=document.getElementById('upbar');
  const inner=bar.firstElementChild;
  bar.classList.add('show'); inner.style.width='0%';
  setStatus('Subiendo '+f.name+'...');
  const xhr=new XMLHttpRequest();
  xhr.open('POST','/upload',true);
  xhr.upload.onprogress=function(e){
    if(e.lengthComputable){inner.style.width=Math.round(e.loaded*100/e.total)+'%';}
  };
  xhr.onload=function(){
    bar.classList.remove('show');
    if(xhr.status>=200&&xhr.status<300){
      let data={};
      try{data=JSON.parse(xhr.responseText);}catch(e){}
      let msg='Archivo enviado'+(data.truncated?' (truncado)':'');
      if(data.file_kind==='video'||data.file_kind==='audio')
        msg+='. Cierra el QR en Kodi para reproducir';
      setStatus(msg,'ok');
    } else setStatus('Error '+xhr.status,'err');
    document.getElementById('upfile').value='';
    if(fn){fn.textContent=''; fn.classList.remove('has-file');}
  };
  xhr.onerror=function(){bar.classList.remove('show'); setStatusHTML('No se pudo subir el archivo.<br><small style="opacity:.8">Causas habituales: el servidor no está activo en Kodi &middot; usas una VPN (bloquea el tráfico de red local) &middot; el dispositivo y Kodi están en redes WiFi distintas &middot; un firewall bloquea el puerto &middot; Kodi se cerró mientras esperaba.</small>','err');};
  const fd=new FormData(); fd.append('file',f);
  xhr.send(fd);
}

async function stopServer(){
  const btn=document.getElementById('stop-btn');
  if(EPHEMERAL_MODE){
    setStatus('Cierra el dialogo "Recibir texto" en Kodi para apagar el servidor','err');
    return;
  }
  btn.disabled=true;
  setStatus('Apagando servidor...');
  try{
    await fetch('/stop',{method:'POST'});
    setStatus('Servidor apagado. Esta pagina ya no responde.','ok');
  }catch(e){
    setStatus('Error al apagar','err');
    btn.disabled=false;
  }
}

(function(){
  const dz=document.getElementById('drop-zone');
  if(!dz) return;
  const hasFiles=e=>e.dataTransfer&&e.dataTransfer.types&&
                    Array.from(e.dataTransfer.types).includes('Files');
  let n=0;
  ['dragover','drop'].forEach(ev=>window.addEventListener(ev,e=>{
    if(e.target.closest&&e.target.closest('#drop-zone')) return;
    if(hasFiles(e)) e.preventDefault();
  }));
  dz.addEventListener('dragenter',e=>{
    if(!hasFiles(e)) return;
    e.preventDefault(); if(++n===1) dz.classList.add('over');
  });
  dz.addEventListener('dragleave',e=>{
    e.preventDefault(); if(--n<=0){n=0; dz.classList.remove('over');}
  });
  dz.addEventListener('dragover',e=>{if(hasFiles(e)) e.preventDefault();});
  dz.addEventListener('drop',e=>{
    e.preventDefault(); n=0; dz.classList.remove('over');
    const files=e.dataTransfer.files;
    if(!files||!files.length) return;
    _doUpload(files[0]);
  });
})();
</script>
</body>
</html>"""


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{_LOG_PREFIX} {msg}', level)


def _is_magnet(text):
    return isinstance(text, str) and text.strip().lower().startswith('magnet:?')


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address):
        # Compat: tests y ui_dialog usan received_text/text_event.
        self.received_text = None
        self.text_event = threading.Event()
        # Nueva fuente de verdad: dict con 'kind' + datos.
        self.received_payload = None
        # First-write-wins: el check `text_event.is_set()` + procesamiento
        # + `text_event.set()` no es atómico: 5 POSTs concurrentes pueden
        # pasar el check antes de que ninguno haya seteado el event,
        # quedando 2-3 ganadores en lugar de uno. Usar un claim bajo lock
        # garantiza exclusión incluso durante el procesamiento (el
        # text_event sigue siendo la señal externa al modal, no la
        # exclusión interna).
        self._claim_lock = threading.Lock()
        self._payload_claimed = False
        super().__init__(address, _Handler)


class _Handler(BaseHTTPRequestHandler):
    # Corta threads zombi si un cliente abre la conexión y se queda mudo
    # (red mala, reset desordenado). 5 min es generoso para uploads grandes
    # en LAN; uno legítimo siempre envía algún byte dentro de ese margen.
    timeout = 300

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body=b'', content_type='text/plain; charset=utf-8'):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if body:
            self.wfile.write(body)

    def _send_json(self, code, obj):
        self._send(code, json.dumps(obj).encode('utf-8'), 'application/json')

    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path in ('/', ''):
            # En efímero el server lo gestiona receive_text.py (modal QR), no
            # el service loop; user_stopped no tiene efecto. El JS detecta el
            # modo y, en efímero, redirige al usuario a cerrar el modal en Kodi
            # en vez de hacer un POST /stop inútil.
            ephemeral = True
            try:
                ephemeral = xbmcaddon.Addon().getSettingBool('server_ephemeral_mode')
            except RuntimeError:
                pass
            body = _HTML_FORM.replace(
                '{{EPHEMERAL_MODE_JSON}}', 'true' if ephemeral else 'false',
            ).encode('utf-8')
            self._send(200, body, 'text/html; charset=utf-8')
        else:
            self._send(404, b'not found')

    def do_POST(self):
        path = self.path.split('?', 1)[0].rstrip('/')
        if path == '/text':
            self._handle_text()
        elif path == '/upload':
            self._handle_upload()
        elif path == '/stop':
            self._handle_stop()
        else:
            # Antes de responder 404 hay que DRENAR el body del cliente.
            # Si cerramos el socket cuando el cliente aún está enviando,
            # Windows lanza RST → cliente recibe ConnectionAbortedError
            # en vez del 404 esperado. Drenar es barato (max _MAX_BODY_BYTES,
            # mismo límite que /text).
            self._drain_request_body()
            _log(f'POST 404 path={self.path[:80]}', xbmc.LOGDEBUG)
            self._send(404, b'not found')

    def _handle_stop(self):
        xbmcgui.Window(10000).setProperty('loiolink.text.user_stopped', '1')
        self._send(200, b'ok')

    def _drain_request_body(self):
        """Lee y descarta el body del request actual hasta Content-Length.

        Necesario en paths de error temprano (404, validación fallida) para
        evitar que el cierre del socket compita con el envío del cliente.
        Solo aplica cuando el body es pequeño y conocido."""
        try:
            length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            return
        if length <= 0 or length > _MAX_BODY_BYTES:
            return
        try:
            self.rfile.read(length)
        except (OSError, ValueError):
            pass

    def _handle_text(self):
        # rfile.read(length) no procesa chunks: rechazamos chunked para que
        # un cliente no pueda saltarse el límite de _MAX_BODY_BYTES.
        te = (self.headers.get('Transfer-Encoding') or '').lower().strip()
        if te and te != 'identity':
            self._send(400, b'transfer-encoding not supported')
            return

        try:
            length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            self._send(400, b'bad length')
            return

        if length <= 0 or length > _MAX_BODY_BYTES:
            self._send(400, b'bad length')
            return

        try:
            body = self.rfile.read(length)
            data = json.loads(body.decode('utf-8'))
            text = (data.get('text') or '').strip()
        except (ValueError, UnicodeDecodeError) as e:
            _log(f'POST /text 400 bad payload: {e}', xbmc.LOGWARNING)
            self._send(400, b'bad payload')
            return

        if not text:
            self._send(400, b'empty')
            return

        # Single-shot: solo el primer envío gana. Claim atómico bajo lock;
        # sin esto, 5 POSTs concurrentes pueden pasar el check antes de
        # que ninguno haya seteado text_event, dando 2-3 ganadores.
        with self.server._claim_lock:
            if (self.server._payload_claimed
                    or self.server.text_event.is_set()):
                _claimed = False
            else:
                self.server._payload_claimed = True
                _claimed = True
        if not _claimed:
            self._send(409, b'already received')
            return

        # Responder al cliente ANTES de set() del event: set() despierta al
        # modal, que dispara server.shutdown() y puede cortar el envío de la
        # respuesta si el handler corre en thread daemon (causaba que la web
        # del móvil viera el upload colgado en "Subiendo..." indefinidamente).
        if _is_magnet(text):
            # NO se guarda en received_text (no es texto-para-pegar).
            # Se encola para que el service muestre el dialog de Elementum.
            from lib.transfers import history
            history.queue_event({'kind': 'magnet_received', 'uri': text})
            self.server.received_payload = {'kind': 'magnet', 'uri': text}
            _log(f'magnet recibido (len={len(text)})')
            self._send_json(200, {'ok': True, 'kind': 'magnet'})
            self.server.text_event.set()
            return

        # Texto normal: flujo clásico.
        self.server.received_text = text
        self.server.received_payload = {'kind': 'text', 'text': text}
        _log(f'texto recibido (len={len(text)})')
        self._send_json(200, {'ok': True, 'kind': 'text'})
        self.server.text_event.set()

    def _handle_upload(self):
        # Claim atómico (mismo patrón que _handle_text): el check-y-set
        # del text_event NO era atómico, dos uploads concurrentes podían
        # pasar ambos. Reservar el slot bajo lock; los demás reciben 409.
        # Si cualquier validación o lectura posterior falla, LIBERAMOS el
        # claim para que un siguiente upload válido pueda probar.
        with self.server._claim_lock:
            if (self.server._payload_claimed
                    or self.server.text_event.is_set()):
                _claimed = False
            else:
                self.server._payload_claimed = True
                _claimed = True
        if not _claimed:
            self._send(409, b'already received')
            return

        def _release_claim():
            with self.server._claim_lock:
                self.server._payload_claimed = False

        # Chunked transfer encoding: el HTTP server de Python no decodifica
        # chunks, así que rfile devolvería bytes crudos con prefijos de
        # tamaño. Misma razón que en _handle_text.
        te = (self.headers.get('Transfer-Encoding') or '').lower().strip()
        if te and te != 'identity':
            _release_claim()
            self._send(400, b'transfer-encoding not supported')
            return

        ctype = self.headers.get('Content-Type', '')
        if 'multipart/form-data' not in ctype.lower():
            _release_claim()
            self._send(400, b'expected multipart/form-data')
            return

        try:
            body_length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            body_length = 0
        if body_length <= 0:
            _release_claim()
            self._send(400, b'missing content-length')
            return

        from lib.transfers import classifier, history, multipart_stream, storage
        try:
            dest_dir = storage.get_dest_dir()
        except storage.StorageError as e:
            _log(f'POST /upload 507: {e}', xbmc.LOGWARNING)
            _release_claim()
            self._send(507, b'destino no disponible')
            return

        # El rfile del HTTP handler es un socket sin EOF implícito: leer más
        # allá del body bloquearía esperando el siguiente request. Limitamos
        # las lecturas a Content-Length para que el parser multipart vea EOF
        # en cuanto agota el body del request actual.
        limited = _LimitedReader(self.rfile, body_length)

        try:
            filepath, name, size, truncated = (
                multipart_stream.stream_multipart_to_disk(
                    limited, ctype, dest_dir, _get_upload_max_bytes(),
                )
            )
        except (ValueError, OSError) as e:
            _log(f'POST /upload 400: {e}', xbmc.LOGWARNING)
            _release_claim()
            self._send(400, b'upload failed')
            return

        # Cualquier fallo a partir de aquí deja el archivo en disco sin
        # historial: hay que limpiarlo para no acumular huérfanos y para
        # mantener "todo o nada" desde la perspectiva del usuario.
        try:
            kind, addon_id = classifier.classify(filepath)
            entry = history.add(
                filepath, name, size, kind, addon_id=addon_id,
                truncated=truncated, source='upload',
            )
            history.queue_event({
                'kind': 'post_transfer',
                'entry': entry,
                'confirm_upload': True,
                'sender_ip': self.client_address[0],
            })
        except OSError as e:
            _log(f'POST /upload 500 post-stream: {e}', xbmc.LOGWARNING)
            try:
                os.remove(filepath)
            except OSError:
                pass
            _release_claim()
            self._send(500, b'internal error')
            return

        self.server.received_payload = {'kind': 'upload', 'entry': entry}
        _log(f'archivo recibido: {name} ({size}b, kind={kind})')
        self._send_json(200, {'ok': True, 'kind': 'upload', 'name': name, 'truncated': truncated, 'file_kind': kind})
        self.server.text_event.set()


def _get_port_start():
    try:
        val = xbmcaddon.Addon().getSetting('server_port')
        if val:
            p = int(val)
            if 1024 <= p <= 65535:
                return p
    except (ValueError, RuntimeError):
        pass
    return _PORT_DEFAULT


def _try_start(ssl_context=None):
    """Bindea el primer puerto libre del rango. Devuelve (server, port) o (None, 0).

    Si ssl_context se pasa, envuelve el socket con TLS tras el bind.
    """
    start = _get_port_start()
    for port in range(start, start + _PORT_RANGE + 1):
        try:
            srv = _Server(('', port))
        except OSError:
            continue
        if ssl_context is not None:
            srv.socket = ssl_context.wrap_socket(srv.socket, server_side=True)
        return srv, port
    return None, 0


def _get_local_ip():
    """Detecta IP LAN. Prefiere xbmc.getIPAddress(); fallback con UDP socket trick."""
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != '127.0.0.1' and not ip.startswith('0.'):
            return ip
    except RuntimeError as e:
        _log(f'getIPAddress error: {e}', xbmc.LOGDEBUG)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            if ip and ip != '127.0.0.1':
                return ip
        finally:
            s.close()
    except OSError as e:
        _log(f'UDP socket error: {e}', xbmc.LOGDEBUG)
    return None


def _start_server_with_qr():
    """Setup común para receive_payload y serve_with_callback.

    Devuelve (server, addr, http_thread) o (None, None, None) si falló.
    Helpers de cleanup quedan a cargo del caller.
    """
    ip = _get_local_ip()
    if not ip:
        info(
            'No se pudo detectar la IP local.\n\n'
            'Asegurate de estar conectado a WiFi o Ethernet.',
            title='loiolink',
        )
        return None, None, None

    from lib.remote import tls
    ssl_context = None
    if tls.is_https_enabled():
        cert, key = tls.get_or_generate_cert(ip)
        if cert and key:
            ssl_context = tls.build_ssl_context(cert, key)
        if ssl_context is None:
            _log('HTTPS pedido pero no disponible; fallback a HTTP', xbmc.LOGWARNING)

    server, port = _try_start(ssl_context=ssl_context)
    if not server:
        port_start = _get_port_start()
        info(
            'No se pudo iniciar el servidor.\n\n'
            f'Los puertos {port_start}-{port_start + _PORT_RANGE} estan ocupados.',
            title='loiolink',
        )
        return None, None, None

    proto = 'https' if ssl_context is not None else 'http'
    addr = f'{proto}://{ip}:{port}'
    _log(f'servidor iniciado en {addr}')

    http_thread = threading.Thread(
        target=server.serve_forever, daemon=True, name='loiolink-http'
    )
    http_thread.start()
    return server, addr, http_thread


def _stop_server(server, http_thread):
    try:
        server.shutdown()
        server.server_close()
    except OSError as e:
        _log(f'error en shutdown: {e}', xbmc.LOGDEBUG)
    http_thread.join(timeout=3)
    _log('servidor cerrado')


def start_background(on_payload):
    """Start text server without UI for persistent (non-ephemeral) mode.

    Returns (server, port, http_thread) or (None, 0, None) on failure.
    Spawns a daemon watcher thread that resets server state and calls
    on_payload for each received payload. Caller owns the returned objects
    and must call stop_background() to tear them down.
    """
    ip = _get_local_ip()
    if not ip:
        _log('sin IP local; servidor persistente no arranca', xbmc.LOGWARNING)
        return None, 0, None

    from lib.remote import tls
    ssl_context = None
    if tls.is_https_enabled():
        cert, key = tls.get_or_generate_cert(ip)
        if cert and key:
            ssl_context = tls.build_ssl_context(cert, key)

    srv, port = _try_start(ssl_context=ssl_context)
    if not srv:
        port_start = _get_port_start()
        _log(
            f'sin puerto libre para servidor persistente '
            f'({port_start}-{port_start + _PORT_RANGE})',
            xbmc.LOGWARNING,
        )
        return None, 0, None

    # stop_event señaliza al watcher que termine. Sin esto, tras shutdown
    # del HTTP server, el watcher seguiría llamando text_event.wait(1.0)
    # eternamente (text_event es un threading.Event vivo aunque el server
    # esté cerrado), acumulando un thread zombi por cada toggle persistente.
    stop_event = threading.Event()
    srv._watcher_stop = stop_event

    http_thread = threading.Thread(
        target=srv.serve_forever, daemon=True, name='loiolink-text-bg',
    )
    http_thread.start()

    def _watcher():
        monitor = xbmc.Monitor()
        while not stop_event.is_set() and not monitor.abortRequested():
            if srv.text_event.wait(timeout=1.0):
                if stop_event.is_set():
                    return
                payload = srv.received_payload
                srv.received_payload = None
                srv.received_text = None
                srv.text_event.clear()
                with srv._claim_lock:
                    srv._payload_claimed = False
                try:
                    if payload is not None:
                        on_payload(payload)
                except Exception as e:
                    _log(f'on_payload error en watcher: {e}', xbmc.LOGWARNING)

    threading.Thread(
        target=_watcher, daemon=True, name='loiolink-text-watcher',
    ).start()

    proto = 'https' if ssl_context is not None else 'http'
    # Exponemos el scheme real bindeado para que el caller no tenga que volver
    # a consultar tls.is_https_enabled() (que podría haber cambiado entre el
    # arranque y el momento de leerlo, dando URLs con scheme incorrecto).
    srv._scheme = proto
    _log(f'servidor de texto persistente {proto} en puerto {port}')
    return srv, port, http_thread


def stop_background(server, http_thread):
    """Stop a server started with start_background."""
    if server is not None:
        # Señalamos al watcher antes de tirar el server. El watcher saldrá
        # en <= 1s (su próximo tick de text_event.wait).
        stop_event = getattr(server, '_watcher_stop', None)
        if stop_event is not None:
            stop_event.set()
    _stop_server(server, http_thread)


def receive_payload():
    """Levanta servidor + modal QR single-shot. Devuelve dict {kind, ...} o None.

    Modo single-shot con timeout: usado por la API externa (lib/remote/api.py).
    El modal del menú interactivo "Recibir texto" usa serve_with_callback en su lugar.

    None si: no se pudo iniciar (sin IP, sin puerto), timeout, o usuario canceló.
    """
    server, addr, http_thread = _start_server_with_qr()
    if not server:
        return None
    try:
        _, timed_out = ui_dialog.run_qr_modal(
            server, addr, timeout_seconds=_get_timeout_seconds(),
        )
    finally:
        _stop_server(server, http_thread)

    if timed_out:
        from lib import accessibility
        accessibility.notify('Tiempo agotado', xbmcgui.NOTIFICATION_WARNING, 2000)
        return None

    return server.received_payload


def serve_with_callback(on_payload):
    """Levanta servidor + modal QR multi-shot, sin timeout.

    `on_payload(dict)` se invoca por cada payload recibido. El modal sigue
    abierto hasta que el usuario lo cierre con Back/Esc o Kodi se cierre.
    Usado por el menú "Recibir texto".
    """
    server, addr, http_thread = _start_server_with_qr()
    if not server:
        return
    try:
        ui_dialog.run_qr_modal(server, addr, on_payload=on_payload)
    finally:
        _stop_server(server, http_thread)


def receive_text():
    """Compat: devuelve solo el texto recibido (o None) si era kind='text'.

    Otros kinds (magnet, upload) se gestionan por el service via cola y
    aquí devolvemos None para que el caller no haga nada extra.
    """
    payload = receive_payload()
    if payload and payload.get('kind') == 'text':
        return payload['text']
    return None
