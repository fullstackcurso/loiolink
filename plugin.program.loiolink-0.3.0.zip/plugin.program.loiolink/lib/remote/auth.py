"""Autenticación del server permanente. Modelo de sesiones por dispositivo.

Sin esto, cualquier dispositivo en la LAN puede borrar archivos del disco
vía POST /history/delete con remove_file=True. La LAN no es un trust
boundary en redes domésticas con dispositivos IoT comprometidos o invitados.

Diseño:
- Cada navegador pareado tiene una SESIÓN con su propio token (no un único
  token global). Modelo + storage en `lib.remote.sessions`.
- El QR del modal de "Control remoto" incluye `?t=<token>` de una sesión
  ad-hoc creada al abrir el modal. Al primer acceso del móvil, el server
  lee el query y setea cookie persistente con ese token.
- Comparación con hmac.compare_digest para evitar timing attacks.
- Fuentes del token (prioridad): query ?t=, cookie loiolink_token,
  header X-Loio-Token.
- Endpoints READ-ONLY (/version, /health) sin auth: diagnóstico mínimo.
  `/remote/status` SÍ requiere auth desde que añadió file/playlistid/streams
  al payload (info que no debería filtrarse a vecinos de LAN).
- Cada request autenticada actualiza last_seen_at/ip de su sesión.

Bypass para tests: env var LOIOLINK_AUTH_DISABLE=1.
"""
import os

from lib.remote import sessions


SETTING_TOKEN = 'remote_auth_token'   # legacy, solo para migración
COOKIE_NAME = 'loiolink_token'
HEADER_NAME = 'X-Loio-Token'
QUERY_PARAM = 't'

# Endpoints accesibles sin token. `/health` y `/version` son diagnóstico
# (info no sensible). `/remote/status` estuvo aquí pero se sacó al añadirle
# campos sensibles (playlistid, file paths, audiostreams) que no deberían
# filtrarse a otros dispositivos de la LAN.
#
# `/manifest.json` y `/sw.js` van aquí porque la instalación PWA falla si
# requieren auth: los navegadores piden el manifest ANTES de tener cookie
# (sin credenciales en el fetch inicial). El manifest es metadata pública
# del addon (nombre, colores, iconos). El service worker es JS sandbox que
# el browser ejecuta en su propio contexto; cuando intenta llamar a
# /api/* o /remote/* sin estar pareado, recibe 401 normal y los datos
# del usuario siguen detrás del muro de auth.
_READ_ONLY_PATHS = frozenset({'/health', '/version', '/manifest.json', '/sw.js'})


def is_read_only_path(path):
    return path in _READ_ONLY_PATHS


def _extract_token_from_request(handler):
    """Busca el token en query > cookie > header. Devuelve string o ''."""
    if '?' in handler.path:
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(handler.path).query)
        candidate = qs.get(QUERY_PARAM, [''])[0]
        if candidate:
            return candidate
    cookie_header = handler.headers.get('Cookie', '')
    for chunk in cookie_header.split(';'):
        chunk = chunk.strip()
        if chunk.startswith(COOKIE_NAME + '='):
            return chunk[len(COOKIE_NAME) + 1:]
    return (handler.headers.get(HEADER_NAME) or '').strip()


def _remote_ip(handler):
    try:
        return handler.client_address[0]
    except (AttributeError, IndexError):
        return ''


def _user_agent(handler):
    try:
        return (handler.headers.get('User-Agent') or '').strip()
    except AttributeError:
        return ''


def is_authorized(handler):
    """¿La petición lleva un token válido?

    Si lo es, actualiza last_seen_at/ip/ua de la sesión correspondiente.
    Si `LOIOLINK_AUTH_DISABLE=1` en env (uso de tests) → siempre True.
    """
    if os.environ.get('LOIOLINK_AUTH_DISABLE') == '1':
        return True
    received = _extract_token_from_request(handler)
    if not received:
        return False
    found = sessions.find_by_token(received)
    if not found:
        return False
    sessions.touch(received, ip=_remote_ip(handler), ua=_user_agent(handler))
    return True


def current_request_token(handler):
    """Token con el que se autenticó esta request (si lo está). Para
    endpoints que necesitan saber 'qué sesión soy yo'."""
    received = _extract_token_from_request(handler)
    if not received:
        return ''
    found = sessions.find_by_token(received)
    return received if found else ''


def is_request_https(handler):
    """¿La request entró por una conexión TLS? Para activar el flag Secure
    de la cookie cuando aplica."""
    # ThreadingHTTPServer guarda el socket en handler.request. Cuando hay
    # TLS, es un ssl.SSLSocket (tiene atributo _sslobj). Comprobamos con
    # isinstance via duck-type para evitar import de ssl si no hace falta.
    try:
        import ssl
        return isinstance(handler.request, ssl.SSLSocket)
    except (AttributeError, ImportError):
        return False


def first_seen_cookie_header(token, secure=False):
    """Cabecera Set-Cookie para persistir el token tras el primer ?t= o /pair.

    Cookie persistente (1 año), HttpOnly (mitiga XSS), SameSite=Lax (bloquea
    POST cross-site, permite navegación top-level; necesario para que
    window.location.href a /library/stream-page envíe la cookie).
    Flag Secure SOLO si la conexión es HTTPS (en HTTP plano un Secure haría
    al navegador descartar la cookie).
    """
    parts = [
        f'{COOKIE_NAME}={token}',
        'Path=/', 'Max-Age=31536000', 'HttpOnly', 'SameSite=Lax',
    ]
    if secure:
        parts.append('Secure')
    return '; '.join(parts)


def clear_cookie_header():
    """Cabecera Set-Cookie para borrar la cookie. Usado al revocar la
    propia sesión desde el panel."""
    return f'{COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax'
