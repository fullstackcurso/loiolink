"""Detección + inyección de texto en el teclado virtual de Kodi.

Promovido desde context.py para que el panel web (server_permanent),
"Recibir texto" (server efímero) y el menú contextual usen la misma lógica
anti-race en lugar de tres copias divergentes.

Patrón anti-race (origen: bug kodi/kodi#20297 en Android):
1. Detectar Window.IsActive(virtualkeyboard).
2. Esperar POST_KB_DETECT_DELAY_MS (250ms mínimo observado).
3. Esperar a que busydialog cierre (BUSY_WAIT_MAX_MS máx).
4. Revalidar que el teclado sigue abierto.
5. Input.SendText.

Mutex window-property serializa inyecciones paralelas (panel A + panel B +
menú contextual no pisan mutuamente).
"""
import time

import xbmc
import xbmcgui

from lib.remote.rpc import RPCError, call_or_raise as _rpc_strict

LOG_PREFIX = '[loiolink.keyboard_input]'

WAIT_INTERVAL_MS = 100
POST_KB_DETECT_DELAY_MS = 500
BUSY_WAIT_MAX_MS = 3000
MUTEX_PROP = 'loiolink.keyboard_input.busy'
MUTEX_STALE_SECONDS = 30


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{LOG_PREFIX} {msg}', level)


def is_keyboard_active():
    return bool(xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'))


def is_busy_dialog_active():
    return (
        xbmc.getCondVisibility('Window.IsActive(busydialog)')
        or xbmc.getCondVisibility('Window.IsActive(busydialognocancel)')
    )


def keyboard_heading():
    """Heading del diálogo. Estuary expone el label en control 311.
    Skins distintos devuelven cadena vacía y el caller pinta fallback."""
    try:
        return (xbmc.getInfoLabel('Control.GetLabel(311)') or '').strip()
    except Exception as e:
        xbmc.log(f'[loiolink] keyboard_heading: {e}', xbmc.LOGDEBUG)
        return ''


def wait_for_busy_clear(monitor=None, max_ms=BUSY_WAIT_MAX_MS):
    """Espera hasta que busydialog desaparezca o se alcance el timeout.

    `monitor` permite abortar limpio si Kodi se está cerrando.
    """
    elapsed = 0
    while is_busy_dialog_active() and elapsed < max_ms:
        if monitor is not None and monitor.abortRequested():
            return False
        xbmc.sleep(100)
        elapsed += 100
    return not is_busy_dialog_active()


def _send_text_rpc(text, done):
    """Wrapper sobre Input.SendText. Propaga RPCError si Kodi rechaza."""
    _rpc_strict('Input.SendText', {'text': str(text), 'done': bool(done)})


def _mutex_acquire():
    """Reclama el mutex si está libre o stale (>MUTEX_STALE_SECONDS)."""
    win = xbmcgui.Window(10000)
    raw = win.getProperty(MUTEX_PROP) or ''
    if raw:
        try:
            held_at = int(raw)
        except (TypeError, ValueError):
            held_at = 0
        if time.time() - held_at < MUTEX_STALE_SECONDS:
            return False
        _log(f'mutex stale ({int(time.time() - held_at)}s), reclamando',
             xbmc.LOGWARNING)
    win.setProperty(MUTEX_PROP, str(int(time.time())))
    return True


def _mutex_release():
    xbmcgui.Window(10000).clearProperty(MUTEX_PROP)


def send_text(text, done=True, wait_appear_ms=0, preview_delay_ms=0,
              monitor=None, acquire_mutex=True):
    """Inyecta `text` en el teclado virtual con el patrón anti-race.

    Args:
        text: string a inyectar.
        done: True cierra el diálogo tras enviar; False lo deja abierto.
        wait_appear_ms: si >0, espera hasta este tiempo a que el teclado
            APAREZCA. Útil cuando el caller dispara una acción que sabe que
            abrirá un teclado (auto-inject desde "Recibir texto").
        preview_delay_ms: si >0 Y done=True, envía primero sin done para que
            el usuario vea el texto en el teclado, espera, y vuelve a enviar
            con done=True. Usado por context.py (menú contextual).
        monitor: opcional xbmc.Monitor() para abortar limpio en shutdown.
        acquire_mutex: si False, el caller YA ha adquirido el mutex y se
            encarga de liberarlo (caso context.main: el mutex protege también
            la fase de yesno/RunPlugin previa al thread).

    Returns:
        True si se inyectó, False si el teclado no apareció o falló timing.
    """
    _log(f'send_text entry: len={len(text)}, done={done}, '
         f'wait_appear_ms={wait_appear_ms}, preview_ms={preview_delay_ms}, '
         f'acquire_mutex={acquire_mutex}')

    if acquire_mutex and not _mutex_acquire():
        _log('mutex ocupado, abortando', xbmc.LOGWARNING)
        return False

    try:
        # 1) Esperar a que el teclado aparezca (opcional).
        t0 = time.time()
        elapsed = 0
        while not is_keyboard_active() and elapsed < wait_appear_ms:
            if monitor is not None and monitor.abortRequested():
                return False
            xbmc.sleep(WAIT_INTERVAL_MS)
            elapsed += WAIT_INTERVAL_MS

        if not is_keyboard_active():
            _log(f'teclado NO aparecio tras {int((time.time()-t0)*1000)}ms',
                 xbmc.LOGWARNING)
            return False

        wnd = xbmc.getInfoLabel('System.CurrentWindow')
        ctrl = xbmc.getInfoLabel('System.CurrentControl')
        _log(f'teclado detectado tras {int((time.time()-t0)*1000)}ms, '
             f'window={wnd!r}, control={ctrl!r}')

        # 2) Delay anti-race kodi/kodi#20297.
        xbmc.sleep(POST_KB_DETECT_DELAY_MS)

        # 3) Esperar a que busydialog cierre; caveat para Container.Update
        # de plugins de directorio (atresdaily, etc.): el busy se queda abierto
        # esperando que el plugin devuelva su listado, pero el plugin a su vez
        # espera que el usuario envíe el texto. Sin nuestro SendText, el busy
        # NO se cierra. Detectar y enviar igualmente.
        # kodi#20297 es sobre la ANIMACIÓN DE CIERRE del busy, no sobre busy
        # establemente abierto; este caveat es seguro.
        if not wait_for_busy_clear(monitor, max_ms=1000):
            if is_keyboard_active():
                _log('busy persiste pero kb sigue activo, '
                     'enviando texto igualmente (chicken-and-egg con plugin)',
                     xbmc.LOGWARNING)
            else:
                _log('busy dialog no cierra y kb tampoco activo',
                     xbmc.LOGWARNING)
                return False
        # 4) Revalidar: el teclado puede haberse cerrado durante la espera.
        if not is_keyboard_active():
            _log('teclado se cerró durante la espera', xbmc.LOGWARNING)
            return False

        # 5) Inyectar. Si preview_delay_ms > 0 y done=True, dos rondas.
        try:
            if done and preview_delay_ms > 0:
                _log('inyectando preview (done=False)')
                _send_text_rpc(text, False)
                if monitor is not None:
                    if monitor.waitForAbort(preview_delay_ms / 1000):
                        return True   # ya inyectado, abort es ok
                else:
                    xbmc.sleep(preview_delay_ms)
                if not wait_for_busy_clear(monitor):
                    return True   # primer SendText ya hizo efecto
                if not is_keyboard_active():
                    return True
                _log('inyectando commit (done=True)')
                _send_text_rpc(text, True)
            else:
                _log(f'inyectando una sola vez (done={done})')
                _send_text_rpc(text, done)
            _log('SendText completado OK')
            return True
        except RPCError as e:
            _log(f'SendText rpc error: {e}', xbmc.LOGWARNING)
            return False
    finally:
        if acquire_mutex:
            _mutex_release()


def cancel_keyboard():
    """Cierra el diálogo de teclado activo (equivalente a back/esc).

    El plugin que abrió el teclado recibe cancelled=True en su doModal.
    """
    try:
        _rpc_strict('Input.ExecuteAction', {'action': 'close'})
        return True
    except RPCError as e:
        _log(f'cancel error: {e}', xbmc.LOGWARNING)
        return False


def try_inject(text, wait_appear_ms=1500, done=True):
    """API conveniente para "intenta inyectar; si no hay teclado, devuelve False".

    NO toca el clipboard ni hace fallback; el caller decide qué hacer si
    devuelve False (típicamente: ya guardado en clipboard, no hacer nada
    más). Pensado para flujos donde la inyección es side-effect opcional.
    """
    return send_text(text, done=done, wait_appear_ms=wait_appear_ms)


def send_now(text, done=True):
    """Envía Input.SendText sin chequear si el teclado está activo.

    El caller (típicamente el endpoint /remote/keyboard-send) ya sabe que
    el teclado estaba abierto porque el watcher long-poll disparó el modal.
    Re-chequear aquí mete un race transitorio: entre la detección del
    watcher y el click del usuario pasan segundos, y un getCondVisibility
    en el medio puede flickear (popups, redibujo) y dar False aunque el
    teclado siga visible. Eso frustraba al usuario con 'el teclado se cerró'
    cuando NO se había cerrado.

    Mantiene el delay anti-race kodi/kodi#20297 y el mutex para no chocar
    con inyecciones desde el menú contextual o receive_text.

    Returns:
        True si Kodi aceptó el SendText, False si rechazó (RPC error) o
        si el mutex estaba ocupado.
    """
    if not _mutex_acquire():
        _log('send_now: mutex ocupado', xbmc.LOGWARNING)
        return False
    try:
        xbmc.sleep(POST_KB_DETECT_DELAY_MS)
        try:
            _send_text_rpc(text, done)
            return True
        except RPCError as e:
            _log(f'send_now: SendText rpc error: {e}', xbmc.LOGWARNING)
            return False
    finally:
        _mutex_release()
