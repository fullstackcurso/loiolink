"""API pública de loiolink para que otros addons reciban texto desde el móvil.

    # En su addon.xml:
    <requires>
        <import addon="plugin.program.loiolink" version="0.3.0"/>
    </requires>

    # En su código Python (sin tocar HTTP, HTML, threading ni puertos):
    import sys, xbmcaddon, os
    addon_path = xbmcaddon.Addon('plugin.program.loiolink').getAddonInfo('path')
    sys.path.insert(0, os.path.join(addon_path, 'lib'))
    from remote.api import receive_text
    text = receive_text(prompt='Buscar en mi addon')

Mantenemos la firma estable. Cualquier breaking change incrementa la versión
major del addon (semver) y se documenta en API.md (pendiente).
"""
import sys

import xbmcaddon


def _ensure_loiolink_path():
    """Añade lib/ de loiolink al sys.path si no está. Necesario cuando el
    addon consumidor importa esto desde fuera del propio loiolink."""
    try:
        addon = xbmcaddon.Addon('plugin.program.loiolink')
        path = addon.getAddonInfo('path')
    except RuntimeError:
        raise ImportError(
            'loiolink no está instalado o no está habilitado. '
            'Instala plugin.program.loiolink y vuelve a intentar.',
        )
    import os
    lib_path = os.path.join(path, 'lib')
    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)


def receive_text(prompt='Recibir texto desde el móvil'):
    """Levanta servidor + modal QR. Devuelve el texto recibido o None.

    Bloquea hasta que el usuario envíe texto, cancele o llegue al timeout.

    Retorna:
    - str: texto recibido (si el usuario envió texto plano).
    - None: timeout, cancelado, error, o el móvil envió otro tipo (magnet,
            upload; éstos se gestionan por separado en loiolink y no
            interesan al integrador que solo quiere texto).

    Nota: prompt es informativo (logging) por ahora. En versiones futuras
    podría customizar el modal QR con un título dinámico.
    """
    _ensure_loiolink_path()
    # Import diferido: server.py importa segno + qr_generator + ui_dialog,
    # módulos pesados que no queremos cargar hasta que receive_text se llame.
    import server
    from lib import log
    log.info(f'API.receive_text invocada: prompt={prompt!r}')
    return server.receive_text()


def start_remote():
    """Devuelve la URL del panel de control remoto si el service está
    activo. None si no.

    Pensado para que un addon consumidor pueda lanzar el QR del panel sin
    construir la URL a mano. La URL ya estará viva; el service la mantiene
    desde el arranque de Kodi.
    """
    _ensure_loiolink_path()
    import xbmcgui
    from lib.remote import server_permanent

    val = xbmcgui.Window(10000).getProperty('loiolink.remote.port')
    try:
        port = int(val) if val else None
    except (TypeError, ValueError):
        port = None
    if port is None:
        return None

    ip = server_permanent.get_local_ip()
    if not ip:
        return None
    from lib.remote import tls
    return f'{tls.scheme()}://{ip}:{port}'
