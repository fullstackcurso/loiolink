"""Helper para reproducir acestream:// vía Plexus o Horus."""
import json
import re
import urllib.parse

import xbmc
import xbmcaddon

PLEXUS_ID = 'program.plexus'
HORUS_ID = 'script.module.horus'

_RE = re.compile(r'^acestream://([a-fA-F0-9]{40})$', re.I)


def is_acestream(text):
    return isinstance(text, str) and bool(_RE.match(text.strip()))


def _content_id(url):
    m = _RE.match(url.strip())
    return m.group(1).lower() if m else None


def _has_addon(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


def play(url):
    """Reproduce acestream://ID. Devuelve 'plexus' o 'horus'.
    Lanza RuntimeError si no hay cliente instalado."""
    cid = _content_id(url)
    if not cid:
        raise ValueError(f'URL acestream no válida: {url!r}')

    clients = [
        (PLEXUS_ID, {'url': f'acestream://{cid}', 'mode': '1', 'name': 'Acestream'}),
        (HORUS_ID, {'action': 'play', 'id': cid}),
    ]
    for addon_id, params in clients:
        if _has_addon(addon_id):
            ace_url = f'plugin://{addon_id}/?' + urllib.parse.urlencode(params)
            # Player.Open JSON-RPC (no PlayMedia) para evitar kodi#14838.
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Player.Open',
                'params': {'item': {'file': ace_url}},
            }))
            return addon_id.split('.')[-1]  # 'plexus' o 'horus'

    raise RuntimeError('no_acestream_client')
