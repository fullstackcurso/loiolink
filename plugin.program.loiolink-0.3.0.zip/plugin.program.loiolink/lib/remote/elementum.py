"""Helper para invocar plugin.video.elementum (torrents/magnets).

Patrón verificado en plugin.video.espatv/url_player.py:821-834 (mi addon):
    elem_url = 'plugin://plugin.video.elementum/play?' + urlencode({'uri': value})
    xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))

Aquí usamos Player.Open JSON-RPC en lugar de PlayMedia para evitar el bug
de parsing de comas en builtins (kodi#14838). La URL plugin:// va como
string JSON, sin riesgo.
"""
import json
import urllib.parse

import xbmc
import xbmcaddon


ELEMENTUM_ID = 'plugin.video.elementum'


def is_installed():
    """¿Elementum está enabled? Usado por menu.py y post_transfer."""
    try:
        xbmcaddon.Addon(ELEMENTUM_ID)
        return True
    except RuntimeError:
        return False


def play(uri):
    """Reproduce un magnet URI o path a .torrent con Elementum."""
    elem_url = f'plugin://{ELEMENTUM_ID}/play?' + urllib.parse.urlencode(
        {'uri': uri},
    )
    req = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
        'params': {'item': {'file': elem_url}},
    }
    xbmc.executeJSONRPC(json.dumps(req))


def search(query):
    """Lanza búsqueda en Elementum (UI con resultados)."""
    elem_url = f'plugin://{ELEMENTUM_ID}/search?' + urllib.parse.urlencode(
        {'q': query},
    )
    xbmc.executebuiltin(f'RunPlugin("{elem_url}")')


def is_magnet(text):
    """¿Este string es un magnet URI?"""
    return isinstance(text, str) and text.strip().lower().startswith('magnet:?')
