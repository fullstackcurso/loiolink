"""Acción 'Importar texto del portapapeles del sistema'.

Lee el clipboard del SO. Cuatro caminos:
- acestream URI → reproducir vía Plexus o Horus.
- magnet URI → encolar evento magnet_received (el service abre Elementum
  o pide instalarlo).
- texto normal → vuelca al clipboard interno y notifica.
- vacío / Android sin JNI → notificación discreta.

Android: get_system_clipboard devuelve None (Kodi no expone ClipboardManager
sin JNI). La notificación lo indica al usuario.
"""
import clipboard
from lib import accessibility, log, os_clipboard
from lib.remote import acestream as ace
from lib.remote import elementum
from lib.transfers import history


def run():
    text = os_clipboard.get_system_clipboard()

    if not text or not text.strip():
        accessibility.notify('Portapapeles vacío o no soportado', ms=3000)
        return

    text = text.strip()

    if ace.is_acestream(text):
        try:
            ace.play(text)
            accessibility.notify('Acestream: lanzando...', ms=2500)
            log.info(f'paste_clipboard: acestream -> play ({len(text)} chars)')
        except RuntimeError:
            accessibility.notify('Acestream requiere Plexus o Horus', ms=4000)
            log.warning('paste_clipboard: acestream sin cliente (Plexus/Horus)')
        return

    # Magnet URI → derivar a Elementum (no tiene sentido meterlo en el
    # clipboard interno, no es texto para pegar en cuadros de búsqueda).
    if elementum.is_magnet(text):
        history.queue_event({'kind': 'magnet_received', 'uri': text})
        accessibility.notify('Magnet detectado, abriendo Elementum...', ms=2500)
        log.info(f'paste_clipboard: magnet -> service ({len(text)} chars)')
        return

    # Texto normal → clipboard interno (con sync al SO via clipboard.py).
    clipboard.set(text)
    preview = text[:50] + ('...' if len(text) > 50 else '')
    accessibility.notify(f'Copiado: {preview}', ms=3000)
    log.info(f'paste_clipboard: texto -> interno ({len(text)} chars)')
