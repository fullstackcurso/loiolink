"""Instala o abre un addon del ecosistema loioloio (FlowFav, LoioLog)."""
import xbmc
import xbmcgui

from lib import installer, log
from lib.ui_select import info


_META = {
    'plugin.program.flowfavmanager': (
        'Flow FavManager',
        'repository.flowfavmanager',
        'https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip',
        'https://loioloio.github.io/flowfav/',
        'Addons de programa',
    ),
    'plugin.program.loiolog': (
        'LoioLog',
        'repository.loiolog',
        'https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip',
        'https://loioloio.github.io/loiolog/',
        'Addons de programa',
    ),
}


def run(addon_id):
    if not addon_id or addon_id not in _META:
        log.warning(f'loioloio_install: addon_id desconocido: {addon_id!r}')
        return

    name, repo_id, repo_zip_url, source_url, addon_category = _META[addon_id]

    if installer.is_ready(addon_id):
        xbmc.executebuiltin(f'RunAddon({addon_id})')
        return

    # Si el addon está instalado pero deshabilitado, recuperarlo sin red.
    if installer.try_recover(addon_id):
        xbmcgui.Dialog().notification(
            'loioloio addons', f'{name} reactivado correctamente',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        xbmc.executebuiltin('Container.Refresh')
        return

    idx = xbmcgui.Dialog().select(
        name,
        ['Instalar automáticamente', 'Ver instrucciones manuales'],
    )
    if idx == -1:
        return
    if idx == 1:
        xbmcgui.Dialog().textviewer(
            f'Cómo instalar {name}',
            f'[B]Cómo instalar {name}[/B]\n\n'
            f'1. Ajustes → Sistema → Addons → activa Orígenes desconocidos\n\n'
            f'2. Ajustes → Explorador de archivos → Añadir fuente:\n'
            f'   {source_url}\n\n'
            f'3. Ajustes → Addons → Instalar desde un archivo zip → {name}\n'
            f'   → {repo_id}-x.x.x.zip\n\n'
            f'4. Instalar desde repositorio → {name} Repository\n'
            f'   → {addon_category} → {name}',
        )
        return

    dp = xbmcgui.DialogProgress()
    dp.create('loioloio addons', f'Descargando repositorio de {name}...')

    def download_cb(done, total):
        if dp.iscanceled():
            raise InterruptedError()
        if total:
            dp.update(int(done * 55 / total), f'{done // 1024} KB / {total // 1024} KB')
        else:
            dp.update(0, f'{done // 1024} KB')

    def repo_status(pct, msg):
        dp.update(55 + int(pct * 0.40), msg)

    try:
        ok = installer.download_and_install_repo(
            repo_zip_url, repo_id,
            progress_cb=download_cb,
            status_cb=repo_status,
        )
    except InterruptedError:
        return
    except installer.InstallError as e:
        log.error(f'InstallError instalando repo de {name}: {e}')
        info(f'Error de instalación: {e}', title='loioloio addons')
        return
    finally:
        dp.close()

    if not ok:
        info(
            f'El repositorio de {name} no se instaló.\n\n'
            'Verifica que "Orígenes desconocidos" está activo en '
            'Ajustes → Sistema → Addons.',
            title='loioloio addons',
        )
        return

    # El repo está listo. Cerramos el diálogo modal antes de InstallAddon
    # para evitar dos modales apilados que pierden foco en algunos skins.
    xbmcgui.Dialog().notification(
        'loioloio addons', f'Confirmando instalación de {name}...',
        xbmcgui.NOTIFICATION_INFO, 4000,
    )

    bg = xbmcgui.DialogProgressBG()
    bg.create('loioloio addons', f'Instalando {name}...')

    def addon_status(pct, msg):
        bg.update(pct, 'loioloio addons', msg)

    try:
        ok = installer.install_addon_from_repo(
            addon_id, repo_id=repo_id, status_cb=addon_status,
        )
    finally:
        bg.close()

    if ok:
        xbmcgui.Dialog().notification(
            'loioloio addons', f'{name} instalado correctamente',
            xbmcgui.NOTIFICATION_INFO, 4000,
        )
        xbmc.executebuiltin('Container.Refresh')
    else:
        info(
            f'No se pudo instalar {name} automáticamente.\n\n'
            'Pruébalo desde: Addons → Instalar desde repositorio.',
            title='loioloio addons',
        )
