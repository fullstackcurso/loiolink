"""Muestra la información de autoría del ecosistema loioloio."""
import xbmcgui


def run():
    xbmcgui.Dialog().ok(
        'Acerca de loioloio',
        'Creado por RubénSDFA1laberot\n'
        'https://loioloio.github.io',
    )
