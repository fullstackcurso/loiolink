"""Menú de opciones como folder de plugin (estilo espadaily/atresdaily/topzilla).

El menú raíz lista carpetas por tema (Recibir texto, Panel web remoto...). Cada
carpeta es su propio módulo en lib/actions/. Las sub-acciones opt_toggle /
opt_num / opt_text / opt_folder, que viven aquí, cambian un setting y refrescan
el container para re-renderizar la carpeta con el valor nuevo.
"""
import xbmc
import xbmcaddon
import xbmcgui

from lib import accessibility, log
from lib.actions import _menu_common as mc
from lib.ui_select import confirm

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Opciones')

    try:
        if not _ADDON.getSettingBool('_options_visited'):
            _ADDON.setSettingBool('_options_visited', True)
    except (RuntimeError, TypeError):
        pass

    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png', is_folder=False):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc, is_folder=is_folder)

    add(
        'Asistente de configuración inicial',
        mc.url('wizard'),
        'Configura loiolink paso a paso: comprueba la red, activa '
        'orígenes desconocidos, elige el modo del servidor y muestra el '
        'QR para conectar tu móvil desde el navegador.',
        icon='wizard.png',
    )

    add(
        'Recibir texto',
        mc.url('options_receive_menu'),
        'Configura el servidor que recibe texto enviado desde otro dispositivo '
        '(móvil, tableta, PC). Aquí cambias el puerto de escucha, si el servidor '
        'se cierra al salir de la ventana o sigue siempre activo, y el tiempo de espera.',
        icon='keyboard.png',
        is_folder=True,
    )

    add(
        'Pegar texto en buscadores',
        mc.url('options_paste_menu'),
        'Controla cómo se pega en los cuadros de búsqueda de Kodi el texto que '
        'recibes. Aquí ajustas las confirmaciones y la vista previa antes de pegar, '
        'pulsar Enter automáticamente, en qué elementos aparece la opción Pegar y '
        'los ajustes del portapapeles.',
        icon='search.png',
        is_folder=True,
    )

    add(
        'Panel web remoto',
        mc.url('options_remote_menu'),
        'Configura el panel web para controlar Kodi desde el navegador del móvil. '
        'Aquí lo enciendes o apagas, cambias el puerto, activas HTTPS y decides '
        'qué permisos tiene (gestionar addons, apagar el equipo).',
        icon='remote.png',
        is_folder=True,
    )

    add(
        'Descargas',
        mc.url('options_downloads_menu'),
        'Ajustes de los archivos que recibes desde el panel remoto: la carpeta '
        'donde se guardan, el tamaño máximo permitido, qué hacer al terminar la '
        'descarga y los tiempos de espera de la red.',
        icon='download.png',
        is_folder=True,
    )

    add(
        'Opciones avanzadas',
        mc.url('options_advanced_menu'),
        'Ajustes para usuarios avanzados: las URLs de los repositorios desde los '
        'que se instalan StreamNinja, Elementum y LoioLog, y las herramientas de '
        'depuración. No necesitas entrar aquí para el uso normal del addon.',
        icon='code.png',
        is_folder=True,
    )

    add(
        'Accesibilidad',
        mc.url('accessibility_menu'),
        'Opciones para hacer el addon más fácil de leer y de usar. Cambia el modo '
        'de color para daltonismo o alto contraste, la negrita, el tamaño en '
        'mayúsculas, la duración de las notificaciones y las confirmaciones antes '
        'de acciones que no se pueden deshacer.',
        icon='accessibility.png',
    )

    add(
        'Log y Diagnóstico',
        mc.url('diagnostics'),
        'Abre LoioLog, el visor de logs avanzado. Si no está instalado, se ofrece '
        'instalarlo desde el repositorio. Útil para depurar problemas del addon.',
        icon='diagnostics.png',
    )

    add(
        'Ajustes nativos de Kodi',
        mc.url('settings'),
        'Abre la ventana de ajustes estándar de Kodi con todas las opciones '
        'organizadas por categorías (Servidor, Transferencias, Pegar, Avanzado). '
        'Útil para ajustes que requieren el slider nativo de Kodi.',
        icon='settings.png',
    )

    mc.end()


def _refresh():
    xbmc.executebuiltin('Container.Refresh')


def _notify_error(msg):
    accessibility.notify(msg, xbmcgui.NOTIFICATION_ERROR, 3000)


def toggle(key):
    try:
        _ADDON.setSettingBool(key, not _ADDON.getSettingBool(key))
    except Exception as e:  # handler UI: una acción fallida no debe romper el flujo
        log.error(f'options_menu.toggle({key!r}) falló: {e!r}')
        _notify_error('Error al aplicar el cambio')
    _refresh()


def num(key, lo, hi, heading):
    try:
        current = _ADDON.getSettingInt(key)
        result = xbmcgui.Dialog().numeric(0, heading, str(current))
        if not result:
            return
        try:
            v = max(lo, min(hi, int(result)))
        except ValueError:
            return
        _ADDON.setSettingInt(key, v)
    except Exception as e:
        log.error(f'options_menu.num({key!r}) falló: {e!r}')
        _notify_error('Error al aplicar el cambio')
    finally:
        _refresh()


def text(key, heading):
    try:
        current = _ADDON.getSetting(key)
        result = xbmcgui.Dialog().input(heading, defaultt=current)
        if result == current:
            return
        # Dialog.input no distingue cancelar de vaciar: si el usuario "vacía"
        # un valor no vacío, confirmar para que un Escape accidental no borre
        # la URL custom.
        if not result and current:
            if not confirm(
                f'¿Borrar el valor actual y volver al valor por defecto?\n\nActual: {current}',
                title=heading,
                default_no=True,
            ):
                return
        _ADDON.setSetting(key, result)
    except Exception as e:
        log.error(f'options_menu.text({key!r}) falló: {e!r}')
        _notify_error('Error al aplicar el cambio')
    finally:
        _refresh()


def folder(key, heading):
    try:
        current = _ADDON.getSetting(key)
        result = xbmcgui.Dialog().browse(3, heading, 'files', '', False, False, current)
        if result == current:
            return
        if not result and current:
            if not confirm(
                f'¿Borrar el valor actual y volver a la carpeta por defecto?\n\nActual: {current}',
                title=heading,
                default_no=True,
            ):
                return
        _ADDON.setSetting(key, result if result else '')
    except Exception as e:
        log.error(f'options_menu.folder({key!r}) falló: {e!r}')
        _notify_error('Error al aplicar el cambio')
    finally:
        _refresh()


def toggle_https():
    try:
        currently_on = _ADDON.getSettingBool('remote_https_enabled')
        if not currently_on and not confirm(
                'HTTPS cifra la conexión entre el navegador y Kodi.\n\n'
                'La primera vez que abras el panel en cada navegador verás la '
                'pantalla "Conexión no privada". Es normal con un certificado '
                'autofirmado, no es un fallo del addon. Pulsa "Avanzado" y '
                'luego "Continuar" (o la opción equivalente de tu navegador) '
                'para entrar.\n\n'
                'Requiere openssl en el sistema. Reinicia Kodi para aplicar.',
                title='Activar HTTPS en el panel',
                yes='Activar', no='Cancelar'):
            _refresh()
            return
        _ADDON.setSettingBool('remote_https_enabled', not currently_on)
        msg = 'HTTPS activado.' if not currently_on else 'HTTPS desactivado.'
        accessibility.notify(f'{msg} Reinicia Kodi para aplicar.', ms=4000)
    except Exception as e:
        log.error(f'options_menu.toggle_https falló: {e!r}')
        _notify_error('Error al aplicar el cambio')
    _refresh()
