"""Acción 'Recibir texto'.

Modo efímero (por defecto): levanta servidor local + modal QR. El servidor
vive mientras el modal está abierto; al cerrarlo para.

Modo persistente (server_ephemeral_mode=False): el servidor lo gestiona
service.py. Esta acción solo muestra el QR con la dirección del servidor
ya activo, leída desde la Window property 'loiolink.text.port'. Los
payloads los procesa service.py directamente.
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import clipboard
import server
import ui_dialog
from lib import accessibility
from lib.remote import keyboard_input, server_permanent


_TEXT_PORT_PROP = 'loiolink.text.port'
_TEXT_SCHEME_PROP = 'loiolink.text.scheme'
_TEXT_STOPPED_PROP = 'loiolink.text.user_stopped'


def _auto_inject_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('remote.auto_inject_text')
    except (TypeError, RuntimeError):
        return True


def _is_ephemeral_mode():
    try:
        return xbmcaddon.Addon().getSettingBool('server_ephemeral_mode')
    except (TypeError, RuntimeError):
        return True


def _process_payload(payload):
    if not payload:
        return
    kind = payload.get('kind')
    if kind == 'text':
        text = payload['text']
        clipboard.set(text)
        accessibility.notify('Texto recibido y guardado', ms=2000)
        if _auto_inject_enabled():
            if keyboard_input.try_inject(text, wait_appear_ms=1500):
                accessibility.notify('También inyectado en Kodi', ms=1500)
    elif kind == 'magnet':
        accessibility.notify('Magnet recibido', ms=2000)
    elif kind == 'upload':
        entry = payload.get('entry', {})
        name = entry.get('name', 'archivo')
        is_playable = entry.get('kind') in ('video', 'audio')
        msg = f'Archivo recibido: {name}'
        if is_playable:
            msg += '. Cierra el QR para reproducir'
        accessibility.notify(msg, ms=3500 if is_playable else 2000)


class _NeverFireEvent:
    """Evento que nunca se activa: el dialog de modo persistente espera al Back del usuario."""
    def __init__(self):
        self._inner = threading.Event()

    def wait(self, timeout=None):
        # Defensivo: timeout=None bloquearía para siempre (el _inner nunca se
        # setea). El poll loop pasa timeout=0.5 explícito, así que esto solo
        # es red de seguridad ante callers futuros.
        if timeout is None:
            return False
        self._inner.wait(timeout)
        return False

    def is_set(self):
        return False

    def clear(self):
        # Branch nunca alcanzado con _PersistentProxy (wait() siempre False),
        # pero define la API completa de threading.Event por si el poll loop
        # del dialog cambia.
        pass


class _PersistentProxy:
    """Proxy de servidor para el modal en modo persistente.

    El modal usa text_event para saber cuándo llegó un payload. En modo
    persistente el payload lo procesa service.py, así que el modal nunca
    recibe nada; solo muestra la dirección y cierra con Back.
    """
    def __init__(self):
        self.received_payload = None
        self.text_event = _NeverFireEvent()


def _run_persistent():
    win = xbmcgui.Window(10000)
    # Si el server estaba parado por el botón web/menú, el usuario al pulsar
    # "Recibir texto" claramente quiere recibir ahora: limpiamos la flag y
    # caemos en la espera normal del port.
    if win.getProperty(_TEXT_STOPPED_PROP) == '1':
        win.clearProperty(_TEXT_STOPPED_PROP)

    # Esperar a que el service loop arranque el server. Cubre cold start
    # (Kodi recién arrancado, service bindando), restart tras user_stopped
    # y reactivación tras cambio de modo. 3s margen: bind normal tarda ms,
    # pero si el puerto está ocupado el service entra en back-off de 30s y
    # no arrancará antes. Mejor abortar con el mensaje genérico.
    port_str = win.getProperty(_TEXT_PORT_PROP)
    if not port_str:
        monitor = xbmc.Monitor()
        deadline = time.time() + 3.0
        while time.time() < deadline:
            if monitor.waitForAbort(0.2):
                return
            port_str = win.getProperty(_TEXT_PORT_PROP)
            if port_str:
                break

    if not port_str:
        # El setting podría estar en True pero service.py aún no haber
        # arrancado el server (bind falló y está en back-off, o el service
        # entero no está corriendo). El usuario no sabe distinguir, así que
        # damos las dos posibilidades.
        accessibility.notify(
            'Servidor persistente no listo. Espera unos segundos '
            'o revisa Ajustes > Servidor de recepción.',
            ms=3500,
        )
        return
    try:
        port = int(port_str)
    except ValueError:
        # Solo pasa si algo escribió basura en la Window property (no debería
        # ocurrir, service.py siempre escribe un puerto válido). Notificar
        # en vez de salir en silencio: el usuario clickó y necesita feedback.
        accessibility.notify(
            f'Puerto inválido en la propiedad ({port_str!r}). Reinicia Kodi.',
            ms=3500,
        )
        return

    ip = server_permanent.get_local_ip()
    if not ip:
        from lib.ui_select import info
        info(
            'No se pudo detectar la IP local.\n\n'
            'Asegúrate de estar conectado a WiFi o Ethernet.',
            title='loiolink',
        )
        return

    # Preferimos el scheme con el que service.py REALMENTE bindeó (escrito
    # en TEXT_SCHEME_PROP) en lugar de releer tls.is_https_enabled(): si el
    # usuario toggleó HTTPS después del arranque y aún no reinició Kodi, el
    # setting actual no coincide con lo que está escuchando.
    proto = win.getProperty(_TEXT_SCHEME_PROP)
    if not proto:
        # Fallback (instalación vieja o service.py sin esta versión).
        from lib.remote import tls
        proto = 'https' if tls.is_https_enabled() else 'http'
    addr = f'{proto}://{ip}:{port}'

    # Mostramos QR con la dirección del servidor de service.py.
    # on_payload=lambda: no-op para activar modo multi-shot (sin timeout, cierra con Back).
    accessibility.notify(
        'Misma WiFi que Kodi. Si no conecta, desactiva la VPN.',
        ms=3500,
    )
    ui_dialog.run_qr_modal(_PersistentProxy(), addr, on_payload=lambda _: None,
                           persistent=True)


def run():
    if _is_ephemeral_mode():
        _pending_uploads = []

        def _wrapped_payload(payload):
            _process_payload(payload)
            if not (payload and payload.get('kind') == 'upload'):
                return False
            entry = payload.get('entry')
            if not entry:
                return False
            _pending_uploads.append(entry)
            # Cierre automático del QR para ZIPs: el dialog "¿Instalar?"
            # aparece al instante tras la transferencia, sin esperar Back.
            # Para vídeo/audio/imagen/torrent el modal sigue abierto (el
            # usuario puede querer enviar más archivos en serie).
            return entry.get('kind') in ('addon_zip', 'repo_zip')

        accessibility.notify(
            'Misma WiFi que Kodi. Si no conecta, desactiva la VPN.',
            ms=3500,
        )
        server.serve_with_callback(_wrapped_payload)
        _handle_pending_uploads(_pending_uploads)
    else:
        _run_persistent()


def _handle_pending_uploads(pending):
    """Procesa entries de upload recibidos durante el QR modal efímero.

    En modo efímero, queue_event() y dequeue_event() existen en intérpretes
    Python distintos (plugin vs. service), así que el service nunca ve los
    eventos de upload encolados por el HTTP handler. Los procesamos aquí,
    desde el hilo principal del plugin, que es seguro para Dialog (kodi#15378).

    Un fallo procesando un entry no debe abortar los restantes ni el
    Container.Refresh final: el JSON ya tiene la entry, el contador del
    menú debe reflejarlo aunque la UI del post-transfer haya fallado.
    """
    if not pending:
        return
    import xbmc
    from lib import log
    from lib.transfers import history, post_transfer
    # Snapshot: el poll thread del QR modal es daemon y podría seguir vivo
    # unos microsegundos tras serve_with_callback(): iterar sobre una lista
    # que aún puede crecer es race-prone aunque CPython lo tolere por GIL.
    for entry in list(pending):
        try:
            fresh = history.get(entry['id'])
            if fresh and fresh.get('action_taken') is None:
                post_transfer.show_post_transfer_dialog(fresh)
        except Exception as e:
            log.error(f'post_transfer falló para {entry.get("id")!r}: {e}')
    xbmc.executebuiltin('Container.Refresh')
