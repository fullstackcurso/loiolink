"""Sub-carpeta de Opciones: descargas y transferencias."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Descargas')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    dest = _ADDON.getSetting('transfer.dest_folder') or '(perfil del addon)'
    add(
        f'Carpeta de destino: [COLOR yellow]{dest}[/COLOR]',
        mc.url('opt_folder', key='transfer.dest_folder',
               heading='Carpeta de destino para archivos recibidos'),
        'Carpeta donde se guardan los archivos recibidos de forma remota. '
        'Déjalo vacío para usar la carpeta del perfil del addon.',
        icon='sources.png',
    )

    auto = _ADDON.getSettingBool('transfer.auto_action')
    add(
        f'Acción automática tras descarga: {mc.color_bool(auto)}',
        mc.url('opt_toggle', key='transfer.auto_action'),
        'Si está activado, al completar una descarga se ejecuta automáticamente '
        'la acción correspondiente (reproducir, instalar addon, etc.) sin preguntar. '
        'Si está desactivado, aparece un menú para elegir qué hacer.',
        icon='auto.png',
    )

    dlg_always = _ADDON.getSettingBool('transfer.always_use_dialog')
    add(
        f'Siempre mostrar diálogo tras descarga: {mc.color_bool(dlg_always)}',
        mc.url('opt_toggle', key='transfer.always_use_dialog'),
        'Si está activado, siempre aparece un diálogo de descarga completada al terminar una transferencia, '
        'aunque la acción sea obvia. '
        'Si está desactivado, usa notificaciones discretas cuando puede.',
        icon='dialog.png',
    )

    maxgb = _ADDON.getSettingInt('transfer_max_size_gb')
    add(
        f'Límite por descarga: [COLOR yellow]{maxgb} GB[/COLOR]',
        mc.url('opt_num', key='transfer_max_size_gb', lo=1, hi=50,
               heading='Límite por descarga (GB)'),
        'Tamaño máximo permitido por archivo descargado. '
        f'Archivos más grandes que {maxgb} GB se rechazan antes de empezar. '
        'Rango: 1-50 GB.',
        icon='download_limit.png',
    )

    dl_t = _ADDON.getSettingInt('network.timeout_download_s')
    add(
        f'Timeout descarga: [COLOR yellow]{dl_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_download_s', lo=5, hi=180,
               heading='Timeout descarga de archivos (s)'),
        f'Segundos sin recibir datos del servidor antes de cancelar una descarga. '
        f'No es el tiempo total: una descarga lenta pero continua no se cancela. '
        f'Súbelo en redes inestables. Valor actual: {dl_t} s. Rango: 5-180 s.',
        icon='timer.png',
    )

    mc.end()
