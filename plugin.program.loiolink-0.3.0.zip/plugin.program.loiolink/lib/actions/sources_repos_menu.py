"""Gestor de fuentes y repositorios.

Aglutina dos cosas que en Kodi son distintas pero conceptualmente cercanas:

- **Fuentes** (sources.xml): las direcciones que el usuario añade desde
  "Añadir fuente" del file manager para luego instalar repos o ver archivos.
  El gestor ofrece añadir, renombrar, eliminar y revisar cambios en cada
  fuente.

- **Repositorios** instalados (addons de tipo repository.*): el gestor
  permite escanear todos los repos a la vez y listar qué addons tienen
  versión nueva disponible.

La detección de cambios y el escaneo NO ocurren al arrancar Kodi ni al
abrir el addon, solo al entrar a este gestor. Cero notificaciones cuando
el usuario está fuera. Cuando hay cambios pendientes, la primera entrada
del menú es un resumen "Hay N fuentes con cambios desde tu última visita".
"""
import concurrent.futures
import hashlib
import os
import time
import urllib.error
import urllib.request

import xbmcaddon
import xbmcgui

from lib import (
    accessibility, github_pages, log, repos, source_state, source_status, sources, url_utils,
)
from lib.ui_select import CloseMenu, SelectItem, confirm, menu, select


_FETCH_TIMEOUT = 10
_SCAN_TOTAL_TIMEOUT = 30
_SCAN_WORKERS = 4
_MENU_ICONS = os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'menu',
)


def _icon_path(filename):
    if not filename:
        return None
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def _http_only(path):
    return path.startswith('http://') or path.startswith('https://')


def _fetch_addons_xml(path):
    """Descarga addons.xml de la fuente. Devuelve (texto, error_str|None)."""
    url = path if path.endswith('/') else path + '/'
    url += 'addons.xml'
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
    })
    try:
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as r:
            return (r.read().decode('utf-8', errors='replace'), None)
    except (urllib.error.URLError, OSError, ValueError) as e:
        return (None, str(e))


def _check_source(source):
    """Comprueba una sola fuente. Diseñado para ejecutarse en thread."""
    name = source['name']
    path = source['path']

    if not _http_only(path):
        return {'name': name, 'path': path, 'kind': 'local',
                'change': False, 'error': None}

    text, err = _fetch_addons_xml(path)
    if err:
        return {'name': name, 'path': path, 'kind': None,
                'change': False, 'error': err}

    if not repos.looks_like_addons_xml(text):
        return {'name': name, 'path': path, 'kind': 'generic',
                'change': False, 'error': None}

    new_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
    prev = source_state.get(path)
    old_hash = prev.get('last_hash')
    addons_map = repos.parse_addons_xml(text)
    return {
        'name': name, 'path': path, 'kind': 'repo',
        'change': bool(old_hash and old_hash != new_hash),
        'new_hash': new_hash,
        'addons': addons_map,
        'prev_addons': prev.get('last_seen_addons', {}),
        'error': None,
    }


def _scan_sources(items):
    """Escaneo paralelo con timeout total. Devuelve lista de resultados."""
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Comprobando fuentes...')
    results = []
    cancelled = False
    deadline = time.time() + _SCAN_TOTAL_TIMEOUT

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
            futures = {pool.submit(_check_source, s): s for s in items}
            total = len(futures)
            done = 0
            for fut in concurrent.futures.as_completed(futures):
                if progress.iscanceled() or time.time() > deadline:
                    cancelled = True
                    break
                src = futures[fut]
                try:
                    results.append(fut.result(timeout=0))
                except Exception as e:  # un fallo en una fuente no aborta el lote
                    log.warning(f'scan: fuente {src["name"]!r} falló: {e!r}')
                    results.append({'name': src['name'], 'path': src['path'],
                                    'kind': None, 'change': False,
                                    'error': str(e)})
                done += 1
                pct = int(done * 100 / total) if total else 0
                progress.update(pct, f'{src["name"]}\n{done}/{total}')
    finally:
        progress.close()

    if cancelled:
        log.info(f'scan cancelado, {len(results)}/{len(items)} fuentes comprobadas')
    return results


def _persist_results(results):
    """Actualiza source_state.json con los resultados del escaneo.

    Usa `transaction()` para aplicar todos los cambios en una sola
    operación atómica (1 read + 1 write en disco, sin race entre items).
    """
    now = int(time.time())
    max_diff_age_s = 30 * 24 * 3600
    with source_state.transaction() as state:
        for r in results:
            path = r['path']
            key = source_state.path_key(path)
            entry = state.get(key, {})
            entry.setdefault('path', path)
            entry['name'] = r['name']
            if r.get('error'):
                entry['errors'] = int(entry.get('errors', 0)) + 1
                entry['last_check_ts'] = now
                entry['reachable'] = False
                state[key] = entry
                continue
            if r['kind'] == 'local':
                entry['kind'] = 'local'
                entry['errors'] = 0
                entry['reachable'] = True
                state[key] = entry
                continue
            if r['kind'] == 'generic':
                entry['kind'] = 'generic'
                entry['errors'] = 0
                entry['reachable'] = True
                entry['last_check_ts'] = now
                state[key] = entry
                continue
            # repo monitorizado
            entry['kind'] = 'repo'
            entry['errors'] = 0
            entry['reachable'] = True
            entry['last_check_ts'] = now
            entry['last_hash'] = r['new_hash']
            entry['last_seen_addons'] = r['addons']
            if r['change']:
                entry['acknowledged'] = False
                # Guardamos el snapshot anterior para poder mostrar el diff cuando
                # el usuario abra el detail. Si no lo guardamos aquí, la siguiente
                # línea sobrescribe last_seen_addons y se pierde la información.
                entry['prev_seen_addons'] = r.get('prev_addons', {})
                history = [
                    h for h in entry.get('diff_history', [])
                    if now - h.get('ts', 0) < max_diff_age_s
                ]
                history.append({'ts': now, 'prev': r.get('prev_addons', {}), 'current': r['addons']})
                entry['diff_history'] = history[-5:]
            state[key] = entry


_status_tag = source_status.status_tag
_source_icon = source_status.status_icon


def _close():
    raise CloseMenu()


def _ack_source(path):
    source_state.mark_acknowledged(path)
    accessibility.notify('Fuente marcada como revisada', ms=2000)


def _action_add_source():
    choice = select('¿Cómo quieres añadir la fuente?', [
        SelectItem(
            label='Repositorio de GitHub Pages',
            plot='Asistente para repos alojados en GitHub Pages. Solo escribes el '
                 'usuario y el nombre del repositorio; el https://, el .github.io y '
                 'la barra final los pone el addon.',
            icon=_icon_path('wizard.png'),
        ),
        SelectItem(
            label='Escribir la URL completa o una ruta',
            plot='Introduces la dirección entera a mano: una URL http(s):// de '
                 'cualquier servidor, o una ruta smb://, nfs:// o local.',
            icon=_icon_path('url.png'),
        ),
    ])
    if choice < 0:
        return

    if choice == 0:
        result = github_pages.prompt_source_url()
        if not result:
            return
        url, suggested = result
    else:
        url = xbmcgui.Dialog().input('URL de la fuente (http:// o https://)')
        if not url:
            return
        suggested = url_utils.suggest_source_name(url)

    if not _http_only(url) and not url.startswith(('smb://', 'nfs://', '/', '\\')):
        if not confirm(
            f'La URL "{url}" no parece http/https. ¿Añadirla igualmente?',
            title='loiolink',
            default_no=True,
        ):
            return

    name = xbmcgui.Dialog().input('Nombre de la fuente', defaultt=suggested)
    if not name:
        return

    sources.add_source(name, url)
    # Fetch inicial dentro de un DialogProgress para que la fuente aparezca
    # ya clasificada en la lista en vez de quedar [Sin comprobar] hasta el
    # siguiente scan automático. Sin progress el UI queda bloqueado hasta 10s
    # sin feedback visual.
    if _http_only(url):
        progress = xbmcgui.DialogProgress()
        progress.create('loiolink', f'Comprobando {url}...')
        try:
            _persist_results([_check_source({'name': name, 'path': url})])
        finally:
            progress.close()
    accessibility.notify('Fuente añadida. Reinicia Kodi para que la vea.', ms=3500)


def _rename_source(old_name):
    new_name = xbmcgui.Dialog().input('Nuevo nombre', defaultt=old_name)
    if not new_name or new_name == old_name:
        return
    # El path lo necesitamos para mantener sincronizado el name en state.
    path = None
    for src in sources.list_files_sources():
        if src['name'] == old_name:
            path = src['path']
            break
    if sources.rename_source(old_name, new_name):
        if path:
            source_state.upsert(path, name=new_name)
        accessibility.notify('Fuente renombrada. Reinicia Kodi.', ms=3000)
        # Cerramos el detail para que la próxima vista del submenú refleje
        # el nombre nuevo. Si no, el título y los labels del detail
        # seguirían con el nombre viejo hasta navegar fuera.
        raise CloseMenu()
    accessibility.notify(
        'No se pudo renombrar', xbmcgui.NOTIFICATION_WARNING, 2500,
    )


def _remove_source(name):
    if not accessibility.confirm_destructive(
        f'¿Eliminar la fuente "{name}" del sources.xml?',
    ):
        return
    # Capturamos el path ANTES de borrar la entrada del XML para poder limpiar
    # también su entry en source_state. Si solo borráramos del XML, la entry
    # del state quedaría huérfana ocupando espacio para siempre.
    path = None
    for src in sources.list_files_sources():
        if src['name'] == name:
            path = src['path']
            break
    if sources.remove_source(name):
        if path:
            source_state.remove(path)
        accessibility.notify('Fuente eliminada. Reinicia Kodi.', ms=3000)
        raise CloseMenu()
    accessibility.notify(
        'No se encontró la fuente', xbmcgui.NOTIFICATION_WARNING, 2500,
    )


def _action_rescan():
    items = sources.list_files_sources()
    results = _scan_sources(items)
    _persist_results(results)
    accessibility.notify(
        f'Comprobadas {len(results)}/{len(items)} fuentes', ms=2500,
    )


def _action_scan_repos():
    from lib.actions import about
    about.scan_installed_repos_ui()


def _maybe_scan_on_open(items):
    """Lanza scan solo si la última comprobación es vieja."""
    threshold = 5 * 60  # 5 minutos
    now = time.time()
    state = source_state.load()
    should_scan = False
    for src in items:
        st = state.get(source_state.path_key(src['path']), {})
        last = int(st.get('last_check_ts', 0))
        if now - last > threshold and _http_only(src['path']):
            should_scan = True
            break
    if not should_scan:
        return
    results = _scan_sources(items)
    _persist_results(results)


def _format_diff(prev, current, limit=12):
    """Devuelve un texto multilínea con los deltas entre dos snapshots.

    prev y current son {addon_id: version}. La salida incluye altas,
    bajas y subidas de versión. Si hay más de `limit` líneas, se trunca
    para no inundar el plot.
    """
    prev_keys = set(prev)
    cur_keys = set(current)
    added = sorted(cur_keys - prev_keys)
    removed = sorted(prev_keys - cur_keys)
    bumped = []
    for k in sorted(prev_keys & cur_keys):
        if prev[k] != current[k]:
            bumped.append((k, prev[k], current[k]))

    lines = []
    for a in added:
        lines.append(f'+ {a} ({current[a]})')
    for r in removed:
        lines.append(f'- {r}')
    for k, old, new in bumped:
        lines.append(f'{k}: {old} → {new}')

    if not lines:
        return 'El contenido remoto ha cambiado pero no se aprecia diferencia de addons.'
    if len(lines) > limit:
        more = len(lines) - limit
        lines = lines[:limit] + [f'... y {more} cambios más']
    return '\n'.join(lines)


def _purge_orphan_state(items):
    """Elimina entries de source_state cuyo path ya no está en sources.xml.

    Esto cubre el caso de que el usuario elimine una fuente desde el file
    manager nativo de Kodi (fuera del addon). Sin esta limpieza el JSON
    crecería con basura cada vez que pasara.
    """
    live_keys = {source_state.path_key(s['path']) for s in items}
    state = source_state.load()
    orphans = [k for k in state if k not in live_keys]
    if not orphans:
        return
    for k in orphans:
        state.pop(k, None)
    source_state.save(state)


def _pending_changes_count():
    state = source_state.load()
    n = 0
    for v in state.values():
        if v.get('kind') == 'repo' and not v.get('acknowledged', True):
            n += 1
    return n


def _source_detail(src):
    """Submenú del detalle de una fuente concreta. Bloqueante hasta que
    el usuario vuelve o se cierra por rename/remove."""
    name = src['name']
    path = src['path']

    def build():
        items = []
        st = source_state.get(path)

        # Si hay cambios pendientes, mostrar deltas concretos como primera fila.
        if not st.get('acknowledged', True) and st.get('kind') == 'repo':
            diff_text = _format_diff(
                st.get('prev_seen_addons', {}),
                st.get('last_seen_addons', {}),
            )
            items.append(SelectItem(
                label='[B]Hay cambios desde tu última visita[/B]',
                plot=diff_text + '\n\nPulsa para marcar la fuente como revisada.',
                icon=_icon_path('notification.png'),
                action=lambda: _ack_source(path),
            ))

        items.append(SelectItem(
            label=f'Nombre: {name}',
            plot='Identificador legible de la fuente. Es el nombre que ves en el file '
                 'manager de Kodi y aquí.',
            icon=_icon_path('edit.png'),
            action=lambda: _rename_source(name),
        ))
        items.append(SelectItem(
            label=f'URL: {path}',
            plot='URL configurada para esta fuente. La URL no se puede modificar desde '
                 'aquí; tienes que eliminar la fuente y añadir una nueva con la URL '
                 'corregida.',
            icon=_icon_path('url.png'),
        ))

        last_check = st.get('last_check_ts')
        if last_check:
            when = time.strftime('%Y-%m-%d %H:%M', time.localtime(last_check))
            items.append(SelectItem(
                label=f'Última comprobación: {when}',
                plot='Fecha de la última vez que el gestor consultó si esta fuente respondía.',
                icon=_icon_path('history.png'),
            ))

        history = st.get('diff_history', [])
        if history:
            history_lines = []
            for entry in reversed(history):
                entry_when = time.strftime('%Y-%m-%d %H:%M', time.localtime(entry.get('ts', 0)))
                diff_text = _format_diff(entry.get('prev', {}), entry.get('current', {}))
                history_lines.append(f'[B]{entry_when}[/B]\n{diff_text}')
            items.append(SelectItem(
                label=f'Historial de cambios ({len(history)})',
                plot='\n\n'.join(history_lines),
                icon=_icon_path('history.png'),
            ))

        items.append(SelectItem(
            label='Renombrar',
            plot='Cambia el nombre legible que aparece en el file manager y aquí. La URL '
                 'no se toca. Kodi solo verá el nombre nuevo tras reiniciar.',
            icon=_icon_path('edit.png'),
            action=lambda: _rename_source(name),
        ))
        items.append(SelectItem(
            label='Eliminar',
            plot='Borra la fuente de sources.xml. Si por error eliminas una que usabas, '
                 'tendrás que volver a añadirla con su URL.',
            icon=_icon_path('delete.png'),
            action=lambda: _remove_source(name),
        ))
        items.append(SelectItem(
            label='Volver',
            plot='Vuelve a la lista de fuentes.',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu(f'Fuente: {name}', build)


def _open_sources_submenu():
    """Submenú de gestión de fuentes. Bloqueante hasta que el usuario vuelve."""

    def build():
        items = []
        items.append(SelectItem(
            label='Añadir una fuente nueva',
            plot='Elige entre el asistente de GitHub Pages (solo escribes usuario y '
                 'repositorio) o escribir la URL completa, y añade la entrada al bloque '
                 'de fuentes para archivos de sources.xml. Kodi solo verá la fuente '
                 'nueva tras reiniciar.',
            icon=_icon_path('add_source.png'),
            action=_action_add_source,
        ))
        items.append(SelectItem(
            label='Volver a comprobar todas las fuentes ahora',
            plot='Lanza el escaneo paralelo de todas las fuentes HTTP/HTTPS para detectar '
                 'cambios y caídas. Útil cuando no quieres esperar a la próxima entrada al '
                 'gestor.',
            icon=_icon_path('sync.png'),
            action=_action_rescan,
        ))

        for src in sources.list_files_sources():
            tag = _status_tag(src['path'])
            label = f'{tag} {src["name"]}' if tag else src['name']
            items.append(SelectItem(
                label=label,
                plot=f'URL: {src["path"]}\n\nPulsa para ver el detalle, renombrar o eliminar '
                     'esta fuente.',
                icon=_icon_path(_source_icon(src['path'])),
                action=lambda s=src: _source_detail(s),
            ))

        items.append(SelectItem(
            label='Volver',
            plot='Vuelve al menú anterior del gestor.',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu('Fuentes', build)


def _build_main_items():
    items = []

    pending = _pending_changes_count()
    if pending:
        items.append(SelectItem(
            label=f'[B]Hay {pending} fuente{"s" if pending != 1 else ""} con cambios[/B]',
            plot='Una o más fuentes han cambiado su contenido desde la última vez que '
                 'entraste al gestor. Pulsa para ir directamente al listado y revisar '
                 'cada fuente con el flag de cambios.',
            icon=_icon_path('notification.png'),
            action=_open_sources_submenu,
        ))

    items.append(SelectItem(
        label='Gestionar fuentes',
        plot='Ver, añadir, renombrar y eliminar las fuentes del bloque de archivos de '
             'sources.xml. Es el equivalente intuitivo al gestor de fuentes nativo de '
             'Kodi, pensado para que añadir repositorios resulte más cómodo.',
        icon=_icon_path('sources.png'),
        action=_open_sources_submenu,
    ))

    items.append(SelectItem(
        label='Comprobar actualizaciones en los repositorios instalados',
        plot='Recorre los addons del tipo repository.* que tienes instalados, descarga '
             'su index remoto y compara las versiones publicadas con las que tienes '
             'activas. Lista al final qué addons tienen actualización disponible.',
        icon=_icon_path('sync.png'),
        action=_action_scan_repos,
    ))

    items.append(SelectItem(
        label='Salir',
        plot='Cierra el gestor y vuelve al menú principal.',
        icon=_icon_path('exit.png'),
        action=_close,
    ))

    return items


def run():
    # Lanzamos un scan al abrir si los datos son viejos. No bloqueante para
    # el usuario porque el progress es cancelable.
    items_first = sources.list_files_sources()
    # Limpieza primero: si una fuente fue eliminada desde el file manager
    # nativo, su entry en source_state queda huérfana hasta que entre aquí.
    _purge_orphan_state(items_first)
    if items_first:
        _maybe_scan_on_open(items_first)

    menu('Gestor de fuentes y repositorios', _build_main_items)
