"""Ventana 'Información del addon y versión'.

Muestra versión, autor y estado de los repositorios StreamNinja, LoioLog y LoioLink. 
Desde la misma ventana se puede lanzar el escaneo de
actualizaciones de los repos instalados, que recorre cada repository.*
y compara las versiones publicadas con las locales.
"""
import xbmcaddon
import xbmcgui

from lib import accessibility
from lib.ui_select import CloseMenu, SelectItem, info, menu


REPO_STREAMNINJA = 'repository.streamninja'
REPO_LOIOLOG = 'repository.loiolog'


def _addon_info(key):
    return xbmcaddon.Addon().getAddonInfo(key)


def _repo_state(repo_id):
    """Devuelve (instalado: bool, versión: str|None)."""
    if repo_id is None:
        return (False, None)
    try:
        addon = xbmcaddon.Addon(repo_id)
        return (True, addon.getAddonInfo('version'))
    except RuntimeError:
        return (False, None)


def _close():
    raise CloseMenu()


def _build_items():
    items = []

    version = _addon_info('version')
    author = _addon_info('author') or 'RubénSDFA1laberot'

    items.append(SelectItem(
        label=accessibility.apply_label(f'Versión {version} (español)'),
        plot='Número de versión del addon que tienes instalado ahora mismo. Si actualizas '
             'desde un ZIP nuevo, este número cambiará al reiniciar Kodi.',
    ))

    items.append(SelectItem(
        label=accessibility.apply_label(f'Autor — {author} (EspaKodi)'),
        plot='Addon escrito y mantenido por RubénSDFA1laberot (EspaKodi).',
    ))

    sn_ok, sn_ver = _repo_state(REPO_STREAMNINJA)
    sn_label = (
        f'[COLOR green][OK][/COLOR] {REPO_STREAMNINJA} — instalado ({sn_ver})' if sn_ok
        else f'[COLOR red][X][/COLOR]  {REPO_STREAMNINJA} — no instalado'
    )
    items.append(SelectItem(
        label=accessibility.apply_label(sn_label),
        plot='Repositorio que sirve StreamNinja y otros addons relacionados. Si aparece '
             'como instalado, las actualizaciones del propio StreamNinja desde la opción '
             'correspondiente del menú principal funcionan sin pasos manuales adicionales.',
    ))

    ll_ok, ll_ver = _repo_state(REPO_LOIOLOG)
    ll_label = (
        f'[COLOR green][OK][/COLOR] {REPO_LOIOLOG} — instalado ({ll_ver})' if ll_ok
        else f'[COLOR red][X][/COLOR]  {REPO_LOIOLOG} — no instalado'
    )
    items.append(SelectItem(
        label=accessibility.apply_label(ll_label),
        plot='Repositorio del visor de logs LoioLog. Sin él la sección de diagnósticos '
             'del addon sigue funcionando, pero no puedes abrir LoioLog directamente '
             'desde aquí.',
    ))

    items.append(SelectItem(
        label=accessibility.apply_label('[COLOR gray][—][/COLOR]  repository.loiolink — pendiente (no disponible aún)'),
        plot='Repositorio dedicado al propio loiolink. Todavía no existe; cuando se '
             'publique habrá que rellenar las constantes REPO_LOIOLINK_ID y '
             'REPO_LOIOLINK_URL en lib/actions/about.py para activar esta comprobación.',
    ))

    items.append(SelectItem(
        label=accessibility.apply_label('Comprobar actualizaciones en los repos instalados'),
        plot='Recorre cada repositorio de Kodi que tengas instalado, descarga su index '
             'remoto y compara las versiones publicadas con las que tienes activas en '
             'el sistema. Si encuentra novedades, muestra la lista al terminar.',
        action=scan_installed_repos_ui,
    ))

    items.append(SelectItem(
        label=accessibility.apply_label('Cerrar'),
        plot='Cierra esta ventana y vuelve al menú anterior.',
        action=_close,
    ))

    return items


def scan_installed_repos_ui():
    """Lanza el escaneo de actualizaciones de los repos instalados y muestra
    el resultado en un textviewer. Función pública para que el gestor de
    fuentes y repos pueda reutilizarla sin acoplarse a una API privada.
    """
    from lib import repos
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Comprobando repositorios instalados...')

    def cb(done, total, current_name):
        if progress.iscanceled():
            raise repos.ScanCancelled()
        pct = int(done * 100 / total) if total else 0
        progress.update(pct, f'{current_name or ""}\n{done}/{total}')

    try:
        result = repos.scan_installed_repos(progress_cb=cb)
    except repos.ScanCancelled:
        progress.close()
        return
    finally:
        progress.close()

    if not result:
        info(
            'No se ha encontrado ningún repositorio Kodi instalado para comprobar.',
            title='loiolink — actualizaciones',
        )
        return

    def _build_result_items():
        items = []
        for repo_id, repo_info in result.items():
            if repo_info.get('error'):
                label = f'[COLOR red][X][/COLOR] {repo_id}'
                plot = ('Error al consultar este repositorio:\n\n'
                        f'{repo_info["error"]}')
            else:
                updates = repo_info.get('updates', [])
                if not updates:
                    label = f'[COLOR green][OK][/COLOR] {repo_id} — sin actualizaciones'
                    plot = ('No hay addons con versión nueva pendientes en '
                            'este repositorio.')
                else:
                    n = len(updates)
                    s = 'es' if n != 1 else ''
                    label = (f'[COLOR orange][!][/COLOR] {repo_id} — '
                             f'{n} actualizacion{s}')
                    detail = [f'{n} addon{"s" if n != 1 else ""} con '
                              'actualización disponible:', '']
                    for u in updates:
                        detail.append(
                            f'  {u["addon_id"]}: {u["local"]} -> {u["remote"]}',
                        )
                    plot = '\n'.join(detail)
            items.append(SelectItem(label=label, plot=plot))
        items.append(SelectItem(
            label='Cerrar',
            plot='Cierra esta ventana y vuelve al menú anterior.',
            action=_close,
        ))
        return items

    menu('loiolink — actualizaciones', _build_result_items, show_icons=False)


def run():
    menu(
        'LoioLink — Información del addon',
        _build_items,
        show_icons=False,
    )
