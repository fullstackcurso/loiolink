"""Sub-carpeta de Opciones: ajustes para usuarios avanzados."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Opciones avanzadas')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png', is_folder=False):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc, is_folder=is_folder)

    sn = _ADDON.getSetting('streamninja_repo_url_override') or '(por defecto)'
    add(
        f'URL repo StreamNinja: [COLOR yellow]{sn}[/COLOR]',
        mc.url('opt_text', key='streamninja_repo_url_override',
               heading='URL repo StreamNinja'),
        'URL personalizada del repositorio desde el que se instala StreamNinja. '
        'Déjalo vacío para usar la URL oficial. '
        'Cambia esto solo si tienes un mirror propio o necesitas probar una versión específica. '
        'URL por defecto: https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip',
        icon='url.png',
    )

    el = _ADDON.getSetting('elementum_repo_url_override') or '(por defecto)'
    add(
        f'URL repo Elementum: [COLOR yellow]{el}[/COLOR]',
        mc.url('opt_text', key='elementum_repo_url_override',
               heading='URL repo Elementum'),
        'URL personalizada del repositorio desde el que se instala Elementum '
        'cuando llega un magnet o un .torrent y Elementum no está disponible. '
        'Déjalo vacío para usar la URL oficial. '
        'URL por defecto: https://elementumorg.github.io/repository.elementumorg-1.0.6.zip',
        icon='url.png',
    )

    ll = _ADDON.getSetting('loiolog_repo_url_override') or '(por defecto)'
    add(
        f'URL repo LoioLog: [COLOR yellow]{ll}[/COLOR]',
        mc.url('opt_text', key='loiolog_repo_url_override',
               heading='URL repo LoioLog'),
        'URL personalizada del repositorio desde el que se instala LoioLog (visor de logs). '
        'Déjalo vacío para usar la URL oficial. '
        'URL por defecto: https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip',
        icon='url.png',
    )

    inst_t = _ADDON.getSettingInt('network.timeout_install_s')
    add(
        f'Timeout instalación addon: [COLOR yellow]{inst_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_install_s', lo=10, hi=300,
               heading='Timeout instalación de addons (s)'),
        f'Segundos sin recibir datos al descargar el zip de un addon externo antes de cancelar. '
        f'No es el tiempo total: una instalación lenta pero continua no se cancela. '
        f'Valor actual: {inst_t} s. Rango: 10-300 s.',
        icon='timer.png',
    )

    tc_t = _ADDON.getSettingInt('network.timeout_transcode_s')
    add(
        f'Timeout transcodificación: [COLOR yellow]{tc_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_transcode_s', lo=2, hi=60,
               heading='Timeout transcodificación FFmpeg (s)'),
        f'Tiempo máximo total para la transcodificación FFmpeg antes de matar el proceso. '
        f'Valor actual: {tc_t} s. Rango: 2-60 s.',
        icon='timer.png',
    )

    add(
        'Debug',
        mc.url('debug_menu'),
        'Opciones de depuración: log de datos sensibles y test del pegado.',
        icon='diagnostics.png',
        is_folder=True,
    )

    mc.end()
