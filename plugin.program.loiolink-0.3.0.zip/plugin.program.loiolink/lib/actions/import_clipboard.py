"""Acción 'Importar contenido del portapapeles del SO'.

Lanzada desde la entrada destacada del menú principal cuando
clipboard_detect.detect_importable() devuelve algo. Lee el clipboard de
nuevo (puede haber cambiado entre construir el menú y pulsar) y despacha
según el kind:

- magnet → encolar evento magnet_received (service abre Elementum o pide
  instalarlo en su main thread).
- url    → pipeline.download_and_register con source='clipboard'.
- aftvnews_code → aftvnews.resolve(code) + pipeline.download_and_register.
"""
import urllib.error

from lib import clipboard_detect
from lib.ui_select import info


def run():
    from lib import accessibility
    detected = clipboard_detect.detect_importable()
    if detected is None:
        accessibility.notify('No hay contenido importable en el portapapeles', ms=2500)
        return

    kind, value, _preview = detected

    if kind == 'magnet':
        from lib.transfers import history
        history.queue_event({'kind': 'magnet_received', 'uri': value})
        accessibility.notify('Magnet importado, abriendo Elementum...', ms=2500)
        return

    if kind == 'url':
        from lib.transfers import pipeline
        try:
            pipeline.download_and_register(value, source='clipboard')
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Descarga falló: {e}', title='loiolink')
        return

    if kind == 'aftvnews_code':
        from lib.transfers import aftvnews, pipeline
        try:
            url = aftvnews.resolve(value)
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Código inválido: {e}', title='loiolink')
            return
        try:
            pipeline.download_and_register(url, source='clipboard')
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Descarga falló: {e}', title='loiolink')
