"""Helpers de accesibilidad y notificación.

Centraliza tres responsabilidades que antes estaban duplicadas o ausentes:

1. `apply_label(text)`: transforma labels de ListItem según los settings de
   accesibilidad (color, negrita, mayúsculas, sustitución de símbolos).
   Inspirado en core_settings.py de topzilla; mismo set de keys de setting
   para mantener consistencia entre los addons del autor.
2. `notify(msg, level, ms)`: notificación con duración multiplicada según
   `acc_notif_multiplier`. Sustituye a las copias dispersas de `_notify` que
   había en context.py, service.py y otros.
3. `confirm_destructive(msg)`: diálogo yesno que solo aparece si
   `acc_confirm_destructive` está activo; si no, devuelve True directamente.
"""
import re

import xbmcaddon
import xbmcgui


_COLOR_MODES = ('none', 'white', 'daltonic_rg', 'daltonic_by', 'hc_dark', 'hc_light')
_NOTIF_MULTIPLIERS = (1, 2, 4)


_SYMBOL_MAP = {
    '★': '*', '☆': '*', '●': '·', '•': '-',
    '▲': '^', '▼': 'v', '►': '>', '◄': '<',
    '➤': '>', '✓': 'OK', '✗': 'X', '✘': 'X',
    '→': '->', '←': '<-', '↑': '^', '↓': 'v',
    '…': '...', '«': '<<', '»': '>>',
}


_COLOR_TRANSFORM = {
    'white': {
        '__default__': 'white',
    },
    'daltonic_rg': {
        'red': 'darkorange', 'crimson': 'darkorange', 'darkred': 'darkorange',
        'tomato': 'darkorange', 'firebrick': 'darkorange',
        'green': 'deepskyblue', 'limegreen': 'deepskyblue', 'lime': 'deepskyblue',
        'darkgreen': 'deepskyblue', 'chartreuse': 'deepskyblue',
    },
    'daltonic_by': {
        'yellow': 'fuchsia', 'gold': 'fuchsia', 'orange': 'fuchsia',
        'darkorange': 'fuchsia', 'lightyellow': 'fuchsia',
        'blue': 'orangered', 'deepskyblue': 'orangered', 'cyan': 'orangered',
        'cornflowerblue': 'orangered', 'royalblue': 'orangered', 'aqua': 'orangered',
    },
    'hc_dark': {
        '__default__': 'yellow',
        'red': 'red',
    },
    'hc_light': {
        '__default__': 'black',
        'red': 'red',
    },
}


_COLOR_WRAP = {
    'white':    'white',
    'hc_dark':  'yellow',
    'hc_light': 'black',
}


_COLOR_TAG_RE = re.compile(r'\[COLOR ([^\]]+)\](.*?)\[/COLOR\]', re.DOTALL)


def _addon():
    return xbmcaddon.Addon()


def _get_enum(key, table, default_value):
    raw = _addon().getSetting(key) or '0'
    try:
        idx = int(raw)
    except ValueError:
        return default_value
    if 0 <= idx < len(table):
        return table[idx]
    return default_value


def get_color_mode():
    return _get_enum('acc_color_mode', _COLOR_MODES, 'none')


def get_force_bold():
    return _addon().getSettingBool('acc_force_bold')


def get_strip_symbols():
    return _addon().getSettingBool('acc_strip_symbols')


def get_font_size():
    return _addon().getSettingBool('acc_font_size')


def get_notif_multiplier():
    return _get_enum('acc_notif_multiplier', _NOTIF_MULTIPLIERS, 1)


def get_confirm_destructive():
    return _addon().getSettingBool('acc_confirm_destructive')


def _apply_color_transform(text, mode):
    transform = _COLOR_TRANSFORM.get(mode)
    if not transform:
        return text
    default = transform.get('__default__')

    def _replace(m):
        color = m.group(1).lower().strip()
        new = transform.get(color, default)
        if new is None:
            return m.group(0)
        return f'[COLOR {new}]{m.group(2)}[/COLOR]'

    result = _COLOR_TAG_RE.sub(_replace, text)
    wrap = _COLOR_WRAP.get(mode)
    if wrap:
        result = f'[COLOR {wrap}]{result}[/COLOR]'
    return result


def apply_label(text, bold=None, strip=None, color_mode=None, font_size=None):
    """Aplica las transformaciones de accesibilidad al texto.

    Parámetros opcionales pre-leídos para evitar N llamadas a getSetting
    cuando se construye un menú con muchos items.
    """
    if not text:
        return text
    if strip is None:
        strip = get_strip_symbols()
    if bold is None:
        bold = get_force_bold()
    if color_mode is None:
        color_mode = get_color_mode()
    if font_size is None:
        font_size = get_font_size()
    if strip:
        for sym, rep in _SYMBOL_MAP.items():
            text = text.replace(sym, rep)
    if color_mode and color_mode != 'none':
        text = _apply_color_transform(text, color_mode)
    if bold:
        text_no_bold = text.replace('[B]', '').replace('[/B]', '')
        text = f'[B]{text_no_bold}[/B]'
    else:
        text = text.replace('[B]', '').replace('[/B]', '')
    if font_size:
        text = f'[UPPERCASE]{text}[/UPPERCASE]'
    return text


def notify(msg, level=xbmcgui.NOTIFICATION_INFO, ms=2500, title='loiolink'):
    """Notificación con duración multiplicada por el setting acc_notif_multiplier."""
    mult = get_notif_multiplier()
    xbmcgui.Dialog().notification(title, msg, level, ms * mult)


def confirm_destructive(msg, title='loiolink'):
    """Yesno solo si el setting está activo; si no, asume confirmación.

    Devuelve True si el usuario confirma o si las confirmaciones están
    desactivadas. False solo si el usuario rechaza explícitamente.
    """
    if not get_confirm_destructive():
        return True
    from lib.ui_select import confirm
    return confirm(msg, title=title, default_no=True)
