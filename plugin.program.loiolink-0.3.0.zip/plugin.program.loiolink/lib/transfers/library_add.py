"""Mueve un archivo recibido a una fuente de la biblioteca de Kodi y dispara
escaneo para que aparezca en Películas / Series / Música.

Kodi no expone VideoLibrary.AddItem para archivos sueltos. El único camino
soportado es: el archivo debe vivir dentro de una carpeta declarada como
source en Kodi, y se llama a VideoLibrary.Scan(path) / AudioLibrary.Scan(path)
sobre esa carpeta.
"""
import os

import xbmcvfs

from lib import accessibility, log
from lib.remote import library as lib_library, player
from lib.remote.rpc import RPCError
from lib.ui_select import SelectItem, info, select


_HEADING = 'loiolink: añadir a biblioteca'


def add_to_library(entry):
    """Mueve el archivo a una source de Kodi y dispara escaneo.

    PRECONDICIÓN: llamar desde main thread; usa select() / info() que
    crean WindowDialog (no thread-safe en Kodi 19, kodi#15378).

    Devuelve el path final del archivo (original o destino tras mover), o None
    si no se realizó acción (usuario canceló, error, sin fuentes). El caller
    puede usar el path devuelto para reproducir desde la ubicación correcta
    cuando la acción es "reproducir y añadir"; evita abrir el archivo antes
    de moverlo.
    """
    kind = entry['kind']
    if kind not in ('video', 'audio'):
        log.warning(f'library_add: kind inesperado {kind!r}')
        return None

    filepath = entry['path']
    media = 'video' if kind == 'video' else 'music'

    sources = lib_library.get_sources(media)
    if not sources:
        tipo = 'vídeo' if kind == 'video' else 'música'
        seccion = 'vídeos' if kind == 'video' else 'música'
        info(
            f'No hay fuentes de {tipo} configuradas en Kodi.\n\n'
            f'Añade una carpeta en Kodi > Ajustes > Archivos > Agregar {seccion}.',
            title=_HEADING,
        )
        return None

    if _file_in_source(filepath, sources):
        _scan(kind, os.path.dirname(xbmcvfs.translatePath(filepath)))
        accessibility.notify('Escaneando biblioteca...', title=_HEADING, ms=3000)
        return filepath

    items = [SelectItem(s['label'], plot=s['file']) for s in sources]
    idx = select(_HEADING, items)
    if idx < 0:
        return None

    src = sources[idx]
    dest_dir = src['file'].rstrip('/\\') + '/'
    dest_path = _unique_dest(dest_dir, os.path.basename(filepath))

    if not _move(filepath, dest_path):
        info(f'No se pudo mover el archivo a "{src["label"]}".', title=_HEADING)
        return None

    from lib.transfers import history
    history.update(entry['id'], path=dest_path)

    _scan(kind, xbmcvfs.translatePath(src['file']))
    accessibility.notify(
        f'"{os.path.basename(dest_path)}" añadido a {src["label"]}. Escaneando...',
        title=_HEADING, ms=4000,
    )
    return dest_path


def _move(src, dst):
    """Mueve src → dst. Intenta os.rename (atómico, mismo FS) primero.

    En el mismo filesystem rename es instantáneo aunque el archivo pese
    varios GB. Cross-device (OSError EXDEV) o sources de red caen al
    fallback xbmcvfs.copy + delete, que sí es bloqueante.
    """
    try:
        os.rename(xbmcvfs.translatePath(src), xbmcvfs.translatePath(dst))
        return True
    except OSError:
        pass
    if not xbmcvfs.copy(src, dst):
        return False
    if not xbmcvfs.delete(src):
        log.warning(f'library_add: no se pudo eliminar original: {src!r}')
    return True


def _unique_dest(dest_dir, basename):
    """Path libre en dest_dir para basename; añade (2), (3)... si ya existe.

    Tope de 999 para acotar el coste si xbmcvfs.exists() siempre devolviera
    True (FS corrupto, source de red colgada). Tras el tope, sobrescribimos
    para no bloquear el main thread indefinidamente.
    """
    candidate = dest_dir + basename
    if not xbmcvfs.exists(candidate):
        return candidate
    name, ext = os.path.splitext(basename)
    for n in range(2, 1000):
        candidate = dest_dir + f'{name} ({n}){ext}'
        if not xbmcvfs.exists(candidate):
            return candidate
    log.warning(f'library_add: tope de unique_dest alcanzado en {dest_dir!r}')
    return dest_dir + basename


def _file_in_source(filepath, sources):
    """Comprueba si filepath ya vive dentro de alguna source local."""
    try:
        real = os.path.normcase(os.path.realpath(xbmcvfs.translatePath(filepath)))
        for s in sources:
            raw = s['file']
            if '://' in raw:
                continue  # source de red: realpath no la resuelve
            src_real = os.path.normcase(os.path.realpath(xbmcvfs.translatePath(raw)))
            if os.path.commonpath([real, src_real]) == src_real:
                return True
    except (ValueError, OSError):
        pass
    return False


def _scan(kind, path):
    try:
        if kind == 'video':
            player.scan_video_library(path)
        else:
            player.scan_audio_library(path)
    except RPCError as e:
        log.warning(f'library_add: scan falló: {e}')
