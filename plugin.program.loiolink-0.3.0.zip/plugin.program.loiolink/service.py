"""Service en background.

Responsabilidades:
1. Drenar la cola de eventos UI de history.dequeue_event(). ÚNICO sitio
   seguro para mostrar Dialog en Kodi 19 (kodi#15378).
2. Mantener vivo el HTTP server permanente para control remoto desde el
   móvil (lib/remote/server_permanent).
3. Si el modo efímero está desactivado, mantener vivo también el servidor
   de recepción de texto (server.py) y procesar sus payloads.

Los puertos de ambos servidores se exponen via Window properties para que
las acciones del addon (remote_qr.py, receive_text.py) los lean sin
comunicación entre procesos por archivos o JSON-RPC.
"""
import xbmc
import xbmcaddon
import xbmcgui

import server as text_server_module
from lib import log, settings_migrations
from lib.remote import server_permanent
from lib.transfers import history
from lib.ui_select import confirm


REMOTE_PORT_PROP = 'loiolink.remote.port'
TEXT_PORT_PROP = 'loiolink.text.port'
# Scheme real con el que arrancó el servidor de texto persistente.
# Necesario porque tls.is_https_enabled() puede cambiar después del arranque
# y daría URLs con scheme incorrecto si se reconsulta al abrir el dialog.
TEXT_SCHEME_PROP = 'loiolink.text.scheme'
# Parada manual del servidor de texto (sin cambiar el setting persistente).
TEXT_STOPPED_PROP = 'loiolink.text.user_stopped'
# Gate del item "Copiar a loiolink" del menú contextual. Inversión a 'disabled'
# (ausencia=visible) para que sea safe cuando el service no ha arrancado.
CONTEXT_COPY_DISABLED_PROP = 'loiolink.context_copy.disabled'
SETTING_ENABLED = 'remote_server_enabled'
SETTING_EPHEMERAL = 'server_ephemeral_mode'
SETTING_CONTEXT_COPY_ENABLED = 'context_copy.enabled'
_BIND_BACKOFF_S = 30


def _read_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_ENABLED)
    except RuntimeError:
        return True


def _read_ephemeral_mode():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_EPHEMERAL)
    except RuntimeError:
        return True


def _read_context_copy_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_CONTEXT_COPY_ENABLED)
    except RuntimeError:
        return True


def _sync_context_copy_property(win):
    if _read_context_copy_enabled():
        win.clearProperty(CONTEXT_COPY_DISABLED_PROP)
    else:
        win.setProperty(CONTEXT_COPY_DISABLED_PROP, '1')


def _process_text_payload(payload):
    """Callback para el servidor de texto en modo persistente."""
    if not payload:
        return
    kind = payload.get('kind')
    if kind != 'text':
        # Magnets y uploads: el handler del server ya los encola en history;
        # _handle_event los mostrará. Solo necesitamos procesar texto.
        return
    import clipboard
    from lib import accessibility
    from lib.remote import keyboard_input
    text = payload['text']
    clipboard.set(text)
    accessibility.notify('Texto recibido y guardado', ms=2000)
    try:
        enabled = xbmcaddon.Addon().getSettingBool('remote.auto_inject_text')
    except (TypeError, RuntimeError):
        enabled = True
    if enabled:
        keyboard_input.try_inject(text, wait_appear_ms=1500)


def _handle_event(event):
    kind = event.get('kind')
    if kind == 'post_transfer':
        if event.get('confirm_upload'):
            from lib.transfers import history as _history
            entry = event['entry']
            name = entry.get('name', 'archivo')
            size = entry.get('size', 0)
            if size >= 1_048_576:
                size_str = f'{size / 1_048_576:.1f} MB'
            elif size >= 1024:
                size_str = f'{size // 1024} KB'
            else:
                size_str = f'{size} B'
            ip = event.get('sender_ip', 'red local')
            if not confirm(
                f'Archivo recibido desde {ip}:\n\n{name}  ({size_str})\n\n¿Aceptarlo?',
                title='loiolink',
                default_no=True,
            ):
                _history.delete(entry['id'], remove_file=True)
                xbmc.executebuiltin('Container.Refresh')
                return
        from lib.transfers import post_transfer
        post_transfer.show_post_transfer_dialog(
            event['entry'],
            already_played=event.get('already_played', False),
            forced_action=event.get('forced_action'),
            force_confirm=event.get('force_confirm', False),
        )
        # Container.Refresh fuerza al skin a recargar el container activo.
        # Si justo se ha lanzado reproducción (ya sea mi código en modo wait
        # o el _play_file del post_transfer con auto_action=True), el menú
        # está oculto bajo el video; refrescarlo es ruido y dispara el
        # BusyDialog del skin sobre el video (widgets cargando thumbnails,
        # scrapers, etc.). Skipear cuando hay player activo.
        try:
            if not xbmc.Player().isPlaying():
                xbmc.executebuiltin('Container.Refresh')
        except RuntimeError:
            xbmc.executebuiltin('Container.Refresh')
        return
    if kind == 'magnet_received':
        from lib.remote import elementum
        uri = event.get('uri', '')
        if not elementum.is_installed():
            from lib.actions import elementum as elementum_install
            if not elementum_install.install_with_progress():
                return
            if not elementum.is_installed():
                return
        preview = uri[:80] + ('...' if len(uri) > 80 else '')
        if confirm(
            f'Magnet recibido:\n{preview}\n\n¿Reproducir con Elementum?',
            title='loiolink', default_no=False,
        ):
            elementum.play(uri)
        return
    if kind == 'notification':
        from lib import accessibility
        accessibility.notify(event.get('msg', ''))
        return
    log.warning(f'Evento desconocido en cola: {kind}')


def run():
    monitor = xbmc.Monitor()
    win = xbmcgui.Window(10000)

    settings_migrations.apply_pending()

    from lib.remote import sessions
    sessions.migrate_legacy_token()

    import stats
    stats.ping()

    server = None
    last_bind_fail = 0.0

    text_server = None
    text_http_thread = None
    last_text_bind_fail = 0.0
    # Tracking del setting ephemeral para detectar transiciones. Sin esto,
    # al cambiar efímero→persistente un user_stopped pegado bloquearía el
    # arranque automático del server.
    prev_ephemeral = _read_ephemeral_mode()
    # Cleanup periódico de sesiones de upload chunked huérfanas (cliente
    # abandona, el navegador se cierra y no llega a /upload/finalize ni a
    # /upload/cancel). TTL configurable en settings.
    last_upload_cleanup = 0.0
    _UPLOAD_CLEANUP_INTERVAL_S = 3600  # 1 hora

    _sync_context_copy_property(win)

    if _read_enabled():
        server, port = server_permanent.start()
        if server is not None:
            win.setProperty(REMOTE_PORT_PROP, str(port))
            log.info(f'Service arrancado. Remote server en :{port}')
        else:
            log.error('No se pudo levantar el server remoto en ningún puerto')
            last_bind_fail = _time_now()
    else:
        log.info('Service arrancado con el panel del móvil DESACTIVADO')

    # Respetar user_stopped del addon-restart (Kodi sigue vivo, propiedad
    # persiste): si el usuario tenía el server apagado, no arrancarlo solo
    # para que el loop lo pare en <=1s (flap visible).
    if (_read_enabled() and not _read_ephemeral_mode()
            and win.getProperty(TEXT_STOPPED_PROP) != '1'):
        text_server, text_port, text_http_thread = (
            text_server_module.start_background(_process_text_payload)
        )
        if text_server is not None:
            win.setProperty(TEXT_PORT_PROP, str(text_port))
            win.setProperty(TEXT_SCHEME_PROP, getattr(text_server, '_scheme', 'http'))
            log.info(f'Servidor de texto persistente en :{text_port}')
        else:
            log.warning('No se pudo levantar el servidor de texto persistente')
            last_text_bind_fail = _time_now()

    try:
        while not monitor.abortRequested():
            _sync_context_copy_property(win)

            desired = _read_enabled()
            is_running = server is not None
            if desired and not is_running:
                if _time_now() - last_bind_fail >= _BIND_BACKOFF_S:
                    server, port = server_permanent.start()
                    if server is not None:
                        win.setProperty(REMOTE_PORT_PROP, str(port))
                        log.info(f'Server reactivado en :{port}')
                        last_bind_fail = 0.0
                    else:
                        last_bind_fail = _time_now()
                        log.warning(
                            'Bind fallido al reactivar el server; '
                            f'reintento en {_BIND_BACKOFF_S}s',
                        )
            elif is_running and not desired:
                server_permanent.stop(server)
                server = None
                win.clearProperty(REMOTE_PORT_PROP)
                log.info('Server detenido por petición del usuario')

            # Reconciliación del servidor de texto (modo persistente).
            # Detectar transición efímero→persistente: el usuario cambió a
            # persistente queriendo el server activo. Si user_stopped persistía
            # de un apagado anterior, limpiarlo evita que bloquee el arranque.
            curr_ephemeral = _read_ephemeral_mode()
            if prev_ephemeral and not curr_ephemeral:
                win.clearProperty(TEXT_STOPPED_PROP)
            prev_ephemeral = curr_ephemeral

            user_stopped = win.getProperty(TEXT_STOPPED_PROP) == '1'
            desired_persistent = desired and not curr_ephemeral and not user_stopped
            text_running = text_server is not None
            if desired_persistent and not text_running:
                if _time_now() - last_text_bind_fail >= _BIND_BACKOFF_S:
                    text_server, text_port, text_http_thread = (
                        text_server_module.start_background(_process_text_payload)
                    )
                    if text_server is not None:
                        win.setProperty(TEXT_PORT_PROP, str(text_port))
                        win.setProperty(TEXT_SCHEME_PROP,
                                        getattr(text_server, '_scheme', 'http'))
                        log.info(f'Servidor de texto reactivado en :{text_port}')
                        last_text_bind_fail = 0.0
                    else:
                        last_text_bind_fail = _time_now()
                        log.warning('Bind fallido al reactivar el servidor de texto')
            elif text_running and not desired_persistent:
                text_server_module.stop_background(text_server, text_http_thread)
                text_server = None
                text_http_thread = None
                win.clearProperty(TEXT_PORT_PROP)
                win.clearProperty(TEXT_SCHEME_PROP)
                log.info('Servidor de texto detenido por cambio de configuración')

            # Cleanup chunked upload sessions stale (cada hora).
            if _time_now() - last_upload_cleanup >= _UPLOAD_CLEANUP_INTERVAL_S:
                last_upload_cleanup = _time_now()
                try:
                    from lib.transfers import upload_session
                    ttl_h = 24
                    try:
                        ttl_h = int(xbmcaddon.Addon().getSetting(
                            'upload.session_ttl_hours') or '24')
                    except (ValueError, RuntimeError):
                        pass
                    n = upload_session.cleanup_stale(ttl_hours=ttl_h)
                    if n:
                        log.info(f'upload_session: limpiadas {n} sesiones stale')
                except Exception as e:
                    log.warning(f'upload_session.cleanup_stale falló: {e}')

            event = history.dequeue_event(timeout=1)
            if event is not None:
                try:
                    _handle_event(event)
                except Exception as e:
                    log.error(f'Error procesando evento {event!r}: {e}')
    finally:
        log.info('Service apagando')
        server_permanent.stop(server)
        if text_server is not None:
            text_server_module.stop_background(text_server, text_http_thread)
        win.clearProperty(REMOTE_PORT_PROP)
        win.clearProperty(TEXT_PORT_PROP)
        win.clearProperty(TEXT_SCHEME_PROP)
        win.clearProperty(CONTEXT_COPY_DISABLED_PROP)


def _time_now():
    import time
    return time.time()


if __name__ == '__main__':
    run()
