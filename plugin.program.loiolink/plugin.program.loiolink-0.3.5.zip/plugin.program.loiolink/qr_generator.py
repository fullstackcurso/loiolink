"""Genera QR PNG con segno (lib/segno). cleanup() es responsabilidad del llamador."""
import os
import struct
import sys
import tempfile
import zlib

import xbmc
import xbmcvfs

_QR_SCALE = 8
_QR_BORDER = 2


def generate(url):
    """Genera un QR PNG en /tmp y devuelve su path, o None si falla."""
    if not url:
        return None

    segno = _import_segno()
    if segno is None:
        return None

    try:
        qr = segno.make(url, micro=False, error="M")
        png = _encode_png_rgba(qr)
    except (ValueError, TypeError) as e:
        xbmc.log(f'[loiolink.qr_generator] no se pudo construir el QR: {e}', xbmc.LOGWARNING)
        return None

    # mkstemp evita colisiones entre invocaciones simultáneas.
    temp_dir = xbmcvfs.translatePath('special://temp/')
    try:
        fd, output_path = tempfile.mkstemp(prefix='loiolink_qr_', suffix='.png', dir=temp_dir)
    except OSError as e:
        xbmc.log(f'[loiolink.qr_generator] mkstemp fallo: {e}', xbmc.LOGWARNING)
        return None

    # Escribimos por el propio fd (una vez fdopen lo toma, el `with` es su único
    # dueño y lo cierra una sola vez; por eso el except NO llama a os.close, que con
    # los worker threads del server activos podría cerrar un fd ya reciclado).
    # Tras escribir + fsync, leemos el fichero de vuelta entero: confirma que quedó
    # legible (no bloqueado por el AV) antes de entregárselo a Kodi.
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(png)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass  # best-effort; el read-back de abajo es quien decide si vale
        with open(output_path, 'rb') as rb:
            head = rb.read(8)
            rb.read()  # agota el fichero: confirma legible entero + cierra el escaneo del AV
        if head != b'\x89PNG\r\n\x1a\n':
            raise ValueError('el fichero escrito no es un PNG legible')
        return output_path
    except (OSError, ValueError) as e:
        xbmc.log(f'[loiolink.qr_generator] no se pudo escribir/leer el QR: {e}', xbmc.LOGWARNING)
        try:
            os.remove(output_path)
        except OSError:
            pass
        return None


def _encode_png_rgba(qr):
    """Codifica la matriz del QR como PNG RGBA de 8 bits.

    segno solo emite PNG greyscale de 1 bit (o indexado de 2/4 bits). El cargador
    de texturas de Kodi renderiza ese formato en blanco de forma intermitente; el
    resto de imágenes del addon son RGBA8 y cargan siempre. Reconstruimos el PNG en
    RGBA8 desde la matriz para que Kodi lo trate igual que cualquier otro asset.
    """
    black = b'\x00\x00\x00\xff'
    white = b'\xff\xff\xff\xff'
    raw = bytearray()
    width = None
    height = 0
    for row in qr.matrix_iter(scale=_QR_SCALE, border=_QR_BORDER):
        raw.append(0)  # tipo de filtro PNG: None
        cols = 0
        for module in row:
            raw += black if module else white
            cols += 1
        if width is None:
            width = cols
        height += 1

    def _chunk(tag, data):
        body = tag + data
        return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body) & 0xFFFFFFFF)

    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    return (
        b'\x89PNG\r\n\x1a\n'
        + _chunk(b'IHDR', ihdr)
        + _chunk(b'IDAT', zlib.compress(bytes(raw), 9))
        + _chunk(b'IEND', b'')
    )


def cleanup(path):
    """Borra el PNG. Idempotente: ignora None o archivos inexistentes."""
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass


def _import_segno():
    """Importa la copia empaquetada en lib/segno antes de la del sistema."""
    lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")

    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)

    try:
        import segno
        return segno
    except ImportError:
        return None
