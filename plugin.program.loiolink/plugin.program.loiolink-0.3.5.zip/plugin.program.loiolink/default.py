"""Entry point del addon loiolink. Router puro y duro. Parsea ?action=X, despacha a lib/actions/.

Imports diferidos dentro de cada rama. El arranque del addon no carga
todos los módulos cuando el usuario solo va a usar uno. Cada acción se carga
en el momento que se necesita.
"""
import sys
from urllib.parse import parse_qsl


def _parse_params():
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    qs = sys.argv[2].lstrip('?')
    return dict(parse_qsl(qs))


def _prefetch_easter_egg_assets():
    import threading

    def _worker():
        import time as _t
        _t.sleep(5)
        try:
            import ascii_signature
            ascii_signature._ensure_ascii_jpg(silent=True)
        except Exception:
            pass

    threading.Thread(target=_worker, daemon=True).start()


def _route(action):
    _prefetch_easter_egg_assets()
    if action == 'receive_text':
        from lib.actions import receive_text
        return receive_text.run()
    if action == 'paste_clipboard':
        from lib.actions import paste_clipboard
        return paste_clipboard.run()
    if action == 'downloads_menu':
        from lib.actions import downloads_menu
        return downloads_menu.run()
    if action == 'download_url':
        from lib.actions import download_url
        return download_url.run()
    if action == 'download_code':
        from lib.actions import download_code
        return download_code.run()
    if action == 'download_telegram':
        from lib.actions import download_telegram
        return download_telegram.run()
    if action == 'history_view':
        from lib.actions import history_view
        return history_view.run()
    if action == 'entry':
        from lib.actions import entry_actions
        return entry_actions.run(_parse_params().get('id'))
    if action == 'remote_qr':
        from lib.actions import remote_qr
        return remote_qr.run()
    if action == 'streamninja':
        from lib.actions import streamninja
        return streamninja.run()
    if action == 'open_url_menu':
        from lib.actions import open_url_menu
        return open_url_menu.run()
    if action == 'open_url_input':
        from lib.actions import open_url_input
        return open_url_input.run(_parse_params().get('url'))
    if action == 'url_input_history_menu':
        from lib.actions import url_input_history_menu
        return url_input_history_menu.run()
    if action == 'url_input_history_clear':
        from lib.actions import url_input_history_menu
        return url_input_history_menu.clear()
    if action == 'url_history_remove':
        from lib.actions import url_input_history_menu
        return url_input_history_menu.remove_one(_parse_params().get('url'))
    if action == 'url_history_download':
        from lib.actions import url_input_history_menu
        return url_input_history_menu.download(_parse_params().get('url'))
    if action == 'url_bookmarks_menu':
        from lib.actions import url_bookmarks_menu
        return url_bookmarks_menu.run()
    if action == 'url_bookmarks_clear':
        from lib.actions import url_bookmarks_menu
        return url_bookmarks_menu.clear()
    if action == 'url_bookmark_add_from_history':
        from lib.actions import url_bookmarks_menu
        return url_bookmarks_menu.add_from_history(_parse_params().get('url'))
    if action == 'url_bookmark_remove':
        from lib.actions import url_bookmarks_menu
        return url_bookmarks_menu.remove(_parse_params().get('url'))
    if action == 'url_bookmark_rename':
        from lib.actions import url_bookmarks_menu
        return url_bookmarks_menu.rename(_parse_params().get('url'))

    if action == 'options_menu':
        from lib.actions import options_menu
        return options_menu.run()
    if action == 'opt_toggle':
        from lib.actions import options_menu
        return options_menu.toggle(_parse_params().get('key'))
    if action == 'opt_num':
        from lib.actions import options_menu
        p = _parse_params()
        return options_menu.num(
            p.get('key'), int(p.get('lo')), int(p.get('hi')),
            p.get('heading', ''),
        )
    if action == 'opt_text':
        from lib.actions import options_menu
        p = _parse_params()
        return options_menu.text(p.get('key'), p.get('heading', ''))
    if action == 'opt_folder':
        from lib.actions import options_menu
        p = _parse_params()
        return options_menu.folder(p.get('key'), p.get('heading', ''))
    if action == 'opt_enum':
        from lib.actions import options_menu
        p = _parse_params()
        return options_menu.enum(p.get('key'), p.get('values', ''), p.get('heading', ''))
    if action == 'opt_cycle':
        from lib.actions import options_menu
        p = _parse_params()
        return options_menu.cycle(p.get('key'), int(p.get('n', 2)))
    if action == 'opt_backup_password':
        from lib.actions import options_menu
        return options_menu.backup_password()
    if action == 'accessibility_menu':
        from lib.actions import accessibility_menu
        return accessibility_menu.run()
    if action == 'debug_menu':
        from lib.actions import debug_menu
        return debug_menu.run()
    if action == 'ui_diag':
        from lib.actions import ui_diag
        return ui_diag.run()
    if action == 'options_receive_menu':
        from lib.actions import options_receive_menu
        return options_receive_menu.run()
    if action == 'options_paste_menu':
        from lib.actions import options_paste_menu
        return options_paste_menu.run()
    if action == 'options_remote_menu':
        from lib.actions import options_remote_menu
        return options_remote_menu.run()
    if action == 'options_downloads_menu':
        from lib.actions import options_downloads_menu
        return options_downloads_menu.run()
    if action == 'options_advanced_menu':
        from lib.actions import options_advanced_menu
        return options_advanced_menu.run()
    if action == 'options_backup_menu':
        from lib.actions import options_backup_menu
        return options_backup_menu.run()
    if action == 'about':
        from lib.actions import about
        return about.run()
    if action == 'sources_repos_menu':
        from lib.actions import sources_repos_menu
        return sources_repos_menu.run()
    if action == 'file_browser':
        from lib.actions import file_browser
        p = _parse_params()
        return file_browser.run(p.get('path'))
    if action == 'file_browser_op':
        from lib.actions import file_browser
        p = _parse_params()
        return file_browser.op(p.get('op'), p.get('path'), p.get('name'))
    if action == 'backup_menu':
        from lib.actions import sources_repos_menu
        return sources_repos_menu.run_backup()
    if action == 'play_media':
        from lib.actions import file_browser
        p = _parse_params()
        return file_browser.play_media(p.get('path'), p.get('kind', 'video'))
    if action == 'install_file':
        from lib.actions import file_browser
        return file_browser.install_file(_parse_params().get('path'))
    if action == 'open_image':
        from lib.actions import file_browser
        return file_browser.open_image(_parse_params().get('path'))
    if action == 'settings':
        from lib.actions import settings_shortcut
        return settings_shortcut.run()
    if action == 'clipboard_view':
        from lib.actions import clipboard_view
        return clipboard_view.run()
    if action == 'clipboard_clear':
        from lib.actions import clipboard_clear
        return clipboard_clear.run()
    if action == 'diagnostics':
        from lib.actions import diagnostics
        return diagnostics.run()
    if action == 'ytdlp_recheck':
        from lib.actions import ytdlp_recheck
        return ytdlp_recheck.run()
    if action == 'regenerate_token':
        from lib.actions import regenerate_token
        return regenerate_token.run()
    if action == 'regenerate_https_cert':
        from lib.actions import regenerate_https_cert
        return regenerate_https_cert.run()
    if action == 'toggle_https':
        from lib.actions import options_menu
        return options_menu.toggle_https()
    if action == 'toggle_remote_server':
        from lib.actions import toggle_remote_server
        return toggle_remote_server.run()
    if action == 'toggle_text_server':
        from lib.actions import toggle_text_server
        return toggle_text_server.run()
    if action == 'import_clipboard':
        from lib.actions import import_clipboard
        return import_clipboard.run()
    if action == 'clipboard_submenu':
        from lib.actions import clipboard_submenu
        return clipboard_submenu.run()
    if action == 'clipboard_test':
        from lib.actions import clipboard_test
        return clipboard_test.run()
    if action == 'clipboard_test_copy':
        from lib.actions import clipboard_test
        return clipboard_test.copy(_parse_params().get('idx'))
    if action == 'clipboard_test_paste':
        from lib.actions import clipboard_test
        return clipboard_test.paste_and_see()
    if action == 'clipboard_test_suite':
        from lib.actions import clipboard_test
        return clipboard_test.suite()
    if action == 'clipboard_test_flakiness':
        from lib.actions import clipboard_test
        return clipboard_test.flakiness()
    if action == 'clipboard_test_compare':
        from lib.actions import clipboard_test
        return clipboard_test.compare()
    if action == 'clipboard_test_mutex':
        from lib.actions import clipboard_test
        return clipboard_test.mutex()
    if action == 'clipboard_test_detection':
        from lib.actions import clipboard_test
        return clipboard_test.detection()
    if action == 'clipboard_test_all':
        from lib.actions import clipboard_test
        return clipboard_test.run_all_no_mutex()
    if action == 'cleanup_menu':
        from lib.actions import cleanup_menu
        return cleanup_menu.run()
    if action == 'wizard':
        from lib.actions import first_run_wizard
        return first_run_wizard.run(force=True)
    if action == 'information_menu':
        from lib.actions import information_menu
        return information_menu.run()
    if action == 'open_user_manual':
        from lib.actions import user_manual
        return user_manual.run()
    if action == 'show_universo':
        import universo
        return universo.show()
    if action == 'loioloio_addons_menu':
        from lib.actions import loioloio_addons_menu
        return loioloio_addons_menu.run()
    if action == 'loioloio_install':
        from lib.actions import loioloio_install
        return loioloio_install.run(_parse_params().get('addon_id'))
    if action == 'loioloio_about':
        from lib.actions import loioloio_about
        return loioloio_about.run()
    if action == 'noop':
        # Separadores del menú: ignorar pulsación.
        return None
    from lib.actions import menu
    return menu.run()


if __name__ == '__main__':
    _route(_parse_params().get('action'))
