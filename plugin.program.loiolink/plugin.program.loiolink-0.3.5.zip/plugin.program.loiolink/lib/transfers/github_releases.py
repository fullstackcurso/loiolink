"""Resuelve enlaces de GitHub releases a sus assets descargables (API REST).

Sin token: la API permite 60 peticiones/hora por IP, de sobra para instalar
addons puntualmente. GitHub exige cabecera User-Agent (responde 403 sin ella).
"""
import json
import re
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

_API = "https://api.github.com/repos/{owner}/{repo}"
_UA = "loiolink/1.0 (+https://github.com/espatv/loiolink)"
_TIMEOUT = 12
_ASSET_EXTS = (".zip", ".apk", ".rar", ".7z")

# Path de un enlace de releases: /owner/repo/releases[/latest | /tag/<tag>].
# NO casa /releases/download/...: eso ya es un asset directo (lo resuelve la ruta
# de extensión del scanner/dispatch).
_PATH_RE = re.compile(
    r"^/([^/]+)/([^/]+)/releases/?(?:latest/?|tag/([^/?#]+)/?)?$", re.I,
)


class GitHubError(Exception):
    """Fallo resolviendo una release (no encontrada, rate limit, sin assets...)."""


def _parse(url):
    """(owner, repo, tag|None) si ``url`` es un enlace de releases de github.com.

    Devuelve None si no lo es. El host se ancla con urlparse (no una regex sobre
    la URL entera) para que 'notgithub.com/.../releases' no dé falso positivo y
    para que una query string no rompa el match.
    """
    parsed = urlparse(url if "://" in (url or "") else "https://" + (url or ""))
    if (parsed.hostname or "").lower() not in ("github.com", "www.github.com"):
        return None
    m = _PATH_RE.match(parsed.path)
    if not m:
        return None
    repo = m.group(2)
    if repo.endswith(".git"):          # compat Python 3.8: str.removesuffix es 3.9+
        repo = repo[:-4]
    return m.group(1), repo, m.group(3)


def is_release_url(url):
    return _parse(url) is not None


def _api_get(endpoint):
    req = Request(endpoint, headers={
        "User-Agent": _UA,
        "Accept": "application/vnd.github+json",
    })
    with urlopen(req, timeout=_TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _fetch_release(base, tag):
    """Devuelve el JSON de la release pedida; lanza GitHubError con mensaje claro."""
    try:
        if tag:
            return _api_get(f"{base}/releases/tags/{tag}")
        try:
            return _api_get(f"{base}/releases/latest")
        except HTTPError as e:
            if e.code != 404:
                raise
            # El repo no tiene release marcada "Latest" (p. ej. solo prereleases):
            # cogemos la más reciente de la lista.
            releases = _api_get(f"{base}/releases")
            if not releases:
                raise GitHubError("El repositorio no tiene releases.") from e
            return releases[0]
    except HTTPError as e:
        if e.code == 404:
            raise GitHubError("Release o repositorio no encontrado.") from e
        if e.code == 403:
            raise GitHubError(
                "Límite de la API de GitHub alcanzado; inténtalo en un rato.",
            ) from e
        raise GitHubError(f"GitHub respondió HTTP {e.code}.") from e
    except (OSError, ValueError) as e:
        # OSError cubre URLError y socket.timeout; ValueError, JSON malformado.
        raise GitHubError(f"No se pudo consultar GitHub: {e}") from e


def resolve(url):
    """Lista de assets descargables [{name, url, size}] de la release.

    Usa la release "Latest" de GitHub; si el repo no tiene ninguna, cae a la más
    reciente. Con /tag/<tag>, esa versión concreta. Lanza GitHubError ante fallo.
    """
    parsed = _parse(url)
    if parsed is None:
        raise GitHubError("No es un enlace de GitHub releases.")
    owner, repo, tag = parsed

    release = _fetch_release(_API.format(owner=owner, repo=repo), tag)
    assets = [
        {"name": a.get("name", ""), "url": a.get("browser_download_url", ""),
         "size": a.get("size")}
        for a in release.get("assets", [])
        if a.get("browser_download_url", "").lower().endswith(_ASSET_EXTS)
    ]
    if not assets:
        raise GitHubError("La release no tiene archivos .zip/.apk descargables.")
    return assets
