# -*- coding: utf-8 -*-
"""Menú 'Limpieza y mantenimiento'.

Reúne la limpieza de lo que loiolink deja en disco (papelera del explorador y
QR temporales huérfanos) y el acceso al mantenimiento del propio Kodi
(paquetes, miniaturas, bases de datos…), que vive en lib/kodi_maintenance.py.
"""
import glob
import os
import time

import xbmcgui
import xbmcvfs

from lib import log
from lib.remote import trash


# Un QR sigue en uso mientras su diálogo (modal) está abierto; desde este menú
# no puede haber uno mostrándose. Aun así solo se borran los que llevan rato en
# disco, por si un proceso en segundo plano dejara uno reciente. En operación
# normal su propio diálogo los borra al cerrarse; los que quedan son restos de
# un cierre abrupto de Kodi.
_QR_ORPHAN_AGE_S = 3600
_QR_GLOB = 'loiolink_qr_*.png'

_HELP = '\n'.join([
    'LIMPIEZA Y MANTENIMIENTO',
    '─' * 40,
    '',
    'Libera espacio sin tocar tu configuración ni tus datos.',
    '',
    '  • Temporales del addon: imágenes QR que quedaron de',
    '    sesiones anteriores. Se regeneran al usar el servidor.',
    '  • Vaciar papelera: borra definitivamente lo que enviaste',
    '    a la papelera desde el explorador de archivos.',
    '  • Mantenimiento de Kodi: limpia y optimiza Kodi en general',
    '    (paquetes, miniaturas en desuso, bases de datos, crashlogs)',
    '    y respalda la configuración del sistema.',
    '',
    'Tus addons, repositorios y favoritos se respaldan aparte,',
    "en 'Backup y restauración'.",
])


def fmt_size(b):
    if b < 1024:
        return f'{b} B'
    if b < 1024 * 1024:
        return f'{b / 1024:.1f} KB'
    return f'{b / 1024 / 1024:.2f} MB'


def _safe_size(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _walk_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            total += _safe_size(os.path.join(root, f))
    return total


def _qr_orphans():
    """PNG temporales de QR sin tocar desde hace _QR_ORPHAN_AGE_S."""
    temp_dir = xbmcvfs.translatePath('special://temp/')
    cutoff = time.time() - _QR_ORPHAN_AGE_S
    out = []
    for p in glob.glob(os.path.join(temp_dir, _QR_GLOB)):
        try:
            if os.path.getmtime(p) < cutoff:
                out.append(p)
        except OSError:
            pass
    return out


def _clean_qr(paths):
    total = sum(_safe_size(p) for p in paths)
    if not xbmcgui.Dialog().yesno(
            'Temporales del addon',
            f'Se borrarán {len(paths)} imágenes QR temporales '
            f'([B]{fmt_size(total)}[/B]) que quedaron de sesiones anteriores.\n\n'
            'Se regeneran solas cuando vuelvas a usar el servidor o el QR.\n\n'
            '¿Continuar?'):
        return
    freed = 0
    for p in paths:
        sz = _safe_size(p)
        try:
            os.remove(p)
            freed += sz
        except OSError as e:
            log.warning(f'[cleanup] no se pudo borrar {p}: {e}')
    xbmcgui.Dialog().notification('loiolink', f'Liberados {fmt_size(freed)}',
                                  xbmcgui.NOTIFICATION_INFO, 3000)


def _empty_trash(items, size):
    if not xbmcgui.Dialog().yesno(
            'Vaciar papelera',
            f'Se borrarán definitivamente {len(items)} elementos de la papelera '
            f'([B]{fmt_size(size)}[/B]).\n\n'
            '[COLOR red]Esto no se puede deshacer[/COLOR]; los archivos no se '
            'podrán restaurar.\n\n¿Continuar?'):
        return
    n = trash.purge_all()
    xbmcgui.Dialog().notification('loiolink', f'Papelera vaciada ({n} elementos)',
                                  xbmcgui.NOTIFICATION_INFO, 3000)


def run():
    """Diálogo en bucle. Un fallo en una opción vuelve al menú, no expulsa."""
    while True:
        try:
            qr_orphans = _qr_orphans()
            qr_size = sum(_safe_size(p) for p in qr_orphans)
            items = trash.list_trash()
            trash_size = _walk_size(trash.trash_dir())
            total = qr_size + trash_size

            opciones, acciones = [], []
            if qr_size > 0:
                opciones.append(f'Temporales del addon    [COLOR grey]{fmt_size(qr_size)}[/COLOR]')
                acciones.append('qr')
            if items:
                opciones.append(
                    f'Vaciar papelera ({len(items)})    [COLOR grey]{fmt_size(trash_size)}[/COLOR]')
                acciones.append('trash')
            opciones.append('[COLOR orange]Mantenimiento de Kodi…[/COLOR]')
            acciones.append('kodi')
            opciones.append('[COLOR grey]¿Qué se limpia? (ayuda)[/COLOR]')
            acciones.append('info')

            heading = (f'Limpieza y mantenimiento - {fmt_size(total)} liberables'
                       if total > 0 else 'Limpieza y mantenimiento')
            idx = xbmcgui.Dialog().select(heading, opciones)
            if idx < 0:
                break
            a = acciones[idx]
            if a == 'qr':
                _clean_qr(qr_orphans)
            elif a == 'trash':
                _empty_trash(items, trash_size)
            elif a == 'kodi':
                from lib import kodi_maintenance
                kodi_maintenance.maintenance_menu()
            elif a == 'info':
                xbmcgui.Dialog().textviewer('Limpieza y mantenimiento - ayuda', _HELP)
        except Exception as e:  # handler de UI: registra, avisa y vuelve al menú
            log.error(f'[cleanup] error inesperado en el menú: {e}')
            xbmcgui.Dialog().ok('loiolink', f'Se produjo un error en limpieza:\n{e}')
