"""Submenú de opciones de depuración."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Debug')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='diagnostics.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    dbg_sensitive = _ADDON.getSettingBool('debug.sensitive_log')
    add(
        f'Log de datos sensibles: {mc.color_bool(dbg_sensitive)}',
        mc.url('opt_toggle', key='debug.sensitive_log'),
        'Si está activado, el log de Kodi incluirá rutas de archivos, URLs externas '
        'y nombres de transferencias. Desactivado por defecto; actívalo solo para depurar.',
    )

    dbg_test = _ADDON.getSettingBool('debug.clipboard_test')
    add(
        f'Test de depuración del pegado: {mc.color_bool(dbg_test)}',
        mc.url('opt_toggle', key='debug.clipboard_test'),
        'Muestra el submenú "Test (depurar pegado)" en Portapapeles interno. '
        'Útil para diagnosticar fallos del flujo de pegado del menú contextual.',
    )

    add(
        'Diagnóstico de ventanas (UI)',
        mc.url('ui_diag'),
        'Dibuja el borde de la rejilla 1280x720 y del panel, sondea las fuentes '
        'del skin y abre una prueba de estrés del ui_select real. Para diagnosticar '
        'por qué el contenido se sale del panel en algunos skins. Solo lectura.',
    )

    mc.end()
