# -*- coding: utf-8 -*-
"""Submenú 'Descargar': dirección web, código numérico e historial de transferencias."""
import os
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility, i18n


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MENU_ICONS = os.path.join(_ADDON_PATH, 'resources', 'media', 'menu')


def _icon_path(filename):
    if not filename:
        return None
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def _item(label, action, plot='', icon=None, is_folder=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label))
    if plot:
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
    icon_p = _icon_path(icon)
    if icon_p:
        li.setArt({'icon': icon_p, 'thumb': icon_p})
    url = f'{_BASE_URL}?action={action}'
    xbmcplugin.addDirectoryItem(
        handle=_HANDLE, url=url, listitem=li, isFolder=is_folder,
    )


def _history_label():
    try:
        prop = xbmcgui.Window(10000).getProperty('loiolink.history.count')
        n = int(prop) if prop else None
    except (ValueError, RuntimeError):
        n = None
    if n is None:
        try:
            from lib.transfers import history
            n = len(history.list_all())
        except (ImportError, AttributeError, OSError):
            n = 0
    if n == 0:
        return i18n.L(30021)
    return i18n.L(30020, n=n)


_PLOT_DL_URL = (
    'Pega una dirección web y Kodi descarga el archivo directamente. '
    'Google Drive y MediaFire tienen soporte nativo.'
)
_PLOT_DL_CODE = (
    'Lo mismo que hace la app Downloader de AFTVnews. Escribes el código corto '
    'de varios dígitos que normalmente se comparte en lugar de la URL larga, el '
    'addon lo resuelve contra go.aftvnews.com y descarga el archivo de destino '
    'sin más pasos. Útil para enlaces de APK, ZIP o cualquier descarga directa '
    'publicada con código abreviado.'
)
_PLOT_DL_TELEGRAM = (
    'Escanea un canal público de Telegram (escribe @canal, t.me/canal o solo '
    'el nombre) y lista los archivos y enlaces que comparte. Elige uno para '
    'descargarlo; si es un vídeo directo puedes reproducirlo en lugar de '
    'descargarlo, y los enlaces a streams o plataformas se abren directamente. '
    'Solo funciona con canales públicos, no con invitaciones privadas.'
)
_PLOT_HISTORY = (
    'Resumen de todas las transferencias previas con su estado. Desde la lista '
    'puedes volver a abrir cada elemento, borrarlo o ver los detalles internos '
    'por si necesitas depurar algo.'
)


def run():
    _item(i18n.L(30003), 'download_url', plot=_PLOT_DL_URL, icon='url.png')
    _item(i18n.L(30004), 'download_code', plot=_PLOT_DL_CODE, icon='code.png')
    _item(i18n.L(30009), 'download_telegram', plot=_PLOT_DL_TELEGRAM, icon='telegram.png')
    _item(_history_label(), 'history_view', plot=_PLOT_HISTORY, icon='history.png',
          is_folder=True)
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
