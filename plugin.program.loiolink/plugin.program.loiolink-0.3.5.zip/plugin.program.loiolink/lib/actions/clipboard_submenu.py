# -*- coding: utf-8 -*-
"""Submenú 'Portapapeles': importar del SO, ver contenido interno y limpiar."""
import os
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility, i18n


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MENU_ICONS = os.path.join(_ADDON_PATH, 'resources', 'media', 'menu')


def _icon_path(filename):
    if not filename:
        return None
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def _item(label, action, plot='', icon=None, is_folder=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label))
    if plot:
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
    icon_p = _icon_path(icon)
    if icon_p:
        li.setArt({'icon': icon_p, 'thumb': icon_p})
    url = f'{_BASE_URL}?action={action}'
    xbmcplugin.addDirectoryItem(
        handle=_HANDLE, url=url, listitem=li, isFolder=is_folder,
    )


_PLOT_PASTE = (
    'Trae lo que tengas copiado en cualquier otro sitio del ordenador '
    '(navegador, bloc de notas, otro programa). Si es un magnet lo lanza '
    'directamente en Elementum para reproducirlo. Si es texto normal queda '
    'guardado dentro del addon, listo para inyectarlo en el cuadro de búsqueda '
    'de cualquier addon de Kodi sin tener que teclearlo a mano. Al abrir el '
    'menú contextual sobre la barra de búsqueda aparece una opción "Pegar" '
    'que mete el texto guardado. En Android puede que no funcione, porque '
    'Kodi no da acceso al portapapeles del sistema en esa plataforma.'
)
_PLOT_CLIPBOARD = (
    'Lo que el addon guarda ahora mismo en su propio portapapeles interno. '
    'Desde aquí puedes vaciarlo, leer el contenido completo o moverlo al '
    'portapapeles del sistema.'
)


def run():
    _item(i18n.L(30002), 'paste_clipboard', plot=_PLOT_PASTE, icon='clipboard.png')
    _item(i18n.L(30100), 'clipboard_view', plot=_PLOT_CLIPBOARD, icon='view.png')
    _item(i18n.L(30101), 'clipboard_clear')
    if xbmcaddon.Addon().getSettingBool('debug.clipboard_test'):
        _item('Test (depurar pegado)', 'clipboard_test', is_folder=True)
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
