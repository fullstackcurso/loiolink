"""Resuelve URLs públicas de servicios a la forma `plugin://` que Kodi
reproduce.

Servicios cubiertos: YouTube, Twitch (live/VOD/clip), Vimeo, SoundCloud.
Para cada uno se intenta una cadena de plugins en orden de preferencia
y, como fallback universal, `plugin.video.sendtokodi` (yt-dlp).

Para URLs que no coinciden con ningún servicio conocido (file-hosters tipo
streamtape/doodstream/mixdrop, o enlaces debrid), se intenta como último
recurso ResolveURL (`script.module.resolveurl`) si está instalado. Cubre
una clase de enlaces distinta a yt-dlp y corre en el Python embebido de
Kodi, así que también funciona en Android.

El resolver es deliberadamente conservador:

- Solo activa cuando la URL coincide con un patrón conocido. Cualquier
  otra URL se devuelve tal cual (caller decide).
- Solo construye `plugin://` cuando el plugin destino está instalado y
  habilitado en Kodi (`installer.is_ready`). Generar una URL apuntando a
  un plugin ausente produciría un error opaco al usuario.
- NO se invoca desde el handler `/cast` ANTES del whitelist de esquemas;
  primero se valida que el input sea http/https y se aplica resolver.
  El resultado plugin:// es construido por nosotros (no procede del
  cliente) y por tanto es seguro pasarlo a Player.Open.
"""
import re
from dataclasses import dataclass
from typing import Callable, Iterable, Optional
from urllib.parse import quote as _urlquote

import xbmc

from lib import installer, log


# Tipo del callable que cada resolver expone. Recibe el match del
# pattern y la URL original; devuelve `plugin://` o None si no hay
# plugin disponible.
_Builder = Callable[[re.Match, str], Optional[str]]


def _has(addon_id: str) -> bool:
    """Indirección sobre `installer.is_ready` para mockear en tests."""
    return installer.is_ready(addon_id)


# YouTube

# Identificador de vídeo: exactamente 11 chars del alfabeto base64 URL-safe.
_YT_ID = r'[A-Za-z0-9_-]{11}'

_YT_PATTERNS = (
    # youtube.com/watch?v=ID  (con o sin sub-dominios m./music./www.)
    re.compile(
        r'(?:https?://)?(?:www\.|m\.|music\.)?youtube\.com/watch\?'
        r'(?:[^#]*&)?v=(?P<id>' + _YT_ID + r')',
        re.IGNORECASE,
    ),
    # youtu.be/ID
    re.compile(
        r'(?:https?://)?youtu\.be/(?P<id>' + _YT_ID + r')',
        re.IGNORECASE,
    ),
    # youtube.com/shorts/ID, /live/ID, /embed/ID
    re.compile(
        r'(?:https?://)?(?:www\.|m\.)?youtube\.com/'
        r'(?:shorts|live|embed)/(?P<id>' + _YT_ID + r')',
        re.IGNORECASE,
    ),
    # youtube-nocookie.com/embed/ID
    re.compile(
        r'(?:https?://)?(?:www\.)?youtube-nocookie\.com/'
        r'embed/(?P<id>' + _YT_ID + r')',
        re.IGNORECASE,
    ),
)


def _build_youtube(m: re.Match, url: str) -> Optional[str]:
    vid = m.group('id')
    if _has('plugin.video.youtube'):
        return f'plugin://plugin.video.youtube/play/?video_id={vid}'
    if _has('plugin.video.piped'):
        return f'plugin://plugin.video.piped/watch/{vid}'
    if _has('plugin.video.tubed'):
        return f'plugin://plugin.video.tubed/?mode=play&video_id={vid}'
    if _has('plugin.video.sendtokodi'):
        # sendtokodi acepta la URL original como path tras el '?'.
        canonical = f'https://www.youtube.com/watch?v={vid}'
        return f'plugin://plugin.video.sendtokodi/?{canonical}'
    # Último escalón: yt-dlp del sistema (cuando ningún plugin está
    # disponible). Devuelve URL directa al stream con pipe-headers si los
    # hay. Solo se ejecuta cuando is_installed() lee el cache positivo —
    # cold path tarda unos pocos segundos pero solo la primera vez.
    return _try_ytdlp(f'https://www.youtube.com/watch?v={vid}')


# Twitch

# VOD: twitch.tv/videos/<digits>
_TW_VOD = re.compile(
    r'(?:https?://)?(?:www\.|m\.)?twitch\.tv/videos/(?P<id>\d+)',
    re.IGNORECASE,
)

# Clip: clips.twitch.tv/<slug>  o  twitch.tv/<channel>/clip/<slug>
_TW_CLIP_DOMAIN = re.compile(
    r'(?:https?://)?clips\.twitch\.tv/(?P<slug>[A-Za-z0-9_-]+)',
    re.IGNORECASE,
)
_TW_CLIP_PATH = re.compile(
    r'(?:https?://)?(?:www\.|m\.)?twitch\.tv/'
    r'[^/]+/clip/(?P<slug>[A-Za-z0-9_-]+)',
    re.IGNORECASE,
)

# Live: twitch.tv/<channel>  (último; cualquier path anterior gana).
_TW_LIVE = re.compile(
    r'(?:https?://)?(?:www\.|m\.)?twitch\.tv/'
    r'(?P<channel>[a-zA-Z0-9_]{3,25})/?(?:\?[^/]*)?$',
    re.IGNORECASE,
)

# Paths reservados en twitch.tv que NO son canales. Verificación
# post-match (mantiene la regex compacta y fácil de auditar).
_TW_RESERVED_CHANNELS = frozenset({
    'videos', 'directory', 'p', 'search', 'settings', 'subscriptions',
    'wallet', 'jobs', 'turbo', 'prime', 'login', 'signup', 'logout',
    'downloads', 'creatorcamp', 'broadcast',
})


def _build_twitch_vod(m: re.Match, url: str) -> Optional[str]:
    vid = m.group('id')
    if _has('plugin.video.twitch'):
        return f'plugin://plugin.video.twitch/?mode=play&video_id={vid}'
    if _has('plugin.video.sendtokodi'):
        return f'plugin://plugin.video.sendtokodi/?https://www.twitch.tv/videos/{vid}'
    return None


def _build_twitch_clip(m: re.Match, url: str) -> Optional[str]:
    slug = m.group('slug')
    if _has('plugin.video.twitch'):
        return f'plugin://plugin.video.twitch/?mode=play&slug={slug}'
    if _has('plugin.video.sendtokodi'):
        return f'plugin://plugin.video.sendtokodi/?https://clips.twitch.tv/{slug}'
    return None


def _build_twitch_live(m: re.Match, url: str) -> Optional[str]:
    channel = m.group('channel')
    # Filtrado post-match: el regex captura cualquier slug de 3-25 chars,
    # pero Twitch reserva varios prefijos del sitio (/directory, /search,
    # /settings...). Tratarlos como canal generaría plugin:// inválidos.
    if channel.lower() in _TW_RESERVED_CHANNELS:
        return None
    if _has('plugin.video.twitch'):
        return f'plugin://plugin.video.twitch/?mode=play&channel_name={channel}'
    if _has('plugin.video.sendtokodi'):
        return f'plugin://plugin.video.sendtokodi/?https://www.twitch.tv/{channel}'
    return None


# Vimeo

# vimeo.com/<digits>[/optional_hash] o player.vimeo.com/video/<digits>
_VIMEO_PATTERNS = (
    re.compile(
        r'(?:https?://)?player\.vimeo\.com/video/(?P<id>\d+)'
        r'(?:[?/]h(?:ash)?=(?P<hash>[A-Za-z0-9]+))?',
        re.IGNORECASE,
    ),
    re.compile(
        r'(?:https?://)?(?:www\.)?vimeo\.com/(?P<id>\d+)'
        r'(?:/(?P<hash>[A-Za-z0-9]+))?',
        re.IGNORECASE,
    ),
)


def _build_vimeo(m: re.Match, url: str) -> Optional[str]:
    vid = m.group('id')
    h = m.groupdict().get('hash')
    if _has('plugin.video.vimeo'):
        suffix = f':{h}' if h else ''
        return f'plugin://plugin.video.vimeo/play/?video_id={vid}{suffix}'
    if _has('plugin.video.sendtokodi'):
        return f'plugin://plugin.video.sendtokodi/?https://vimeo.com/{vid}'
    return None


# SoundCloud

_SC_PATTERN = re.compile(
    r'(?:https?://)?(?:www\.|m\.|mobi\.)?soundcloud\.com/[^?\s]+',
    re.IGNORECASE,
)


def _build_soundcloud(m: re.Match, url: str) -> Optional[str]:
    # SoundCloud necesita la URL completa, no un ID. Codificamos para
    # el querystring del plugin oficial.
    if _has('plugin.audio.soundcloud'):
        encoded = _urlquote(url, safe='')
        return f'plugin://plugin.audio.soundcloud/play/?url={encoded}'
    if _has('plugin.video.sendtokodi'):
        return f'plugin://plugin.video.sendtokodi/?{url}'
    return None


# Dailymotion

# ID estilo `x8abc12` (letra inicial + base36, ~6-12 chars típicamente).
# Aceptamos rango amplio porque DM no documenta el formato y ha variado.
_DM_ID = r'[a-zA-Z0-9]{5,20}'

_DM_PATTERNS = (
    # dailymotion.com/video/<id>  (con o sin www./touch./geo.)
    re.compile(
        r'(?:https?://)?(?:www\.|touch\.|geo\.)?dailymotion\.com/video/'
        r'(?P<id>' + _DM_ID + r')',
        re.IGNORECASE,
    ),
    # dailymotion.com/embed/video/<id>
    re.compile(
        r'(?:https?://)?(?:www\.)?dailymotion\.com/embed/video/'
        r'(?P<id>' + _DM_ID + r')',
        re.IGNORECASE,
    ),
    # dai.ly/<id> (shortener)
    re.compile(
        r'(?:https?://)?dai\.ly/(?P<id>' + _DM_ID + r')',
        re.IGNORECASE,
    ),
)


def _build_dailymotion(m: re.Match, url: str) -> Optional[str]:
    vid = m.group('id')
    # plugin.video.dailymotion_com (gujal) acepta el ID via querystring.
    # API verificada en resources/lib/dailymotion.py:836 (`mode == 'playVideo'`).
    if _has('plugin.video.dailymotion_com'):
        return (
            f'plugin://plugin.video.dailymotion_com/'
            f'?url={_urlquote(vid, safe="")}&mode=playVideo'
        )
    if _has('plugin.video.sendtokodi'):
        return (
            f'plugin://plugin.video.sendtokodi/'
            f'?https://www.dailymotion.com/video/{vid}'
        )
    # Sin plugin: cadena propia yt-dlp → dm_gujal embebido. Cubre Android
    # (sin python del sistema) y Windows con CDN block (dm_gujal usa UA
    # móvil Android para esquivar el 403).
    from lib import dm_resolver
    return dm_resolver.resolve(url)


def _try_ytdlp(canonical_url: str) -> Optional[str]:
    """Fallback yt-dlp con dos backends, en orden:

    1. yt-dlp del sistema (subprocess) si está instalado — el más potente
       (runtime JS para YouTube, 1800+ sitios).
    2. el addon `script.module.youtube.dl` (in-process) si el sistema no está
       o falla — más limitado pero funciona en Android y sin Python de sistema.

    Devuelve URL directa al stream con pipe-headers o None.
    """
    from lib import ytdlp_resolver
    info = None
    if ytdlp_resolver.is_installed():  # lee cache, rápido en warm path.
        info = ytdlp_resolver.resolve_full(canonical_url)
    if info is None:
        from lib import ytdlp_addon
        if ytdlp_addon.is_available():
            info = ytdlp_addon.resolve_full(canonical_url)
    if not info:
        return None
    headers = ytdlp_resolver.meaningful_headers(info['headers'])
    if not headers:
        return info['url']
    encoded = '&'.join(
        f'{_urlquote(k, safe="")}={_urlquote(str(v), safe="")}'
        for k, v in headers.items()
    )
    return f"{info['url']}|{encoded}"


def _try_resolveurl(url: str) -> Optional[str]:
    """Fallback final para URLs sin servicio conocido: ResolveURL, si está
    instalado y reconoce el host. Cubre file-hosters y debrid (lo que yt-dlp
    no resuelve). Corre en el Python embebido, así que también va en Android.

    Devuelve la URL directa al stream (con `|headers` si el resolver los
    añade) o None. El import es pesado (carga cientos de plugins) pero Python
    lo cachea; solo se llega aquí cuando ninguna regla hizo match.
    """
    if not xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)'):
        return None
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if not hmf.valid_url():  # regex local, sin red: filtra hosts no soportados.
            return None
        stream = hmf.resolve()
    except Exception as e:
        # Handler ancho: ResolveURL carga plugins de terceros que pueden
        # lanzar cualquier cosa; un fallo suyo no debe tumbar la resolución.
        log.warning(f'[url_resolver] ResolveURL falló: {e!r}')
        return None
    if not (isinstance(stream, str) and stream):
        return None
    # Algunos resolvers (youtube, vimeo...) devuelven plugin://otro.addon;
    # esa delegación la maneja mejor la cadena de plugins/yt-dlp de arriba.
    if stream.startswith('plugin://'):
        return None
    return stream


# Tabla maestra. El orden importa: el primer match gana.

@dataclass(frozen=True)
class _Rule:
    name: str
    pattern: re.Pattern
    builder: _Builder


_RULES: tuple = (
    # YouTube primero (el más común). Múltiples patrones, mismo builder.
    *(_Rule(name='youtube', pattern=p, builder=_build_youtube)
      for p in _YT_PATTERNS),
    # Twitch: VOD y clip antes del live para no capturar /videos/N o
    # /clip/X como canal.
    _Rule(name='twitch_vod', pattern=_TW_VOD, builder=_build_twitch_vod),
    _Rule(name='twitch_clip', pattern=_TW_CLIP_DOMAIN, builder=_build_twitch_clip),
    _Rule(name='twitch_clip', pattern=_TW_CLIP_PATH, builder=_build_twitch_clip),
    _Rule(name='twitch_live', pattern=_TW_LIVE, builder=_build_twitch_live),
    # Vimeo.
    *(_Rule(name='vimeo', pattern=p, builder=_build_vimeo)
      for p in _VIMEO_PATTERNS),
    # Dailymotion: patrones específicos (path /video/ o dai.ly).
    *(_Rule(name='dailymotion', pattern=p, builder=_build_dailymotion)
      for p in _DM_PATTERNS),
    # SoundCloud (último porque la regex es laxa).
    _Rule(name='soundcloud', pattern=_SC_PATTERN, builder=_build_soundcloud),
)


def resolve(url: str) -> Optional[str]:
    """Convierte `url` en `plugin://...` si coincide con un servicio
    conocido y hay un plugin disponible para reproducirlo.

    Devuelve:
    - La URL `plugin://` cuando hay plugin instalado.
    - Una URL directa al stream cuando, sin servicio conocido, ResolveURL
      reconoce y resuelve el host (file-hosters, debrid).
    - None cuando hay match pero ningún plugin de la cadena (incluyendo
      sendtokodi) está instalado, o cuando no hay match ni ResolveURL
      resuelve. El caller decide qué hacer (probablemente pasar la URL
      cruda y dejar que Kodi lo intente).

    Idempotente sobre `plugin://`: si la URL ya es de un plugin, se
    devuelve None (el caller debe enviarla cruda; doble-resolución
    rompería el flow).

    Los patrones se aplican con `re.match` (anclado al inicio) para
    impedir que una URL `https://X/?to=https://youtu.be/abc12345XYZ`
    se "re-resuelva" capturando la substring del query string.

    Nunca lanza. Entrada vacía o tipo incorrecto devuelven None.
    """
    if not isinstance(url, str) or not url:
        return None
    if url.startswith('plugin://'):
        return None
    for rule in _RULES:
        m = rule.pattern.match(url)
        if m is None:
            continue
        result = rule.builder(m, url)
        if result is not None:
            return result
        # Match pero sin plugin: NO seguir probando otras reglas (la URL
        # ya está identificada; otra regla podría dar un falso positivo
        # contra un patrón menos específico). Tampoco ResolveURL: para
        # servicios mainstream devuelve plugin:// o delega, peor que la
        # cadena de plugins/yt-dlp de arriba.
        return None
    # Ningún servicio conocido: último recurso ResolveURL (file-hosters,
    # debrid). None si no está instalado o no reconoce el host.
    return _try_resolveurl(url)


def rule_names() -> Iterable[str]:
    """Para inspección/tests. Devuelve los nombres de reglas en orden."""
    return tuple(r.name for r in _RULES)
