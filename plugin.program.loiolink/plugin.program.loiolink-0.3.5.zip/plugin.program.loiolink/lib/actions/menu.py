"""Renderiza el menú principal del addon.

Si el clipboard del SO contiene algo importable (URL, magnet, código aftvnews),
aparece como primera entrada destacada "Importar: <preview>".

Las strings de los labels vienen de resources/language/.../strings.po vía
lib.i18n.L(). Los plots se mantienen inline aquí porque son párrafos largos
y mover cada uno a strings.po complica más que aporta (mismo criterio que
lib/actions/options_menu.py).

Iconos en resources/media/menu/*.png. Si el PNG no existe, Kodi usa el
icono por defecto (sin warning).
"""
import os
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility, clipboard_detect, i18n


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MENU_ICONS = os.path.join(_ADDON_PATH, 'resources', 'media', 'menu')


def _icon_path(filename):
    if not filename:
        return None
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def _item(label, action, plot='', icon=None, is_folder=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label))
    if plot:
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
    icon_p = _icon_path(icon)
    if icon_p:
        li.setArt({'icon': icon_p, 'thumb': icon_p})
    url = f'{_BASE_URL}?action={action}'
    xbmcplugin.addDirectoryItem(
        handle=_HANDLE, url=url, listitem=li, isFolder=is_folder,
    )


def _history_label():
    try:
        prop = xbmcgui.Window(10000).getProperty('loiolink.history.count')
        n = int(prop) if prop else None
    except (ValueError, RuntimeError):
        n = None
    if n is None:
        try:
            from lib.transfers import history
            n = len(history.list_all())
        except (ImportError, AttributeError, OSError):
            n = 0
    if n == 0:
        return i18n.L(30021)
    return i18n.L(30020, n=n)


def _options_label():
    try:
        visited = xbmcaddon.Addon().getSettingBool('_options_visited')
    except (RuntimeError, TypeError):
        visited = True
    if visited:
        return i18n.L(30008)
    return f'{i18n.L(30008)} [COLOR orange](IMPORTANTE)[/COLOR]'


# Plots redactados en párrafos completos, sin patrones tipo "no es solo X
# sino Y" y sin acumular dos puntos. Pensados para verse al pulsar "i" sobre
# el item en skins que muestran el plot (Estuary y mayoría compatibles).
_PLOT_IMPORT = (
    'Atajo destacado que aparece cuando el portapapeles del sistema tiene algo '
    'reconocible. El addon detecta si es una URL HTTP, un magnet o torrent, un '
    'enlace AceStream o un código corto de la app Downloader de AFTVnews, y al '
    'pulsar aquí se importa directamente sin tener que ir a la opción '
    'correspondiente.'
)
_PLOT_RECEIVE = (
    'Levanta dentro de tu Kodi un servidor pequeño y muestra un QR junto con '
    'la URL legible debajo. Desde el móvil, PC o cualquier dispositivo conectado '
    'a la misma red, lo abres escaneando el QR o tecleando esa URL en el '
    'navegador, y mandas lo que quieras: texto (URL, magnet, búsqueda...) o un '
    'archivo. Vídeo y audio se reproducen, imágenes se muestran, .torrent se '
    'lanza con Elementum, APK abre el instalador de Android, ZIP de addon o '
    'repo se instala en Kodi. El servidor sigue abierto y acepta envíos en '
    'serie hasta que pulsas Atrás/Esc o se cierra Kodi.'
    '\n\n'
    'Si Kodi tiene un teclado virtual abierto al recibir el texto '
    '(por ejemplo estás dentro de "Buscar" de un addon), el texto se inyecta '
    'directamente en ese cuadro y la búsqueda arranca, sin tocar la tele. '
    'Además se guarda en el clipboard interno igual que siempre, por si más '
    'tarde lo quieres pegar manualmente. La inyección automática se puede '
    'desactivar en Ajustes → Servidor.'
)
_PLOT_PORTAPAPELES = (
    'Importa lo que tengas copiado en el ordenador, o consulta y gestiona el '
    'portapapeles interno del addon.'
)
_PLOT_DOWNLOADS = (
    'Descarga archivos desde una URL, un código corto (estilo Downloader de '
    'AFTVnews) o un canal de Telegram. Los vídeos y streams de Telegram se '
    'pueden reproducir directamente sin guardar nada; los ZIP se pueden '
    'instalar como addon al terminar. Historial de todas las transferencias '
    'anteriores.'
)
_PLOT_REMOTE = (
    'Abre un panel web de control remoto en el navegador de cualquier dispositivo (móvil, tableta, PC...). '
    'Desde ahí puedes controlar la reproducción de Kodi (play/pausa, posición, volumen), '
    'enviar texto o magnets y subir archivos desde tu dispositivo para procesarlos en la tele: '
    'vídeo o audio se reproducen, imágenes se muestran, archivos .torrent se lanzan con '
    'Elementum, APKs abren el instalador de Android (en Fire TV o Android TV) y ZIPs '
    'de addons o repositorios se instalan directamente en Kodi. '
    'También puedes volver a reproducir o ver en tu propio dispositivo cualquier archivo del '
    'historial de transferencias (con transcoding al vuelo si el navegador no entiende '
    'el formato). '
    'Incluye un explorador con películas, series y música indexadas por Kodi '
    '(con carátulas, sinopsis y punto de reanudación) más navegador de las fuentes '
    'configuradas, todo reproducible tanto en la tele como en tu dispositivo. '
    'También admite lanzar en Kodi enlaces HTTP/HTTPS directos a vídeo o audio y magnets '
    '(estos vía Elementum); no resuelve YouTube, Dailymotion ni páginas web; para eso usa '
    'StreamNinja. '
    'En la pestaña Sistema puedes habilitar o deshabilitar addons remotamente y '
    'entrar dentro de cualquier addon de tipo plugin para reproducir o lanzar '
    'su contenido directamente desde el panel, sin tocar el mando de la tele. '
    'Si al navegar dentro de un addon aparece un cuadro de búsqueda, el panel '
    'muestra automáticamente un input emergente para que escribas de forma remota. '
    'Toda la gestión y navegación de addons está apagada por '
    'defecto; se activa en Ajustes → Servidor. '
    'El acceso se establece la primera vez escaneando el QR o, si la cámara '
    'falla o la TV está lejos, escribiendo en el navegador la URL corta y el '
    'PIN de 6 cifras que se muestran junto al QR. A partir de ahí el navegador '
    'guarda el acceso para las próximas veces.'
)
_PLOT_SOURCES_REPOS = (
    'Alternativa al gestor de fuentes que trae Kodi de serie, pensada para que '
    'añadir, renombrar y revisar fuentes resulte más cómodo. Además avisa cuando '
    'una fuente cambia su contenido o cuando un repositorio instalado tiene un '
    'addon con versión nueva.'
)
_PLOT_FILE_BROWSER = (
    'Navega por las fuentes y carpetas. Añade nuevas, cambia el destino '
    'de subida al directorio actual y gestiona los ficheros: copiar, mover, '
    'renombrar, eliminar. Al pulsar sobre un archivo, vídeo y audio se '
    'reproducen (mp4, mkv, mp3, flac...), las imágenes se muestran '
    '(jpg, png, gif...), los ZIPs de addons o repositorios se instalan '
    'directamente en Kodi y los APKs abren el instalador de Android (en '
    'Fire TV o Android TV). Dentro de cada carpeta puedes buscar, ordenar '
    'y filtrar, marcar archivos o carpetas como favoritos y ver su '
    'información. Además, puedes compartir cualquier fuente por QR y '
    'exportar/importar toda la lista.'
)
_PLOT_BACKUP = (
    'Crea copias de seguridad de addons, repositorios y favoritos, completas o '
    'eligiendo qué se incluye, y restáuralas cuando quieras. Los backups pueden '
    'guardarse en local, USB o NAS, exportarse a otro dispositivo o importarse '
    'desde una ruta externa. Antes de restaurar puedes hacer un dry-run que '
    'muestra qué cambiaría sin tocar nada. También genera copias saneadas sin '
    'credenciales para compartir e instala lotes de addons desde un fichero XML.'
)
_PLOT_OPEN_URL = (
    'Introducir manualmente una URL para reproducirla. El cuadro se '
    'pre-rellena con el portapapeles del sistema si parece una URL, así que '
    'en el caso típico (copiar en el navegador → pegar en la tele) basta con '
    'pulsar OK. Cada URL queda guardada en el historial para repetirla luego '
    'sin volver a teclear. Aquí también se accede a StreamNinja, que '
    'resuelve casos que el procesador interno no cubre (YouTube, '
    'Dailymotion, Twitch...).'
)
_PLOT_CLEANUP = (
    'Libera espacio en el dispositivo. Limpia los temporales del addon, vacía '
    'la papelera del explorador de archivos y entra al mantenimiento de Kodi: '
    'paquetes de instalación, miniaturas en desuso, bases de datos, registros '
    'de fallos y copia de la configuración del sistema. No toca tus addons, '
    'repositorios ni favoritos, que se respaldan en "Backup y restauración de Kodi".'
)
_PLOT_OPTIONS = (
    'Configura cómo se comporta el addon en su día a día. Aquí encuentras las '
    'preferencias del servidor, las opciones de pegado y el modo de accesibilidad.'
)
_PLOT_INFORMATION = (
    'Información del addon y acceso a los instaladores de los addons del '
    'ecosistema loioloio: FlowFav y LoioLog.'
)


def _add_import_entry_if_clipboard_has_content():
    """Si el SO clipboard tiene algo importable, añadir entrada destacada.

    Devuelve True si se añadió la entrada.
    """
    detected = clipboard_detect.detect_importable()
    if detected is None:
        return False
    kind, _value, preview = detected
    if kind == 'magnet':
        prefix = 'Magnet'
    elif kind == 'acestream':
        prefix = 'Acestream'
    elif kind == 'aftvnews_code':
        prefix = 'Código'
    else:
        prefix = 'URL'
    # Color gold para que destaque sobre el resto. accessibility.apply_label
    # respetará la transformación si hay modo daltónico/alto contraste activo.
    label = f'[COLOR gold][B]Importar {prefix}:[/B] {preview}[/COLOR]'
    _item(label, 'import_clipboard', plot=_PLOT_IMPORT, icon='clipboard.png')
    return True


def run():
    _add_import_entry_if_clipboard_has_content()
    _item(i18n.L(30005), 'remote_qr', plot=_PLOT_REMOTE, icon='remote.png')
    _item(i18n.L(30001), 'receive_text', plot=_PLOT_RECEIVE, icon='qr.png')
    _item('Portapapeles', 'clipboard_submenu', plot=_PLOT_PORTAPAPELES,
          icon='clipboard.png', is_folder=True)
    _item('Descargas - [COLOR white]URL · Número · Telegram · Instalar · Reproducir[/COLOR]',
          'downloads_menu', plot=_PLOT_DOWNLOADS, icon='download.png', is_folder=True)
    _item(i18n.L(30300), 'sources_repos_menu',
          plot=_PLOT_SOURCES_REPOS, icon='sources.png')
    _item('Explorador de archivos', 'file_browser',
          plot=_PLOT_FILE_BROWSER, icon='file_browser.png', is_folder=True)
    _item('Backup y restauración de Kodi', 'backup_menu',
          plot=_PLOT_BACKUP, icon='download.png', is_folder=False)
    _item('Limpieza y mantenimiento', 'cleanup_menu',
          plot=_PLOT_CLEANUP, icon='delete.png', is_folder=False)
    _item('Pegar enlace y reproducir', 'open_url_menu',
          plot=_PLOT_OPEN_URL, icon='url.png', is_folder=True)
    _item(_options_label(), 'options_menu', plot=_PLOT_OPTIONS, icon='settings.png',
          is_folder=True)
    _item('Información, Manual y Ecosistema', 'information_menu', plot=_PLOT_INFORMATION,
          icon='info.png', is_folder=True)

    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
