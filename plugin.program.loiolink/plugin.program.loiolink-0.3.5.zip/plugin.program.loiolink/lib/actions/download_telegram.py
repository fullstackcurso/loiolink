"""Acción 'Descargar desde Telegram': escanea un canal público y, según el
tipo de cada enlace, lo descarga o lo reproduce.

loiolink no tiene yt-dlp: los enlaces a plataformas (YouTube, Vimeo…) y los
streams (m3u8/mpd/ts) no son descargables, así que se delegan al pipeline de
reproducción ya existente (paste_clipboard.process_text). Los archivos directos
sí se descargan; los vídeos directos ofrecen además reproducir.
"""
import xbmcgui

from lib import log
from lib.transfers import pipeline

# Extensiones (sin punto, como las emite telegram_scanner) por destino:
_VIDEO_FILE_EXTS = frozenset(('mp4', 'mkv', 'webm', 'avi', 'mov'))  # descargar o reproducir
_DOWNLOAD_EXTS = frozenset(('zip', 'rar', '7z', 'torrent', 'nfo', 'apk'))  # solo descargar
# El resto (m3u8/mpd/ts streams, ext vacía = enlace de plataforma) no es
# descargable por loiolink → se reproduce vía process_text.


def run():
    from lib.transfers import telegram_scanner

    channel = xbmcgui.Dialog().input('Canal PÚBLICO de Telegram (@canal, t.me/canal o solo el nombre):')
    if not channel or not channel.strip():
        return
    channel = channel.strip()

    if telegram_scanner.is_private_invite(channel):
        xbmcgui.Dialog().ok(
            'loiolink',
            'Es un enlace de invitación a un canal o grupo PRIVADO de Telegram.\n\n'
            'Solo se pueden escanear canales públicos (t.me/nombre).',
        )
        return

    items = []
    seen = set()
    cursor = None
    first = True

    while True:
        progress = xbmcgui.DialogProgress()
        progress.create(
            'loiolink',
            'Leyendo las últimas entradas…' if first else 'Cargando más antiguas…',
        )
        try:
            batch, cursor = telegram_scanner.scan_channel_paged(channel, before_id=cursor)
        except Exception as exc:
            # Red + parseo de HTML ajeno: no debe tumbar la acción. _fetch_page
            # ya filtra OSError; aquí cubrimos lo que se escape (IncompleteRead
            # de http.client no es OSError, p.ej.).
            log.warning(f'download_telegram: fallo escaneando {channel[:40]}: {exc}')
            batch, cursor = [], None
        finally:
            progress.close()

        added = 0
        for it in batch:
            url = it.get('url', '')
            if url and url not in seen:
                seen.add(url)
                items.append(it)
                added += 1

        if not items:
            xbmcgui.Dialog().ok(
                'loiolink',
                'No se encontraron archivos ni enlaces en el canal.\n\n'
                'Verifica que el nombre es correcto, que el canal es público '
                '(t.me/nombre) y que comparte archivos.',
            )
            return

        if not first and added == 0:
            xbmcgui.Dialog().notification(
                'loiolink', 'Sin enlaces nuevos en entradas anteriores',
                xbmcgui.NOTIFICATION_INFO, 2500,
            )
        first = False

        options = [_label(it) for it in items]
        more_idx = -1
        if cursor:
            more_idx = len(options)
            options.append('[COLOR cyan]Cargar más antiguos[/COLOR]')

        sel = xbmcgui.Dialog().select(f'Telegram: {len(items)} enlaces', options)
        if sel < 0:
            return
        if sel == more_idx:
            continue
        _dispatch(items[sel])
        return


def _label(item):
    parts = [item.get('title') or item.get('url', '')[:60]]
    ext = item.get('ext', '')
    if ext:
        parts.append(ext.upper())
    return ' — '.join(parts)


def _dispatch(item):
    url = item.get('url', '')
    if not url:
        return
    ext = (item.get('ext') or '').lower()
    title = item.get('title') or None

    if ext in _VIDEO_FILE_EXTS:
        sel = xbmcgui.Dialog().select(
            '¿Qué hacer con este vídeo?', ['Reproducir ahora', 'Descargar'],
        )
        if sel == 0:
            from lib.remote import player
            player.play_file(url, title=title)
        elif sel == 1:
            pipeline.download_and_register(url, source='telegram')
        return

    if ext in _DOWNLOAD_EXTS:
        pipeline.download_and_register(url, source='telegram')
        return

    from lib.transfers import github_releases
    if github_releases.is_release_url(url):
        _download_github_release(url)
        return

    # Stream o enlace de plataforma: no descargable; reproducir/resolver.
    from lib.actions import paste_clipboard
    paste_clipboard.process_text(url)


def _download_github_release(url):
    """Resuelve un enlace de GitHub releases a su(s) asset(s) y descarga el elegido."""
    from lib.transfers import github_releases

    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Consultando la release en GitHub…')
    try:
        assets = github_releases.resolve(url)
    except github_releases.GitHubError as e:
        log.warning(f'download_telegram: github release {url[:60]}: {e}')
        xbmcgui.Dialog().ok('loiolink', str(e))
        return
    finally:
        progress.close()

    if len(assets) == 1:
        chosen = assets[0]
    else:
        sel = xbmcgui.Dialog().select(
            'Elige el archivo a descargar', [_asset_label(a) for a in assets],
        )
        if sel < 0:
            return
        chosen = assets[sel]

    pipeline.download_and_register(chosen['url'], source='telegram')


def _asset_label(asset):
    size = asset.get('size')
    if not size:
        return asset['name']
    if size >= 1024 * 1024:
        return f"{asset['name']}  ({size // (1024 * 1024)} MB)"
    return f"{asset['name']}  ({size // 1024} KB)"
