"""Diálogo de selección modal con layout amplio, mouse hover y scroll.

Sustituye xbmcgui.Dialog().select(useDetails=True) por un panel amplio
con plot a la izquierda y lista a la derecha. Cada fila es un
ControlButton, lo que permite que Kodi gestione automáticamente el
foco por mouse hover. Las flechas las maneja onAction directamente
porque la auto-navegación de Kodi entre botones de WindowDialog no
funciona de forma fiable.

La geometría se calcula sobre la rejilla fija 1280x720 que Kodi asigna
a toda WindowDialog de Python y escala a la pantalla real (sea 720p,
1080p o 4K). Esa rejilla NO respeta la calibración/overscan del TV (no
hay API para leerla), así que el panel se mete hacia dentro un margen de
seguridad configurable; ver tv_safe_area_pct().

Hay dos APIs públicas:

- `select(title, items)` devuelve el índice elegido y cierra el modal
  al seleccionar. Útil para preguntas puntuales.

- `menu(title, build)` no cierra al seleccionar: ejecuta la `action`
  asociada al item, llama `build()` para refrescar los items y
  re-renderiza. Cierra solo con Atrás/ESC o si una action lanza
  `CloseMenu`. Útil para menús con acciones permanentes (toggles,
  sub-menús, etc.).
"""
import os
import re
from dataclasses import dataclass
from typing import Callable, List, Optional

import xbmcaddon
import xbmcgui

from lib import log


# Solo mayúsculas (convención BBCode de Kodi: [B], [I], [COLOR red], [COLOR=ff0000],
# [LIGHT], [UPPERCASE]...). Sin IGNORECASE para no comerse [texto] del usuario.
# El separador puede ser '=' o espacio según el tag.
_BBCODE_RE = re.compile(r'\[/?[A-Z]+(?:[ =][^\]]*)?\]')


def _plain_length(text):
    """Longitud aproximada del texto sin BBCode, para heurísticas de tamaño."""
    return len(_BBCODE_RE.sub('', text or ''))


def _line_estimate(text, chars_per_line=50):
    """Líneas aproximadas tras strip de BBCode y wrap por chars_per_line."""
    plain = _BBCODE_RE.sub('', text or '')
    if not plain:
        return 1
    lines = 0
    for raw_line in plain.split('\n'):
        lines += max(1, (len(raw_line) + chars_per_line - 1) // chars_per_line)
    return lines


def tv_safe_area_pct():
    """Margen de seguridad (%) para que las ventanas propias no caigan fuera
    de la zona visible en TVs con overscan.

    Una WindowDialog de Python dibuja sobre la rejilla cruda 1280x720 y NO
    respeta la calibración de Kodi; tampoco hay API para leerla. Por eso el
    usuario ajusta este margen a ojo en su televisor (Ajustes > Accesibilidad).
    """
    try:
        pct = int(xbmcaddon.Addon().getSetting('ui.tv_safe_area') or 0)
    except (RuntimeError, ValueError):
        pct = 0
    return max(0, min(pct, 12))


class CloseMenu(Exception):
    """Lanzada desde la action de un SelectItem para cerrar el menú
    actual desde dentro (por ejemplo, una entrada 'Cerrar' explícita).
    """


@dataclass(frozen=True)
class SelectItem:
    label: str
    plot: str = ''
    icon: Optional[str] = None  # Path absoluto o None. El llamante resuelve.
    # En modo `menu`, callable que se ejecuta al seleccionar el item.
    # None significa item informativo (ignorado al pulsar). En modo
    # `select` este campo es ignorado.
    action: Optional[Callable[[], None]] = None


def select(title: str,
           items: List[SelectItem],
           preselect: int = 0,
           show_icons: bool = True) -> int:
    """Modal con plot a la izquierda y lista a la derecha.

    Devuelve el índice elegido o -1 si se cancela. Lista vacía
    devuelve -1 inmediato sin crear la ventana.
    """
    if not items:
        return -1
    dlg = _SelectDialog(title, items, preselect, show_icons)
    try:
        dlg.doModal()
        return dlg.result
    finally:
        del dlg


def menu(title: str,
         build: Callable[[], List[SelectItem]],
         show_icons: bool = True,
         compact: bool = False) -> None:
    """Modal con bucle interno. `build()` se llama al abrir y tras
    cada acción ejecutada para refrescar los items. Cierra solo con
    Atrás/ESC o si una action lanza CloseMenu.
    """
    items = build()
    if not items:
        return
    dlg = _SelectDialog(title, items, 0, show_icons, build=build,
                        compact=compact)
    try:
        dlg.doModal()
    finally:
        del dlg


def confirm(msg: str,
            title: str = 'loiolink',
            yes: str = 'Sí',
            no: str = 'No',
            default_no: bool = True) -> bool:
    """Modal Sí/No con el estilo de menu(). Devuelve True si el usuario
    confirma. ESC/Atrás se asimila a No (False), igual que yesno() nativo.
    Con default_no=True el botón inicialmente enfocado es "No" (seguro
    para confirmaciones destructivas).

    Se usa panel compacto solo para mensajes cortos sin párrafos. Si el
    mensaje tiene saltos dobles o estima más de 4 líneas (a 40 chars por
    línea, ancho real del plot en compact), se cae al panel ancho para
    que el texto quepa entero.
    """
    result = {'value': False}

    def _yes():
        result['value'] = True
        raise CloseMenu()

    def _no():
        result['value'] = False
        raise CloseMenu()

    if default_no:
        items = [
            SelectItem(no, plot=msg, action=_no),
            SelectItem(yes, plot=msg, action=_yes),
        ]
    else:
        items = [
            SelectItem(yes, plot=msg, action=_yes),
            SelectItem(no, plot=msg, action=_no),
        ]

    compact = ('\n\n' not in msg
               and _line_estimate(msg, chars_per_line=40) <= 4
               and _plain_length(msg) <= 200)

    menu(title, lambda: items, show_icons=False, compact=compact)
    return result['value']


def info(msg: str, title: str = 'loiolink') -> None:
    """Modal informativo con un solo botón Aceptar. Equivalente a ok()."""
    def _close():
        raise CloseMenu()

    items = [SelectItem('Aceptar', plot=msg, action=_close)]
    menu(title, lambda: items, show_icons=False)


def show_text(title: str, body: str) -> None:
    """Modal con texto largo a ancho completo del panel (sin lista lateral).

    El cierre se hace con el botón Cerrar del header, ESC o Atrás. La
    rueda del ratón, las flechas y PageUp/PageDown desplazan el textbox.
    """
    dlg = _SelectDialog(
        title, [], 0, show_icons=False,
        text_only=True, text_body=body,
    )
    try:
        dlg.doModal()
    finally:
        del dlg


class _SelectDialog(xbmcgui.WindowDialog):
    # Colores AARRGGBB. Alpha FF = opaco total.
    _C_OVERLAY = '0xFF000000'
    _C_PANEL_IDENTITY = '0xFFFFFFFF'  # identidad multiplicativa
    _C_BORDER = '0xFF30363D'
    _C_TITLE = '0xFFFFFFFF'
    _C_TEXT = '0xFFE6EDF3'
    _C_TEXT_FOCUSED = '0xFFFFFFFF'
    _C_PLOT = '0xFFC9D1D9'
    _C_HINT = '0xFF8B949E'
    _C_SB_TRACK = '0xFF666666'
    _C_SB_THUMB = '0xFFFFFFFF'

    _FONT_TITLE = 'font20'
    _FONT_ROW = 'font14'
    _FONT_PLOT = 'font14'
    _FONT_HINT = 'font12'

    XBFONT_CENTER_X = 0x00000002
    XBFONT_CENTER_Y = 0x00000004
    XBFONT_RIGHT = 0x00000001

    _CLOSE_ACTIONS = {
        xbmcgui.ACTION_PREVIOUS_MENU,
        xbmcgui.ACTION_NAV_BACK,
        xbmcgui.ACTION_STOP,
    }
    # ACTION_MOUSE_LEFT_CLICK = 100 cubre clicks del ratón.
    # WindowDialog no dispara onClick(), así que select tiene que
    # vivir aquí en onAction.
    _SELECT_ACTIONS = {
        xbmcgui.ACTION_SELECT_ITEM,
        xbmcgui.ACTION_MOUSE_LEFT_CLICK,
    }
    _UP_ACTIONS = {xbmcgui.ACTION_MOVE_UP}
    _DOWN_ACTIONS = {xbmcgui.ACTION_MOVE_DOWN}
    _PAGE_UP_ACTIONS = {xbmcgui.ACTION_PAGE_UP, xbmcgui.ACTION_FIRST_PAGE}
    _PAGE_DOWN_ACTIONS = {xbmcgui.ACTION_PAGE_DOWN, xbmcgui.ACTION_LAST_PAGE}
    # En algunas builds antiguas estas constantes no están expuestas;
    # los IDs 104/105 son estables en Kodi 19+.
    _WHEEL_UP = {getattr(xbmcgui, 'ACTION_MOUSE_WHEEL_UP', 104)}
    _WHEEL_DOWN = {getattr(xbmcgui, 'ACTION_MOUSE_WHEEL_DOWN', 105)}

    # Gestos táctiles y drag de ratón para arrastrar la lista con el dedo.
    # IDs estables en Kodi 19+; getattr por si una build no los expone.
    _GESTURE_BEGIN = getattr(xbmcgui, 'ACTION_GESTURE_BEGIN', 501)
    _GESTURE_PAN = getattr(xbmcgui, 'ACTION_GESTURE_PAN', 504)
    _GESTURE_ABORT = getattr(xbmcgui, 'ACTION_GESTURE_ABORT', 505)
    _GESTURE_END = getattr(xbmcgui, 'ACTION_GESTURE_END', 599)
    _MOUSE_DRAG = getattr(xbmcgui, 'ACTION_MOUSE_DRAG', 106)
    _MOUSE_DRAG_END = getattr(xbmcgui, 'ACTION_MOUSE_DRAG_END', 109)
    _PAN_BEGIN = {_GESTURE_BEGIN}
    _PAN_MOVE = {_GESTURE_PAN, _MOUSE_DRAG}
    _PAN_END = {_GESTURE_END, _GESTURE_ABORT, _MOUSE_DRAG_END}

    def __init__(self, title, items, preselect, show_icons, build=None,
                 text_only=False, text_body='', compact=False):
        super().__init__()
        self._title = title
        self._items = items
        self._show_icons = show_icons
        # En modo `menu`, callback que recalcula los items tras cada
        # acción ejecutada. None = modo `select` clásico (cierra al
        # seleccionar y devuelve el índice).
        self._build = build
        # En modo text_only no hay lista: el plot ocupa el ancho completo
        # y muestra `text_body`. El cierre va por el botón Cerrar del
        # header o por ESC/Atrás.
        self._text_only = text_only
        self._text_body = text_body
        self._text_offset = 0
        # En modo compact el panel se dimensiona al contenido y se centra
        # en pantalla en vez de ocupar full-screen. Pensado para confirms
        # cortos donde el overlay grande es desproporcionado.
        self._compact = compact
        self._has_plots = (not text_only) and any(item.plot for item in items)
        self._cursor = max(0, min(preselect, len(items) - 1)) if items else 0
        self._offset = 0
        # Estado del arrastre táctil: y del último evento de pan y resto
        # sub-fila acumulado entre eventos.
        self._pan_anchor_y = None
        self._pan_accum = 0.0
        # Geometría del scrollbar; la real la fija _build_list, 0 hasta entonces.
        self._sb_x = 0
        self._sb_track_y = 0
        self._sb_track_h = 0
        self._sb_arrow_h = 0
        # Hueco entre las dos flechas por donde viaja el thumb.
        self._sb_gutter_y = 0
        self._sb_gutter_h = 0
        self._slots = []  # list de (btn, icon_ctrl)
        self._plot_box = None
        self._counter_label = None
        self._scrollbar_track = None
        self._scrollbar_thumb = None
        self._scrollbar_up = None
        self._scrollbar_down = None
        self._scrollbar_up_img = None
        self._scrollbar_down_img = None
        self._close_button = None
        self.result = -1

        # Geometría base 1280x720 (Kodi escala automáticamente al tamaño real).
        self._W = 1280
        self._H = 720

        if compact:
            # Dimensionar al contenido y centrar. Plot+lista comparten el
            # panel con el mismo split 43/57 que el modo grande, así no
            # hay que tocar _build_plot / _build_list.
            plot_text = items[0].plot if items else ''
            plot_lines = _line_estimate(plot_text, chars_per_line=40)
            line_h = max(18, int(self._H * 22 / 720))
            row_h = int(self._H * 64 / 720)
            row_gap = int(self._H * 4 / 720)
            header_h = int(self._H * 52 / 720)
            footer_h = int(self._H * 48 / 720)
            pad = int(self._H * 28 / 720)
            list_h = len(items) * row_h + max(0, len(items) - 1) * row_gap
            plot_h = plot_lines * line_h
            content_h = max(plot_h, list_h) + pad * 2
            self._PANEL_W = int(self._W * 0.50)
            self._PANEL_W = max(int(self._W * 0.38),
                                min(self._PANEL_W, int(self._W * 0.55)))
            raw_h = header_h + footer_h + content_h
            self._PANEL_H = max(int(self._H * 0.22),
                                min(raw_h, int(self._H * 0.55)))
            self._PANEL_X = (self._W - self._PANEL_W) // 2
            self._PANEL_Y = (self._H - self._PANEL_H) // 2
        else:
            # Layout proporcional: 40 px de margen sobre base 1280, escalado,
            # más el margen de seguridad TV (overscan). El overlay negro sigue
            # cubriendo toda la rejilla; solo el panel y su contenido se meten
            # hacia dentro para no caer fuera de pantalla en televisores.
            sa = tv_safe_area_pct()
            inset_x = int(self._W * sa / 100)
            inset_y = int(self._H * sa / 100)
            margin = int(self._W * 40 / 1280)
            self._PANEL_X = inset_x + margin
            self._PANEL_Y = inset_y + margin
            self._PANEL_W = self._W - 2 * (inset_x + margin)
            self._PANEL_H = self._H - 2 * (inset_y + margin)

        self._HEADER_H = int(self._H * 52 / 720)
        self._FOOTER_H = int(self._H * 48 / 720)
        self._PAD = int(self._W * 28 / 1280)

        # Plot ocupa ~43% del ancho del panel, lista el resto.
        # Si ningún item tiene plot, colapsar el panel izquierdo y usar
        # el ancho completo para la lista.
        if self._has_plots:
            self._PLOT_AREA_W = int(self._PANEL_W * 0.43)
            self._SEPARATOR_W = 1
        else:
            self._PLOT_AREA_W = 0
            self._SEPARATOR_W = 0
        self._LIST_AREA_W = self._PANEL_W - self._PLOT_AREA_W - self._SEPARATOR_W

        self._ROW_H = int(self._H * 64 / 720)
        self._ROW_GAP = int(self._H * 4 / 720)
        self._ROW_INSET_X = int(self._W * 8 / 1280)
        self._ICON_SIZE = int(self._H * 48 / 720)
        self._ICON_MARGIN_X = int(self._W * 20 / 1280)
        self._LABEL_OFFSET_X = self._ICON_MARGIN_X + self._ICON_SIZE + 16
        self._LABEL_OFFSET_X_NO_ICON = int(self._W * 24 / 1280)

        # Scrollbar vertical: ocupa el margen derecho del área de lista.
        # Siempre reservamos el espacio aunque no haya scroll, así el
        # ancho de las filas no cambia entre rebuilds.
        self._SB_W = max(10, int(self._W * 12 / 1280))
        self._SB_GAP = max(2, int(self._W * 6 / 1280))

        self._build_ui()
        if self._text_only:
            if self._plot_box is not None:
                self._plot_box.setText(self._text_body or '')
            if self._close_button is not None:
                self.setFocus(self._close_button)
        else:
            self._scroll_to_cursor()
            self._render()
            self._focus_cursor()

    def _media_path(self, name):
        return os.path.join(
            xbmcaddon.Addon().getAddonInfo('path'),
            'resources', 'media', name,
        )

    def _build_ui(self):
        panel_bg = self._media_path('panel_bg.png')
        hilite = self._media_path('hilite.png')
        transparent = self._media_path('transparent.png')

        # Overlay opaco a pantalla completa: tapa el skin de Kodi.
        # aspectRatio=0 = stretch (fuerza al PNG 4x4 a llenar el control).
        self.addControl(xbmcgui.ControlImage(
            0, 0, self._W, self._H,
            panel_bg,
            aspectRatio=0,
            colorDiffuse=self._C_OVERLAY,
        ))

        # Panel principal sólido (color directo del PNG, sin tinte).
        self.addControl(xbmcgui.ControlImage(
            self._PANEL_X, self._PANEL_Y, self._PANEL_W, self._PANEL_H,
            panel_bg,
            aspectRatio=0,
            colorDiffuse=self._C_PANEL_IDENTITY,
        ))

        self._build_header(panel_bg, hilite, transparent)
        if self._text_only:
            self._build_fullwidth_plot()
        else:
            if self._has_plots:
                self._build_plot()
                self._build_separator(panel_bg)
            self._build_list(hilite, transparent)
        self._build_footer(panel_bg)

    def _build_header(self, panel_bg, hilite, transparent):
        # Borde inferior del header.
        self.addControl(xbmcgui.ControlImage(
            self._PANEL_X, self._PANEL_Y + self._HEADER_H,
            self._PANEL_W, 1,
            panel_bg,
            aspectRatio=0, colorDiffuse=self._C_BORDER,
        ))

        # Botón Cerrar en la esquina superior derecha. Solo accesible
        # por ratón (hover + click): se auto-loopea para no romper la
        # navegación con flechas de la lista. El teclado sigue usando
        # ESC/Atrás.
        close_w = int(self._W * 100 / 1280)
        close_h = int(self._H * 40 / 720)
        close_y = self._PANEL_Y + (self._HEADER_H - close_h) // 2
        close_x = self._PANEL_X + self._PANEL_W - close_w - self._PAD
        self._close_button = xbmcgui.ControlButton(
            close_x, close_y, close_w, close_h,
            label='Cerrar',
            focusTexture=hilite,
            noFocusTexture=transparent,
            alignment=self.XBFONT_CENTER_X | self.XBFONT_CENTER_Y,
            font=self._FONT_HINT,
            textColor=self._C_HINT,
            focusedColor=self._C_TEXT_FOCUSED,
        )
        self.addControl(self._close_button)
        self._close_button.controlUp(self._close_button)
        self._close_button.controlDown(self._close_button)
        self._close_button.controlLeft(self._close_button)
        self._close_button.controlRight(self._close_button)

        # Título a la izquierda.
        title_h = int(self._H * 30 / 720)
        title_y = self._PANEL_Y + (self._HEADER_H - title_h) // 2
        counter_w = int(self._W * 170 / 1280)
        counter_gap = int(self._W * 16 / 1280)
        counter_x = close_x - counter_w - counter_gap
        self.addControl(xbmcgui.ControlLabel(
            self._PANEL_X + self._PAD,
            title_y,
            counter_x - self._PANEL_X - self._PAD * 2,
            title_h,
            self._title,
            font=self._FONT_TITLE,
            textColor=self._C_TITLE,
            alignment=self.XBFONT_CENTER_Y,
        ))
        # Contador "N de M" a la izquierda del botón Cerrar.
        self._counter_label = xbmcgui.ControlLabel(
            counter_x,
            title_y,
            counter_w, title_h,
            '',
            font=self._FONT_HINT,
            textColor=self._C_HINT,
            alignment=self.XBFONT_RIGHT | self.XBFONT_CENTER_Y,
        )
        self.addControl(self._counter_label)

    def _build_plot(self):
        plot_x = self._PANEL_X + self._PAD
        plot_y = self._PANEL_Y + self._HEADER_H + self._PAD
        plot_w = self._PLOT_AREA_W - self._PAD * 2
        plot_h = self._PANEL_H - self._HEADER_H - self._FOOTER_H - self._PAD * 2
        self._plot_box = xbmcgui.ControlTextBox(
            plot_x, plot_y, plot_w, plot_h,
            font=self._FONT_PLOT,
            textColor=self._C_PLOT,
        )
        self.addControl(self._plot_box)

    def _build_fullwidth_plot(self):
        """Plot a ancho completo del panel para el modo text_only."""
        plot_x = self._PANEL_X + self._PAD
        plot_y = self._PANEL_Y + self._HEADER_H + self._PAD
        plot_w = self._PANEL_W - self._PAD * 2
        plot_h = self._PANEL_H - self._HEADER_H - self._FOOTER_H - self._PAD * 2
        self._plot_box = xbmcgui.ControlTextBox(
            plot_x, plot_y, plot_w, plot_h,
            font=self._FONT_PLOT,
            textColor=self._C_PLOT,
        )
        self.addControl(self._plot_box)

    def _build_separator(self, panel_bg):
        sep_x = self._PANEL_X + self._PLOT_AREA_W
        sep_y = self._PANEL_Y + self._HEADER_H + self._PAD
        sep_h = self._PANEL_H - self._HEADER_H - self._FOOTER_H - self._PAD * 2
        self.addControl(xbmcgui.ControlImage(
            sep_x, sep_y, self._SEPARATOR_W, sep_h,
            panel_bg,
            aspectRatio=0, colorDiffuse=self._C_BORDER,
        ))

    def _build_list(self, hilite, transparent):
        list_x = self._PANEL_X + self._PLOT_AREA_W + self._SEPARATOR_W
        list_y = self._PANEL_Y + self._HEADER_H + int(self._H * 12 / 720)
        list_w = self._LIST_AREA_W
        list_h = self._PANEL_H - self._HEADER_H - self._FOOTER_H - int(self._H * 24 / 720)

        row_total = self._ROW_H + self._ROW_GAP
        visible_rows = (list_h + self._ROW_GAP) // row_total
        visible_rows = max(1, min(visible_rows, len(self._items)))

        if self._show_icons:
            text_offset_x = self._LABEL_OFFSET_X
        else:
            text_offset_x = self._LABEL_OFFSET_X_NO_ICON

        # Reservar espacio para el scrollbar en el margen derecho.
        btn_area_w = list_w - self._ROW_INSET_X * 2 - self._SB_W - self._SB_GAP

        for i in range(visible_rows):
            row_y = list_y + i * row_total
            btn_x = list_x + self._ROW_INSET_X
            btn_w = btn_area_w

            btn = xbmcgui.ControlButton(
                btn_x, row_y, btn_w, self._ROW_H,
                label='',
                focusTexture=hilite,
                noFocusTexture=transparent,
                textOffsetX=text_offset_x,
                textOffsetY=0,
                alignment=self.XBFONT_CENTER_Y,
                font=self._FONT_ROW,
                textColor=self._C_TEXT,
                focusedColor=self._C_TEXT_FOCUSED,
            )
            self.addControl(btn)

            icon_x = btn_x + self._ICON_MARGIN_X
            icon_y = row_y + (self._ROW_H - self._ICON_SIZE) // 2
            icon = xbmcgui.ControlImage(
                icon_x, icon_y,
                self._ICON_SIZE, self._ICON_SIZE,
                transparent,
                aspectRatio=0,
            )
            self.addControl(icon)

            self._slots.append((btn, icon))

        # Encadenamos los botones en ciclo (wrap-around): en Android el D-pad
        # necesita que el foco cambie de control para disparar onAction; los
        # self-loops anteriores lo bloqueaban. En PC la auto-navegación sigue
        # sin funcionar en WindowDialog con flechas de teclado, así que onAction
        # continúa siendo el responsable del cursor mediante _move_cursor.
        # Left/right: self-loop para evitar que el D-pad horizontal saque el foco.
        n = len(self._slots)
        for i, (btn, _) in enumerate(self._slots):
            btn.controlUp(self._slots[(i - 1) % n][0])
            btn.controlDown(self._slots[(i + 1) % n][0])
            btn.controlLeft(btn)
            btn.controlRight(btn)

        # Scrollbar estilo escritorio: flecha arriba, canal con thumb, flecha
        # abajo. La columna cubre las filas visibles; el thumb viaja solo por
        # el hueco (gutter) entre las dos flechas.
        self._sb_x = list_x + list_w - self._SB_W - self._ROW_INSET_X
        self._sb_track_y = list_y
        self._sb_track_h = visible_rows * row_total - self._ROW_GAP
        self._sb_arrow_h = max(self._SB_W, int(self._H * 16 / 720))
        self._sb_gutter_y = self._sb_track_y + self._sb_arrow_h
        self._sb_gutter_h = max(1, self._sb_track_h - 2 * self._sb_arrow_h)

        # Textura blanca: colorDiffuse multiplica el color del PNG, así que
        # sobre panel_bg (gris muy oscuro) el thumb nunca saldría blanco.
        # Con white.png el diffuse da el color literal (blanco puro en el
        # thumb, gris en el canal).
        white = self._media_path('white.png')
        self._scrollbar_track = xbmcgui.ControlImage(
            self._sb_x, self._sb_track_y, self._SB_W, self._sb_track_h,
            white, aspectRatio=0, colorDiffuse=self._C_SB_TRACK,
        )
        self.addControl(self._scrollbar_track)

        # Tamaño y posición del thumb se ajustan dinámicamente en
        # _update_scrollbar tras cada render.
        self._scrollbar_thumb = xbmcgui.ControlImage(
            self._sb_x, self._sb_gutter_y, self._SB_W, self._ROW_H,
            white, aspectRatio=0, colorDiffuse=self._C_SB_THUMB,
        )
        self.addControl(self._scrollbar_thumb)

        # Flechas: ControlImage (glifo blanco visible) + ControlButton
        # transparente encima como captador de click. El click se detecta por
        # FOCO (getFocusId en _handle_pan), no por coordenadas: es lo único
        # fiable con ratón, igual que el botón Cerrar. Los botones se
        # auto-loopean para no robar foco al D-pad. El thumb viaja por el
        # gutter (entre las flechas), así no se solapa con los captadores.
        transparent = self._media_path('transparent.png')
        up_y = self._sb_track_y
        down_y = self._sb_track_y + self._sb_track_h - self._sb_arrow_h
        self._scrollbar_up_img = xbmcgui.ControlImage(
            self._sb_x, up_y, self._SB_W, self._sb_arrow_h,
            self._media_path('arrow_up.png'), aspectRatio=2,
        )
        self.addControl(self._scrollbar_up_img)
        self._scrollbar_down_img = xbmcgui.ControlImage(
            self._sb_x, down_y, self._SB_W, self._sb_arrow_h,
            self._media_path('arrow_down.png'), aspectRatio=2,
        )
        self.addControl(self._scrollbar_down_img)
        self._scrollbar_up = xbmcgui.ControlButton(
            self._sb_x, up_y, self._SB_W, self._sb_arrow_h,
            label='', focusTexture=transparent, noFocusTexture=transparent,
        )
        self.addControl(self._scrollbar_up)
        self._scrollbar_down = xbmcgui.ControlButton(
            self._sb_x, down_y, self._SB_W, self._sb_arrow_h,
            label='', focusTexture=transparent, noFocusTexture=transparent,
        )
        self.addControl(self._scrollbar_down)
        for btn in (self._scrollbar_up, self._scrollbar_down):
            btn.controlUp(btn)
            btn.controlDown(btn)
            btn.controlLeft(btn)
            btn.controlRight(btn)

    def _build_footer(self, panel_bg):
        footer_y = self._PANEL_Y + self._PANEL_H - self._FOOTER_H
        self.addControl(xbmcgui.ControlImage(
            self._PANEL_X, footer_y, self._PANEL_W, 1,
            panel_bg,
            aspectRatio=0, colorDiffuse=self._C_BORDER,
        ))
        hint_h = int(self._H * 22 / 720)
        self.addControl(xbmcgui.ControlLabel(
            self._PANEL_X + self._PAD,
            footer_y + (self._FOOTER_H - hint_h) // 2,
            self._PANEL_W - self._PAD * 2,
            hint_h,
            '[B]OK[/B] seleccionar    [B]Atrás[/B] cancelar    [B]Flechas[/B] navegar',
            font=self._FONT_HINT,
            textColor=self._C_HINT,
        ))

    @property
    def _visible_rows(self):
        return len(self._slots)

    def _scroll_to_cursor(self):
        if not self._slots:
            self._offset = 0
            return
        if self._cursor < self._offset:
            self._offset = self._cursor
        elif self._cursor >= self._offset + self._visible_rows:
            self._offset = self._cursor - self._visible_rows + 1
        max_offset = max(0, len(self._items) - self._visible_rows)
        self._offset = max(0, min(self._offset, max_offset))

    def _render(self):
        for i, (btn, icon) in enumerate(self._slots):
            idx = self._offset + i
            if idx >= len(self._items):
                btn.setLabel('')
                btn.setEnabled(False)
                btn.setVisible(False)
                icon.setVisible(False)
                continue
            item = self._items[idx]
            btn.setLabel(item.label)
            btn.setEnabled(True)
            btn.setVisible(True)
            if self._show_icons and item.icon:
                icon.setImage(item.icon)
                icon.setVisible(True)
            else:
                icon.setVisible(False)
        self._refresh_plot_and_counter()

    def _refresh_plot_and_counter(self):
        if self._plot_box is not None:
            if 0 <= self._cursor < len(self._items):
                plot_text = self._items[self._cursor].plot or ''
            else:
                plot_text = ''
            self._plot_box.setText(plot_text)
            # setText resetea el scroll del textbox; si el contenido excede
            # el área visible y el plot no es focusable (los botones lo son),
            # activar autoScroll para que el usuario pueda leerlo entero.
            if self._plot_overflows(plot_text):
                try:
                    self._plot_box.autoScroll(2500, 3500, True)
                except (RuntimeError, AttributeError) as e:
                    log.debug(f'ui_select plot autoScroll falló: {e}')
        self._counter_label.setLabel(
            f'{self._cursor + 1} de {len(self._items)}'
        )
        self._update_scrollbar()

    def _plot_overflows(self, text):
        if not text or self._PLOT_AREA_W <= 0:
            return False
        plot_w_box = self._PLOT_AREA_W - self._PAD * 2
        plot_h_box = (self._PANEL_H - self._HEADER_H
                      - self._FOOTER_H - self._PAD * 2)
        if plot_w_box <= 0 or plot_h_box <= 0:
            return False
        # Heurística para font14: ~8 px/char y ~20 px/line incluyendo gap.
        chars_per_line = max(15, plot_w_box // 8)
        visible_lines = max(1, plot_h_box // 20)
        return _line_estimate(text, chars_per_line=chars_per_line) > visible_lines

    def _update_scrollbar(self):
        if self._scrollbar_track is None:
            return
        n = len(self._items)
        visible = self._visible_rows
        show = n > visible
        for ctrl in (self._scrollbar_track, self._scrollbar_thumb,
                     self._scrollbar_up, self._scrollbar_down,
                     self._scrollbar_up_img, self._scrollbar_down_img):
            if ctrl is not None:
                ctrl.setVisible(show)
        if not show:
            return

        gutter_h = self._sb_gutter_h
        min_thumb_h = max(20, self._ROW_H // 2)
        thumb_h = max(min_thumb_h, int(gutter_h * visible / n))
        thumb_h = min(thumb_h, gutter_h)

        max_offset = n - visible
        if max_offset > 0:
            thumb_y = self._sb_gutter_y + int(
                (gutter_h - thumb_h) * self._offset / max_offset
            )
        else:
            thumb_y = self._sb_gutter_y

        try:
            self._scrollbar_thumb.setHeight(thumb_h)
            self._scrollbar_thumb.setPosition(self._sb_x, thumb_y)
        except (RuntimeError, AttributeError) as e:
            # Algunas builds antiguas no exponen setHeight/setPosition
            # en ControlImage. Sin resize visible, pero no es crítico.
            log.debug(f'ui_select scrollbar resize falló: {e}')

    def _focus_cursor(self):
        slot_idx = self._cursor - self._offset
        if 0 <= slot_idx < len(self._slots):
            btn, _ = self._slots[slot_idx]
            self.setFocus(btn)

    def _focused_slot_index(self):
        try:
            fid = self.getFocusId()
        except (RuntimeError, SystemError):
            return None
        for i, (btn, _) in enumerate(self._slots):
            if btn.getId() == fid:
                return i
        return None

    def onAction(self, action):
        aid = action.getId()

        if aid in self._CLOSE_ACTIONS:
            self.result = -1
            self.close()
            return

        # Arrastre táctil (Android) o drag de ratón: una lista de
        # ControlButton hechos a mano no scrollea sola, así que traducimos
        # el gesto a desplazamiento. Va antes del bloque text_only para
        # que el arrastre funcione también en show_text.
        if self._handle_pan(aid, action):
            return

        # Modo text_only: no hay lista, las teclas de navegación scrollean
        # el textbox. SELECT solo cierra si el foco está en el botón Cerrar
        # del header (el único focusable en este modo).
        if self._text_only:
            if aid in self._SELECT_ACTIONS:
                if self._close_button is not None:
                    try:
                        if self.getFocusId() == self._close_button.getId():
                            self.close()
                            return
                    except (RuntimeError, SystemError):
                        pass
                return
            if aid in self._WHEEL_UP:
                self._scroll_text(-3)
                return
            if aid in self._WHEEL_DOWN:
                self._scroll_text(3)
                return
            if aid in self._UP_ACTIONS:
                self._scroll_text(-1)
                return
            if aid in self._DOWN_ACTIONS:
                self._scroll_text(1)
                return
            if aid in self._PAGE_UP_ACTIONS:
                self._scroll_text(-10)
                return
            if aid in self._PAGE_DOWN_ACTIONS:
                self._scroll_text(10)
                return
            return

        # Para SELECT (Enter o click), sincronizar cursor con el foco
        # actual primero por si llegamos aquí desde un hover de ratón.
        if aid in self._SELECT_ACTIONS:
            # Click sobre el botón Cerrar del header: cierra el dialog.
            if self._close_button is not None:
                try:
                    if self.getFocusId() == self._close_button.getId():
                        if self._build is None:
                            self.result = -1
                        self.close()
                        return
                except (RuntimeError, SystemError):
                    pass

            slot = self._focused_slot_index()
            if slot is not None:
                self._cursor = self._offset + slot
            if not (0 <= self._cursor < len(self._items)):
                return
            if self._build is None:
                # Modo `select`: cerrar y devolver el índice.
                self.result = self._cursor
                self.close()
                return
            # Modo `menu`: ejecutar la action del item sin cerrar.
            item = self._items[self._cursor]
            if item.action is None:
                return  # Item informativo: ignorar pulsación.
            try:
                item.action()
            except CloseMenu:
                self.close()
                return
            except Exception as e:
                log.error(f'ui_select.menu: action falló: {e!r}')
                return
            self._reload_items()
            return

        # Flechas: cursor manual, no dependemos del foco automático
        # de Kodi (que no se movía con flechas en WindowDialog).
        if aid in self._UP_ACTIONS:
            self._move_cursor(-1)
            return
        if aid in self._DOWN_ACTIONS:
            self._move_cursor(1)
            return
        if aid in self._PAGE_UP_ACTIONS:
            self._move_cursor(-self._visible_rows)
            return
        if aid in self._PAGE_DOWN_ACTIONS:
            self._move_cursor(self._visible_rows)
            return

        # Rueda del ratón: scrollea la ventana visible (offset), sin
        # tocar el cursor directamente. El highlight queda en el item
        # que pasa por debajo del puntero del ratón gracias al sync
        # de hover de ACTION_MOUSE_MOVE. Esto evita el "baja y vuelve"
        # que sale si la rueda mueve el cursor y luego el hover lo
        # resincroniza al slot bajo el ratón.
        if aid in self._WHEEL_UP:
            self._scroll_offset(-1)
            return
        if aid in self._WHEEL_DOWN:
            self._scroll_offset(1)
            return

        # Mouse hover: Kodi mueve el foco al control sobrevolado.
        # Sincronizamos el cursor con el foco real para que el plot
        # refleje la fila bajo el ratón.
        if aid == xbmcgui.ACTION_MOUSE_MOVE:
            slot = self._focused_slot_index()
            if slot is None:
                return
            new_cursor = self._offset + slot
            if new_cursor != self._cursor and 0 <= new_cursor < len(self._items):
                self._cursor = new_cursor
                self._refresh_plot_and_counter()
            return

    def _move_cursor(self, delta):
        if not self._items:
            return
        n = len(self._items)
        # Wrap-around natural en listas de Kodi.
        new_cursor = (self._cursor + delta) % n
        if delta == 0 or new_cursor == self._cursor:
            return
        self._cursor = new_cursor
        self._scroll_to_cursor()
        self._render()
        self._focus_cursor()

    def _scroll_text(self, delta):
        """Scrollea el ControlTextBox del modo text_only por `delta` líneas.

        ControlTextBox.scroll(line) salta a una línea concreta. Sin API
        para preguntar cuántas líneas tiene tras el wrapping, dejamos que
        Kodi sature en el fondo cuando nos pasamos. El offset solo se
        clampa por abajo a 0.
        """
        if self._plot_box is None:
            return
        new_offset = max(0, self._text_offset + delta)
        if new_offset == self._text_offset and delta != 0:
            return
        self._text_offset = new_offset
        try:
            self._plot_box.scroll(self._text_offset)
        except (RuntimeError, AttributeError) as e:
            log.debug(f'ui_select textbox scroll falló: {e}')

    def _scrollbar_arrow_zone(self, x, y):
        """'up' | 'down' | None según si (x, y) cae sobre una flecha. Respaldo
        para el táctil, donde el toque puede llegar como gesto (no como click
        con foco). Banda horizontal ancha para acertar con el dedo.
        """
        if self._scrollbar_track is None or self._text_only:
            return None
        if len(self._items) <= self._visible_rows:
            return None
        hit_pad = max(self._SB_W, int(self._W * 20 / 1280))
        if not (self._sb_x - hit_pad <= x <= self._sb_x + self._SB_W + hit_pad):
            return None
        if self._sb_track_y <= y < self._sb_gutter_y:
            return 'up'
        if (self._sb_gutter_y + self._sb_gutter_h
                <= y <= self._sb_track_y + self._sb_track_h):
            return 'down'
        return None

    def _focused_arrow(self):
        """'up'|'down'|None según si el foco está en un botón de flecha.
        Detección por foco (no por coordenadas): es lo único fiable para el
        ratón, igual que el botón Cerrar.
        """
        try:
            fid = self.getFocusId()
        except (RuntimeError, SystemError):
            return None
        if self._scrollbar_up is not None and fid == self._scrollbar_up.getId():
            return 'up'
        if self._scrollbar_down is not None and fid == self._scrollbar_down.getId():
            return 'down'
        return None

    def _handle_pan(self, aid, action):
        """Flechas del scrollbar (subir/bajar una fila) y arrastre táctil de la
        lista (scroll por delta).

        Las flechas con ratón se detectan por FOCO (fiable, igual que Cerrar).
        En táctil, donde el toque llega como gesto, se detectan por zona de
        coordenadas como respaldo. El arrastre del thumb no existe con ratón
        (Kodi no manda ACTION_MOUSE_DRAG a controles que no lo reclaman) y se
        descartó; el canal vacío no hace nada (las flechas y la rueda bastan).
        """
        # Click de ratón sobre una flecha (por foco). Fuera de las flechas
        # devolvemos False para que siga la selección normal de la lista.
        if aid == xbmcgui.ACTION_MOUSE_LEFT_CLICK:
            arrow = self._focused_arrow()
            if arrow == 'up':
                self._scroll_offset(-1)
                return True
            if arrow == 'down':
                self._scroll_offset(1)
                return True
            return False

        if aid in self._PAN_END:
            self._pan_anchor_y = None
            self._pan_accum = 0.0
            return True

        if aid in self._PAN_BEGIN or aid in self._PAN_MOVE:
            x = action.getAmount1()
            y = action.getAmount2()
            # Primer evento del gesto: si cae sobre una flecha, una fila.
            if self._pan_anchor_y is None:
                self._pan_anchor_y = y
                self._pan_accum = 0.0
                zone = self._scrollbar_arrow_zone(x, y)
                if zone == 'up':
                    self._scroll_offset(-1)
                elif zone == 'down':
                    self._scroll_offset(1)
                return True
            # Arrastre de la lista: delta sobre el offset (o el textbox).
            # Dedo hacia arriba (dy<0) descubre items posteriores: scroll
            # positivo. Por eso aplicamos -rows en ambos modos.
            self._pan_accum += y - self._pan_anchor_y
            self._pan_anchor_y = y
            rows = int(self._pan_accum / self._ROW_H)
            if rows:
                self._pan_accum -= rows * self._ROW_H
                if self._text_only:
                    self._scroll_text(-rows)
                else:
                    self._scroll_offset(-rows)
            return True
        return False

    def _scroll_offset(self, delta):
        """Desplaza la ventana visible sin tocar el cursor 'lógico'.

        Si el cursor queda fuera de la ventana visible tras el scroll,
        lo arrastra al borde más cercano para mantener el highlight en
        pantalla. Si el ratón está sobre la lista, el siguiente
        ACTION_MOUSE_MOVE acabará sincronizando el cursor al item bajo
        el puntero; comportamiento natural de scroll de escritorio.
        """
        if not self._items:
            return
        n = len(self._items)
        if n <= self._visible_rows:
            return
        max_offset = n - self._visible_rows
        self._commit_offset(max(0, min(self._offset + delta, max_offset)))

    def _commit_offset(self, new_offset):
        """Fija el offset, arrastra el cursor a la ventana visible si quedó
        fuera, y re-renderiza. El llamante ya entrega el offset clampado.
        """
        if new_offset == self._offset:
            return
        self._offset = new_offset
        visible = self._visible_rows
        if self._cursor < self._offset:
            self._cursor = self._offset
        elif self._cursor >= self._offset + visible:
            self._cursor = self._offset + visible - 1
        self._render()
        self._focus_cursor()

    def _reload_items(self):
        """Recalcula los items con build() (modo menu) y re-renderiza
        sin cerrar la ventana. Si build() devuelve lista vacía, cierra.
        """
        if self._build is None:
            return
        new_items = self._build()
        if not new_items:
            self.close()
            return
        self._items = new_items
        if self._cursor >= len(self._items):
            self._cursor = max(0, len(self._items) - 1)
        self._scroll_to_cursor()
        self._render()
        self._focus_cursor()
