"""Fallback de resolución in-process vía el addon `script.module.youtube.dl`.

A diferencia de `ytdlp_resolver` (yt-dlp del sistema por subprocess), esto corre
en el Python embebido de Kodi, así que funciona también en Android y sin Python
instalado. El addon expone el módulo `youtube_dl` (API `YoutubeDL`, idéntica a
yt-dlp). Es más limitado que el yt-dlp del sistema para YouTube (sin runtime JS),
pero cubre muchos sitios y es el único backend in-process disponible en Android.

Devuelve el mismo dict que `ytdlp_resolver.resolve_full` ({url, headers,
protocol, ext}) para que el caller los trate igual.
"""
import xbmc

from lib import log

ADDON_ID = 'script.module.youtube.dl'


def is_available():
    """True si el addon está instalado. Su `lib/` lo añade Kodi al path por la
    dependencia opcional declarada en addon.xml.
    """
    return xbmc.getCondVisibility(f'System.HasAddon({ADDON_ID})')


def _pick_stream(info):
    """Extrae {url, headers, protocol, ext} del info dict de youtube_dl, o None.
    Si es playlist, toma la primera entrada; si no hay url top-level (el selector
    de formato no la fijó), cae al mejor formato con url.
    """
    if not isinstance(info, dict):
        return None
    if 'entries' in info:
        entries = [e for e in (info.get('entries') or []) if e]
        if not entries:
            return None
        info = entries[0]
    stream = info.get('url')
    headers = info.get('http_headers') or {}
    ext = info.get('ext') or ''
    protocol = info.get('protocol') or ''
    if not stream:
        for fmt in reversed(info.get('formats') or []):
            if fmt.get('url'):
                stream = fmt['url']
                headers = fmt.get('http_headers') or headers
                ext = fmt.get('ext') or ext
                protocol = fmt.get('protocol') or protocol
                break
    if not stream:
        return None
    return {'url': stream, 'headers': headers, 'protocol': protocol, 'ext': ext}


def resolve_full(url, fmt='best[ext=mp4]/best'):
    """Resuelve `url` con el módulo youtube_dl del addon. Dict o None.

    NUNCA propaga: el módulo carga cientos de extractores de terceros que
    pueden lanzar cualquier cosa; un fallo suyo solo debe dar None.
    """
    if not is_available():
        return None
    try:
        import youtube_dl
    except Exception as e:
        # Ancho a propósito: importar youtube_dl ejecuta el init de cientos de
        # extractores de terceros, que puede fallar más allá de ImportError
        # (módulo ausente, dep transitiva rota, etc.). No debe tumbar la
        # reproducción.
        log.warning(f'[ytdlp_addon] import youtube_dl falló: {e!r}')
        return None
    # socket_timeout acota la espera de red: corremos in-process (sin el
    # timeout de subprocess del yt-dlp de sistema), y el default de youtube_dl
    # son 600s; un sitio lento no debe congelar la reproducción.
    opts = {
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'skip_download': True,
        'socket_timeout': 15,
        'format': fmt,
    }
    try:
        with youtube_dl.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception as e:
        log.warning(f'[ytdlp_addon] extract_info falló: {e!r}')
        return None
    return _pick_stream(info)
