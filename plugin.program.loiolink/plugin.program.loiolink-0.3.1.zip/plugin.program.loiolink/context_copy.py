"""Item de menú contextual: copia el label del item enfocado al portapapeles
interno de loiolink (que ya sincroniza al portapapeles del SO si la setting
`clipboard.sync_to_os` está activa).

Flujo inverso al de `context.py`: en vez de PEGAR el clipboard en el item
enfocado, COPIA el texto visible del item al clipboard.
"""
import re
import sys

import xbmc
import xbmcgui

import clipboard
from lib import accessibility


LOG_PREFIX = '[loiolink.context_copy]'

# Whitelist cerrada de tags BBCode de Kodi (https://kodi.wiki/view/Label_formatting).
# Lista cerrada para NO comerse texto literal entre corchetes que NO es BBCode,
# como '[REC]' (título de peli) o '[Director's Cut]'.
_BBCODE_RE = re.compile(
    r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR|COLOR|TABS|FONT)'
    r'(?:[ =][^\]]*)?\]',
    re.IGNORECASE,
)

# Placeholders de navegación que no aportan nada copiar.
_USELESS_LABELS = frozenset(('..', '.', '/'))


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{LOG_PREFIX} {msg}', level)


def _strip_bbcode(text):
    return _BBCODE_RE.sub('', text).strip()


def _read_focused_label():
    """Lee el texto del item sobre el que se abrió el menú contextual.

    Prioridad: sys.listitem (snapshot oficial que Kodi pasa al handler) sobre
    InfoLabel del foco actual. sys.listitem es el item canónico; InfoLabel
    puede haber driftado si el cursor se movió tras abrir el menú.
    """
    label = ''
    if hasattr(sys, 'listitem') and sys.listitem:
        try:
            label = sys.listitem.getLabel() or ''
        except (AttributeError, RuntimeError) as e:
            log(f'sys.listitem.getLabel error: {e}', xbmc.LOGDEBUG)
    if not label:
        label = xbmc.getInfoLabel('ListItem.Label') or ''
    label = _strip_bbcode(label)
    if label in _USELESS_LABELS:
        return ''
    return label


def main():
    label = _read_focused_label()
    if not label:
        accessibility.notify('Nada que copiar', xbmcgui.NOTIFICATION_WARNING, 2000)
        log('label vacio o inutil, abortando', xbmc.LOGDEBUG)
        return

    clipboard.set(label)
    accessibility.notify(f'Copiado: {label[:80]}')
    log(f'copiado, len={len(label)}, preview={label[:40]!r}')


if __name__ == '__main__':
    # Red de seguridad: si algo falla en runtime, notificamos al usuario en
    # vez de dejarlo sin feedback con solo un traceback en kodi.log.
    try:
        main()
    except Exception as e:
        xbmc.log(f'{LOG_PREFIX} error inesperado: {e}', xbmc.LOGERROR)
        accessibility.notify('Error al copiar', xbmcgui.NOTIFICATION_ERROR, 2000)
