"""Portapapeles interno persistente durante la sesión Kodi (Window 10000 prop).

set() también propaga al clipboard del SO cuando es posible (N1 del plan
de fixes). Así el texto recibido del móvil se puede pegar EN CUALQUIER
SITIO (campos del skin, otros addons sin context menu, apps externas),
no solo en cuadros de búsqueda de addons que tengan loiolink instalado.

Setting `clipboard.sync_to_os` (bool, default true) controla el sync.
"""
import re

import xbmc
import xbmcaddon
import xbmcgui


PROPERTY_NAME = 'loiolink.clipboard'
WIN_HOME = 10000
SETTING_SYNC_TO_OS = 'clipboard.sync_to_os'

_CTRL_CHARS_RE = re.compile(r'[\x00-\x08\x0b-\x1f\x7f]')


def sanitize(text):
    """Limpia chars que rompen Input.SendText (control chars, saltos de línea)."""
    if not text:
        return ''
    cleaned = _CTRL_CHARS_RE.sub(
        '',
        text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' '),
    )
    return cleaned.strip()


def get():
    raw = xbmcgui.Window(WIN_HOME).getProperty(PROPERTY_NAME) or ''
    return sanitize(raw)


def _sync_to_os_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_SYNC_TO_OS)
    except RuntimeError:
        # Pre-init: el addon todavía no está cargado. Default true conservador.
        return True


def set(text):
    clean = sanitize(text)
    xbmcgui.Window(WIN_HOME).setProperty(PROPERTY_NAME, clean)
    # Propagar al clipboard del SO si está activado. Catch ancho justificado:
    # handler de I/O del SO, no debe tumbar el flujo principal si falla en
    # Android sin JNI, Linux sin xclip, etc.
    if clean and _sync_to_os_enabled():
        try:
            from lib import os_clipboard
            os_clipboard.set_system_clipboard(clean)
        except Exception as e:
            xbmc.log(f'[loiolink] clipboard: sync_to_os falló: {e}', xbmc.LOGDEBUG)


def clear():
    xbmcgui.Window(WIN_HOME).clearProperty(PROPERTY_NAME)
