"""Migraciones versionadas de settings y datos del addon.

Llamado desde service.py:run() al arrancar. Cada migración debe ser
idempotente: volverla a correr no debe causar daño (importante por si la
versión almacenada se corrompe o si una migración falla y se reintenta).

Para añadir una migración nueva:
1. Subir _LATEST_VERSION.
2. Añadir handler `_migrate_vN_to_vN_plus_1()`.
3. Registrarlo en _MIGRATIONS.
"""
import xbmcaddon

from lib import log
from lib.transfers import history


SETTING_SCHEMA_VERSION = '_settings_schema_version'
_LATEST_VERSION = 2


def _get_current_version():
    raw = (xbmcaddon.Addon().getSetting(SETTING_SCHEMA_VERSION) or '').strip()
    try:
        return int(raw)
    except ValueError:
        return 0


def _set_current_version(version):
    xbmcaddon.Addon().setSetting(SETTING_SCHEMA_VERSION, str(version))


def _migrate_v0_to_v1():
    """Migra el token legacy a una sesión nueva.

    El modelo viejo era un único token global en setting `remote_auth_token`.
    El modelo nuevo (lib.remote.sessions) son sesiones por dispositivo en
    addon_data/sessions.json. Si el setting legacy tiene valor, se crea
    una sesión 'Sesión original' y el setting se vacía.

    Idempotente: si ya se migró, no hace nada. Si no había token legacy
    tampoco hace nada: el primer pareo creará la primera sesión.
    """
    from lib.remote import sessions
    sessions.migrate_legacy_token()


def _migrate_v1_to_v2():
    """Rellena `source='unknown'` en entries del historial antiguos.

    El campo `source` se introdujo después del primer release; entries
    creadas antes lo tienen ausente.
    """
    # Usa la API privada de history a propósito: necesitamos el lock y
    # _save() atómico, sin pasar por add() que crea entries nuevas.
    with history._LOCK:
        entries = history._load()
        changed = False
        for e in entries:
            if not e.get('source'):
                e['source'] = 'unknown'
                changed = True
        if changed:
            history._save(entries)


_MIGRATIONS = {
    0: _migrate_v0_to_v1,
    1: _migrate_v1_to_v2,
}


def apply_pending():
    """Aplica todas las migraciones pendientes en orden.

    Si una migración falla, registra el error y aborta sin avanzar la
    versión; el siguiente arranque la reintentará.
    """
    version = _get_current_version()
    if version >= _LATEST_VERSION:
        return
    log.info(
        f'settings schema v{version} → v{_LATEST_VERSION}: '
        'aplicando migraciones',
    )
    while version < _LATEST_VERSION:
        migration = _MIGRATIONS.get(version)
        if migration is None:
            log.error(f'No hay handler para migración v{version}')
            return
        try:
            migration()
        except Exception as e:
            log.error(f'Migración v{version}→v{version + 1} falló: {e}')
            return
        version += 1
        _set_current_version(version)
        log.info(f'settings schema actualizado a v{version}')
