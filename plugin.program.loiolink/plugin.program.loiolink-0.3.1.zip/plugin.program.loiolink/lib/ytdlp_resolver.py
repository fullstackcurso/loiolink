"""Wrapper de yt-dlp vía subprocess. Inspirado en plugin.video.espatv.

APIs:
- is_available()        → solo chequea plataforma (Android no). Instantáneo.
- is_installed()        → cache persistido en disco (TTL 1h) de Python+yt-dlp.
                          Bool. Cold cache: ~3-5s peor caso (detección síncrona).
                          Warm cache: <50ms (lee JSON).
- resolve(url, fmt)     → string URL del stream o None.
- resolve_full(url, fmt)→ dict {url, headers, protocol, ext} o None.
- scan_videos(url)      → lista de dicts (vídeos detectados, kind='video').
- invalidate_installed_cache() → borra el JSON; siguiente is_installed re-detecta.
- meaningful_headers(headers) → filtra los headers que Kodi ya inyecta.

Decisiones clave (vs espatv):

- **Cache persistido en disco**: espatv usa cache módulo-global, que en Kodi
  se pierde entre invocaciones plugin:// (cada plugin URL arranca subprocess
  nuevo del addon). Sin persistencia, cada paste_clipboard pagaría la
  detección completa.
- **Timeouts agresivos (2-3s)**: un sistema sano responde en milisegundos a
  `python -c "import sys; print(...)"`. Si tarda más, lo damos por roto.
- **Detección Python en cascada**: python3 → python → py (cubre Linux moderno
  sin alias `python`, Windows con `py` launcher, macOS).
- **`--extractor-args youtube:player_client=tv,web_safari,mweb,tv_simply`**:
  yt-dlp prueba múltiples player clients YouTube como fallback intra-yt-dlp
  ante bot-block. Sin coste y robustez extra (espatv).
"""
import json
import os
import subprocess
import tempfile
import time

import xbmc
import xbmcvfs

from lib import log


_CREATE_NO_WINDOW = 0x08000000
_PYTHON_CANDIDATES = ('python3', 'python', 'py')
_PYTHON_MIN = (3, 10)
_PY_PROBE_TIMEOUT = 2
_YTDLP_PROBE_TIMEOUT = 3
_CACHE_TTL = 3600  # 1 hora

_PROFILE = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/',
)
_CACHE_PATH = os.path.join(_PROFILE, 'ytdlp_status.json')

# Headers que el player Kodi ya inyecta o ignora. Solo pasamos los que
# diferencian (Auth, Cookie custom, Referer no-genérico). Tomado de espatv.
_GENERIC_HEADERS = frozenset({
    'user-agent', 'accept', 'accept-language', 'accept-encoding',
    'sec-fetch-dest', 'sec-fetch-mode', 'sec-fetch-site',
    'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform',
})


def is_available():
    """False en Android (sin python del sistema). Instantáneo."""
    return not xbmc.getCondVisibility('System.Platform.Android')


def _creation_flags():
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return _CREATE_NO_WINDOW
    return 0


def _load_cache():
    try:
        with open(_CACHE_PATH, encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    checked_at = data.get('checked_at', 0)
    if not isinstance(checked_at, (int, float)) or time.time() - checked_at > _CACHE_TTL:
        return None
    return data


def _save_cache(python_cmd, ytdlp_version):
    """Atomic write race-safe.

    En Kodi cada plugin:// arranca subprocess separado del addon → dos
    invocaciones concurrentes (panel web + UI) podrían disparar `is_installed()`
    simultáneamente con cold cache. Sin atomic write, `open(path, 'w')` trunca
    el archivo y la segunda llamada puede pisar a la primera, dejando JSON
    parcial o mixto. `_load_cache` tolera corrupción (devuelve None → re-detect),
    pero pagamos el coste extra. `mkstemp` por llamada + `os.replace` da
    atomicidad garantizada en NTFS/ext4/APFS dentro del mismo volumen, idéntico
    al patrón de `lib/url_input_history.save`.
    """
    payload = {
        'checked_at': int(time.time()),
        'python_cmd': python_cmd,
        'ytdlp_version': ytdlp_version,
    }
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        fd, tmp = tempfile.mkstemp(
            prefix='ytdlp_status_', suffix='.tmp', dir=_PROFILE,
        )
    except OSError as e:
        log.warning(f'[ytdlp_resolver] mkstemp falló: {e!r}')
        return
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(payload, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, _CACHE_PATH)
    except OSError as e:
        log.warning(f'[ytdlp_resolver] cache save falló: {e!r}')
        try:
            os.remove(tmp)
        except OSError:
            pass


def _detect_python_uncached():
    if not is_available():
        return None
    for cmd in _PYTHON_CANDIDATES:
        try:
            r = subprocess.run(
                [cmd, '-c', 'import sys; print(sys.version_info[0], sys.version_info[1])'],
                capture_output=True, timeout=_PY_PROBE_TIMEOUT, text=True,
                creationflags=_creation_flags(),
            )
            if r.returncode != 0:
                continue
            major, minor = (int(x) for x in r.stdout.strip().split())
            if (major, minor) >= _PYTHON_MIN:
                return cmd
        except (OSError, subprocess.TimeoutExpired, ValueError):
            continue
    return None


def is_installed():
    """True si hay Python>=3.10 + yt-dlp utilizable. Resultado en cache disco
    durante _CACHE_TTL segundos. Bool explícito.
    """
    cached = _load_cache()
    if cached is not None:
        return bool(cached.get('python_cmd') and cached.get('ytdlp_version'))
    # Cold: re-detección síncrona (peor caso ~9s = 3 probes Python × 2s + 3s yt-dlp;
    # caso típico <1s porque python3 responde inmediato).
    py = _detect_python_uncached()
    if not py:
        _save_cache(None, None)
        return False
    try:
        r = subprocess.run(
            [py, '-c', 'import yt_dlp; print(yt_dlp.version.__version__)'],
            capture_output=True, timeout=_YTDLP_PROBE_TIMEOUT, text=True,
            creationflags=_creation_flags(),
        )
        version = r.stdout.strip() if r.returncode == 0 else ''
    except (OSError, subprocess.TimeoutExpired):
        version = ''
    _save_cache(py if version else None, version or None)
    return bool(version)


def _get_python():
    """Devuelve el binario Python utilizable o None. Warms up cache si hace falta."""
    cached = _load_cache()
    if cached is not None:
        return cached.get('python_cmd')
    is_installed()
    cached = _load_cache()
    return cached.get('python_cmd') if cached else None


def invalidate_installed_cache():
    """Borra el JSON. Siguiente is_installed() re-detecta."""
    try:
        if os.path.isfile(_CACHE_PATH):
            os.remove(_CACHE_PATH)
    except OSError as e:
        log.warning(f'[ytdlp_resolver] invalidate cache falló: {e!r}')


def _build_args(extra):
    base = [
        '--dump-json', '--no-download',
        '--extractor-args', 'youtube:player_client=tv,web_safari,mweb,tv_simply',
    ]
    base.extend(extra or [])
    return base


def _run(cmd_extra, url, timeout):
    py = _get_python()
    if not py:
        return None
    cmd = [py, '-m', 'yt_dlp'] + _build_args(cmd_extra) + ['--', url]
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=timeout, text=True,
            encoding='utf-8', errors='replace',
            creationflags=_creation_flags(),
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning(f'[ytdlp_resolver] subprocess: {type(e).__name__}')
        return None
    if r.returncode != 0:
        log.warning(f'[ytdlp_resolver] exit={r.returncode}: {(r.stderr or "")[:200]}')
        return None
    return r.stdout


def resolve_full(url, fmt='best[ext=mp4]/best', timeout=30):
    """Resuelve URL única. Devuelve dict {url, headers, protocol, ext} o None.

    `headers` son los http_headers que yt-dlp recomienda — NO filtrados;
    el caller decide qué pasar al player (usar meaningful_headers).
    """
    stdout = _run(['--format', fmt], url, timeout)
    if not stdout:
        return None
    try:
        # `--dump-json` para una URL única devuelve una sola línea JSON; en
        # algunas plataformas yt-dlp escribe avisos extra antes. Tomar la
        # última línea no vacía que parsee como JSON.
        info = None
        for line in reversed(stdout.splitlines()):
            line = line.strip()
            if not line:
                continue
            try:
                info = json.loads(line)
                break
            except ValueError:
                continue
        if info is None:
            return None
    except (ValueError, IndexError):
        return None
    stream_url = info.get('url') or ''
    if not stream_url:
        return None
    return {
        'url': stream_url,
        'headers': info.get('http_headers') or {},
        'protocol': info.get('protocol') or '',
        'ext': info.get('ext') or '',
    }


def resolve(url, fmt='best[ext=mp4]/best', timeout=30):
    """Wrapper que devuelve solo la URL string. None si falla."""
    info = resolve_full(url, fmt, timeout)
    return info['url'] if info else None


def scan_videos(url, timeout=60):
    """Lista de {title, url, duration, filesize, ext, kind: 'video'}.
    Lista vacía si yt-dlp no disponible/falla.
    """
    stdout = _run(['--flat-playlist'], url, timeout)
    if not stdout:
        return []
    results = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            info = json.loads(line)
        except ValueError:
            continue
        vurl = info.get('url') or info.get('webpage_url') or ''
        if not vurl:
            continue
        results.append({
            'title': info.get('title') or vurl,
            'url': vurl,
            'duration': info.get('duration'),
            'filesize': info.get('filesize') or info.get('filesize_approx'),
            'ext': info.get('ext') or '',
            'kind': 'video',
        })
    return results


def meaningful_headers(headers):
    """Filtra headers genéricos. Devuelve dict (puede ser vacío)."""
    return {k: v for k, v in (headers or {}).items()
            if k.lower() not in _GENERIC_HEADERS}


def run_inline_script(script, args=(), timeout=20):
    """Ejecuta `script` (string Python) en el Python del SISTEMA, no en
    el embebido de Kodi. Devuelve stdout (str) o None si falla.

    Caso de uso: bypass del fingerprint TLS del Python embebido de Kodi
    cuando un CDN (Dailymotion en Windows) rechaza al embebido pero acepta
    al sistema. El script puede usar urllib stdlib o intentar requests con
    fallback. Patrón tomado de plugin.video.topzilla/default.py:2310.

    Args:
        script: código Python autocontenido (sin imports de loiolink).
                Recibe sys.argv[1:] como `args`.
        args:   tupla de strings (sanitizar el caller; van como argv).
        timeout: segundos máximos. Si expira, returncode no-cero.

    NUNCA propaga excepciones. Devuelve None ante cualquier fallo.
    """
    py = _get_python()
    if not py:
        return None
    cmd = [py, '-c', script] + list(args)
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=timeout, text=True,
            encoding='utf-8', errors='replace',
            creationflags=_creation_flags(),
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning(f'[ytdlp_resolver] inline script: {type(e).__name__}')
        return None
    if r.returncode != 0:
        log.warning(
            f'[ytdlp_resolver] inline script exit={r.returncode}: '
            f'{(r.stderr or "")[:200]}',
        )
        return None
    return r.stdout
