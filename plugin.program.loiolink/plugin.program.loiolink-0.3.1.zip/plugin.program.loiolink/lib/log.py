"""Wrapper sobre xbmc.log con prefijo [loiolink]. Filtrable en kodi.log.

`security()` usa un prefijo distinto ([loiolink.SEC]) para que el usuario
pueda filtrar incidentes de seguridad sin verse inundado por logs normales.
"""
import xbmc
import xbmcaddon

_PREFIX = '[loiolink] '
_SEC_PREFIX = '[loiolink.SEC] '


def info(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGINFO)


def warning(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGWARNING)


def error(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGERROR)


def debug(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGDEBUG)


def security(msg):
    """Log de incidente de seguridad. WARNING level + prefix dedicado.

    Para filtrar: grep '\\[loiolink\\.SEC\\]' kodi.log
    """
    xbmc.log(_SEC_PREFIX + str(msg), xbmc.LOGWARNING)


def sensitive(msg):
    try:
        if xbmcaddon.Addon().getSettingBool('debug.sensitive_log'):
            xbmc.log(_PREFIX + str(msg), xbmc.LOGINFO)
    except RuntimeError:
        pass  # addon no inicializado: no se puede leer el setting
