"""Persistencia del estado de cada fuente monitorizada.

Guarda en addon_data/source_state.json un mapa indexado por sha256(path)
de la fuente con: nombre, kind (repo/generic/local), último hash conocido,
lista de addons vistos por última vez, contador de errores y flag de
"cambios reconocidos".

Mismo patrón de atomic write (.tmp + rename) que lib/transfers/history.py
para que un fallo a mitad de escritura no deje el archivo corrupto.

Concurrencia: `upsert`, `remove` y `transaction()` ejecutan el ciclo
read-modify-write bajo un único `RLock`, así dos threads del mismo proceso
no pueden pisarse cambios (escenario típico: HTTP handler del panel
modificando estado mientras el scanner de repos hace lo suyo). La lock
es reentrante para permitir que `transaction()` invoque `get()`/`load()`
en su interior sin deadlock.

Limitación conocida: el lock es intra-proceso. Kodi lanza cada invocación
de `RunPlugin` en un intérprete Python aparte; si dos invocaciones escriben
a la vez (ej. clicks rápidos), una puede perder cambios. El atomic write
garantiza que el JSON nunca quede corrupto, así que el peor caso es perder
una actualización aislada.
"""
import contextlib
import hashlib
import json
import os
import threading

import xbmcvfs


_PROFILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.loiolink/')
_STATE_FILE = os.path.join(_PROFILE, 'source_state.json')
_STATE_TMP = _STATE_FILE + '.tmp'

_lock = threading.RLock()


def path_key(path):
    """Hash estable del path para indexar el estado.

    sha256 sobre la representación normalizada del path. No tiene que ser
    criptográfico, solo determinista entre invocaciones.
    """
    return hashlib.sha256(path.strip().encode('utf-8')).hexdigest()


def _ensure_dir():
    if not os.path.isdir(_PROFILE):
        os.makedirs(_PROFILE, exist_ok=True)


def _load_unlocked():
    if not os.path.isfile(_STATE_FILE):
        return {}
    try:
        with open(_STATE_FILE, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _save_unlocked(state):
    _ensure_dir()
    with open(_STATE_TMP, 'w', encoding='utf-8') as fh:
        json.dump(state, fh, ensure_ascii=False, indent=2)
    os.replace(_STATE_TMP, _STATE_FILE)


def load():
    """Devuelve el dict completo. {} si no existe o está corrupto."""
    with _lock:
        return _load_unlocked()


def save(state):
    """Vuelca state a disco con atomic rename."""
    with _lock:
        _save_unlocked(state)


def upsert(path, **fields):
    """Crea o actualiza la entrada de `path` con los campos dados.

    Atómico: el ciclo read-modify-write se serializa bajo `_lock`.
    """
    with _lock:
        state = _load_unlocked()
        key = path_key(path)
        entry = state.get(key, {})
        entry.update(fields)
        entry.setdefault('path', path)
        state[key] = entry
        _save_unlocked(state)
    return entry


def get(path):
    with _lock:
        return _load_unlocked().get(path_key(path), {})


def mark_acknowledged(path):
    upsert(path, acknowledged=True)


def remove(path):
    with _lock:
        state = _load_unlocked()
        state.pop(path_key(path), None)
        _save_unlocked(state)


@contextlib.contextmanager
def transaction():
    """Permite leer y modificar el state completo en una operación atómica.

    Uso típico cuando hay que aplicar muchos cambios a la vez (ej. verify_all
    actualizando N fuentes), para evitar el coste de N×(load+save) y el
    racing entre iteraciones:

        with source_state.transaction() as state:
            for path, ok in results:
                key = source_state.path_key(path)
                entry = state.get(key, {})
                ...
                state[key] = entry

    Al salir del `with` el estado se vuelca a disco una sola vez. Si el
    bloque lanza, los cambios NO se persisten (es el comportamiento
    esperado: o se aplica todo o nada).
    """
    with _lock:
        state = _load_unlocked()
        yield state
        _save_unlocked(state)
