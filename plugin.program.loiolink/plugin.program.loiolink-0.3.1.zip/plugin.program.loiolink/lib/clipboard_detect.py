"""Detecta contenido importable en el clipboard del SO.

Usado por:
- lib/actions/menu.py: entrada "Importar: <preview>" destacada al abrir el
  menú principal, solo si hay algo útil en el clipboard.
- lib/actions/paste_clipboard.py: si es magnet, deriva a Elementum en vez
  de meterlo en el clipboard interno.

Setting `menu.detect_clipboard` (bool, default true). Opt-out por
privacidad. Si false, devuelve siempre None.

Privacidad: preview truncado a 50 chars. Tokens/claves base64-like de >40
chars se enmascaran como `<token>` para no exponer secrets en el menú.
"""
import re

import xbmcaddon


_ACESTREAM_RE = re.compile(r'^acestream://[a-fA-F0-9]{40}$', re.I)
_ACESTREAM_ID_RE = re.compile(r'^[a-fA-F0-9]{40}$', re.I)
_MAGNET_RE = re.compile(r'^magnet:\?', re.I)
_HTTP_RE = re.compile(r'^https?://[^\s]+', re.I)
_AFTV_CODE_RE = re.compile(r'^\d{4,6}$')
_BASE64_LIKE_RE = re.compile(r'^[A-Za-z0-9+/=_-]{40,}$')

_PREVIEW_MAX = 50
_SETTING_DETECT = 'menu.detect_clipboard'


def _detection_enabled():
    """¿El usuario tiene activada la detección de clipboard?"""
    try:
        return xbmcaddon.Addon().getSettingBool(_SETTING_DETECT)
    except RuntimeError:
        # Pre-init: addon todavía no cargado. Default true conservador.
        return True


def _make_preview(text, kind):
    """Trunca y enmascara para mostrar al usuario sin filtrar secrets."""
    if _BASE64_LIKE_RE.match(text):
        return '<contenido cifrado / token>'
    if len(text) <= _PREVIEW_MAX:
        return text
    return text[:_PREVIEW_MAX - 1] + '…'


def detect_importable():
    """Lee el clipboard del SO y devuelve (kind, value, preview) o None.

    kinds: 'acestream', 'magnet', 'stream_url', 'url', 'aftvnews_code'.

    Para `acestream` el `value` siempre es la URL canónica
    `acestream://hash` (lowercase), incluso si en el clipboard había el
    ID desnudo. Así los callers no tienen que volver a normalizar.
    """
    if not _detection_enabled():
        return None

    try:
        # Import diferido: lib/os_clipboard requiere xbmc, evita ciclos.
        from lib import os_clipboard
        raw = os_clipboard.get_system_clipboard()
    except (ImportError, OSError, RuntimeError):
        return None

    if not raw:
        return None
    text = raw.strip()
    if not text:
        return None

    if _ACESTREAM_RE.match(text):
        return ('acestream', text, _make_preview(text, 'acestream'))
    if _ACESTREAM_ID_RE.match(text):
        canon = f'acestream://{text.lower()}'
        return ('acestream', canon, _make_preview(canon, 'acestream'))
    if _MAGNET_RE.match(text):
        return ('magnet', text, _make_preview(text, 'magnet'))
    # Import diferido para no cargar xbmc en pre-init y romper ciclos.
    from lib.remote import stream_player
    if stream_player.is_stream_url(text):
        return ('stream_url', text, _make_preview(text, 'stream_url'))
    if _HTTP_RE.match(text):
        return ('url', text, _make_preview(text, 'url'))
    if _AFTV_CODE_RE.match(text):
        return ('aftvnews_code', text, text)
    return None
