"""Abstracción de jobs asíncronos para operaciones de backup desde el web.

El panel HTTP no tiene SSE ni WebSocket: cuando una operación tarda más de
unos segundos (un backup completo, un restore con red, una instalación
batch) el cliente necesita poder consultar el progreso por polling y
cancelar si quiere. Este módulo provee la pieza:

- `start_job(kind, func, *args, **kwargs)` arranca un thread daemon y
  devuelve el job_id.
- `get_job(job_id)` devuelve el estado actual (estable, dict serializable).
- `cancel_job(job_id)` marca el job como cancelado; la función worker debe
  consultar `make_cancel_check(job_id)` y abortar limpiamente cuando vea
  True.
- `make_progress_cb(job_id)` produce el callback `(done, total, msg)` que
  el worker pasa hacia abajo a `lib.backup`.

Los jobs viejos se purgan a `_JOB_TTL_S` (1 h) en cada start_job para evitar
crecimiento ilimitado.
"""
import threading
import time
import uuid

from lib import log


_JOB_TTL_S = 3600
_lock = threading.RLock()
_jobs = {}


# Estados posibles del job (string constants, no enum para mantener simple)
STATE_PENDING = 'pending'
STATE_RUNNING = 'running'
STATE_DONE = 'done'
STATE_ERROR = 'error'
STATE_CANCELLED = 'cancelled'


def _new_id():
    return uuid.uuid4().hex[:16]


def _now():
    return int(time.time())


def _cleanup_old_locked():
    """Borra jobs cuyo last update sea anterior a now - _JOB_TTL_S.

    Caller debe tener _lock. Solo borra jobs en estado terminal (no
    "running" para no perder progreso de un job real en vuelo).
    """
    cutoff = _now() - _JOB_TTL_S
    terminal = (STATE_DONE, STATE_ERROR, STATE_CANCELLED)
    for jid in list(_jobs.keys()):
        job = _jobs[jid]
        if job['state'] in terminal and job['updated_at'] < cutoff:
            del _jobs[jid]


def start_job(kind, func, *args, **kwargs):
    """Lanza un thread daemon que ejecuta func(*args, **kwargs).

    func recibe dos kwargs especiales adicionales: progress_cb y
    cancel_check. Si la función no los acepta, basta con que use
    `**kwargs` o aceptarlos explícitamente. El resultado de func se guarda
    en job['result']; si lanza, se guarda en job['error'] y state pasa a
    'error' (o 'cancelled' si fue InterruptedError).
    """
    with _lock:
        _cleanup_old_locked()
        jid = _new_id()
        now = _now()
        _jobs[jid] = {
            'id': jid,
            'kind': kind,
            'state': STATE_PENDING,
            'progress': 0,
            'total': 0,
            'message': '',
            'created_at': now,
            'updated_at': now,
            'result': None,
            'error': None,
            'cancel_requested': False,
        }

    def _run():
        try:
            with _lock:
                job = _jobs.get(jid)
                if job:
                    job['state'] = STATE_RUNNING
                    job['updated_at'] = _now()
            kwargs['progress_cb'] = make_progress_cb(jid)
            kwargs['cancel_check'] = make_cancel_check(jid)
            res = func(*args, **kwargs)
            with _lock:
                job = _jobs.get(jid)
                if job is not None:
                    if job['cancel_requested']:
                        job['state'] = STATE_CANCELLED
                    else:
                        job['state'] = STATE_DONE
                        job['progress'] = 100
                    job['result'] = res
                    job['updated_at'] = _now()
        except InterruptedError as e:
            with _lock:
                job = _jobs.get(jid)
                if job is not None:
                    job['state'] = STATE_CANCELLED
                    job['message'] = str(e) or 'Cancelado'
                    job['updated_at'] = _now()
        except BaseException as e:
            # BaseException (no solo Exception) para que MemoryError, SystemExit
            # u otros fallos de bajo nivel no dejen el job en RUNNING para siempre
            # y bloqueen el mutex de backup hasta el stale timeout.
            log.warning(f'[backup_jobs] {kind} job {jid} falló: {e!r}')
            with _lock:
                job = _jobs.get(jid)
                if job is not None:
                    job['state'] = STATE_ERROR
                    job['error'] = str(e) or e.__class__.__name__
                    job['updated_at'] = _now()
                    # BackupBusyError es transitorio: marcar como retry para
                    # que el frontend ofrezca "Reintentar" en lugar de fatal.
                    cls_name = e.__class__.__name__
                    if cls_name == 'BackupBusyError':
                        job['retry_recommended'] = True
                        job['error_kind'] = 'busy'
                    else:
                        job['error_kind'] = 'fatal'
        finally:
            # Garantía dura: si el thread termina con el job aún en RUNNING
            # por cualquier razón (raise dentro de un except, etc.), marcarlo
            # como error para no zombificar el mutex.
            with _lock:
                job = _jobs.get(jid)
                if job is not None and job['state'] == STATE_RUNNING:
                    job['state'] = STATE_ERROR
                    job['error'] = 'thread terminó sin actualizar estado'
                    job['updated_at'] = _now()

    t = threading.Thread(target=_run, name=f'backup-job-{kind}-{jid}',
                         daemon=True)
    t.start()
    return jid


def get_job(job_id):
    """Devuelve una copia serializable del estado del job, o None."""
    with _lock:
        job = _jobs.get(job_id)
        if job is None:
            return None
        # Copia plana sin internals
        return {
            'id': job['id'],
            'kind': job['kind'],
            'state': job['state'],
            'progress': job['progress'],
            'total': job['total'],
            'message': job['message'],
            'created_at': job['created_at'],
            'updated_at': job['updated_at'],
            'result': job['result'],
            'error': job['error'],
            'cancellable': job['state'] in (STATE_PENDING, STATE_RUNNING),
            'retry_recommended': job.get('retry_recommended', False),
            'error_kind': job.get('error_kind'),
        }


def cancel_job(job_id):
    """Marca el job como cancelado. El worker lo verá en cancel_check."""
    with _lock:
        job = _jobs.get(job_id)
        if job is None:
            return False
        if job['state'] in (STATE_DONE, STATE_ERROR, STATE_CANCELLED):
            return False
        job['cancel_requested'] = True
        job['updated_at'] = _now()
        return True


def make_progress_cb(job_id):
    """Devuelve un callable progress_cb(done, total, msg) para pasar abajo."""
    def _cb(done, total, msg=''):
        with _lock:
            job = _jobs.get(job_id)
            if job is None:
                return
            try:
                done = int(done)
            except (TypeError, ValueError):
                done = 0
            try:
                total = int(total)
            except (TypeError, ValueError):
                total = 0
            job['progress'] = done
            job['total'] = total
            if msg:
                job['message'] = str(msg)[:200]
            job['updated_at'] = _now()
    return _cb


def make_cancel_check(job_id):
    """Devuelve un callable que returns True si se pidió cancelar."""
    def _check():
        with _lock:
            job = _jobs.get(job_id)
            return bool(job and job['cancel_requested'])
    return _check


def list_jobs():
    """Lista todos los jobs vivos (útil para diagnóstico)."""
    with _lock:
        return [get_job(jid) for jid in _jobs]
