"""Abstracción de feedback al usuario durante backup/restore.

Tres modos:
  - silent   (0): sin UI (para tareas de fondo, ej. resume tras restart)
  - notifications (1): xbmcgui.Dialog().notification al inicio y fin
  - dialog   (2): xbmcgui.DialogProgress bloqueante (el actual en TV)

Setting que controla el modo: `backup.progress_mode_manual` (default 2).
Las operaciones en background (futuro scheduler) usarían un setting
distinto; por ahora la API acepta el modo como parámetro explícito y
respeta el setting solo si el caller no lo especifica.

La clase devuelve un objeto que también implementa el protocolo
(progress_cb, cancel_check) que esperan `create_backup` y `restore_*`:

    ui = BackupProgressUI.from_settings(title='Backup completo')
    ui.start()
    try:
        result = backup.create_backup(..., progress_cb=ui.progress_cb,
                                       cancel_check=ui.cancel_check)
    finally:
        ui.close()
"""
import xbmcaddon
import xbmcgui

from lib import log


MODE_SILENT = 0
MODE_NOTIFICATIONS = 1
MODE_DIALOG = 2

_SETTING_MANUAL = 'backup.progress_mode_manual'


def _read_mode_from_setting(default=MODE_DIALOG):
    try:
        raw = xbmcaddon.Addon().getSetting(_SETTING_MANUAL)
        if not raw:
            return default
        return int(raw)
    except (RuntimeError, ValueError):
        return default


class _BaseProgressUI:
    """Base con interface común. No instanciar directo."""

    def __init__(self, *, title='loiolink'):
        self.title = title
        self._cancelled = False
        self._closed = False

    def start(self):
        pass

    def update(self, pct, msg=''):
        pass

    def close(self):
        self._closed = True

    def is_cancelled(self):
        return self._cancelled

    # Adaptadores para la API que esperan create_backup/restore_*:
    # progress_cb(done, total, msg) y cancel_check() -> bool

    def progress_cb(self, done, total, msg=''):
        try:
            if total and total > 0:
                pct = max(0, min(100, int(done * 100 / total)))
            else:
                pct = max(0, min(100, int(done)))
        except (TypeError, ValueError):
            pct = 0
        self.update(pct, msg or '')

    def cancel_check(self):
        return self.is_cancelled()


class SilentProgressUI(_BaseProgressUI):
    """No imprime nada. Útil para tareas background o tests."""
    pass


class NotificationProgressUI(_BaseProgressUI):
    """Toast al inicio y al final. Sin progreso incremental visible.

    Pensado para scheduler (cuando se implemente) o tareas que no deben
    interrumpir la TV con un diálogo bloqueante.
    """

    def __init__(self, *, title='loiolink', icon_path=None, start_msg=None,
                 done_msg=None):
        super().__init__(title=title)
        self.icon_path = icon_path
        self.start_msg = start_msg or 'Backup en curso...'
        self.done_msg = done_msg or 'Backup completado'
        self._started = False

    def start(self):
        if self._started:
            return
        self._started = True
        try:
            xbmcgui.Dialog().notification(
                self.title, self.start_msg,
                self.icon_path or xbmcgui.NOTIFICATION_INFO, 3000,
            )
        except Exception as e:  # noqa: BLE001
            log.warning(f'[backup_progress] notif start falló: {e!r}')

    def update(self, pct, msg=''):
        # Modo notif no muestra progreso continuo (evita spam). Solo
        # actualiza el mensaje "interno" por si el caller hace polling.
        pass

    def close(self):
        if self._closed:
            return
        super().close()
        try:
            xbmcgui.Dialog().notification(
                self.title, self.done_msg,
                self.icon_path or xbmcgui.NOTIFICATION_INFO, 2500,
            )
        except Exception as e:  # noqa: BLE001
            log.warning(f'[backup_progress] notif close falló: {e!r}')


class DialogProgressUI(_BaseProgressUI):
    """DialogProgress bloqueante (modo actual TV). El usuario puede cancelar."""

    def __init__(self, *, title='loiolink', initial_msg='Preparando...'):
        super().__init__(title=title)
        self.initial_msg = initial_msg
        self._dlg = None

    def start(self):
        if self._dlg is not None:
            return
        self._dlg = xbmcgui.DialogProgress()
        self._dlg.create(self.title, self.initial_msg)

    def update(self, pct, msg=''):
        if self._dlg is None:
            return
        try:
            self._dlg.update(pct, msg or '')
        except RuntimeError:
            # Dialog fue cerrado externamente.
            pass

    def close(self):
        if self._closed:
            return
        super().close()
        if self._dlg is not None:
            try:
                self._dlg.close()
            except RuntimeError:
                pass
            self._dlg = None

    def is_cancelled(self):
        if self._cancelled:
            return True
        if self._dlg is None:
            return False
        try:
            if self._dlg.iscanceled():
                self._cancelled = True
                return True
        except RuntimeError:
            pass
        return False


def make_progress_ui(*, mode=None, title='loiolink', initial_msg='Preparando...'):
    """Factory.

    mode: None => leer del setting; 0/1/2 => forzar modo.
    """
    if mode is None:
        mode = _read_mode_from_setting()
    if mode == MODE_SILENT:
        return SilentProgressUI(title=title)
    if mode == MODE_NOTIFICATIONS:
        return NotificationProgressUI(title=title)
    return DialogProgressUI(title=title, initial_msg=initial_msg)
