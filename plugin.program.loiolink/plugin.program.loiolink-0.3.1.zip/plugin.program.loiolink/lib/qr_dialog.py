"""Popup mínimo para mostrar un texto/URL como QR escaneable.

El modal de `remote_qr` es específico del flujo de pairing (PIN, auto-close
al reproducir, dismiss-flags del server). Aquí queremos algo más simple:
título + URL + QR + cerrar con BACK o SELECT. Pensado para casos como
"comparte la URL de esta fuente con otro dispositivo".
"""
import xbmcgui

import qr_generator
from lib import log


_HOME_WINDOW_ID = 10000


class _QRPopup(xbmcgui.WindowDialog):
    _W, _H = 1280, 720
    _PANEL_W, _PANEL_H = 620, 560
    _PANEL_X = (_W - _PANEL_W) // 2
    _PANEL_Y = (_H - _PANEL_H) // 2

    _C_TITLE = '0xFFFFFFFF'
    _C_URL = '0xFF58A6FF'
    _C_HINT = '0xFF8B949E'

    _ALIGN_CENTER = 0x00000002

    _CLOSE_ACTIONS = {
        xbmcgui.ACTION_PREVIOUS_MENU,
        xbmcgui.ACTION_NAV_BACK,
        xbmcgui.ACTION_STOP,
        xbmcgui.ACTION_SELECT_ITEM,
    }

    def __init__(self, title, url):
        super().__init__()
        self._url = url
        self._qr_path = None

        px, py, pw, ph = self._PANEL_X, self._PANEL_Y, self._PANEL_W, self._PANEL_H

        self.addControl(xbmcgui.ControlImage(
            px, py, pw, ph, '', colorDiffuse='0xEE111418',
        ))
        self.addControl(xbmcgui.ControlLabel(
            px, py + 24, pw, 30, title,
            font='font20', textColor=self._C_TITLE, alignment=self._ALIGN_CENTER,
        ))
        self.addControl(xbmcgui.ControlLabel(
            px + 20, py + 64, pw - 40, 28, url,
            font='font14', textColor=self._C_URL, alignment=self._ALIGN_CENTER,
        ))

        qr_size = 380
        qr_x = px + (pw - qr_size) // 2
        qr_y = py + 110
        self._qr_size = qr_size
        self._qr_x = qr_x
        self._qr_y = qr_y

        self._fallback_lbl = xbmcgui.ControlLabel(
            qr_x, qr_y + qr_size // 2 - 14, qr_size, 28,
            '',
            font='font14', textColor=self._C_HINT, alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._fallback_lbl)

        self.addControl(xbmcgui.ControlLabel(
            px, py + ph - 40, pw, 24,
            'Pulsa OK o Atrás para cerrar',
            font='font12', textColor=self._C_HINT, alignment=self._ALIGN_CENTER,
        ))

        self._add_qr_image()

    def _add_qr_image(self):
        self._qr_path = qr_generator.generate(self._url)
        if not self._qr_path:
            log.warning('qr_dialog: qr_generator devolvio None')
            self._fallback_lbl.setLabel('No se pudo generar el QR')
            return
        try:
            self.addControl(xbmcgui.ControlImage(
                self._qr_x, self._qr_y, self._qr_size, self._qr_size,
                self._qr_path,
            ))
        except (OSError, ValueError, RuntimeError, TypeError) as e:
            log.warning(f'qr_dialog: no se pudo cargar el QR: {e}')
            self._fallback_lbl.setLabel('No se pudo cargar el QR')

    def onAction(self, action):
        if action.getId() in self._CLOSE_ACTIONS:
            self.close()

    def cleanup(self):
        if self._qr_path:
            qr_generator.cleanup(self._qr_path)
            self._qr_path = None


def show(title, url):
    """Muestra un QR modal con `title` y `url`. Bloquea hasta que el user cierra."""
    if not url:
        return
    dlg = _QRPopup(title, url)
    try:
        dlg.doModal()
    finally:
        dlg.cleanup()
        del dlg
