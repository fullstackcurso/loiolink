# -*- coding: utf-8 -*-
# loiolink — Copyright (C) 2025-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Consulta el archivo LICENSE para mas detalles.
# ============================================================================
# dm_gujal.py — Integración con Dailymotion
# ============================================================================
#
# LICENCIA: GNU General Public License v3 (GPL-3.0)
#
# Este archivo contiene código derivado del proyecto
# plugin.video.dailymotion_com desarrollado por Gujal00.
#
# Código original: https://github.com/Gujal00/Kodi-Official
#
# Adaptación a loiolink basada en `plugin.video.topzilla/dm_gujal.py`
# el original importa `requests`, aquí se reescribe con
# `urllib.request` (stdlib) para evitar añadir `script.module.requests`
# como dependencia del addon.
#
# Este archivo se distribuye bajo los términos de la GPL v3 y puede ser
# modificado y redistribuido libremente bajo esos mismos términos. Como
# loiolink es GPL-2.0-or-later, la cláusula "or later" permite incluir
# código GPL-3.0; el conjunto resultante se distribuye como GPL-3.0+.
# ============================================================================
"""Resolución de Dailymotion sin yt-dlp.

Endpoint público de metadatos del player + parseo M3U8 + reciclaje de
tokens `sec=`. Cubre Android (sin python del sistema para yt-dlp) y
Windows con CDN block (yt-dlp da 403). UA Android mitiga el bloqueo.
"""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

from lib import log, url_utils


_UA_MOBILE = (
    'Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/55.0.2883.91 Mobile Safari/537.36'
)
_HEADERS = {
    'User-Agent': _UA_MOBILE,
    'Origin': 'https://www.dailymotion.com',
    'Referer': 'https://www.dailymotion.com/',
}
_COOKIES = 'lang=es_ES; ff=off'

_METADATA_URL = 'https://www.dailymotion.com/player/metadata/video/{}'
_TIMEOUT_META = 15
_TIMEOUT_M3U8 = 10
_MAX_BYTES = 2 * 1024 * 1024  # 2 MB cap defensivo (manifests M3U8 son pequeños)


def _http_get(url, extra_headers=None, timeout=_TIMEOUT_META):
    """GET con stdlib + pre-resolución DNS.

    `urlopen(timeout=N)` NO acota la fase DNS en Windows/Android (issues
    Python gh-78649, gh-103998). Sin precheck, un Dailymotion con DNS
    lento podría colgar el thread principal 15-30s. Reutilizamos
    `url_utils._dns_precheck` igual que thumb_resolver.

    Devuelve (body_bytes, response_headers_dict) o (None, None) si:
    - DNS no resuelve en `timeout`.
    - HTTP timeout / 4xx / 5xx / URL malformada / status != 200.
    """
    _, dns_err = url_utils._dns_precheck(url, timeout)
    if dns_err:
        log.warning(f'[dm_gujal] DNS falló: {dns_err}')
        return None, None
    headers = dict(_HEADERS)
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if r.status != 200:
                log.warning(f'[dm_gujal] HTTP {r.status} en {url[:80]}')
                return None, None
            body = r.read(_MAX_BYTES)
            # urllib HTTPResponse.headers es un email.message.Message; convertir
            # a dict simple. Set-Cookie puede tener múltiples valores (raros en
            # Dailymotion).
            resp_headers = {k: v for k, v in r.headers.items()}
            return body, resp_headers
    except (urllib.error.URLError, OSError, ValueError) as e:
        log.warning(f'[dm_gujal] HTTP falló: {type(e).__name__} en {url[:80]}')
        return None, None


def _parse_m3u8(text):
    """Extrae pares (NAME, URL) del master M3U8. Dos formatos:
    1. PROGRESSIVE-URI inline (formato Gujal00 con renderers).
    2. NAME="..." seguido de URL en la línea siguiente (estándar HLS).
    """
    entries = re.findall(
        r'NAME="([^"]+)",PROGRESSIVE-URI="([^"]+)"', text,
    )
    if not entries:
        entries = re.findall(r'NAME="(\d+)".*\n([^\n]+)', text)
    return entries


def _sort_key(elem):
    try:
        return int(elem[0].split('@')[0])
    except (ValueError, IndexError):
        return 0


def _fetch_metadata(vid):
    """Devuelve (json_dict, response_headers) o (None, None)."""
    body, resp_headers = _http_get(
        _METADATA_URL.format(vid),
        extra_headers={'Cookie': _COOKIES},
    )
    if body is None:
        return None, None
    try:
        content = json.loads(body.decode('utf-8', errors='replace'))
    except ValueError as e:
        log.warning(f'[dm_gujal] JSON inválido: {e!r}')
        return None, None
    if not isinstance(content, dict):
        return None, None
    err = content.get('error')
    if err:
        err_type = err.get('type') if isinstance(err, dict) else str(err)
        log.warning(f'[dm_gujal] Dailymotion error: {err_type}')
        return None, None
    return content, resp_headers


def _extract_hls(content):
    """De `content['qualities']['auto'][*]` devuelve la URL HLS o ''."""
    qualities = content.get('qualities') or {}
    auto = qualities.get('auto') or []
    if not isinstance(auto, list):
        return ''
    for item in auto:
        if isinstance(item, dict) and item.get('type') == 'application/x-mpegURL':
            return item.get('url') or ''
    return ''


def _extract_subs(content):
    """De `content['subtitles']['data'][lang]['urls'][0]` por cada idioma."""
    subs = []
    subs_obj = content.get('subtitles')
    if not isinstance(subs_obj, dict):
        return subs
    data = subs_obj.get('data')
    if not isinstance(data, dict):
        return subs
    for lang_key, lang_val in data.items():
        if not isinstance(lang_val, dict):
            continue
        urls = lang_val.get('urls') or []
        if urls:
            subs.append(urls[0])
    return subs


def _refresh_sec_token(m_url, meta_cookie_header):
    """Si la URL del manifest contiene `?sec=`, hace request con
    redirect=0 para refrescar el token y obtener cookies extra.

    Devuelve (m3u8_text, extra_cookie_header_or_None).
    """
    if '?sec=' not in m_url:
        # Manifest simple sin token.
        body, _ = _http_get(m_url, timeout=_TIMEOUT_M3U8)
        if body is None:
            return None, None
        return body.decode('utf-8', errors='replace'), None

    # Manifest con token: refrescar.
    parts = m_url.split('?sec=', 1)
    redirect_url = parts[0] + '?redirect=0&sec=' + urllib.parse.quote(parts[1])
    extra = {}
    if meta_cookie_header:
        extra['Cookie'] = meta_cookie_header
    body, resp_headers = _http_get(redirect_url, extra_headers=extra, timeout=_TIMEOUT_M3U8)
    if body is None:
        # Fallback: pedir el manifest original directo.
        body, resp_headers = _http_get(m_url, extra_headers=extra, timeout=_TIMEOUT_M3U8)
        if body is None:
            return None, None
    extra_cookie = resp_headers.get('Set-Cookie') if resp_headers else None
    return body.decode('utf-8', errors='replace'), extra_cookie


def _build_final_url(stream_url, extra_cookie=None):
    """URL del segmento HLS con pipe-headers de Kodi."""
    headers_str = urllib.parse.urlencode(_HEADERS)
    if extra_cookie:
        return f'{stream_url}|{headers_str}&Cookie={urllib.parse.quote(extra_cookie)}'
    return f'{stream_url}|{headers_str}'


def play_dm_extreme(vid, max_quality=1080):
    """Resolución completa con subtítulos y limitador de calidad.

    Devuelve (url, subtitulos, mime) o (None, None, None) si falla.
    """
    try:
        content, meta_headers = _fetch_metadata(vid)
        if content is None:
            return None, None, None

        subs = _extract_subs(content)
        m_url = _extract_hls(content)
        if not m_url:
            log.warning(f'[dm_gujal] sin stream HLS para {vid}')
            return None, None, None

        meta_cookie = meta_headers.get('Set-Cookie') if meta_headers else None
        mbtext, extra_cookie = _refresh_sec_token(m_url, meta_cookie)
        if mbtext is None:
            return None, None, None

        mb = _parse_m3u8(mbtext)
        if mb:
            mb = sorted(mb, key=_sort_key, reverse=True)
            selected = None
            for quality, strurl in mb:
                try:
                    q = int(quality.split('@')[0])
                except (ValueError, IndexError):
                    q = 0
                if q <= max_quality:
                    selected = strurl.split('#cell')[0]
                    break
            if not selected:
                selected = mb[-1][1].split('#cell')[0]
            return _build_final_url(selected, extra_cookie), subs, 'video/mp4'

        # Si no parseamos variantes, devolver el master HLS directo —
        # inputstream.adaptive puede manejarlo.
        return _build_final_url(m_url), subs, 'application/x-mpegURL'
    except (OSError, ValueError) as e:
        log.warning(f'[dm_gujal] extreme falló: {e!r}')
        return None, None, None


def play_dm_basic(vid):
    """Resolución mínima: pide el HLS master sin parsear variantes ni subs.

    Devuelve (url, mime) o (None, None) si falla.
    """
    try:
        content, _ = _fetch_metadata(vid)
        if content is None:
            return None, None

        m_url = _extract_hls(content)
        if not m_url:
            return None, None

        body, _ = _http_get(m_url, timeout=_TIMEOUT_M3U8)
        if body is None:
            # No pudimos leer el manifest; devolver el master tal cual.
            return _build_final_url(m_url), 'application/x-mpegURL'
        mbtext = body.decode('utf-8', errors='replace')
        mb = _parse_m3u8(mbtext)
        if mb:
            mb = sorted(mb, key=_sort_key, reverse=True)
            best = mb[0][1].split('#cell')[0]
            return _build_final_url(best), 'video/mp4'
        return _build_final_url(m_url), 'application/x-mpegURL'
    except (OSError, ValueError) as e:
        log.warning(f'[dm_gujal] basic falló: {e!r}')
        return None, None
