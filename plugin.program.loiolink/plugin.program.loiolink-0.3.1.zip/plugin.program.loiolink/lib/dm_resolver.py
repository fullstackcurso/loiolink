"""Resolución de Dailymotion con cadena yt-dlp → syspy-gujal → dm_gujal → None.

Cuatro niveles, cada uno cubre un escenario distinto:

1. **yt-dlp** (si python sistema + yt-dlp instalados): cobertura amplia,
   maneja DRM/age-gate, devuelve headers HTTP precisos.
2. **syspy-gujal** (si python sistema disponible pero yt-dlp no, o yt-dlp
   falló): mismo flow que dm_gujal pero ejecutado en Python del SISTEMA.
   Bypassea el fingerprint TLS del Python embebido de Kodi, que en Windows
   Dailymotion CDN a veces rechaza (403). Patrón copiado de
   plugin.video.topzilla/default.py:2256-2324.
3. **dm_gujal** (Python embebido de Kodi): cobertura universal incluido
   Android. Si el CDN no bloquea el embebido, funciona.
4. **dm_gujal basic**: último fallback minimal.

`resolve(url)` devuelve string lista para `play_file()` o None.
"""
import re
import urllib.parse

from lib import dm_gujal, log, ytdlp_resolver


_DM_VIDEO_RE = re.compile(
    r'(?:dailymotion\.com/(?:embed/)?video/|dai\.ly/)([A-Za-z0-9]+)',
    re.IGNORECASE,
)

# Validación de video_id antes de pasar a subprocess: solo alfanumérico.
# Defensa frente a inyección por URL maliciosa que pasara el regex superior.
_VID_SAFE_RE = re.compile(r'^[A-Za-z0-9]+$')


# Script Python del sistema. Misma lógica que dm_gujal.play_dm_extreme pero
# corre fuera del Python embebido de Kodi (cuyo fingerprint TLS Dailymotion
# CDN rechaza en algunos Windows). Tomado de plugin.video.topzilla con
# adaptaciones mínimas:
# - Devuelve también los headers que el caller debe poner en pipe-headers.
# - Maneja errores con códigos de salida específicos (más diagnosticable).
_DM_SYSPY_SCRIPT = r'''
import sys, json, re

_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) "
                   "Chrome/55.0.2883.91 Mobile Safari/537.36"),
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

try:
    import requests
    def _get(u, h=None, timeout=15):
        r = requests.get(u, headers=h or _HEADERS, timeout=timeout)
        return r.status_code, r.text, dict(r.headers)
except ImportError:
    import urllib.request, urllib.error
    def _get(u, h=None, timeout=15):
        req = urllib.request.Request(u, headers=h or _HEADERS)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read(2 * 1024 * 1024).decode("utf-8", errors="replace")
                return r.getcode(), body, dict(r.headers.items())
        except urllib.error.HTTPError as e:
            return e.code, "", {}
        except (urllib.error.URLError, OSError):
            return 0, "", {}

vid = sys.argv[1]
status, body, _h = _get("https://www.dailymotion.com/player/metadata/video/" + vid)
if status != 200:
    sys.exit(10)
try:
    data = json.loads(body)
except Exception:
    sys.exit(11)
if data.get("error"):
    sys.exit(12)
hls = ""
for it in (data.get("qualities") or {}).get("auto") or []:
    if isinstance(it, dict) and it.get("type") == "application/x-mpegURL":
        hls = it.get("url", "")
        break
if not hls:
    sys.exit(13)
status2, master, _h2 = _get(hls)
if status2 != 200:
    sys.exit(14)
variants = re.findall(r'NAME="(\d+)"[^\n]*\n([^\n]+)', master)
if variants:
    variants.sort(key=lambda x: int(x[0]), reverse=True)
    stream = variants[0][1].split("#cell")[0]
    print(json.dumps({"url": stream, "headers": _HEADERS, "mime": "video/mp4"}))
else:
    print(json.dumps({"url": hls, "headers": _HEADERS, "mime": "application/x-mpegURL"}))
'''


def extract_video_id(url):
    if not url:
        return None
    m = _DM_VIDEO_RE.search(url)
    return m.group(1) if m else None


def resolve(url):
    """Devuelve la URL final lista para reproducir, o None si todo falla.

    Cadena de 4 niveles (cada uno cubre un escenario distinto, ver docstring
    del módulo para el reparto):
    1. yt-dlp (si is_installed) → URL + pipe-headers de los meaningful.
    2. syspy-gujal → script de dm_gujal ejecutado en Python del SISTEMA
       (bypassea fingerprint TLS del embebido en Windows con CDN block).
    3. dm_gujal.play_dm_extreme → flow completo en Python embebido (Android
       y cualquier plataforma donde el CDN no rechace al embebido).
    4. dm_gujal.play_dm_basic → fallback mínimo si extreme falla.

    Output: string lista para `kodi_player.play_file()` o None.
    """
    vid = extract_video_id(url)
    if not vid or not _VID_SAFE_RE.match(vid):
        # vid no alfanumérico: rechazar (defensa contra inyección en
        # subprocess; el regex superior ya garantiza esto, pero damos
        # doble validación para defensa en profundidad).
        return None

    # 1) yt-dlp si disponible
    if ytdlp_resolver.is_installed():
        info = ytdlp_resolver.resolve_full(url)
        if info:
            return _build_pipe_url(
                info['url'],
                ytdlp_resolver.meaningful_headers(info['headers']),
            )
        log.info(f'[dm_resolver] yt-dlp falló para {vid}, probando syspy-gujal')

    # 2) syspy-gujal: mismo flow que dm_gujal pero en Python del SISTEMA.
    # Bypassea el fingerprint TLS del embebido de Kodi (CDN Dailymotion en
    # Windows a veces rechaza al embebido con 403). Solo se intenta si hay
    # Python sistema accesible — si no, _get_python() devuelve None y
    # run_inline_script retorna None sin gasto extra.
    syspy_url = _resolve_via_syspython(vid)
    if syspy_url:
        return syspy_url
    log.info(f'[dm_resolver] syspy-gujal falló o no disponible para {vid}, probando dm_gujal embebido')

    # 3) dm_gujal extreme (URL ya con pipe-headers embebidos)
    try:
        extreme_url, _subs, _mime = dm_gujal.play_dm_extreme(vid)
    except Exception as e:  # noqa: BLE001  (defensa frente a errores no previstos)
        log.warning(f'[dm_resolver] dm_gujal.play_dm_extreme excepción: {e!r}')
        extreme_url = None
    if extreme_url:
        return extreme_url

    # 4) dm_gujal basic
    try:
        basic_url, _mime = dm_gujal.play_dm_basic(vid)
    except Exception as e:  # noqa: BLE001
        log.warning(f'[dm_resolver] dm_gujal.play_dm_basic excepción: {e!r}')
        basic_url = None
    return basic_url  # string o None


def _resolve_via_syspython(vid):
    """Ejecuta el script de dm_gujal en el Python del SISTEMA. Devuelve
    URL final con pipe-headers o None.

    `vid` ya fue validado como alfanumérico por el caller; aun así pasa
    como argv y el subprocess se invoca con shell=False y args como
    lista, por lo que no hay vector de inyección.
    """
    import json
    stdout = ytdlp_resolver.run_inline_script(_DM_SYSPY_SCRIPT, args=(vid,))
    if not stdout:
        return None
    try:
        data = json.loads(stdout.strip())
    except (ValueError, TypeError):
        log.warning(f'[dm_resolver] syspy-gujal stdout no es JSON: {stdout[:120]!r}')
        return None
    stream_url = data.get('url') or ''
    headers = data.get('headers') or {}
    if not stream_url:
        return None
    return _build_pipe_url(stream_url, headers)


def _build_pipe_url(stream_url, headers):
    """URL con pipe-headers para `Player.Open` legacy (no inputstream.adaptive).

    Formato: 'https://x.mp4|User-Agent=Foo&Referer=https://y'

    Headers se URL-encode con `quote(safe='')` para que valores con '&'
    o '=' (Cookie, valores con tokens) no rompan el parsing.
    """
    if not headers:
        return stream_url
    encoded = '&'.join(
        f'{urllib.parse.quote(k, safe="")}={urllib.parse.quote(str(v), safe="")}'
        for k, v in headers.items()
    )
    return f'{stream_url}|{encoded}'
