"""Historial persistente de URLs introducidas por el usuario en 'Abrir URL'.

Distinto del historial de transferencias (lib/transfers/history.py): aquí solo
guardamos URLs tecleadas o pegadas por el usuario en el cuadro 'Abrir URL', para
poder repetirlas sin volver a teclearlas. Las transferencias resultantes (si las
hay) se siguen registrando en el otro historial.

JSON en addon_data/url_history.json. Max 20 entradas; duplicados se mueven al
principio en lugar de acumularse.
"""
import json
import os
import tempfile
import time

import xbmcvfs

from lib import log


_PROFILE = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/',
)
_HISTORY_PATH = os.path.join(_PROFILE, 'url_history.json')
_MAX_ENTRIES = 20
_LABEL_MAX = 60


def _ensure_dir():
    try:
        os.makedirs(_PROFILE, exist_ok=True)
    except OSError as e:
        log.warning(f'[url_input_history] mkdir falló: {e!r}')


def load():
    if not os.path.isfile(_HISTORY_PATH):
        return []
    try:
        with open(_HISTORY_PATH, encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError) as e:
        log.warning(f'[url_input_history] JSON corrupto, tratando como vacío: {e!r}')
        return []
    if not isinstance(data, list):
        return []
    # Filtrar entradas malformadas. La validación de tipo de 'url' es borde
    # de confianza: el archivo es local pero editable por el usuario, y aguas
    # abajo urlencode() peta si recibe algo que no sea str.
    return [
        e for e in data
        if isinstance(e, dict)
        and isinstance(e.get('url'), str)
        and e['url']
    ]


def save(entries):
    """Escribe el historial de forma atómica y race-safe.

    Cada llamada usa su propio tmp (mkstemp → nombre único). Si el proceso
    muere a mitad del write, el JSON original queda intacto. Si dos saves
    concurren, gana uno completo o el otro completo — `os.replace()` es
    atómico en NTFS/ext4/APFS dentro del mismo volumen. Un tmp compartido
    (HISTORY + '.tmp') causaría mezcla de contenidos en carrera (verificado
    con test de threads).

    Nota Windows: `os.replace` usa `MoveFileEx`, atómico SOLO si origen y
    destino están en el mismo volumen. Como tmp se crea con `mkstemp(dir=
    _PROFILE)`, ambos viven en el mismo directorio → mismo volumen → atómico.
    Si en el futuro alguien cambia tmp a `/tmp` o similar fuera del profile,
    perdería la garantía en Windows.
    """
    _ensure_dir()
    try:
        fd, tmp = tempfile.mkstemp(prefix='url_history_', suffix='.tmp', dir=_PROFILE)
    except OSError as e:
        log.warning(f'[url_input_history] mkstemp falló: {e!r}')
        return
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(entries[:_MAX_ENTRIES], f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, _HISTORY_PATH)
    except OSError as e:
        log.warning(f'[url_input_history] save falló: {e!r}')
        try:
            os.remove(tmp)
        except OSError:
            pass


def add(url, label='', thumb=''):
    """Añade una entrada al inicio. Si la URL ya existía, se reemplaza con
    estos metadatos (los nuevos ganan: pensado para el flujo "pegar URL"
    donde el resolver acaba de calcular thumb/label).

    Para mover-al-frente preservando metadatos viejos, usar `touch()`.
    """
    url = (url or '').strip()
    if not url:
        return
    if not label:
        label = url[:_LABEL_MAX]
    entries = load()
    entries = [e for e in entries if e.get('url') != url]
    entries.insert(0, {
        'url': url,
        'label': label,
        'thumb': thumb,
        'ts': int(time.time()),
    })
    save(entries)


def touch(url):
    """Bring-to-front si `url` está en el historial. No-op si no.

    True si encontró y movió (o ya estaba al frente), False si no estaba.
    Pensado para el flujo "click en una URL del historial o de marcadores":
    si era de marcadores y NO estaba en el historial, NO se añade aquí
    (las dos listas son independientes y los marcadores son curados).
    """
    url = (url or '').strip()
    if not url:
        return False
    entries = load()
    for i, e in enumerate(entries):
        if e.get('url') != url:
            continue
        if i == 0:
            return True
        entry = entries.pop(i)
        entry['ts'] = int(time.time())
        entries.insert(0, entry)
        save(entries)
        return True
    return False


def remove(url):
    """Elimina UNA entrada por URL exacta. True si se eliminó algo."""
    url = (url or '').strip()
    if not url:
        return False
    entries = load()
    new = [e for e in entries if e.get('url') != url]
    if len(new) == len(entries):
        return False
    save(new)
    return True


def count():
    return len(load())


def clear():
    """True si el historial queda vacío después (no había nada o se borró bien)."""
    if not os.path.isfile(_HISTORY_PATH):
        return True
    try:
        os.remove(_HISTORY_PATH)
    except OSError as e:
        log.warning(f'[url_input_history] clear falló: {e!r}')
        return False
    return True


def get(url):
    """Devuelve la entry dict de `url` si existe, None si no. Útil para
    leer thumb/label antes de copiarlos a marcadores.
    """
    url = (url or '').strip()
    if not url:
        return None
    for e in load():
        if e.get('url') == url:
            return e
    return None
