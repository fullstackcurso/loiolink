"""Atajo para getLocalizedString con formateo opcional. IDs propios: 30000-30999."""
import xbmcaddon

_ADDON = xbmcaddon.Addon()


def L(string_id, **kwargs):
    s = _ADDON.getLocalizedString(string_id)
    return s.format(**kwargs) if kwargs else s
