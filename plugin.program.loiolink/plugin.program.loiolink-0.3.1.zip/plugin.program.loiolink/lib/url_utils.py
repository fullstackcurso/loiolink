"""Helpers para trabajar con URLs de fuentes Kodi.

Centraliza cinco cosas reutilizables: detección de URL en texto (para
auto-pegar del portapapeles), normalización para comparar duplicados, test
rápido de alcance HTTP, sugerencia de nombre a partir del host, y cálculo
del equivalente HTTPS. El test bloquea poco (timeout corto) porque se
llama en flujos interactivos donde el usuario está esperando.
"""
import re
import socket
import threading
import urllib.error
import urllib.parse
import urllib.request


_URL_SCHEMES = ('http://', 'https://', 'ftp://', 'smb://', 'nfs://')
_URL_REGEX = re.compile(
    r'(?P<url>(?:https?|ftp|smb|nfs)://[^\s<>"\']+)',
    re.IGNORECASE,
)


# Esquemas que el endpoint /cast del servidor acepta. mux() rechaza
# todo lo demás para evitar normalizar a un esquema que el server
# vetaría aguas abajo. La whitelist de _handle_cast es la fuente de
# verdad; aquí la replicamos para que el cliente reciba feedback
# inmediato si pega algo no soportado.
_MUX_PLAYABLE_SCHEMES = frozenset({'http', 'https', 'magnet', 'acestream'})

# Esquemas rechazados activamente. Listarlos es defensa en profundidad:
# si en el futuro alguien añade un esquema a _URL_SCHEMES sin tocar
# mux(), no se permitirá silenciosamente.
_MUX_REJECTED_SCHEMES = frozenset({
    'file', 'smb', 'nfs', 'ftp', 'plugin', 'special', 'androidapp',
    'resource', 'image', 'script', 'addons',
})

_SCHEME_PREFIX_RE = re.compile(r'^([a-z][a-z0-9+.\-]*):', re.IGNORECASE)


def mux(text):
    """Normaliza el input del usuario a una URL reproducible o None.

    Comportamiento:

    - Quita espacios alrededor.
    - Si NO hay esquema: prepend `http://` (sirve para "youtube.com/...",
      "youtu.be/X" o input pegado sin protocolo).
    - Si el esquema está en `_MUX_REJECTED_SCHEMES`, devuelve None (la
      defensa explícita evita que `file:///etc/passwd` pasara como
      "URL válida" para flujos locales de confianza).
    - Si el esquema no es reproducible (`_MUX_PLAYABLE_SCHEMES`),
      devuelve None.
    - Para `magnet:`, exige un parámetro `xt=` (anti `magnet:?` vacío).
    - Para el resto, exige `netloc` no vacío después de parsear.

    Devuelve la cadena normalizada o None si la entrada no representa
    una URL reproducible. Pensado para flujos que vienen de fuentes de
    confianza (clipboard local, panel propio); el servidor mantiene su
    whitelist estricta y NO debe llamar a esta función.
    """
    if not text:
        return None
    candidate = text.strip()
    if not candidate:
        return None

    scheme_match = _SCHEME_PREFIX_RE.match(candidate)
    if scheme_match is None:
        # Sin esquema. Limitamos a un host plausible para evitar promover
        # ruido ("hola mundo") a "http://hola mundo".
        if ' ' in candidate or '\t' in candidate:
            return None
        if '.' not in candidate and not candidate.startswith('//'):
            return None
        candidate = 'http://' + candidate.lstrip('/')
        scheme_match = _SCHEME_PREFIX_RE.match(candidate)
        if scheme_match is None:
            return None

    scheme = scheme_match.group(1).lower()
    if scheme in _MUX_REJECTED_SCHEMES:
        return None
    if scheme not in _MUX_PLAYABLE_SCHEMES:
        return None

    if scheme == 'magnet':
        # magnet:?xt=urn:btih:HASH&dn=...; sin xt no es procesable.
        if 'xt=' not in candidate:
            return None
        return candidate

    try:
        parsed = urllib.parse.urlparse(candidate)
    except ValueError:
        return None
    if not parsed.netloc:
        return None
    return candidate


def is_source_url(text):
    """True si `text` empieza por uno de los esquemas que Kodi acepta como fuente."""
    if not text:
        return False
    t = text.strip().lower()
    return any(t.startswith(s) for s in _URL_SCHEMES)


def extract_first_url(text):
    """Busca la primera URL bien formada dentro de `text`. None si no hay."""
    if not text:
        return None
    # Si el texto entero es ya una URL, devolvemos eso tal cual (preserva el
    # case original del path para servidores case-sensitive).
    stripped = text.strip()
    if is_source_url(stripped) and ' ' not in stripped:
        return stripped
    m = _URL_REGEX.search(text)
    return m.group('url') if m else None


def normalize_for_compare(url):
    """Normaliza para comparar duplicados: lowercase del scheme+host y sin trailing slash.

    El path se preserva en su case original porque muchos servidores son
    case-sensitive a partir del host. Para detectar duplicados típicos
    ("http://X/repo" vs "http://x/repo/") basta con esto.
    """
    if not url:
        return ''
    u = url.strip()
    # Separamos scheme://host(/path) y bajamos a lowercase el prefijo
    # hasta el primer slash tras el host.
    lower = u.lower()
    for scheme in _URL_SCHEMES:
        if lower.startswith(scheme):
            rest = u[len(scheme):]
            slash = rest.find('/')
            if slash == -1:
                return scheme + rest.lower()
            host = rest[:slash].lower()
            path = rest[slash:].rstrip('/')
            return scheme + host + path
    return u.rstrip('/')


def _resolve_host_with_timeout(host, timeout_s):
    """Resuelve `host` en un thread daemon con timeout. (ok: bool, err: str).

    Python aplica el `timeout` de urlopen al socket TCP, pero NO a la
    fase de resolución DNS subyacente (gh-78649, gh-103998). En Windows
    o Android con DNS lento esto congela el hilo de UI 15-30s. Lo
    saltamos haciendo la resolución en un thread aparte con join(timeout).
    """
    result = []

    def worker():
        # getaddrinfo lanza socket.gaierror (OSError) en fallos de DNS y
        # UnicodeError (ValueError) en hostnames IDN inválidos o con NULL
        # injection. Sin UnicodeError, el worker daemon moriría silencioso y
        # el caller recibiría 'DNS error' genérico en vez de la causa real.
        try:
            socket.getaddrinfo(host, None)
            result.append((True, ''))
        except (OSError, UnicodeError) as e:
            result.append((False, str(e)))

    t = threading.Thread(target=worker, daemon=True, name='loiolink-dns')
    t.start()
    t.join(timeout_s)
    if t.is_alive():
        return False, 'DNS timeout'
    if not result:
        return False, 'DNS error'
    return result[0]


def _dns_precheck(url, timeout):
    """Pre-resuelve el host de `url` con timeout corto. (None, err) si falla."""
    try:
        host = urllib.parse.urlparse(url).hostname
    except ValueError:
        return None, 'URL malformada'
    if not host:
        return None, None
    dns_ok, dns_err = _resolve_host_with_timeout(host, min(2.5, timeout))
    if not dns_ok:
        return None, f'Sin conexión: {dns_err}'
    return host, None


def test_http_reachable(url, timeout=4):
    """HEAD a la URL (GET si HEAD no es soportado). Devuelve (ok: bool, info: str).

    `info` describe brevemente el resultado para mostrar al usuario:
    "200 OK", "404 Not Found", "Timeout", "DNS no resuelve", etc.
    No lanza excepciones: cualquier fallo se convierte en (False, mensaje).
    """
    if not url or not (url.startswith('http://') or url.startswith('https://')):
        return (False, 'No es una URL http/https')

    _, dns_err = _dns_precheck(url, timeout)
    if dns_err:
        return (False, dns_err)

    req = urllib.request.Request(url, method='HEAD', headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return (True, f'{r.status} {r.reason}')
    except urllib.error.HTTPError as e:
        # Algunos servidores no soportan HEAD: probamos GET con Range para
        # no descargar el cuerpo entero. 405/501 son los códigos típicos
        # cuando el verbo no está permitido.
        if e.code in (405, 501):
            return _test_http_with_range_get(url, timeout)
        return (False, f'{e.code} {e.reason}')
    except urllib.error.URLError as e:
        reason = getattr(e, 'reason', e)
        return (False, f'Sin conexión: {reason}')
    except (OSError, ValueError) as e:
        return (False, f'Error: {e}')


def suggest_source_name(url):
    """A partir de una URL, devuelve un nombre legible para sugerir al usuario.

    Heurística: del host quitamos `www.`, `repo.`, `repository.`,
    `addons.`, `kodi.` y nos quedamos con el primer label significativo.
    Ej. `https://repo.kodinerds.net/repos` → `kodinerds`,
    `http://addons.foo.tv/...` → `foo`,
    `smb://192.168.1.10/share` → `192.168.1.10`.
    Para rutas locales o IPs sin más, devuelve algo razonable o ''.
    """
    if not url:
        return ''
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return ''
    host = (parsed.hostname or '').lower()
    if not host:
        return ''
    # Si es IP, devolvemos la IP entera (no tiene "labels" útiles).
    if re.fullmatch(r'[0-9.:a-f]+', host) and ('.' in host or ':' in host):
        return host
    labels = host.split('.')
    skip = {'www', 'repo', 'repository', 'repos', 'addons', 'kodi', 'mirror'}
    for label in labels:
        if label and label not in skip:
            return label
    return labels[0] if labels else ''


def to_https(url):
    """Devuelve la URL equivalente con scheme `https://`, o None si no aplica.

    Solo convierte fuentes http://. Para cualquier otro scheme devuelve None
    (no tiene sentido "actualizar a https" smb:// o local).
    """
    if not url or not url.startswith('http://'):
        return None
    return 'https://' + url[len('http://'):]


def _test_http_with_range_get(url, timeout):
    _, dns_err = _dns_precheck(url, timeout)
    if dns_err:
        return (False, dns_err)
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
        'Range': 'bytes=0-0',
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return (True, f'{r.status} {r.reason}')
    except urllib.error.HTTPError as e:
        return (False, f'{e.code} {e.reason}')
    except urllib.error.URLError as e:
        reason = getattr(e, 'reason', e)
        return (False, f'Sin conexión: {reason}')
    except (OSError, ValueError) as e:
        return (False, f'Error: {e}')
