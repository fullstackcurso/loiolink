"""Backup y restore del estado de visionado de la biblioteca.

Respaldar playcount, lastplayed y resume position de películas, episodios y
canciones. Los addons de backup genéricos solo respaldan archivos; al
restaurar se pierde el progreso de visionado, invaluable en bibliotecas
grandes.

Estrategia:
  - Dump: indexar por (mediatype, file_path). file_path es estable
    aunque los IDs de DB cambien tras una reinstalación.
  - Restore: match exacto por file_path; fallback por basename si no
    encuentra (caso típico: media movida a otro share).
  - Paginado JSON-RPC: 500 items por request, hasta agotar.
  - Si la biblioteca no se ha escaneado todavía en el destino, el
    restore solo marca los items que existen (los demás van a
    `not_found` sin fallar).
"""
import os

from lib import jsonrpc_safe, log


_PAGE_SIZE = 500


class WatchedStateError(Exception):
    """JSON-RPC indisponible o sin respuesta al dump de watched_state.

    Distingue "biblioteca vacía" (lista vacía válida) de "RPC colgado / Kodi
    no responde" (que antes se silenciaba devolviendo `[]` y producía backups
    "OK" con historial de visionado vacío sin avisar al usuario).
    """


def _list_paginated(method, params_base, properties, key, *,
                     progress_cb=None, progress_label=None):
    """Itera GetMovies/GetEpisodes/GetSongs paginado. Devuelve lista plana.

    `key`: campo del response que contiene la lista (e.g. 'movies').
    `progress_cb(done, total, msg)`: se llama por cada página; en bibliotecas
    de 10k+ episodios sin esto el dump parece colgado durante minutos.

    Lanza `WatchedStateError` si la PRIMERA página falla (RPC indisponible).
    Si falla una página intermedia se devuelven los datos acumulados con un
    log.warning: paginación parcial es mejor que perder todo.
    """
    out = []
    start = 0
    while True:
        params = dict(params_base)
        params['limits'] = {'start': start, 'end': start + _PAGE_SIZE}
        params['properties'] = list(properties)
        res = jsonrpc_safe.call(
            method, params,
            timeout_s=30.0,
            default=None,
            log_label=f'watched_state:{method}:page{start}',
        )
        if res is None:
            if start == 0:
                raise WatchedStateError(
                    f'{method} sin respuesta de JSON-RPC (timeout o Kodi no '
                    f'disponible)',
                )
            log.warning(
                f'[watched_state] {method} paginación truncada en {start} '
                f'(RPC sin respuesta)',
            )
            break
        items = res.get(key) or []
        if not items:
            break
        out.extend(items)
        limits = res.get('limits') or {}
        total = limits.get('total', 0)
        if progress_cb and total:
            label = progress_label or method
            progress_cb(len(out), total, f'{label} {len(out)}/{total}')
        if total <= 0 or start + len(items) >= total:
            break
        start += len(items)
        if start > 1_000_000:  # paranoid cap
            log.warning(f'[watched_state] paginación interrumpida en {start}')
            break
    return out


def dump_watched_state(*, progress_cb=None):
    """Snapshot del estado de visionado de toda la biblioteca.

    Devuelve dict con totals y per-type lists indexadas por file_path.
    Items sin file_path se omiten (no podemos matchearlos al restaurar).

    LIMITACIÓN (A3): el dump es BEST-EFFORT, no atómico. Si el usuario
    está viendo algo mientras corre la paginación, valores entre páginas
    pueden quedar inconsistentes (item X de la página 1 con playcount=0,
    luego user ve X y avanza, item X' de la página 2 con resume actualizado
    pero playcount aún 0). No es crítico: el restore aplica lo que tengamos
    y los valores reflejan el estado en el momento del dump (con jitter).
    Para snapshots realmente atómicos haría falta una transacción a nivel
    de Kodi que la API JSON-RPC no expone.
    """
    out = {
        'schema_version': 1,
        'totals': {},
        'movies': [],
        'episodes': [],
        'musicvideos': [],
        'songs': [],
    }
    errors = []
    if progress_cb:
        progress_cb(0, 0, 'Leyendo películas...')
    try:
        movies = _list_paginated(
            'VideoLibrary.GetMovies', {},
            ['playcount', 'lastplayed', 'resume', 'file', 'title', 'year'],
            'movies',
            progress_cb=progress_cb, progress_label='Películas',
        )
    except WatchedStateError as e:
        log.warning(f'[watched_state] dump de películas falló: {e}')
        errors.append(f'movies: {e}')
        movies = []
    for m in movies:
        f = m.get('file')
        if not f:
            continue
        out['movies'].append({
            'file': f,
            'playcount': m.get('playcount') or 0,
            'lastplayed': m.get('lastplayed') or '',
            'resume': m.get('resume') or {},
            'title': m.get('title') or '',
            'year': m.get('year') or 0,
        })

    if progress_cb:
        progress_cb(0, 0, 'Leyendo episodios...')
    try:
        episodes = _list_paginated(
            'VideoLibrary.GetEpisodes', {},
            ['playcount', 'lastplayed', 'resume', 'file', 'tvshowid',
             'season', 'episode', 'showtitle'],
            'episodes',
            progress_cb=progress_cb, progress_label='Episodios',
        )
    except WatchedStateError as e:
        log.warning(f'[watched_state] dump de episodios falló: {e}')
        errors.append(f'episodes: {e}')
        episodes = []
    for e in episodes:
        f = e.get('file')
        if not f:
            continue
        out['episodes'].append({
            'file': f,
            'playcount': e.get('playcount') or 0,
            'lastplayed': e.get('lastplayed') or '',
            'resume': e.get('resume') or {},
            'showtitle': e.get('showtitle') or '',
            'season': e.get('season') or 0,
            'episode': e.get('episode') or 0,
        })

    if progress_cb:
        progress_cb(0, 0, 'Leyendo canciones...')
    try:
        songs = _list_paginated(
            'AudioLibrary.GetSongs', {},
            ['playcount', 'lastplayed', 'file', 'title', 'artist'],
            'songs',
            progress_cb=progress_cb, progress_label='Canciones',
        )
    except WatchedStateError as e:
        log.warning(f'[watched_state] dump de canciones falló: {e}')
        errors.append(f'songs: {e}')
        songs = []
    for s in songs:
        f = s.get('file')
        if not f:
            continue
        out['songs'].append({
            'file': f,
            'playcount': s.get('playcount') or 0,
            'lastplayed': s.get('lastplayed') or '',
            'title': s.get('title') or '',
        })

    out['totals'] = {
        'movies': len(out['movies']),
        'episodes': len(out['episodes']),
        'songs': len(out['songs']),
    }
    if errors:
        out['errors'] = errors
    return out


def _build_path_index(method, key, id_field, properties):
    """Devuelve (by_path, by_basename) con los items actuales de la biblioteca.

    by_path: dict {file_path: id} para match exacto O(1).
    by_basename: dict {basename: id} para fuzzy match cuando file path
    cambió (e.g. /storage/movies/X.mkv → smb://NAS/movies/X.mkv).
    """
    by_path = {}
    by_basename = {}
    current = _list_paginated(method, {}, properties + ['file'], key)
    for it in current:
        f = it.get('file')
        item_id = it.get(id_field)
        if not f or item_id is None:
            continue
        by_path[f] = item_id
        base = os.path.basename(f)
        if base and base not in by_basename:
            by_basename[base] = item_id
    return by_path, by_basename


def restore_watched_state(dump, *, fuzzy_path_match=True, progress_cb=None):
    """Aplica el dump del watched_state.

    Para cada item del dump:
      1. Match exacto por file path
      2. Si no encontrado y fuzzy=True: match por basename
      3. Si encontrado: SetMovieDetails/etc con playcount, lastplayed, resume
      4. Si no encontrado: aparece en not_found (no falla)

    Devuelve dict con applied/not_found/failed/by_type.
    """
    result = {
        'applied': 0,
        'not_found': 0,
        'failed': 0,
        'by_type': {},
    }
    if not dump or not isinstance(dump, dict):
        return result

    errors = []

    # Movies
    if dump.get('movies'):
        if progress_cb:
            progress_cb(0, 0, 'Aplicando estado de películas...')
        try:
            by_path, by_base = _build_path_index(
                'VideoLibrary.GetMovies', 'movies', 'movieid',
                ['title'],
            )
        except WatchedStateError as e:
            log.warning(f'[watched_state] restore películas: índice falló: {e}')
            errors.append(f'movies: {e}')
            by_path, by_base = {}, {}
        applied, nf, fail = 0, 0, 0
        for m in dump['movies']:
            f = m.get('file')
            if not f:
                continue
            mid = by_path.get(f)
            if mid is None and fuzzy_path_match:
                mid = by_base.get(os.path.basename(f))
            if mid is None:
                nf += 1
                continue
            params = {
                'movieid': mid,
                'playcount': int(m.get('playcount') or 0),
                'lastplayed': m.get('lastplayed') or '',
            }
            resume = m.get('resume') or {}
            if resume.get('position'):
                params['resume'] = {
                    'position': float(resume.get('position', 0)),
                    'total': float(resume.get('total', 0)),
                }
            ok = jsonrpc_safe.call_void(
                'VideoLibrary.SetMovieDetails', params, timeout_s=5.0,
            )
            if ok:
                applied += 1
            else:
                fail += 1
        result['by_type']['movies'] = {
            'applied': applied, 'not_found': nf, 'failed': fail,
        }
        result['applied'] += applied
        result['not_found'] += nf
        result['failed'] += fail

    # Episodes
    if dump.get('episodes'):
        if progress_cb:
            progress_cb(0, 0, 'Aplicando estado de episodios...')
        try:
            by_path, by_base = _build_path_index(
                'VideoLibrary.GetEpisodes', 'episodes', 'episodeid',
                ['showtitle', 'season', 'episode'],
            )
        except WatchedStateError as e:
            log.warning(f'[watched_state] restore episodios: índice falló: {e}')
            errors.append(f'episodes: {e}')
            by_path, by_base = {}, {}
        applied, nf, fail = 0, 0, 0
        for e in dump['episodes']:
            f = e.get('file')
            if not f:
                continue
            eid = by_path.get(f)
            if eid is None and fuzzy_path_match:
                eid = by_base.get(os.path.basename(f))
            if eid is None:
                nf += 1
                continue
            params = {
                'episodeid': eid,
                'playcount': int(e.get('playcount') or 0),
                'lastplayed': e.get('lastplayed') or '',
            }
            resume = e.get('resume') or {}
            if resume.get('position'):
                params['resume'] = {
                    'position': float(resume.get('position', 0)),
                    'total': float(resume.get('total', 0)),
                }
            ok = jsonrpc_safe.call_void(
                'VideoLibrary.SetEpisodeDetails', params, timeout_s=5.0,
            )
            if ok:
                applied += 1
            else:
                fail += 1
        result['by_type']['episodes'] = {
            'applied': applied, 'not_found': nf, 'failed': fail,
        }
        result['applied'] += applied
        result['not_found'] += nf
        result['failed'] += fail

    # Songs
    if dump.get('songs'):
        if progress_cb:
            progress_cb(0, 0, 'Aplicando estado de canciones...')
        try:
            by_path, by_base = _build_path_index(
                'AudioLibrary.GetSongs', 'songs', 'songid',
                ['title'],
            )
        except WatchedStateError as e:
            log.warning(f'[watched_state] restore canciones: índice falló: {e}')
            errors.append(f'songs: {e}')
            by_path, by_base = {}, {}
        applied, nf, fail = 0, 0, 0
        for s in dump['songs']:
            f = s.get('file')
            if not f:
                continue
            sid = by_path.get(f)
            if sid is None and fuzzy_path_match:
                sid = by_base.get(os.path.basename(f))
            if sid is None:
                nf += 1
                continue
            params = {
                'songid': sid,
                'playcount': int(s.get('playcount') or 0),
                'lastplayed': s.get('lastplayed') or '',
            }
            ok = jsonrpc_safe.call_void(
                'AudioLibrary.SetSongDetails', params, timeout_s=5.0,
            )
            if ok:
                applied += 1
            else:
                fail += 1
        result['by_type']['songs'] = {
            'applied': applied, 'not_found': nf, 'failed': fail,
        }
        result['applied'] += applied
        result['not_found'] += nf
        result['failed'] += fail

    if errors:
        result['errors'] = errors
    return result
