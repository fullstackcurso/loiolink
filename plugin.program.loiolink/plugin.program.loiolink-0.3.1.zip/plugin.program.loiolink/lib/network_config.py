"""Timeouts HTTP leídos de settings, con clamp al rango declarado en settings.xml.

Centraliza la lectura para que `downloader`, `installer`, `transcode` y
`aftvnews` compartan el mismo origen; el usuario puede subirlos en
redes lentas o HW antiguo sin tocar código.
"""
import xbmcaddon


# (default, min, max). Default coincide con el comportamiento previo hardcoded
# para que actualizar el addon no cambie nada hasta que el usuario toque el
# setting deliberadamente.
_SPECS = {
    'download':  (30, 5, 180),
    'install':   (60, 10, 300),
    'transcode': (10, 2, 60),
}

_SETTING_KEYS = {
    'download':  'network.timeout_download_s',
    'install':   'network.timeout_install_s',
    'transcode': 'network.timeout_transcode_s',
}


def get_timeout(kind):
    """Devuelve el timeout en segundos para `kind` ∈ {'download','install','transcode'}.

    Si el setting está vacío, fuera de rango o el addon aún no está inicializado,
    devuelve el default del spec.
    """
    default, lo, hi = _SPECS[kind]
    try:
        raw = xbmcaddon.Addon().getSettingInt(_SETTING_KEYS[kind])
    except (RuntimeError, ValueError, TypeError):
        return default
    if not raw:
        return default
    return max(lo, min(hi, raw))
