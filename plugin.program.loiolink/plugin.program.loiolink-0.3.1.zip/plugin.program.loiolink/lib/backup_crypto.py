"""Cifrado híbrido de backups: AES-256-CBC + PBKDF2-HMAC-SHA256.

Solo se cifra el manifest.json (no el ZIP completo): da seguridad
criptográfica real sin el coste prohibitivo de cifrar archivos grandes en
Python puro (~30 min para 500 MB). pyzipper/pycryptodome no están
disponibles en Android, Apple TV, Xbox ni LibreELEC (sin C ext), de ahí AES
puro-Python; con manifest ~50KB el cifrado tarda <1s en cualquier plataforma.

Sin manifest no se puede restaurar (addon IDs, hashes, paths están dentro),
así que el ZIP queda opaco aunque sus archivos individuales no estén
cifrados. Para protección total del contenido, el usuario debe usar
cifrado del medio (LUKS, BitLocker, SMB cifrado, etc.).

Formato del manifest cifrado dentro del ZIP:
- Archivo: 'manifest.json.enc' (en vez de 'manifest.json')
- Estructura binaria: salt (16 bytes) + iv (16 bytes) + ciphertext
- KDF: PBKDF2-HMAC-SHA256
"""
import hashlib
import json

from lib import log
from lib._vendor import pyaes


# PBKDF2 iterations per OWASP Password Storage Cheat Sheet 2024-2025
# (https://cheatsheetseries.owasp.org/). Histórico: 100k (2015) → 310k
# (2020) → 600k (2023+). A 100k una GPU moderna prueba ~38k passwords/s;
# 600k lo reduce 6x. Coste ~0.5s por backup (manifest <50KB).
_PBKDF2_ITERATIONS = 600_000
_SALT_LEN = 16
_IV_LEN = 16
_KEY_LEN = 32  # AES-256


class CryptoError(Exception):
    """Error en cifrado/descifrado de backup."""


class BadPasswordError(CryptoError):
    """Password incorrecto al descifrar."""


def derive_key(password, salt, *, iterations=_PBKDF2_ITERATIONS):
    """PBKDF2-HMAC-SHA256 para derivar clave AES-256 desde password.

    password: str o bytes. Se encodea a UTF-8 si es str.
    salt: bytes (16 bytes recomendado).
    Devuelve key de 32 bytes.
    """
    if isinstance(password, str):
        password = password.encode('utf-8')
    if not password:
        raise CryptoError('password vacío no permitido')
    return hashlib.pbkdf2_hmac(
        'sha256', password, salt, iterations, dklen=_KEY_LEN,
    )


def encrypt_manifest_bytes(manifest_bytes, password):
    """Cifra bytes del manifest. Devuelve blob (salt + iv + ciphertext).

    Layout del blob:
      bytes[0:16]   = salt (PBKDF2)
      bytes[16:32]  = iv (AES-CBC)
      bytes[32:]    = ciphertext (PKCS#7 padded)
    """
    if not isinstance(manifest_bytes, bytes):
        raise CryptoError('manifest_bytes debe ser bytes')
    salt = pyaes.random_salt(_SALT_LEN)
    iv = pyaes.random_iv()
    key = derive_key(password, salt)
    cipher = pyaes.AES256CBC(key, iv)
    ciphertext = cipher.encrypt(manifest_bytes)
    return salt + iv + ciphertext


def decrypt_manifest_bytes(blob, password):
    """Descifra blob (salt + iv + ciphertext). Devuelve manifest bytes.

    Lanza BadPasswordError si el password es incorrecto (detectado por
    fallo en PKCS#7 unpad).
    """
    if not isinstance(blob, bytes):
        raise CryptoError('blob debe ser bytes')
    if len(blob) < _SALT_LEN + _IV_LEN + 16:
        raise CryptoError(
            f'blob demasiado corto ({len(blob)} bytes); ¿manifest cifrado?'
        )
    salt = blob[:_SALT_LEN]
    iv = blob[_SALT_LEN:_SALT_LEN + _IV_LEN]
    ciphertext = blob[_SALT_LEN + _IV_LEN:]
    if len(ciphertext) % 16 != 0:
        raise CryptoError('ciphertext no es múltiplo de 16 bytes')
    key = derive_key(password, salt)
    cipher = pyaes.AES256CBC(key, iv)
    try:
        plaintext = cipher.decrypt(ciphertext)
    except ValueError as e:
        # PKCS#7 unpad falló. Sin AEAD no podemos distinguir password
        # incorrecto (caso común) de blob corrupto (descarga interrumpida,
        # bit-rot). El mensaje cubre ambos casos.
        raise BadPasswordError(
            'Password incorrecto. Si lo escribiste bien, el backup puede '
            'estar dañado: intenta descargar el ZIP de nuevo.'
        ) from e
    return plaintext


def encrypt_manifest_json(manifest_dict, password):
    """Helper: serializa dict a JSON y cifra. Devuelve blob bytes."""
    data = json.dumps(
        manifest_dict, indent=2, ensure_ascii=False,
    ).encode('utf-8')
    return encrypt_manifest_bytes(data, password)


def decrypt_manifest_json(blob, password):
    """Helper: descifra blob y parsea JSON. Devuelve dict.

    Lanza BadPasswordError si password incorrecto.
    Lanza CryptoError si tras descifrar el JSON no es válido.
    """
    plaintext = decrypt_manifest_bytes(blob, password)
    try:
        return json.loads(plaintext.decode('utf-8'))
    except (ValueError, UnicodeDecodeError) as e:
        # Si llegamos aquí, descifrado fue OK (PKCS#7 unpad OK) pero el
        # contenido no es JSON válido. Podría ser un blob de otro origen.
        raise CryptoError(f'manifest descifrado no es JSON válido: {e}')


# ─── Persistencia opcional del password (low-trust storage) ───────────

def _obfuscate_password(password):
    """XOR con UUID estable del addon. NO es seguridad, solo evita lectura
    casual del password en disco/settings.xml. Si el atacante tiene acceso
    al disco, también puede leer el UUID; trivialmente reversible.

    Para seguridad real: pedir password al usuario en cada operación y NO
    almacenarlo. Esta función es para users que prefieren UX por encima
    de seguridad estricta.
    """
    import uuid as _uuid
    if isinstance(password, str):
        password = password.encode('utf-8')
    # UUID estable del addon (mismo para toda instalación)
    # Usamos un namespace fijo para que sea determinístico
    NAMESPACE = _uuid.UUID('a8b9c0d1-e2f3-4a5b-6c7d-8e9f0a1b2c3d')
    addon_uuid = _uuid.uuid5(NAMESPACE, 'loiolink.backup.password').bytes
    out = bytearray()
    for i, b in enumerate(password):
        out.append(b ^ addon_uuid[i % len(addon_uuid)])
    return bytes(out)


def obfuscate_password_for_storage(password):
    """Devuelve hex del password obfuscado para guardar en settings."""
    if not password:
        return ''
    return _obfuscate_password(password).hex()


def deobfuscate_password_from_storage(hex_str):
    """Decode hex y de-obfuscate. Devuelve str password."""
    if not hex_str:
        return ''
    try:
        blob = bytes.fromhex(hex_str)
    except ValueError:
        return ''
    plaintext = _obfuscate_password(blob)  # XOR es simétrico
    try:
        return plaintext.decode('utf-8')
    except UnicodeDecodeError:
        log.warning('[backup_crypto] password obfuscado corrupto')
        return ''
