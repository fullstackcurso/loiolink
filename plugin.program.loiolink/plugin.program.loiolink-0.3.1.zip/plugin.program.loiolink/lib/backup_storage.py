"""Abstracción de destino de backup.

Permite que `list_snapshots`, `snapshot_path`, `delete_snapshot` y
`rotate_snapshots` operen sobre múltiples ubicaciones (default local +
custom path configurado por el usuario) sin que el resto del código
sepa de la diferencia.

Storages disponibles:
- LocalStorage: encapsula SNAPSHOTS_DIR (perfil del addon).
- CustomPathStorage: ruta configurada en `backup.custom_path`.

`get_active_storages()` devuelve la lista ORDENADA: el primer storage
escribible es donde se crean los backups nuevos por defecto.

Diseño: Python duck typing, sin ABC. Cada storage expone:
  - name: str (para diagnóstico)
  - origin: str ('default' | 'custom')
  - root_path: str (path absoluto donde viven los snapshots)
  - writable() -> bool
  - list() -> list[dict] (mismo shape que list_snapshots actual)
  - exists(filename) -> bool
  - path_for(filename) -> str (path absoluto)
  - delete(filename) -> bool

`filename` SIEMPRE pasa por `_safe_snapshot_filename` validation antes de
llegar aquí; los storages no re-validan path traversal (lo hace el
caller). El motivo: mantener la responsabilidad de seguridad en un solo
sitio (backup.py).
"""
import os
import re
import time

import xbmcvfs

from lib import log


_SAFE_FILE_RE = re.compile(r'^kodi_backup_[A-Za-z0-9._-]+\.zip$')
# Regex combinada: valida formato safe + extrae timestamp/label en una sola
# pasada. Importante con 100+ snapshots en _scan_dir.
_SAFE_LABEL_RE = re.compile(
    r'^kodi_backup_(?P<ts>\d{4}-\d{2}-\d{2}_\d{6})(?:_(?P<label>[A-Za-z0-9._-]+))?\.zip$',
)


def _scan_dir(root, *, origin):
    """Lista archivos .zip dentro de `root` con metadata estable.

    Ignora archivos no .zip, archivos .tmp (backups en curso) y entries
    con filename sospechoso (no cumplen el patrón seguro).
    """
    if not root or not os.path.isdir(root):
        return []
    out = []
    try:
        names = sorted(os.listdir(root), reverse=True)
    except OSError as e:
        log.warning(f'[backup_storage] no se pudo listar {origin}: {type(e).__name__}')
        log.sensitive(f'[backup_storage] listar {origin} err={e!r}')
        return []
    for name in names:
        if not name.lower().endswith('.zip'):
            continue
        # P-4: una sola regex que valida + extrae timestamp + label opcional.
        m = _SAFE_LABEL_RE.match(name)
        if m is None:
            # Archivos manualmente puestos por el usuario con otro nombre
            # se ignoran. Para gestionarlos debe usar "Importar a mis
            # backups", que los renombra al patrón canónico.
            continue
        full = os.path.join(root, name)
        try:
            st = os.stat(full)
        except OSError:
            continue
        entry = {
            'filename': name,
            'size': st.st_size,
            'created': int(st.st_mtime),
            'origin': origin,
        }
        label_value = m.group('label')
        if label_value:
            entry['label'] = label_value
        out.append(entry)
    return out


class LocalStorage:
    """Destino por defecto: `addon_data/plugin.program.loiolink/backups/snapshots/`."""

    name = 'local'
    origin = 'default'

    def __init__(self, root_path):
        self.root_path = root_path

    def writable(self):
        # Comprobación cheap: el dir existe (o se puede crear) y es escribible.
        try:
            os.makedirs(self.root_path, exist_ok=True)
            return os.access(self.root_path, os.W_OK)
        except OSError:
            return False

    def list(self):
        return _scan_dir(self.root_path, origin=self.origin)

    def exists(self, filename):
        if not _SAFE_FILE_RE.match(filename):
            return False
        return os.path.isfile(os.path.join(self.root_path, filename))

    def path_for(self, filename):
        if not _SAFE_FILE_RE.match(filename):
            raise ValueError(f'filename inválido: {filename!r}')
        return os.path.join(self.root_path, filename)

    def delete(self, filename):
        if not _SAFE_FILE_RE.match(filename):
            return False
        full = os.path.join(self.root_path, filename)
        if not os.path.isfile(full):
            return False
        try:
            os.unlink(full)
            return True
        except OSError as e:
            log.warning(f'[backup_storage] delete {filename!r}: {type(e).__name__}')
            log.sensitive(f'[backup_storage] delete {filename!r} err={e!r}')
            return False


class CustomPathStorage:
    """Destino configurable por el usuario (setting `backup.custom_path`).

    Si no hay setting configurado o el path es inválido, `writable()`
    devuelve False y `list()` devuelve [].
    """

    name = 'custom'
    origin = 'custom'

    def __init__(self, root_path):
        raw = (root_path or '').strip()
        if raw:
            translated = xbmcvfs.translatePath(raw)
            if '://' in translated:
                log.warning(
                    f'[backup_storage] custom path no soportado '
                    f'(solo carpetas locales): {raw}'
                )
                raw = ''
            else:
                raw = translated
        self.root_path = raw

    def writable(self):
        if not self.root_path:
            return False
        try:
            if not xbmcvfs.exists(self.root_path):
                # Intento de creación; si falla, no writable.
                if not xbmcvfs.mkdir(self.root_path):
                    return False
            # Sentinel con UUID, no solo timestamp: dos threads llamando
            # writable() en el mismo segundo colisionarían y uno borraría
            # el sentinel del otro causando FileNotFoundError.
            import uuid as _uuid
            sentinel = os.path.join(
                self.root_path,
                f'.loiolink_write_test_{int(time.time())}_{_uuid.uuid4().hex}',
            )
            with open(sentinel, 'w', encoding='utf-8') as fh:
                fh.write('ok')
            try:
                os.unlink(sentinel)
            except OSError:
                # Otro proceso/thread pudo haberlo borrado (limpieza externa);
                # no es un fallo real del test write.
                pass
            return True
        except (OSError, PermissionError) as e:
            log.warning(f'[backup_storage] custom path no escribible: {type(e).__name__}')
            log.sensitive(f'[backup_storage] custom path err={e!r}')
            return False

    def list(self):
        if not self.root_path:
            return []
        return _scan_dir(self.root_path, origin=self.origin)

    def exists(self, filename):
        if not self.root_path or not _SAFE_FILE_RE.match(filename):
            return False
        return os.path.isfile(os.path.join(self.root_path, filename))

    def path_for(self, filename):
        if not _SAFE_FILE_RE.match(filename):
            raise ValueError(f'filename inválido: {filename!r}')
        if not self.root_path:
            raise ValueError('CustomPathStorage sin root_path configurado')
        return os.path.join(self.root_path, filename)

    def delete(self, filename):
        if not self.root_path or not _SAFE_FILE_RE.match(filename):
            return False
        full = os.path.join(self.root_path, filename)
        if not os.path.isfile(full):
            return False
        try:
            os.unlink(full)
            return True
        except OSError as e:
            log.warning(f'[backup_storage] delete custom {filename!r}: {type(e).__name__}')
            log.sensitive(f'[backup_storage] delete custom {filename!r} err={e!r}')
            return False


# ─── Registro global ───────────────────────────────────────────────────


def _read_custom_path_setting():
    """Lee el setting `backup.custom_path`. Vacío = sin custom destino."""
    try:
        import xbmcaddon
        path = xbmcaddon.Addon().getSetting('backup.custom_path') or ''
        return path.strip()
    except RuntimeError:
        return ''


def get_active_storages(default_root):
    """Devuelve la lista de storages a operar.

    El primero es donde se ESCRIBEN backups nuevos. El resto solo se usan
    para listar/leer/borrar snapshots existentes ahí.
    """
    storages = [LocalStorage(default_root)]
    custom_path = _read_custom_path_setting()
    if custom_path:
        custom = CustomPathStorage(custom_path)
        # Si el custom es escribible, va PRIMERO (destino por defecto de
        # backups nuevos). Si no, queda al final como solo-lectura.
        if custom.writable():
            storages.insert(0, custom)
        else:
            storages.append(custom)
    return storages


def find_storage_by_filename(filename, *, default_root):
    """Localiza el storage que contiene `filename`. Devuelve (storage, path).

    Si el filename no existe en ningún storage activo: devuelve (None, None).
    """
    for st in get_active_storages(default_root):
        if st.exists(filename):
            return st, st.path_for(filename)
    return None, None
