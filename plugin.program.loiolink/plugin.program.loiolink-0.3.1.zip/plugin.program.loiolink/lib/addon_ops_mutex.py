"""Mutex coordinador para operaciones que tocan `addons/` o
`userdata/addon_data/<id>/`.

Existe porque hoy `installer` y `backup` tienen mutexes INDEPENDIENTES,
lo que permite que ambos corran a la vez y choquen leyendo/escribiendo
en `addons/`. Este mutex es superordinado: cualquier operación que vaya a
tocar el filesystem de addons debería adquirirlo PRIMERO (antes de su
mutex específico, si tiene).

Hoy el llamador prudente es `backup` (operaciones largas, riesgo alto si
se mezclan con instalaciones). El installer y transfers se pueden migrar
incrementalmente sin romper backward compat.

Patrón CAS idéntico a `installer._acquire_install_mutex` y
`backup.acquire_backup_mutex`: token `timestamp:uuid` en Window(10000)
property, verificación post-set. Timeout stale generoso (30 min) para
soportar backups grandes a SMB lento.

Uso:

    from lib.addon_ops_mutex import addon_ops_lock

    with addon_ops_lock('backup_create', timeout_s=5) as ok:
        if not ok:
            raise BusyError('hay otra operación tocando addons/')
        # ... trabajo que escribe en addons/ o lee inconsistente ...
"""
import threading
import time
import uuid

import xbmcgui

from lib import log

_PROP = 'loiolink.addon_ops.busy'
_STALE_S = 1800  # 30 min: backup completo a SMB lento puede tardar más
_TOKEN = None
# Serializa el CAS intra-proceso (defensa contra threads paralelos en
# ThreadingHTTPServer que invocan backup/install).
_INTRA_LOCK = threading.Lock()


def acquire(owner, *, timeout_s=0):
    """Reclama el mutex coordinador.

    owner: string identificador del llamador (`backup_create`,
        `backup_restore`, `install_addon`, `transfers_extract`...). Va en
        el token para diagnóstico (queda visible en Window property).
    timeout_s: si >0, espera hasta `timeout_s` segundos comprobando cada
        500 ms. Si 0 (default), no-blocking.

    Devuelve True si lo adquirió, False si no pudo.
    """
    win = xbmcgui.Window(10000)
    deadline = time.time() + max(0.0, float(timeout_s))
    while True:
        if _try_acquire(win, owner):
            return True
        if time.time() >= deadline:
            return False
        # waitForAbort no está disponible fuera de un xbmc.Monitor; usamos
        # un sleep corto. Caller que necesite cancellation debería pasar
        # timeout_s pequeño y reintentar.
        time.sleep(0.5)


def _try_acquire(win, owner):
    """CAS-like con spin-loop sobre Window properties.

    `xbmcgui.Window.setProperty` / `getProperty` no están documentadas como
    atómicas en Kodi: dos threads en una ventana de ~µs pueden ambos creer
    haber adquirido el mutex. Mitigamos haciendo hasta 3 lecturas tras el
    set; si nuestro token (uuid) sobrevive a las 3, aceptamos. No es CAS
    real, pero reduce la race a sub-milisegundos, suficiente para mutex de
    operaciones de backup que duran segundos+.
    """
    global _TOKEN
    with _INTRA_LOCK:
        raw = win.getProperty(_PROP) or ''
        if raw:
            ts_part = raw.split(':', 1)[0]
            try:
                held = int(ts_part)
            except (TypeError, ValueError):
                held = 0
            if time.time() - held < _STALE_S:
                return False
            log.warning(
                f'[addon_ops] mutex stale ({int(time.time() - held)}s, '
                f'previo owner: {raw}), reclamando'
            )
        token = f'{int(time.time())}:{owner}:{uuid.uuid4().hex}'
        win.setProperty(_PROP, token)
        # Spin-loop CAS-like: hasta 3 lecturas con sleep entre ellas. Si otro
        # proceso (NO thread del nuestro: el intra-lock ya serializa eso)
        # escribió en el medio, su token prevalece y devolvemos False.
        for attempt in range(3):
            read_back = win.getProperty(_PROP) or ''
            if read_back == token:
                _TOKEN = token
                return True
            if attempt < 2:
                try:
                    import xbmc
                    xbmc.sleep(1)
                except (ImportError, Exception):  # noqa: BLE001
                    time.sleep(0.001)
        log.warning(
            f'[addon_ops] CAS failed: nuestro token {token[:24]}... '
            f'no persiste tras 3 lecturas (otro proceso ganó la race)'
        )
        return False


def release():
    # Validación CAS: solo borramos la prop si sigue siendo nuestro token.
    # Si pasó el stale y otro proceso reclamó, su token está ahí; borrar
    # incondicionalmente destruiría su lock activo.
    global _TOKEN
    with _INTRA_LOCK:
        if not _TOKEN:
            return
        win = xbmcgui.Window(10000)
        if win.getProperty(_PROP) == _TOKEN:
            win.clearProperty(_PROP)
        else:
            log.warning(
                f'[addon_ops] release con token expirado ({_TOKEN[:24]}...); '
                'no tocamos la prop'
            )
        _TOKEN = None


def current_owner():
    """Devuelve el owner actual o None. Útil para diagnóstico/logging."""
    raw = xbmcgui.Window(10000).getProperty(_PROP) or ''
    if not raw:
        return None
    parts = raw.split(':', 2)
    return parts[1] if len(parts) >= 2 else None


class addon_ops_lock:
    """Context manager.

    Uso:
        with addon_ops_lock('backup_create', timeout_s=5) as ok:
            if not ok:
                raise BusyError(...)
            # trabajo

    El __enter__ devuelve True si adquirió, False si no. El llamador
    decide si abortar o continuar. El __exit__ solo libera si la
    adquisición fue exitosa (no libera un mutex ajeno).
    """

    def __init__(self, owner, *, timeout_s=0):
        self.owner = owner
        self.timeout_s = timeout_s
        self.acquired = False

    def __enter__(self):
        self.acquired = acquire(self.owner, timeout_s=self.timeout_s)
        return self.acquired

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            release()
        return False  # no swallow exceptions
