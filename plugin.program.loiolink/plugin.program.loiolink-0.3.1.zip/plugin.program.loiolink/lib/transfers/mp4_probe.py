"""Probe rápido de container MP4 para detectar layout faststart.

MP4/MOV/M4V usan estructura de "boxes" [size:4 BE][type:4 ASCII][payload].
El box `moov` (índices de codec, sample tables, offsets) es obligatorio
para decodificar. Dos layouts:

- Faststart (ftyp → moov → mdat): moov al inicio. Reproducible mientras
  se descarga/sube.
- No-faststart (ftyp → mdat → ... → moov): moov tras el media. Si el file
  no está completo en disco, el player hace seek a un offset inexistente
  y falla con "Error de reproducción".

Esta función lee los primeros bytes (default 256 KB) y parsea boxes
top-level hasta encontrar moov o mdat. No depende de Kodi; pura I/O.
"""
import os
import struct


def is_mp4_faststart(filepath, max_bytes=262144):
    """Devuelve True si moov aparece antes de mdat en los primeros
    `max_bytes` del archivo, False si mdat aparece antes, None si no
    se puede determinar (no es MP4 reconocible, archivo truncado en
    medio de un box, moov más allá del límite, error de I/O).

    El caller debe tratar None como "no reproducir incrementalmente"
    (fallback seguro: el archivo puede no ser MP4 o tener moov enorme
    al final).
    """
    try:
        size_on_disk = os.path.getsize(filepath)
    except OSError:
        return None
    limit = min(max_bytes, size_on_disk)
    if limit < 16:
        return None
    try:
        with open(filepath, 'rb') as f:
            data = f.read(limit)
    except OSError:
        return None
    return _scan_boxes(data)


def _scan_boxes(data):
    """Parsea boxes top-level en `data`. Devuelve True/False/None según
    encuentre moov antes que mdat, mdat antes que moov, o no resuelva.
    """
    n = len(data)
    pos = 0
    saw_ftyp = False
    while pos + 8 <= n:
        size = struct.unpack('>I', data[pos:pos+4])[0]
        btype = data[pos+4:pos+8]
        header_len = 8
        # size==1 → extended size (8 bytes BE) en los siguientes 8 bytes.
        if size == 1:
            if pos + 16 > n:
                return None
            size = struct.unpack('>Q', data[pos+8:pos+16])[0]
            header_len = 16
        # size==0 → este box ocupa hasta EOF (solo válido en el último).
        # Para nuestro propósito: si vemos eso antes de moov/mdat el
        # parser no puede continuar.
        elif size == 0:
            # Si justo este box es moov o mdat, decidimos; si no, no
            # podemos saltarlo.
            if btype == b'moov':
                return True
            if btype == b'mdat':
                return False
            return None
        if size < header_len:
            # Box inválido (size menor que la cabecera).
            return None
        if btype == b'moov':
            return True
        if btype == b'mdat':
            return False
        if btype == b'ftyp':
            saw_ftyp = True
        pos += size
    # Llegamos al límite del buffer sin encontrar ninguno. Si ni
    # siquiera vimos ftyp probablemente no es MP4.
    if not saw_ftyp:
        return None
    # Vimos ftyp + otros boxes pero ni moov ni mdat caben en el límite:
    # moov debe estar al final (no-faststart con moov enorme) o el file
    # es muy raro. Tratamos como no-faststart por seguridad.
    return None
