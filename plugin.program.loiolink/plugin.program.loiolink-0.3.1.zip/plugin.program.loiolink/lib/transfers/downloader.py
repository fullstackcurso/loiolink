"""Descarga archivos por URL: universal + resolvers opt-in para hosts populares.

Estrategia:
1. ¿Hay resolver específico para este host? (Drive, MediaFire) → usarlo.
2. Si no → pipeline genérico:
   a. GET. Si responde binario o con Content-Disposition filename → bajar.
   b. Si responde HTML → buscar URL real con heurísticas (meta refresh,
      <a download>, links a extensiones descargables, formularios).
   c. Si no encuentra nada → ValueError legible para el usuario.

Sin yt-dlp (decisión del ROADMAP).
"""
import html
import os
import re
import urllib.parse
import urllib.request
from urllib.error import HTTPError

from lib import log, network_config
from lib.transfers import storage
from lib.transfers.multipart_stream import _sanitize_filename


_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
)

# Extensiones que el pipeline genérico considera "claramente un archivo de
# descarga" cuando aparecen como enlaces en HTML. Lista conservadora:
# falsos negativos OK (mensaje claro al usuario); falsos positivos no.
_DOWNLOADABLE_EXTS = (
    '.zip', '.tar', '.tar.gz', '.tgz', '.tar.bz2', '.7z', '.rar',
    '.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.flv',
    '.mp3', '.flac', '.aac', '.m4a', '.ogg', '.opus', '.wav',
    '.jpg', '.jpeg', '.png', '.gif', '.webp',
    '.apk', '.ipa', '.deb', '.rpm', '.exe', '.msi', '.dmg', '.pkg',
    '.iso', '.img', '.pdf', '.torrent',
)


def download_url(url, dest_dir, progress_cb=None, timeout=None):
    """Descarga URL a dest_dir. Devuelve (filepath, filename, size).

    progress_cb(bytes_downloaded, total_bytes_or_None) si se pasa.
    timeout en segundos; None → setting `network.timeout_download_s`.
    Lanza ValueError / PermissionError / FileNotFoundError / URLError según el caso.
    """
    if timeout is None:
        timeout = network_config.get_timeout('download')
    resolver = _find_specific_resolver(url)
    if resolver is not None:
        return resolver(url, dest_dir, progress_cb, timeout)
    return _generic_download(url, dest_dir, progress_cb, timeout)


def _find_specific_resolver(url):
    host = (urllib.parse.urlparse(url).hostname or '').lower()
    for hosts, resolver in _SPECIFIC_RESOLVERS:
        if any(host == h or host.endswith('.' + h) for h in hosts):
            return resolver
    return None


def _generic_download(url, dest_dir, progress_cb, timeout, visited=None):
    """Universal: directo si es archivo, HTML-scraping si no.

    visited: set de URLs ya intentadas. Tope implícito de 3 saltos.
    """
    visited = visited or set()
    if url in visited or len(visited) > 3:
        raise ValueError(f'Loop de redirects detectado en {url}')
    visited.add(url)

    req = urllib.request.Request(url, headers={
        'User-Agent': _USER_AGENT,
        'Accept': '*/*',
    })
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except HTTPError as e:
        if e.code in (401, 403):
            raise PermissionError(
                f'Acceso denegado ({e.code}). El archivo puede ser privado o '
                f'requerir login.',
            ) from e
        raise

    with r:
        ctype = (r.headers.get('Content-Type') or '').lower()
        cd = r.headers.get('Content-Disposition') or ''

        # Tres señales de "es archivo directo":
        # (1) Content-Disposition con filename, (2) Content-Type binario,
        # (3) URL final acaba en extensión conocida.
        is_file = bool(cd) and 'filename' in cd
        if not is_file and ctype and not ctype.startswith('text/html'):
            is_file = ctype not in ('text/plain', 'application/json', 'application/xml')
        if not is_file:
            final_url = r.geturl()
            is_file = any(
                final_url.lower().split('?')[0].endswith(ext)
                for ext in _DOWNLOADABLE_EXTS
            )

        if is_file:
            return _stream_to_disk(r, url, dest_dir, progress_cb)

        # HTML: buscar URL de descarga real con heurísticas.
        # Leer max 2MB de HTML; suficiente para encontrar lo que sea.
        html = r.read(2 * 1024 * 1024)
        base_url = r.geturl()

    candidate = _extract_download_url_from_html(html, base_url)
    if candidate is None:
        raise ValueError(
            'La URL devolvió HTML y no se encontró un enlace de descarga claro. '
            'Comparte una URL directa al archivo.',
        )
    log.sensitive(f'Resolución genérica: {url} -> {candidate}')
    return _generic_download(candidate, dest_dir, progress_cb, timeout, visited)


def _extract_download_url_from_html(html, base_url):
    """Heurísticas universales para encontrar URL de descarga en HTML.

    Orden por fiabilidad:
    1. <meta http-equiv="refresh" content="N; url=...">
    2. <a download href="..."> con extensión descargable
    3. <a href="..."> con extensión descargable
    4. <form action="..."> que apunte a archivo descargable

    Devuelve URL absoluta o None.
    """
    text = html.decode('utf-8', errors='replace') if isinstance(html, bytes) else html

    m = re.search(
        r'<meta[^>]*http-equiv=["\']?refresh["\']?[^>]*content=["\'][^"\']*?url=([^"\'>]+)',
        text, re.I,
    )
    if m:
        return urllib.parse.urljoin(base_url, _unquote_html(m.group(1).strip()))

    for m in re.finditer(
        r'<a\b[^>]*\bdownload\b[^>]*\bhref=["\']([^"\']+)["\']', text, re.I,
    ):
        href = _unquote_html(m.group(1))
        if _looks_downloadable(href):
            return urllib.parse.urljoin(base_url, href)

    for m in re.finditer(r'<a\b[^>]*\bhref=["\']([^"\']+)["\']', text, re.I):
        href = _unquote_html(m.group(1))
        if _looks_downloadable(href):
            return urllib.parse.urljoin(base_url, href)

    for m in re.finditer(
        r'<form\b[^>]*\baction=["\']([^"\']+)["\'][^>]*>', text, re.I,
    ):
        action = _unquote_html(m.group(1))
        if _looks_downloadable(action):
            return urllib.parse.urljoin(base_url, action)

    return None


def _looks_downloadable(href):
    path = href.split('?', 1)[0].split('#', 1)[0].lower()
    return any(path.endswith(ext) for ext in _DOWNLOADABLE_EXTS)


def _unquote_html(s):
    return html.unescape(s)


def _stream_to_disk(response, original_url, dest_dir, progress_cb,
                    suggested_name=None):
    filename = suggested_name or _guess_filename(
        response.geturl() or original_url, response.headers,
    )
    # Reserva atómica para evitar que dos descargas concurrentes con el mismo
    # nombre se pisen el archivo (cada open('wb') trunca al anterior). El
    # segundo recibe un sufijo "-1", "-2"... y conservamos ambos íntegros.
    filepath = storage.reserve_unique_path(os.path.join(dest_dir, filename))
    filename = os.path.basename(filepath)

    total = response.headers.get('Content-Length')
    total = int(total) if total and total.isdigit() else None

    downloaded = 0
    chunk = 64 * 1024
    try:
        with open(filepath, 'wb') as out:
            while True:
                buf = response.read(chunk)
                if not buf:
                    break
                out.write(buf)
                downloaded += len(buf)
                if progress_cb:
                    progress_cb(downloaded, total)
    except BaseException:
        # Red caída, disco lleno, cancel del usuario: borrar el parcial para
        # no dejar archivos a medias que el usuario crea descargas completas.
        try:
            os.unlink(filepath)
        except OSError:
            pass
        raise

    return filepath, filename, downloaded


def _guess_filename(url, headers):
    cd = headers.get('Content-Disposition') or ''
    # filename*= (RFC 5987): charset'language'value. Split por comilla simple
    # a 3 partes; las internas dentro de `value` van como %27 por RFC.
    m = re.search(r"filename\*=([^;\r\n]+)", cd, re.I)
    if m:
        raw = m.group(1).strip(' "')
        parts = raw.split("'", 2)
        value = parts[2] if len(parts) == 3 else parts[-1]
        guessed = os.path.basename(urllib.parse.unquote(value))
        return _sanitize_filename(guessed) if guessed else 'archivo'
    # filename= (legacy)
    m = re.search(r'filename="([^"]+)"', cd, re.I)
    if m:
        return _sanitize_filename(os.path.basename(m.group(1)))
    # Path de la URL
    name = os.path.basename(urllib.parse.urlparse(url).path)
    guessed = urllib.parse.unquote(name) or 'archivo'
    return _sanitize_filename(guessed)


# Drive: confirm token flow. Endpoint verificado mayo 2026:
# drive.usercontent.google.com/download (sustituyó a drive.google.com/uc?...
# en enero 2024).

_DRIVE_HOSTS = (
    'drive.google.com', 'drive.usercontent.google.com', 'docs.google.com',
)
_DRIVE_ID_RES = (
    re.compile(r'/file/d/([a-zA-Z0-9_-]{20,})'),
    re.compile(r'[?&]id=([a-zA-Z0-9_-]{20,})'),
    re.compile(r'/document/d/([a-zA-Z0-9_-]{20,})'),
)
_DRIVE_CONFIRM_RES = (
    re.compile(rb'href="(/uc\?export=download[^"]+)"'),
    re.compile(rb'name="confirm"\s+value="([^"]+)"'),
)


def _resolve_drive(url, dest_dir, progress_cb, timeout):
    """Drive necesita endpoint específico + confirm token para archivos grandes."""
    fid = None
    for rx in _DRIVE_ID_RES:
        m = rx.search(url)
        if m:
            fid = m.group(1)
            break
    if fid is None:
        raise ValueError(f'No se pudo extraer FILE_ID de URL Drive: {url}')

    base = 'https://drive.usercontent.google.com/download'
    params = urllib.parse.urlencode({
        'id': fid, 'export': 'download', 'confirm': 't',
    })
    target = f'{base}?{params}'

    req = urllib.request.Request(target, headers={'User-Agent': _USER_AGENT})
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except HTTPError as e:
        if e.code in (403, 404):
            raise PermissionError(
                'Archivo de Drive privado, eliminado o requiere login.',
            ) from e
        raise

    with r:
        ctype = (r.headers.get('Content-Type') or '').lower()
        if 'text/html' not in ctype:
            return _stream_to_disk(r, url, dest_dir, progress_cb)
        html = r.read(2 * 1024 * 1024)

    # Drive devolvió HTML aunque pusimos confirm=t → archivo grande / AV scan.
    for rx in _DRIVE_CONFIRM_RES:
        m = rx.search(html)
        if not m:
            continue
        token_or_url = m.group(1).decode('utf-8', errors='replace')
        next_url = (token_or_url if token_or_url.startswith('http')
                    else urllib.parse.urljoin(base, token_or_url))
        next_url = next_url.replace('&amp;', '&')
        with urllib.request.urlopen(
            urllib.request.Request(next_url, headers={'User-Agent': _USER_AGENT}),
            timeout=timeout,
        ) as r2:
            return _stream_to_disk(r2, url, dest_dir, progress_cb)

    raise ValueError(
        'Drive pidió confirmación pero no se pudo extraer el token '
        '(¿layout cambió?). Comparte URL directa al archivo.',
    )


# MediaFire: scrapear la página intermedia para extraer el href del botón.
_MEDIAFIRE_HOSTS = ('mediafire.com',)
_MF_LINK_RES = (
    re.compile(r'id="downloadButton"[^>]*href="(https?://download[^"]+)"'),
    re.compile(r'aria-label="Download file"[^>]*href="(https?://download[^"]+)"'),
    re.compile(r'(https?://download\d+\.mediafire\.com/[^"\'<>\s]+)'),
)


def _resolve_mediafire(url, dest_dir, progress_cb, timeout):
    req = urllib.request.Request(url, headers={
        'User-Agent': _USER_AGENT,
        'Accept-Language': 'en-US,en;q=0.9',
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        html = r.read().decode('utf-8', errors='replace')

    if 'Invalid or Deleted File' in html or 'errorPageWrap' in html:
        raise FileNotFoundError('Archivo eliminado o clave inválida en MediaFire.')

    direct = None
    for rx in _MF_LINK_RES:
        m = rx.search(html)
        if m:
            direct = m.group(1)
            break
    if not direct:
        raise ValueError(
            'MediaFire no expuso enlace de descarga directa (¿layout cambió?). '
            'Comparte URL directa al archivo.',
        )

    suggested = os.path.basename(urllib.parse.urlparse(direct).path) or None
    with urllib.request.urlopen(
        urllib.request.Request(direct, headers={'User-Agent': _USER_AGENT}),
        timeout=timeout,
    ) as r:
        return _stream_to_disk(r, url, dest_dir, progress_cb,
                               suggested_name=suggested)


# Registro de resolvers, orden = prioridad. Cuando aparezca un host popular
# nuevo que el genérico no maneje, añadir aquí ~30-50 líneas más.
_SPECIFIC_RESOLVERS = (
    (_DRIVE_HOSTS, _resolve_drive),
    (_MEDIAFIRE_HOSTS, _resolve_mediafire),
)
