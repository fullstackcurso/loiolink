"""Diálogo post-transferencia: decide qué hacer según el tipo de archivo.

PRECONDICIÓN: llamar SOLO desde el main thread del service (consumer de
history.dequeue_event). NUNCA desde el thread del HTTP handler; Dialog
no es thread-safe en Kodi 19 (kodi#15378).

Tipos:
- video/audio  → ¿reproducir? con Player.Open JSON-RPC (PlayMedia tiene
                  bug con comas: kodi#14838).
- image        → ¿ver imagen? con ShowPicture builtin (única opción en
                  Kodi 19; comillas escapadas para mitigar).
- apk          → ¿instalar APK? (solo Android, incluido Fire TV; dispara
                  StartAndroidActivity sobre el package installer).
- addon_zip    → ¿instalar addon?
- repo_zip     → ¿instalar repositorio?
- torrent      → ¿reproducir con Elementum? Si no está, ofrecer instalar.
- other        → notificación de "archivo recibido".

El setting transfer.auto_action salta los diálogos y ejecuta la acción
directa para media (video/audio/image/torrent). Decisión 1.6 del ROADMAP.
NO aplica a APK/addon/repo: las instalaciones siempre piden confirmación
porque corren código nuevo en Kodi/Android y son vector de malware si un
dispositivo pareado se compromete.
"""
import threading

import xbmc
import xbmcaddon

from lib import accessibility, installer, log
from lib.transfers import history, ui_context
from lib.transfers.library_add import add_to_library
from lib.ui_select import SelectItem, confirm, info, select


# Heading contextual: identifica el origen del dialog cuando aparece fuera
# del addon (por upload del móvil, descarga remota, etc.).
HEADING_RECEIVED = 'loiolink: archivo recibido'
HEADING_TORRENT = 'loiolink: torrent recibido'
HEADING_INSTALL = 'loiolink: instalación'

_PLUGIN_URL = 'plugin://plugin.program.loiolink/'
# Prefijo sin slash final: Container.FolderPath unas veces incluye el slash
# y otras no según el contexto (root vs subruta). Comparar sin él evita
# ActivateWindow redundante cuando ya estamos dentro del addon.
_PLUGIN_PREFIX = 'plugin://plugin.program.loiolink'

# Timeouts del watcher de post-reproducción.
_WATCHER_START_TIMEOUT_S = 5.0   # max espera a que arranque el player
_WATCHER_END_GRACE_S = 1.0       # ventana tras stop para detectar cadena
_WATCHER_POLL_S = 0.5            # frecuencia de sondeo durante reproducción

# Watcher único de post-reproducción. Si llegan uploads encadenados, el
# primer watcher cubre toda la sesión y solo navega cuando termine el
# último vídeo (evita ActivateWindow redundante o flicker entre items).
_watcher_lock = threading.Lock()
_watcher_active = False


def _auto_action():
    try:
        return xbmcaddon.Addon().getSettingBool('transfer.auto_action')
    except RuntimeError:
        return False


def _platform_name():
    """Nombre legible del SO donde corre Kodi. Para mensajes al usuario
    cuando una acción depende de la plataforma (p.ej. APK necesita Android).
    """
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return 'Windows'
    if xbmc.getCondVisibility('System.Platform.OSX'):
        return 'macOS'
    if xbmc.getCondVisibility('System.Platform.IOS'):
        return 'iOS'
    if xbmc.getCondVisibility('System.Platform.Linux'):
        return 'Linux'
    return 'este sistema'


def _navigate_after_playback():
    """Espera a que termine la reproducción y vuelve al menú del addon.

    Sin esto, al terminar el vídeo Kodi vuelve al contenedor que había
    detrás del diálogo (inicio o favoritos de Kodi) en vez de al addon,
    porque el diálogo se muestra desde el service sin establecer un
    contexto de navegación de plugin.
    """
    global _watcher_active
    monitor = xbmc.Monitor()
    try:
        # Esperar arranque (Player.Open / Player.play() son async). Sondeo
        # cada 100ms hasta _WATCHER_START_TIMEOUT_S.
        for _ in range(max(1, int(_WATCHER_START_TIMEOUT_S * 10))):
            if monitor.abortRequested():
                return
            if xbmc.Player().isPlaying():
                break
            xbmc.sleep(100)
        else:
            return  # nunca arrancó

        # Esperar fin definitivo de la sesión. Si entre items hay un hueco
        # breve (cola, segundo upload encadenado) no navegar todavía:
        # solo cuando el player lleve _WATCHER_END_GRACE_S sin nada.
        while True:
            while xbmc.Player().isPlaying():
                if monitor.waitForAbort(_WATCHER_POLL_S):
                    return
            if monitor.waitForAbort(_WATCHER_END_GRACE_S):
                return
            if not xbmc.Player().isPlaying():
                break

        # Si Kodi ya está dentro del addon (usuario navegando o el back
        # automático ya cubrió el caso), no recargar el container raíz;
        # se perdería su posición.
        container = xbmc.getInfoLabel('Container.FolderPath') or ''
        if container.startswith(_PLUGIN_PREFIX):
            return

        xbmc.executebuiltin(f'ActivateWindow(Videos,{_PLUGIN_URL},return)')
    finally:
        with _watcher_lock:
            _watcher_active = False


def _spawn_post_play_watcher():
    global _watcher_active
    with _watcher_lock:
        if _watcher_active:
            return
        _watcher_active = True
    threading.Thread(
        target=_navigate_after_playback,
        name='loiolink-postplay-nav',
        daemon=True,
    ).start()


def _play_file(path, title=None, kind='video'):
    """Reproduce un archivo local usando xbmc.PlayList + xbmc.Player().play()
    con ListItem rico (vía `lib.remote.player.play_file`).

    Esto resuelve tres bugs a la vez:
    - Bug -32602: Player.Open JSON-RPC fallaba con paths con caracteres
      acentuados / paréntesis ("Lo de Évole - Temporada 7.mp4").
    - Spinner de "primera vez": al pasar metadata explícita en el ListItem,
      Kodi no intenta scrap → no aparece el BusyDialog del skin.
    - Cola sin encadenado: reproducir vía PlayList pone el item en la
      playlist activa, de modo que los items en cola encadenan al terminar.

    `title` viene del entry['name'] del historial (basename sanitizado).
    Si no se pasa, se deriva del basename del path.

    Lanza un watcher en thread daemon que al terminar la reproducción
    devuelve al addon (sin esto Kodi vuelve al contenedor previo al
    diálogo, que suele ser la pantalla de inicio o los favoritos de Kodi).
    """
    import os as _os
    if not title:
        title = _os.path.splitext(_os.path.basename(path))[0]
    from lib.remote import player as _player
    _player.play_file(path, title=title, kind=kind)
    _spawn_post_play_watcher()


def _stop_picture_player():
    """Para el picture player si está activo.

    ShowPicture no reinicia el player cuando ya hay uno abierto: solo
    actualiza la imagen actual. Si el player está en estado de error
    (p.ej. por un webp que no pudo decodificarse), las imágenes siguientes
    también fallan. Cerrarlo explícitamente fuerza un arranque limpio.
    """
    from lib.remote.rpc import call as _rpc
    players = _rpc('Player.GetActivePlayers').get('result', [])
    for p in players:
        if p.get('type') == 'picture':
            _rpc('Player.Stop', {'playerid': p['playerid']})
            xbmc.sleep(400)
            return


def _show_picture(path):
    # ShowPicture es la única opción en Kodi 19 para imágenes sueltas.
    # Escapamos comillas dobles (paths con quotes son raros pero existen).
    _stop_picture_player()
    escaped = path.replace('"', '\\"')
    xbmc.executebuiltin(f'ShowPicture("{escaped}")')


_MEDIA_ACTIONS = ('play', 'library', 'both', 'decline')


def _ask_media_action(name):
    items = [
        SelectItem('Reproducir ahora',
                   plot=f'{name}\n\nAbre el archivo en el reproductor de Kodi.'),
        SelectItem('Añadir a biblioteca',
                   plot=f'{name}\n\nMueve el archivo a una fuente de la biblioteca y lanza un escaneo.'),
        SelectItem('Reproducir y añadir a biblioteca',
                   plot=f'{name}\n\nReproducir ahora y también añadir a la biblioteca de Kodi.'),
        SelectItem('Más tarde',
                   plot=f'{name}\n\nEl archivo queda guardado en el historial.'),
    ]
    idx = select(HEADING_RECEIVED, items)
    return _MEDIA_ACTIONS[idx] if 0 <= idx < len(_MEDIA_ACTIONS) else 'decline'


_FORCED_MEDIA_ACTIONS = frozenset({'play', 'queue', 'library', 'both', 'decline'})


def _add_to_queue(path, title, kind):
    """Añade un archivo a la cola sin interrumpir lo que se está
    reproduciendo. Usado por la acción 'queue' del modal del panel
    (Bloque 2 del plan).

    `kind` ('video'|'audio') determina la playlist destino, NO el
    player activo. Sin esto, subir un vídeo mientras suena audio
    encolaría a la playlist de audio (id 0) y Kodi no lo reproduciría.

    Usa `add_local_to_queue` (no `add_to_queue`) porque el path es local,
    rechazado por la whitelist http-only de `add_to_queue`. El path viene
    de un upload del propio addon, trusted.

    Nota sobre concatenación: si el reproductor actual fue abierto con
    `Player.Open({item: {file: ...}})` (modo single-item, sin playlist),
    los items añadidos a la playlist NO se reproducen al terminar el
    actual; Kodi no los está "consumiendo". Para que la cola encadene,
    el primer item tendría que estar él mismo dentro de la playlist
    activa. Se notifica al usuario via Kodi notif cuando se detecta este
    caso, para que sepa por qué la cola no encadena."""
    from lib.remote import player as _p
    pid = _p._TYPE_TO_PLAYLISTID.get(kind, 1)
    try:
        _p.add_local_to_queue(pid, path)
    except Exception as e:
        log.warning(f'add_local_to_queue falló: {type(e).__name__}')
        log.sensitive(f'add_local_to_queue falló para {path!r}: {e}')
        return
    # Detectar si el reproductor actual está en modo single-item (sin
    # playlist); en cuyo caso el Add anterior va a una playlist que
    # nadie está consumiendo y no encadenará al terminar el actual.
    try:
        from lib.remote.rpc import call as _jsonrpc
        active = _jsonrpc('Player.GetActivePlayers').get('result', [])
        if active:
            pid_active = active[0].get('playerid')
            props = _jsonrpc(
                'Player.GetProperties',
                {'playerid': pid_active, 'properties': ['playlistid']},
            ).get('result', {})
            if props.get('playlistid', -1) < 0:
                log.warning(
                    'add_to_queue: reproducción en curso fuera de playlist; '
                    'el archivo encolado NO encadenará al terminar el actual')
                accessibility.notify(
                    f'{title or "archivo"} en cola (reproducción actual no '
                    'soporta encadenado)',
                    ms=4000, title=HEADING_RECEIVED,
                )
    except Exception as e:
        log.warning(f'add_to_queue: detección de modo playlist falló: {e}')


def _run_forced_action(entry, kind, action):
    """Ejecuta la acción que el usuario eligió en el panel del móvil.
    No muestra diálogo modal en TV; el usuario ya decidió.
    """
    if action == 'elementum':
        if kind != 'torrent':
            return
        from lib.actions import elementum as elementum_action
        from lib.remote import elementum as elementum_helper
        if not elementum_helper.is_installed():
            if elementum_action.install_with_progress():
                elementum_helper.play(entry['path'])
                history.update(entry['id'], action_taken='played_elementum')
            else:
                history.update(entry['id'], action_taken='declined')
        else:
            elementum_helper.play(entry['path'])
            history.update(entry['id'], action_taken='played_elementum')
        return

    if action == 'play' and kind == 'image':
        # ShowPicture es el único reproductor de imágenes en Kodi 19+;
        # no es _play_file ni va por Player.Open. Caso separado para no
        # contaminar la rama de video/audio
        _show_picture(entry['path'])
        history.update(entry['id'], action_taken='played')
        return

    if action not in _FORCED_MEDIA_ACTIONS:
        return
    if kind not in ('video', 'audio', 'hls_recording'):
        return
    # HLS recording es un .ts crudo de captura: encaja en play/queue (mismo
    # PlayMedia que cualquier vídeo) pero no en library/both (no es archivo de
    # catálogo). El frontend del historial no ofrece esos botones para
    # `kind='hls_recording'`, pero defensa en profundidad: un cliente con
    # sesión podría enviar `action='both'` por curl y add_to_library actuaría.
    # NO sobrescribimos action_taken: la grabación pudo terminar 'completed'
    # y marcarla 'declined' aquí pisaría su estado real. Solo log + return.
    if kind == 'hls_recording' and action in ('library', 'both'):
        log.info(
            f'_run_forced_action: action={action!r} no aplica a hls_recording; '
            'ignorada (action_taken preservado)',
        )
        return
    if action == 'play':
        _play_file(entry['path'], title=entry.get('name'), kind=kind)
        history.update(entry['id'], action_taken='played')
    elif action == 'queue':
        # Cola: añade sin interrumpir lo que esté reproduciendo. No
        # marca played; el archivo se reproducirá cuando termine el
        # actual (Kodi gestiona la playlist).
        _add_to_queue(entry['path'], entry.get('name', ''), kind)
        history.update(entry['id'], action_taken='queued')
    elif action == 'library':
        ok = add_to_library(entry) is not None
        history.update(
            entry['id'],
            action_taken='added_to_library' if ok else 'declined',
        )
    elif action == 'both':
        # Mover primero (file lock al reproducir el original; ver línea
        # similar más abajo en el flujo del diálogo).
        final_path = add_to_library(entry)
        _play_file(final_path or entry['path'], title=entry.get('name'))
        history.update(entry['id'], action_taken='played')
    elif action == 'decline':
        history.update(entry['id'], action_taken='declined')


def show_post_transfer_dialog(entry, already_played=False, forced_action=None,
                              force_confirm=False):
    assert threading.current_thread() is threading.main_thread(), (
        'show_post_transfer_dialog debe llamarse desde main thread '
        '(consumer del service), no desde un HTTP handler (kodi#15378).'
    )

    # force_confirm: la acción viene del botón "Instalar/Abrir" del panel web
    # (no de un upload). El usuario quiere confirmación explícita aunque tenga
    # transfer.auto_action activado (que está pensado para automatizar uploads,
    # no para que el panel web instale APKs/addons en silencio).
    auto = _auto_action() and not force_confirm
    kind = entry['kind']

    # forced_action: el usuario eligió en el banner del panel del móvil
    # tras un upload. Ejecutamos la acción sin diálogo modal en TV.
    if forced_action:
        _run_forced_action(entry, kind, forced_action)
        return

    # already_played: el handler del upload ya lanzó play_file (modo wait o
    # _on_first_write). No mostrar el diálogo de 4 opciones; el usuario ya
    # decidió reproducir. Solo notif discreta + marcar como played.
    if already_played and kind in ('video', 'audio'):
        history.update(entry['id'], action_taken='played')
        accessibility.notify(
            f"{entry['name']} (reproduciendo)",
            ms=2500, title=HEADING_RECEIVED,
        )
        return

    # Si hay reproducción activa, no interrumpir con modal. La entry queda
    # en el historial con action_taken=None ("pendiente") y el usuario
    # decide cuando vuelve al menú.
    use_notif = ui_context.should_use_notification() and not auto

    if use_notif and kind not in ('addon_zip', 'repo_zip'):
        # Para reproducir/ver, basta con notificación. ZIPs siempre dialog
        # (instalar requiere confirmación explícita).
        accessibility.notify(
            f"{entry['name']} (ver en Historial)",
            ms=3500, title=HEADING_RECEIVED,
        )
        return

    if kind in ('video', 'audio'):
        if auto:
            _play_file(entry['path'])
            history.update(entry['id'], action_taken='played')
        else:
            action = _ask_media_action(entry['name'])
            if action == 'play':
                _play_file(entry['path'])
                history.update(entry['id'], action_taken='played')
            elif action == 'library':
                ok = add_to_library(entry) is not None
                history.update(
                    entry['id'],
                    action_taken='added_to_library' if ok else 'declined',
                )
            elif action == 'both':
                # Mover primero para evitar file lock al reproducir el original
                # (Player.Open es async; si abrimos antes, delete falla en Windows).
                final_path = add_to_library(entry)
                _play_file(final_path or entry['path'])
                history.update(entry['id'], action_taken='played')
            elif action == 'decline':
                history.update(entry['id'], action_taken='declined')
        return

    if kind == 'image':
        if auto or confirm(f"{entry['name']}\n\n¿Ver imagen?",
                            title=HEADING_RECEIVED, default_no=False):
            _show_picture(entry['path'])
            history.update(entry['id'], action_taken='played')
        else:
            history.update(entry['id'], action_taken='declined')
        return

    if kind == 'torrent':
        # Importación diferida (elementum vive en lib/actions/; circular si
        # se importa al top con history que importa post_transfer).
        from lib.actions import elementum as elementum_action
        from lib.remote import elementum as elementum_helper

        if not elementum_helper.is_installed():
            msg = (f"{entry['name']}\n\n"
                   'Es un torrent. Elementum no está instalado.\n'
                   '¿Instalar Elementum ahora?')
            if confirm(msg, title=HEADING_TORRENT, default_no=False):
                elementum_action.run()
                if elementum_helper.is_installed():
                    elementum_helper.play(entry['path'])
                    history.update(entry['id'], action_taken='played_elementum')
                    return
            history.update(entry['id'], action_taken='declined')
            return

        if auto or confirm(
            f"{entry['name']}\n\n¿Reproducir torrent con Elementum?",
            title=HEADING_TORRENT, default_no=False,
        ):
            elementum_helper.play(entry['path'])
            history.update(entry['id'], action_taken='played_elementum')
        else:
            history.update(entry['id'], action_taken='declined')
        return

    if kind == 'apk':
        if not installer.is_android():
            # Diálogo modal en vez de notificación toast: el usuario llegó
            # aquí por una acción explícita (click en "Abrir" o aceptar el
            # upload), merece feedback bloqueante y claro sobre por qué no
            # aparece el instalador.
            info(
                f"{entry['name']}\n\n"
                'Este archivo es un instalador de Android (APK).\n\n'
                f'Estás ejecutando Kodi en {_platform_name()}, que no tiene '
                'instalador de APKs. Solo se pueden instalar en dispositivos '
                'con Android (Fire TV, Android TV, móviles, etc.).',
                title=HEADING_INSTALL,
            )
            return
        msg = (f"{entry['name']}\n\n"
               '¿Instalar este APK? Se abrirá el instalador de Android.\n\n'
               'Requiere activar la instalación de apps desconocidas '
               'en los Ajustes de Android.')
        # Instalaciones siempre piden confirmación. transfer.auto_action está
        # pensado para media (video/audio/image), no para ejecutables: una
        # APK no confirmada sería vector trivial para que un dispositivo
        # pareado comprometido instale malware.
        if not confirm(msg, title=HEADING_INSTALL, default_no=False):
            history.update(entry['id'], action_taken='declined')
            return
        try:
            public_path = installer.install_apk(entry['path'])
        except installer.InstallBusyError:
            accessibility.notify(
                'Ya hay una instalación en curso. Espera a que termine.',
                title=HEADING_INSTALL, ms=3500,
            )
            return
        except installer.InstallError as e:
            log.error(f'install_apk falló: {e}')
            info(
                f'No se pudo lanzar el instalador.\n\n{e}\n\n'
                + installer.HINT_ANDROID_PERMISSIONS,
                title=HEADING_INSTALL,
            )
            history.update(entry['id'], action_taken='install_failed')
            return
        history.update(entry['id'], action_taken='install_launched')
        # Fallback informativo: en Kodi 21- con Android 7+ el installer
        # puede fallar silenciosamente. Avisamos al usuario de dónde está
        # el APK por si tiene que abrirlo manualmente desde un gestor.
        accessibility.notify(
            f'APK preparado en {public_path}. Si el instalador no aparece, '
            f'ábrelo desde un gestor de archivos.',
            title=HEADING_INSTALL, ms=7000,
        )
        return

    if kind in ('addon_zip', 'repo_zip'):
        label = 'addon' if kind == 'addon_zip' else 'repositorio'
        msg = f"{entry['name']}\n\n¿Instalar {label} en Kodi?"
        # Misma razón que APK: instalar un addon/repo no confirmado es vector
        # de ejecución arbitraria (los addons corren código Python en Kodi).
        if not confirm(msg, title=HEADING_INSTALL, default_no=False):
            history.update(entry['id'], action_taken='declined')
            return
        try:
            ok = installer.install_zip(
                entry['path'], entry['addon_id'],
                kind='repo' if kind == 'repo_zip' else 'addon',
            )
        except installer.InstallBusyError:
            accessibility.notify(
                'Ya hay una instalación en curso. Espera a que termine.',
                title=HEADING_INSTALL, ms=3500,
            )
            return
        except installer.InstallError as e:
            log.error(f'InstallError: {e}')
            info(f'Error instalando: {e}', title=HEADING_INSTALL)
            history.update(entry['id'], action_taken='install_failed')
            return
        history.update(
            entry['id'],
            action_taken='installed' if ok else 'install_failed',
        )
        if ok:
            accessibility.notify(
                f"{entry['addon_id']} instalado.", title=HEADING_INSTALL,
            )
        else:
            info(
                f"Instalación de {entry['addon_id']} falló. Ver kodi.log.",
                title=HEADING_INSTALL,
            )
        return

    # unknown_zip / other
    accessibility.notify(entry['name'], title=HEADING_RECEIVED)
