"""MD5 + SHA-256 de archivos transferidos.

Se calculan tras la transferencia (en una pasada, ~200 MB/s en SSD moderno)
y se guardan en el historial. El visor del historial los muestra bajo
'Ver checksums'. Útiles para verificar integridad cuando alguien comparte
un archivo y dice "el hash es X".
"""
import hashlib


def compute_hashes(filepath, chunk=64 * 1024):
    """Calcula MD5 y SHA-256 en una sola pasada. Devuelve (md5, sha256)."""
    md5 = hashlib.md5()
    sha = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while True:
            data = f.read(chunk)
            if not data:
                break
            md5.update(data)
            sha.update(data)
    return md5.hexdigest(), sha.hexdigest()
