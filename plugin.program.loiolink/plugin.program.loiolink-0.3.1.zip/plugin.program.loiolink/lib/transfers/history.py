"""Historial de transferencias en JSON (decisión §1 del ROADMAP).

I/O via xbmcvfs.File + xbmcvfs.rename. open()/os.replace fallan con
PermissionError en Android 11+ sandboxed (Fire TV / Shield); xbmcvfs es
el wrapper que Kodi expone a Python y maneja eso transparentemente.

Lock: threading.Lock por proceso. Solo service.py escribe; default.py
(visor del historial) solo lee. No hay race entre procesos distintos
porque default.py es read-only.

Cola de eventos UI: el HTTP handler encola con queue_event() y el main
thread del service drena con dequeue_event(). NUNCA llamar Dialog desde
threads del handler (kodi#15378).
"""
import json
import queue
import threading
import time
import uuid

import xbmcgui
import xbmcvfs


_PROFILE_VFS = 'special://profile/addon_data/plugin.program.loiolink/'
_HISTORY_VFS = _PROFILE_VFS + 'history.json'
_HISTORY_TMP = _PROFILE_VFS + 'history.json.tmp'

_LOCK = threading.Lock()
_QUEUE = queue.Queue()

# Window property compartida entre intérpretes (plugin, service, otros addons)
# para que _history_label() del menú lea el count actualizado al instante,
# sin tener que esperar a un re-load del JSON. Indispensable para que el
# contador del menú principal se actualice sin cerrar/reabrir el addon.
_COUNT_PROP = 'loiolink.history.count'


def _publish_count(n):
    """Refleja el count actual en una Window property. Idempotente y barato.

    RuntimeError surge si Kodi todavía no ha inicializado xbmcgui (tests
    fuera del contexto Kodi); ignorarlo deja la fallback a disco intacta.
    """
    try:
        xbmcgui.Window(10000).setProperty(_COUNT_PROP, str(n))
    except RuntimeError:
        pass


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE_VFS):
        xbmcvfs.mkdirs(_PROFILE_VFS)


def _load():
    if not xbmcvfs.exists(_HISTORY_VFS):
        return []
    f = xbmcvfs.File(_HISTORY_VFS, 'r')
    try:
        raw = f.read()
    finally:
        f.close()
    if not raw:
        return []
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return []


def _save(entries):
    """Write atómico: escribir a .tmp + rename. xbmcvfs.rename es atómico
    dentro del mismo directorio en POSIX/Android; en Windows envuelve
    MoveFileExW con MOVEFILE_REPLACE_EXISTING.
    """
    _ensure_profile()
    data = json.dumps(entries, indent=2, ensure_ascii=False).encode('utf-8')
    f = xbmcvfs.File(_HISTORY_TMP, 'wb')
    try:
        ok = f.write(bytearray(data))
        if ok is False:
            raise OSError('xbmcvfs.write devolvió False')
    finally:
        f.close()
    # rename con overwrite: algunas builds de xbmcvfs.rename no sobrescriben.
    if xbmcvfs.exists(_HISTORY_VFS):
        xbmcvfs.delete(_HISTORY_VFS)
    xbmcvfs.rename(_HISTORY_TMP, _HISTORY_VFS)


def add(filepath, name, size, kind, addon_id=None, truncated=False,
        source='upload', action_taken=None):
    """Añade una entrada y la devuelve. Más recientes primero.

    `action_taken`: si ya conocemos la acción al crear (ej: handler
    upload disparó play_file en modo wait), pasarlo aquí evita un
    `history.add()` + `history.update()` posterior; operación no
    atómica que puede perder datos si el main thread del service
    procesa post_transfer en medio.
    """
    entry = {
        'id': uuid.uuid4().hex,
        'name': name,
        'path': filepath,
        'size': size,
        'kind': kind,
        'addon_id': addon_id,
        'truncated': truncated,
        'source': source,        # 'upload' | 'url' | 'aftvnews_code' | 'hls'
        'created_at': int(time.time()),
        'action_taken': action_taken,  # 'played' | 'installed' | 'declined' | None
        'sha256': None,          # rellenado por checksums on-demand
        'md5': None,
    }
    with _LOCK:
        entries = _load()
        entries.insert(0, entry)
        _save(entries)
        _publish_count(len(entries))
    return entry


def update(entry_id, **fields):
    with _LOCK:
        entries = _load()
        for e in entries:
            if e['id'] == entry_id:
                e.update(fields)
                break
        _save(entries)


def list_all():
    with _LOCK:
        return _load()


def get(entry_id):
    with _LOCK:
        for e in _load():
            if e['id'] == entry_id:
                return e
    return None


def delete(entry_id, remove_file=True):
    with _LOCK:
        entries = _load()
        for i, e in enumerate(entries):
            if e['id'] == entry_id:
                path = e.get('path')
                if remove_file and path and xbmcvfs.exists(path):
                    xbmcvfs.delete(path)
                entries.pop(i)
                break
        _save(entries)
        _publish_count(len(entries))


def queue_event(event):
    """Encola un evento UI (dialog, notificación) para el main thread del service.

    NUNCA llamar Dialog().yesno() desde el HTTP handler; encolar y dejar
    que service.py lo drene en su main thread (kodi#15378).
    """
    _QUEUE.put(event)


def dequeue_event(timeout=0.5):
    try:
        return _QUEUE.get(timeout=timeout)
    except queue.Empty:
        return None
