"""Helper compartido por download_url y download_code (Sec 2).

Descarga URL → clasifica → registra en historial → muestra el diálogo de
acción inline. La llamada al diálogo es segura aquí porque este módulo
corre en el main thread del proceso plugin (no en un HTTP handler).
"""
import os
import urllib.error

import xbmc
import xbmcgui

from lib import log
from lib.transfers import classifier, downloader, history, post_transfer, storage
from lib.ui_select import info


def download_and_register(url, source):
    """Descarga URL → historial → diálogo de acción. source: 'url' o 'aftvnews_code'.

    Muestra DialogProgress cancelable. Si el usuario cancela, borra el
    archivo parcial (cumple Sec 4 de UX: progress dialogs SIEMPRE cancelables).
    """
    try:
        dest_dir = storage.get_dest_dir()
    except storage.StorageError as e:
        info(f'Carpeta de destino no válida: {e}', title='loiolink')
        log.warning(f'download_and_register abortado: {e}')
        return

    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Descargando\n{url[:80]}')

    cancelled = {'v': False}

    def cb(done, total):
        if progress.iscanceled():
            cancelled['v'] = True
            raise InterruptedError('descarga cancelada por el usuario')
        if total:
            pct = int(done * 100 / total)
            progress.update(pct, f'{done // 1024} KB / {total // 1024} KB')
        else:
            progress.update(0, f'{done // 1024} KB')

    filepath = None
    try:
        filepath, name, size = downloader.download_url(url, dest_dir, cb)
    except InterruptedError:
        log.info('descarga cancelada por el usuario')
        return
    except (PermissionError, FileNotFoundError, ValueError,
            urllib.error.URLError, OSError) as e:
        progress.close()
        info(f'Descarga falló: {e}', title='loiolink')
        log.warning(f'download_url falló: {e}')
        return
    finally:
        progress.close()
        if cancelled['v'] and filepath:
            try:
                os.unlink(filepath)
            except OSError:
                pass

    kind, addon_id = classifier.classify(filepath)
    entry = history.add(
        filepath, name, size, kind, addon_id=addon_id, source=source,
    )
    post_transfer.show_post_transfer_dialog(entry)
    xbmc.executebuiltin('Container.Refresh')
