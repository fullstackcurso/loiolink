"""Resuelve códigos del shortener https://go.aftvnews.com/<CODE>.

Verificado empíricamente mayo 2026: el servicio sigue activo PERO tiene
anti-bot agresivo. La primera visita responde 200 y setea cookie PHPSESSID;
visitas siguientes sin cookie reciben 403. Por eso un cookie jar Python
compartido entre llamadas + UA Chrome real es OBLIGATORIO.

El HTML contiene la URL destino en dos sitios estables:
1. JS `window.location = "URL"`
2. <noscript><a href="URL">...</a></noscript> (fallback)
"""
import http.cookiejar
import re
import urllib.error
import urllib.parse
import urllib.request

from lib import network_config


_RE_JS = re.compile(r'window\.location\s*=\s*"(https?://[^"]+)"')
_RE_NOSCRIPT = re.compile(
    r'<noscript[^>]*>.*?<a[^>]*href="(https?://[^"]+)"', re.DOTALL,
)

_UA_BROWSER = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
)

# Cookie jar compartido por sesión Python.
_COOKIE_JAR = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(_COOKIE_JAR),
)
_OPENER.addheaders = [
    ('User-Agent', _UA_BROWSER),
    ('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
    ('Accept-Language', 'en-US,en;q=0.9'),
]


def resolve(code, timeout=None):
    """Devuelve la URL destino del código numérico.

    timeout en segundos; None → setting `network.timeout_download_s`.
    Lanza ValueError si el código no existe, no resuelve, o el HTML cambió.
    """
    code = str(code).strip().lstrip('0') or '0'
    if not code.isdigit():
        raise ValueError(f'Código no numérico: {code}')

    if timeout is None:
        timeout = network_config.get_timeout('download')

    url = f'https://go.aftvnews.com/{code}'
    try:
        with _OPENER.open(url, timeout=timeout) as r:
            html = r.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        if e.code == 403:
            raise ValueError(
                'aftvnews bloqueó la petición (anti-bot). '
                'Reintenta en unos segundos o usa la URL directa.',
            ) from e
        raise

    for rx in (_RE_JS, _RE_NOSCRIPT):
        m = rx.search(html)
        if m:
            return m.group(1)
    raise ValueError(
        f'Código {code} no resuelve a URL (¿no existe o HTML cambió?)',
    )
