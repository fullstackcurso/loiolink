"""Gestión de sesiones de upload chunked + resumibles.

El cliente parte el archivo en bloques de N MB y los sube uno a uno con
`POST /upload/chunk` (header Content-Range bytes start-end/total). Si la
conexión se cae, el cliente consulta `GET /upload/status?id=<sid>` y
reanuda desde el byte siguiente al último recibido. Al completar, el
cliente llama `POST /upload/finalize` que concatena chunks → archivo
final + fsync + history.add + cleanup del directorio de sesión.

Estructura en disco (special://profile/addon_data/.../upload_sessions/<sid>/):
- meta.json: {name, total_bytes, mime, created_at, received_bytes}
- chunk_NNNNNN: bloques numerados secuencialmente por offset/CHUNK_SIZE

Por qué chunks numerados en vez de un solo archivo con seeks:
- Recuperación más simple si un chunk falla (volver a pedirlo)
- No requiere truncate/sparse files (problemático en algunos FS)
- Cliente puede reenviar el mismo chunk sin corromper datos previos

TTL: `cleanup_stale(ttl_hours=24)` borra sesiones inactivas (sin
write_chunk hace 24h). Se invoca desde el cron del service.py.

Thread-safety: cada sesión tiene su propio lock (no se solapan distintas
sesiones del mismo usuario). El _SESSIONS dict global está protegido por
_REGISTRY_LOCK.
"""
import json
import os
import re
import threading
import time
import uuid

import xbmcvfs


_PROFILE_VFS = 'special://profile/addon_data/plugin.program.loiolink/'
_SESSIONS_DIR_VFS = _PROFILE_VFS + 'upload_sessions/'

# session_id es hex de 32 chars (uuid4().hex). Validar evita path traversal.
_SAFE_ID_RE = re.compile(r'^[a-f0-9]{32}$')

# Lock por sesión: se obtiene/crea bajo _REGISTRY_LOCK.
_REGISTRY_LOCK = threading.Lock()
_SESSION_LOCKS = {}   # session_id → threading.Lock


class UploadSessionError(Exception):
    pass


class SessionNotFound(UploadSessionError):
    pass


class InvalidRange(UploadSessionError):
    pass


def _session_dir(session_id):
    """VFS path del directorio de una sesión."""
    if not _SAFE_ID_RE.match(session_id):
        raise SessionNotFound(f'session_id inválido: {session_id!r}')
    return _SESSIONS_DIR_VFS + session_id + '/'


def _session_lock(session_id):
    """Obtiene (o crea) el lock para una sesión concreta."""
    with _REGISTRY_LOCK:
        lk = _SESSION_LOCKS.get(session_id)
        if lk is None:
            lk = threading.Lock()
            _SESSION_LOCKS[session_id] = lk
        return lk


def _ensure_sessions_dir():
    if not xbmcvfs.exists(_SESSIONS_DIR_VFS):
        xbmcvfs.mkdirs(_SESSIONS_DIR_VFS)


def _real_path(vfs_path):
    """Convierte special:// a path del filesystem real."""
    return xbmcvfs.translatePath(vfs_path)


def _load_meta(session_id):
    meta_vfs = _session_dir(session_id) + 'meta.json'
    if not xbmcvfs.exists(meta_vfs):
        raise SessionNotFound(session_id)
    f = xbmcvfs.File(meta_vfs, 'r')
    try:
        raw = f.read()
    finally:
        f.close()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        raise SessionNotFound(session_id)


def _save_meta(session_id, meta):
    meta_vfs = _session_dir(session_id) + 'meta.json'
    data = json.dumps(meta, ensure_ascii=False).encode('utf-8')
    f = xbmcvfs.File(meta_vfs, 'wb')
    try:
        f.write(bytearray(data))
    finally:
        f.close()


def create_session(name, total_bytes, mime=''):
    """Inicia una sesión nueva y devuelve su id."""
    if not name:
        raise ValueError('name vacío')
    try:
        total_bytes = int(total_bytes)
    except (TypeError, ValueError):
        raise ValueError(f'total_bytes inválido: {total_bytes!r}')
    if total_bytes <= 0:
        raise ValueError(f'total_bytes debe ser positivo: {total_bytes}')
    _ensure_sessions_dir()
    session_id = uuid.uuid4().hex
    xbmcvfs.mkdirs(_session_dir(session_id))
    _save_meta(session_id, {
        'name': name,
        'total_bytes': total_bytes,
        'mime': mime or '',
        'created_at': int(time.time()),
        'updated_at': int(time.time()),
        'received_bytes': 0,
    })
    return session_id


def get_status(session_id):
    """Devuelve {name, total_bytes, received_bytes, mime, created_at}."""
    meta = _load_meta(session_id)
    return dict(meta)


def write_chunk(session_id, offset, data):
    """Escribe un chunk en el offset indicado. Devuelve received_bytes total.

    El offset debe ser exactamente received_bytes actual; los chunks van
    en orden estricto. Permitir saltos invitaría a corrupción silenciosa
    o agujeros en el archivo final.
    Si offset == received_bytes - chunk_size (último chunk recibido pero
    cliente lo reintenta por desconocer si llegó), aceptamos idempotente
    sin doble-escribir.
    """
    with _session_lock(session_id):
        meta = _load_meta(session_id)
        received = int(meta.get('received_bytes', 0))
        total = int(meta.get('total_bytes', 0))
        n = len(data)
        if offset == received:
            # Caso normal: chunk en orden.
            pass
        elif offset < received and (offset + n) <= received:
            # Reintento idempotente del cliente; descartar silenciosamente.
            return received
        else:
            raise InvalidRange(
                f'offset {offset} != received {received}'
                f' (total={total}, chunk_n={n})')
        if received + n > total:
            raise InvalidRange(
                f'chunk excede total: {received}+{n} > {total}')

        # Escribir chunk al final del archivo destino (modo append-only
        # garantizado por el check de offset). Usamos xbmcvfs para compat
        # con Android/Fire TV.
        chunk_idx = received  # offset = chunk_idx en bytes
        chunk_name = f'chunk_{chunk_idx:016d}'
        chunk_vfs = _session_dir(session_id) + chunk_name
        f = xbmcvfs.File(chunk_vfs, 'wb')
        try:
            ok = f.write(bytearray(data))
            if ok is False:
                raise OSError('xbmcvfs.write devolvió False')
        finally:
            f.close()

        meta['received_bytes'] = received + n
        meta['updated_at'] = int(time.time())
        _save_meta(session_id, meta)
        return meta['received_bytes']


def is_complete(session_id):
    meta = _load_meta(session_id)
    return int(meta.get('received_bytes', 0)) >= int(meta.get('total_bytes', 0))


def finalize(session_id, dest_dir):
    """Concatena todos los chunks → archivo final en dest_dir, fsync, y
    limpia la sesión. Devuelve (filepath, name, total_bytes).

    `dest_dir`: ruta del filesystem real (no VFS) donde escribir el final.
    Reusa la reserva atómica de `storage.reserve_unique_path` para evitar
    colisiones con uploads previos del mismo nombre.
    """
    from lib.transfers import storage
    from lib.transfers.multipart_stream import _sanitize_filename
    with _session_lock(session_id):
        meta = _load_meta(session_id)
        if int(meta.get('received_bytes', 0)) < int(meta.get('total_bytes', 0)):
            raise UploadSessionError(
                f'sesión {session_id} incompleta: '
                f'{meta["received_bytes"]}/{meta["total_bytes"]}')

        name = _sanitize_filename(meta['name'])
        final_path = storage.reserve_unique_path(os.path.join(dest_dir, name))
        session_real = _real_path(_session_dir(session_id))

        # Listar chunks ordenados por nombre (offset numérico padded).
        chunk_names = sorted(
            n for n in os.listdir(session_real)
            if n.startswith('chunk_')
        )
        if not chunk_names:
            raise UploadSessionError(f'sesión {session_id} sin chunks')

        try:
            with open(final_path, 'wb') as out:
                for cn in chunk_names:
                    cpath = os.path.join(session_real, cn)
                    with open(cpath, 'rb') as cf:
                        while True:
                            block = cf.read(64 * 1024)
                            if not block:
                                break
                            out.write(block)
                try:
                    os.fsync(out.fileno())
                except OSError:
                    pass
        except OSError:
            try:
                os.remove(final_path)
            except OSError:
                pass
            raise

        # Cleanup: borrar chunks + meta + dir de sesión.
        _delete_session_dir(session_id)
        return final_path, name, int(meta['total_bytes'])


def cancel(session_id):
    """Borra todos los chunks + meta + directorio. Idempotente."""
    with _session_lock(session_id):
        _delete_session_dir(session_id)


def _delete_session_dir(session_id):
    sdir_vfs = _session_dir(session_id)
    sdir_real = _real_path(sdir_vfs)
    if not os.path.isdir(sdir_real):
        return
    try:
        for n in os.listdir(sdir_real):
            try:
                os.remove(os.path.join(sdir_real, n))
            except OSError:
                pass
        os.rmdir(sdir_real)
    except OSError:
        pass
    # Liberar el lock del registro.
    with _REGISTRY_LOCK:
        _SESSION_LOCKS.pop(session_id, None)


def list_sessions():
    """Devuelve lista de session_ids existentes (para diagnóstico/cleanup)."""
    _ensure_sessions_dir()
    sdir_real = _real_path(_SESSIONS_DIR_VFS)
    try:
        return [n for n in os.listdir(sdir_real)
                if _SAFE_ID_RE.match(n)
                and os.path.isdir(os.path.join(sdir_real, n))]
    except OSError:
        return []


def cleanup_stale(ttl_hours=24):
    """Borra sesiones sin actualización en `ttl_hours`. Devuelve nº borradas.

    Race con sesión activa: si entre el primer chequeo de `updated_at` y
    la decisión de borrar, `write_chunk` actualiza la sesión, no debemos
    borrarla. Por eso re-cargamos meta bajo el lock antes del cancel
    (double-check pattern).
    """
    cutoff = int(time.time()) - ttl_hours * 3600
    deleted = 0
    for sid in list_sessions():
        try:
            meta = _load_meta(sid)
        except SessionNotFound:
            # Sin meta válido: directorio huérfano.
            _delete_session_dir(sid)
            deleted += 1
            continue
        if int(meta.get('updated_at', meta.get('created_at', 0))) < cutoff:
            with _session_lock(sid):
                try:
                    meta2 = _load_meta(sid)
                except SessionNotFound:
                    continue   # ya borrado por otro thread
                if int(meta2.get('updated_at', meta2.get('created_at', 0))) < cutoff:
                    _delete_session_dir(sid)
                    deleted += 1
                # else: write_chunk concurrente la rejuveneció, dejarla.
    return deleted
