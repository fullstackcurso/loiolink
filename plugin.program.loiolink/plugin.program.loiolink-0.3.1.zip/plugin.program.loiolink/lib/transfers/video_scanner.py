"""Orquesta html_scanner regex + yt-dlp, fusiona resultados con dedup.

Estrategia:
1. SIEMPRE corre html_scanner.scan_page (incluye magnets/.torrent + 7
   extractores de vídeo).
2. Si yt-dlp está disponible (no-Android, instalado y verificado en cache):
   también corre yt-dlp para ampliar a sitios con JS dinámico que el regex
   no detecta.
3. Fusiona ambas listas (yt-dlp primero por tener mejor metadata),
   deduplica por URL exacta, respeta MAX_RESULTS.

Coste peor caso: ~30s (regex 10s + yt-dlp 60s típico para playlist). En
Android o sin yt-dlp: solo regex (~10s).
"""
from lib import log, ytdlp_resolver
from lib.transfers import html_scanner


_MAX_RESULTS = 50


def scan_videos(url, timeout=None):
    """Devuelve lista deduplicada de dicts vídeos+magnets+torrents.

    `timeout` aplica al regex scanner; yt-dlp tiene su propio timeout
    interno (60s). El caller que llame esto debe envolverlo en una UI
    no-bloqueante (DialogProgressBG) porque la operación puede tardar
    hasta ~70s en caso pésimo.
    """
    regex_results = []
    try:
        regex_results = html_scanner.scan_page(url, timeout=timeout)
    except Exception as e:
        log.warning(f'[video_scanner] html_scanner falló: {e!r}')

    ytdlp_results = []
    # is_installed() lee el cache → muy rápido (<50ms warm). Solo el cold
    # path puede tardar ~3-5s, pero ese coste ya lo asume el usuario al
    # invocar el escaneo.
    if ytdlp_resolver.is_installed():
        try:
            ytdlp_results = ytdlp_resolver.scan_videos(url)
        except Exception as e:
            log.warning(f'[video_scanner] yt-dlp falló: {e!r}')

    return _merge_dedup(ytdlp_results, regex_results)


def _merge_dedup(primary, secondary):
    """yt-dlp primero (mejor metadata), regex después (aporta magnets que
    yt-dlp NO devuelve nunca). Dedup por URL exacta.
    """
    seen = set()
    out = []
    for item in list(primary) + list(secondary):
        u = item.get('url', '')
        if not u or u in seen:
            continue
        seen.add(u)
        item.setdefault('kind', 'video')
        out.append(item)
        if len(out) >= _MAX_RESULTS:
            break
    return out
