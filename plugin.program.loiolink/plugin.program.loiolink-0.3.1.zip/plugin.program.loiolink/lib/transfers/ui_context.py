"""Decisión: ¿interrumpir al usuario con dialog o solo notificar?

N5 del plan de fixes: cuando termina una descarga / llega un archivo del
móvil, no siempre queremos interrumpir con un modal:

- Usuario está navegando menús de Kodi → dialog es OK (responde rápido).
- Usuario está viendo una peli/serie → notification discreta. El archivo
  queda en el historial; cuando termine, lo procesa desde ahí.

Setting `transfer.always_use_dialog` (bool, default false) fuerza dialog
incluso con player activo (para usuarios que prefieran no perderse nada).
"""
import xbmcaddon

from lib.remote.rpc import call as _jsonrpc


SETTING_FORCE_DIALOG = 'transfer.always_use_dialog'


def _force_dialog():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_FORCE_DIALOG)
    except RuntimeError:
        return False


def should_use_notification():
    """¿Hay un player activo (video o audio) y NO está pausado?

    Si sí → notification para no interrumpir. Si no → dialog OK.
    El setting `transfer.always_use_dialog` override la decisión a False.
    """
    if _force_dialog():
        return False

    players = _jsonrpc('Player.GetActivePlayers').get('result', [])
    for p in players:
        if p.get('type') in ('video', 'audio'):
            props = _jsonrpc('Player.GetProperties', {
                'playerid': p['playerid'],
                'properties': ['speed'],
            }).get('result', {})
            # Si está reproduciendo (speed != 0), interrumpirlo es molesto.
            if props.get('speed', 1) != 0:
                return True
            # Si está pausado, el usuario probablemente está navegando; dialog OK.
    return False
