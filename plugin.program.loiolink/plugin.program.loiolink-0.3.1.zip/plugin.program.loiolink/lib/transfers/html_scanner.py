"""Escáner HTML de vídeos embebidos.

Descarga el HTML de una página y extrae URLs de vídeo usando patrones
comunes: etiquetas HTML5 ``<video>`` / ``<source>``, meta Open Graph,
iframes de plataformas conocidas (YouTube, Dailymotion, Vimeo, Twitch,
Rumble, Odysee, VK, OK.ru, Rutube), datos estructurados JSON-LD,
fuentes declaradas en JavaScript inline (JWPlayer, Flowplayer) y
atributos ``data-*`` de carga diferida.

Funciona sin dependencias externas — solamente ``urllib`` y ``re`` de
la librería estándar — lo que permite ejecutarlo en cualquier
plataforma, incluido Android.

Portado de plugin.video.streamninja (mismo autor) bajo GPL-2.0-or-later.
"""
import html as _html
import json
import re
from urllib.parse import urljoin, urlparse
from urllib.request import urlopen, Request

from lib import log


_VIDEO_EXTENSIONS = frozenset((
    '.mp4', '.m3u8', '.webm', '.mkv', '.avi', '.mpd',
    '.ts', '.flv', '.mov', '.wmv', '.m3u',
))

_MAX_HTML_BYTES = 512 * 1024  # 512 KB: defensa contra páginas gigantes.
_MAX_RESULTS = 50
_HEAD_TIMEOUT = 4
_DOWNLOAD_TIMEOUT = 10

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
       'AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/131.0.0.0 Safari/537.36')

_TG_CHANNEL_RE = re.compile(
    r'^https?://t\.me/(?!s/)([a-zA-Z][a-zA-Z0-9_]{3,})/?$', re.I
)

_KNOWN_VIDEO_DOMAINS = frozenset((
    'youtube.com', 'youtu.be', 'twitch.tv', 'vimeo.com',
    'dailymotion.com', 'dai.ly', 'rumble.com', 'odysee.com',
    'soundcloud.com',
))


# API pública


def scan_page(url, timeout=None):
    """Descarga *url* y devuelve los vídeos detectados en el HTML.

    Args:
        url:     Dirección de la página a analizar.
        timeout: Segundos máximos para la descarga del HTML.

    Returns:
        Lista de dicts con claves ``title``, ``url``, ``filesize``
        (int o None) y ``ext``. Lista vacía si no se encuentra nada o
        si la descarga falla.
    """
    if timeout is None:
        timeout = _DOWNLOAD_TIMEOUT

    url = _normalize_telegram_url(url)
    html = _download_html(url, timeout)
    if not html:
        return []

    seen = set()
    results = []

    extractors = (
        _extract_telegram_links,
        _extract_og_videos,
        _extract_html5_videos,
        _extract_jsonld_videos,
        _extract_iframes,
        _extract_js_sources,
        _extract_data_attrs,
        _extract_direct_urls,
        _extract_magnets_torrents,
    )

    for extract in extractors:
        for entry in extract(html, url):
            video_url = entry.get('url', '')
            if not video_url or video_url in seen:
                continue
            seen.add(video_url)
            results.append(entry)
            if len(results) >= _MAX_RESULTS:
                return results

    # Tamaño on-demand para los que tengan extensión directa de vídeo.
    # Iframes/plataformas no devuelven Content-Length útil aquí.
    for entry in results:
        if entry.get('filesize') is None and _has_video_extension(entry['url']):
            entry['filesize'] = _get_filesize(entry['url'])

    return results


def format_size(byte_count):
    """Convierte bytes a formato legible (``1.2 GB``, ``340 MB``, …).

    Devuelve cadena vacía si *byte_count* es ``None`` o negativo.
    """
    if byte_count is None or byte_count < 0:
        return ''
    if byte_count == 0:
        return '0 B'

    units = ('B', 'KB', 'MB', 'GB', 'TB')
    size = float(byte_count)
    for unit in units:
        if size < 1024.0:
            if unit == 'B':
                return f'{size:.0f} {unit}'
            return f'{size:.1f} {unit}'
        size /= 1024.0
    return f'{size:.1f} PB'


def format_duration(seconds):
    """Convierte segundos a ``HH:MM:SS`` o ``MM:SS``.

    Devuelve cadena vacía si *seconds* es ``None`` o negativo.
    """
    if seconds is None or seconds < 0:
        return ''
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f'{h:02d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'


# Descarga


_ACCEPTED_TYPES = ('text/html', 'text/xml', 'application/xhtml+xml',
                   'application/xml')


def _normalize_telegram_url(url):
    """https://t.me/canal → https://t.me/s/canal (vista web pública de canal)."""
    if not isinstance(url, str):
        return url
    m = _TG_CHANNEL_RE.match(url)
    if m:
        return f'https://t.me/s/{m.group(1)}'
    return url


def _download_html(url, timeout):
    """Descarga los primeros bytes del HTML de *url*."""
    try:
        req = Request(url, headers={'User-Agent': _UA})
        with urlopen(req, timeout=timeout) as resp:
            content_type = resp.headers.get('Content-Type', '')
            if not any(ct in content_type for ct in _ACCEPTED_TYPES):
                log.debug(f'[scanner] Content-Type no soportado: {content_type}')
                return ''
            raw = resp.read(_MAX_HTML_BYTES)
        return raw.decode('utf-8', errors='replace')
    except Exception as exc:
        log.debug(f'[scanner] error descargando {url}: {exc!r}')
        return ''


# Extractores


def _extract_og_videos(html, base_url):
    """Extrae URLs de vídeo desde meta tags ``og:video``."""
    results = []
    pattern = re.compile(
        r'<meta\s+[^>]*?(?:property|name)=["\']og:video(?::url)?["\']'
        r'[^>]*?content=["\']([^"\']+)',
        re.I,
    )
    pattern_rev = re.compile(
        r'<meta\s+[^>]*?content=["\']([^"\']+)["\']'
        r'[^>]*?(?:property|name)=["\']og:video(?::url)?["\']',
        re.I,
    )
    og_title = _extract_meta_content(html, 'og:title') or ''

    urls_found = set()
    for m in pattern.finditer(html):
        urls_found.add(m.group(1).strip())
    for m in pattern_rev.finditer(html):
        urls_found.add(m.group(1).strip())

    for video_url in urls_found:
        video_url = urljoin(base_url, video_url)
        results.append({
            'title': og_title or _title_from_url(video_url),
            'url': video_url,
            'filesize': None,
            'ext': _get_extension(video_url),
        })
    return results


def _extract_html5_videos(html, base_url):
    """Extrae URLs desde ``<video>`` y ``<source>`` HTML5."""
    results = []

    # <video src="..."> y <video data-src="...">.
    # El contexto semántico de <video> basta para incluir la URL aunque
    # no tenga extensión reconocida (CDNs con rutas opacas).
    video_src_re = re.compile(
        r'<video\s[^>]*?(?:data-src|src)=["\']([^"\']+)', re.I,
    )
    for m in video_src_re.finditer(html):
        src = urljoin(base_url, m.group(1).strip())
        results.append({
            'title': _title_from_url(src),
            'url': src,
            'filesize': None,
            'ext': _get_extension(src),
        })

    # <source src="..." type="video/...">.
    source_re = re.compile(r'<source\s([^>]+)', re.I)
    for m in source_re.finditer(html):
        attrs = m.group(1)
        src_m = re.search(r'(?:data-src|src)=["\']([^"\']+)', attrs)
        if not src_m:
            continue
        src = urljoin(base_url, src_m.group(1).strip())
        has_video_type = bool(re.search(r'type=["\']video/', attrs, re.I))
        if not _has_video_extension(src) and not has_video_type:
            continue
        results.append({
            'title': _title_from_url(src),
            'url': src,
            'filesize': None,
            'ext': _get_extension(src),
        })

    return results


def _extract_iframes(html, base_url):
    """Extrae vídeos embebidos en iframes de plataformas conocidas."""
    results = []
    iframe_re = re.compile(r'<iframe\s[^>]*?src=["\']([^"\']+)', re.I)

    for m in iframe_re.finditer(html):
        src = m.group(1).strip()

        # YouTube embed (estándar y nocookie).
        yt = re.search(
            r'youtube(?:-nocookie)?\.com/embed/([a-zA-Z0-9_-]+)', src,
        )
        if yt:
            vid = yt.group(1)
            results.append({
                'title': f'YouTube: {vid}',
                'url': f'https://www.youtube.com/watch?v={vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Dailymotion embed.
        dm = re.search(r'dailymotion\.com/embed/video/([a-zA-Z0-9]+)', src)
        if dm:
            vid = dm.group(1)
            results.append({
                'title': f'Dailymotion: {vid}',
                'url': f'https://www.dailymotion.com/video/{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Vimeo embed.
        vm = re.search(r'player\.vimeo\.com/video/(\d+)', src)
        if vm:
            vid = vm.group(1)
            results.append({
                'title': f'Vimeo: {vid}',
                'url': f'https://vimeo.com/{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Twitch canal.
        tw = re.search(
            r'player\.twitch\.tv/\?[^"\']*?channel=([a-zA-Z0-9_]+)', src,
        )
        if tw:
            channel = tw.group(1)
            results.append({
                'title': f'Twitch: {channel}',
                'url': f'https://www.twitch.tv/{channel}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Twitch clip.
        tc = re.search(
            r'clips\.twitch\.tv/embed\?[^"\']*?clip=([a-zA-Z0-9_-]+)', src,
        )
        if tc:
            clip_id = tc.group(1)
            results.append({
                'title': f'Twitch Clip: {clip_id}',
                'url': f'https://clips.twitch.tv/{clip_id}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Rumble embed.
        rb = re.search(r'rumble\.com/embed/([a-zA-Z0-9]+)', src)
        if rb:
            vid = rb.group(1)
            results.append({
                'title': f'Rumble: {vid}',
                'url': f'https://rumble.com/embed/{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Odysee embed.
        od = re.search(r'odysee\.com/\$/embed/([^"\'?#]+)', src)
        if od:
            slug = od.group(1).rstrip('/')
            results.append({
                'title': f'Odysee: {slug}',
                'url': f'https://odysee.com/{slug}',
                'filesize': None,
                'ext': '',
            })
            continue

        # VK video embed.
        vk = re.search(
            r'vk\.com/video_ext\.php\?[^"\']*?oid=(-?\d+)[^"\']*?id=(\d+)',
            src,
        )
        if vk:
            oid, vid = vk.group(1), vk.group(2)
            results.append({
                'title': f'VK: {oid}_{vid}',
                'url': f'https://vk.com/video{oid}_{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # OK.ru embed.
        ok = re.search(r'ok\.ru/videoembed/(\d+)', src)
        if ok:
            vid = ok.group(1)
            results.append({
                'title': f'OK.ru: {vid}',
                'url': f'https://ok.ru/video/{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Rutube embed.
        rt = re.search(
            r'rutube\.ru/(?:play/embed|embed)/([a-f0-9]+)', src, re.I,
        )
        if rt:
            vid = rt.group(1)
            results.append({
                'title': f'Rutube: {vid}',
                'url': f'https://rutube.ru/video/{vid}',
                'filesize': None,
                'ext': '',
            })
            continue

        # Iframe genérico con URL de vídeo directa.
        if _has_video_extension(src):
            abs_src = urljoin(base_url, src)
            results.append({
                'title': _title_from_url(abs_src),
                'url': abs_src,
                'filesize': None,
                'ext': _get_extension(abs_src),
            })

    return results


def _extract_direct_urls(html, base_url):
    """Busca URLs con extensiones de vídeo en el HTML."""
    results = []

    anchor_map = _build_anchor_map(
        html, predicate=lambda h: h.lower().startswith(('http://', 'https://')),
    )

    url_re = re.compile(
        r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv))'
        r'(?:[?#][^\s"\'<>]*)?',
        re.I,
    )

    for m in url_re.finditer(html):
        raw = m.group(0).strip()
        # Limpia paréntesis de cierre que se cuelan en HTML cargado por JS.
        raw = raw.rstrip(')')
        results.append({
            'title': anchor_map.get(raw) or _title_from_url(raw),
            'url': raw,
            'filesize': None,
            'ext': _get_extension(raw),
        })

    return results


_MAGNET_RE = re.compile(
    r'(?:href|data-magnet|data-url)\s*=\s*["\'](magnet:\?[^"\']+)["\']',
    re.I,
)
_TORRENT_RE = re.compile(
    r'(?:href|src|data-url)\s*=\s*["\']'
    r'((?:https?:)?(?://|/)?[^"\'\s<>]+\.torrent(?:[?#][^"\'\s<>]*)?)["\']',
    re.I,
)
_ACESTREAM_RE = re.compile(
    # Captura ocurrencias en CUALQUIER posición del HTML, no solo en atributos:
    # los acestream en foros/posts se publican habitualmente como texto plano
    # ("acestream://abc...") no envueltos en <a href>. La negative lookahead
    # `(?![a-fA-F0-9])` evita que un hash de 41+ chars se trunque a un ID
    # inválido al matchear solo los primeros 40.
    r'acestream://([a-fA-F0-9]{40})(?![a-fA-F0-9])',
    re.I,
)


def _magnet_display_name(magnet):
    """Extrae el `dn=` (display name) del magnet URI; '' si no existe."""
    m = re.search(r'[?&]dn=([^&]+)', magnet)
    if not m:
        return ''
    try:
        from urllib.parse import unquote_plus
        return unquote_plus(m.group(1))[:120]
    except ValueError:
        return ''


def _torrent_display_name(torrent_url):
    """Nombre del archivo sin extensión, derivado del path."""
    try:
        path = urlparse(torrent_url).path
        name = path.rsplit('/', 1)[-1]
        if name.lower().endswith('.torrent'):
            name = name[:-len('.torrent')]
        return name[:120]
    except ValueError:
        return ''


def _extract_magnets_torrents(html, base_url):
    """Extrae enlaces magnet:, URLs a .torrent y acestream:// embebidos.

    Marca el resultado con `kind='magnet'`, `kind='torrent'` o
    `kind='acestream'` para que el caller los despache correctamente.

    Defensa: el regex acepta href relativos (`/dl/x.torrent`); `urljoin`
    resuelve contra `base_url`. Si tras resolver no es http(s), se descarta
    (no queremos `file://` ni schemes raros).
    """
    results = []

    magnet_anchor_map = _build_anchor_map(
        html, predicate=lambda h: h.lower().startswith('magnet:?'),
    )
    torrent_anchor_map = _build_anchor_map(
        html, predicate=lambda h: '.torrent' in h.lower(),
    )

    for m in _MAGNET_RE.finditer(html):
        magnet = m.group(1)
        if 'xt=' not in magnet:
            # magnets sin info-hash no son procesables; descartar para
            # evitar contaminar la lista con basura cosmética.
            continue
        title = _magnet_display_name(magnet) or magnet_anchor_map.get(magnet, '') or 'Magnet'
        results.append({
            'url': magnet,
            'title': title,
            'filesize': None,
            'ext': '',
            'kind': 'magnet',
        })

    for m in _TORRENT_RE.finditer(html):
        raw = m.group(1)
        resolved = urljoin(base_url, raw)
        if not resolved.lower().startswith(('http://', 'https://')):
            continue
        title = _torrent_display_name(resolved) or torrent_anchor_map.get(raw, '') or '.torrent'
        results.append({
            'url': resolved,
            'title': title,
            'filesize': None,
            'ext': 'torrent',
            'kind': 'torrent',
        })

    # Dedup local por hash normalizado a lowercase: una misma página suele
    # repetir el ID en varios botones (`href`, copy-to-clipboard, texto
    # plano). `_merge_dedup` del video_scanner también dedupea, pero
    # quitarlo aquí dejaría la lista local con duplicados antes del merge.
    seen_ace = set()
    for m in _ACESTREAM_RE.finditer(html):
        hash_id = m.group(1).lower()
        if hash_id in seen_ace:
            continue
        seen_ace.add(hash_id)
        results.append({
            'url': f'acestream://{hash_id}',
            'title': f'Acestream {hash_id[:8]}...',
            'filesize': None,
            'ext': '',
            'kind': 'acestream',
        })

    return results


def _extract_telegram_links(html, base_url):
    """Extrae URLs reproducibles de mensajes en un canal público t.me/s/."""
    if 'tgme_widget_message' not in html:
        return []

    results = []
    msg_re = re.compile(
        r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</div>',
        re.I | re.S,
    )
    anchor_re = re.compile(
        r'<a\b[^>]*?href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
        re.I | re.S,
    )
    plain_url_re = re.compile(r'(?:https?://|magnet:\?|acestream://)[^\s<>"\']+', re.I)

    seen = set()
    for msg_m in msg_re.finditer(html):
        block = msg_m.group(1)
        for m in anchor_re.finditer(block):
            u = m.group(1).strip()
            if u and u not in seen and _is_playable_url(u):
                seen.add(u)
                text = _clean_anchor_text(m.group(2))
                results.append({
                    'title': text or _title_from_url(u),
                    'url': u,
                    'filesize': None,
                    'ext': _get_extension(u),
                })
        for m in plain_url_re.finditer(re.sub(r'<[^>]+>', ' ', block)):
            u = m.group(0).strip().rstrip('.,;)')
            if u and u not in seen and _is_playable_url(u):
                seen.add(u)
                results.append({
                    'title': _title_from_url(u),
                    'url': u,
                    'filesize': None,
                    'ext': _get_extension(u),
                })
    return results


def _extract_jsonld_videos(html, base_url):
    """Extrae vídeos desde datos estructurados JSON-LD (schema.org)."""
    results = []
    for m in re.finditer(
        r'<script\s+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S,
    ):
        try:
            data = json.loads(m.group(1))
        except (json.JSONDecodeError, ValueError):
            continue

        videos = data if isinstance(data, list) else [data] if isinstance(data, dict) else []

        for item in videos:
            if not isinstance(item, dict):
                continue
            vtype = item.get('@type', '')
            if vtype not in ('VideoObject', 'Video'):
                continue
            content_url = item.get('contentUrl') or item.get('embedUrl') or ''
            if not content_url:
                continue
            content_url = urljoin(base_url, content_url)
            title = item.get('name') or _title_from_url(content_url)
            seconds = _parse_iso_duration(item.get('duration') or '')
            results.append({
                'title': title,
                'url': content_url,
                'filesize': None,
                'ext': _get_extension(content_url),
                'duration': seconds,
            })

    return results


def _extract_js_sources(html, base_url):
    """Extrae URLs de vídeo embebidas en bloques JavaScript.

    Cubre reproductores como JWPlayer y Flowplayer que declaran sus
    fuentes con patrones del tipo ``"file":"url"`` o ``"src":"url"``
    dentro de ``<script>``.
    """
    results = []
    js_keys = r'file|src|source|url|video_url|mp4_url|hls'
    js_exts = r'mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv'
    js_re = re.compile(
        r'["\'](?:' + js_keys + r')["\']\s*:\s*'
        r'["\'](https?://[^"\']+\.(?:' + js_exts + r')'
        r'(?:[?#][^"\']*)?)\s*["\']',
        re.I,
    )
    for m in js_re.finditer(html):
        video_url = m.group(1).strip()
        results.append({
            'title': _title_from_url(video_url),
            'url': video_url,
            'filesize': None,
            'ext': _get_extension(video_url),
        })

    return results


def _extract_data_attrs(html, base_url):
    """Extrae URLs de vídeo desde atributos ``data-*`` en elementos HTML.

    Muchas webs usan lazy-loading o configuraciones de reproductor
    almacenadas en atributos ``data-src``, ``data-video-url``, etc.
    """
    results = []
    data_re = re.compile(
        r'data-(?:src|video-url|video|file|stream|hls)\s*=\s*'
        r'["\']([^"\']+)',
        re.I,
    )
    for m in data_re.finditer(html):
        url = m.group(1).strip()
        if not _has_video_extension(url):
            continue
        abs_url = urljoin(base_url, url)
        results.append({
            'title': _title_from_url(abs_url),
            'url': abs_url,
            'filesize': None,
            'ext': _get_extension(abs_url),
        })

    return results


# Utilidades internas


def _extract_meta_content(html, prop):
    """Devuelve el valor ``content`` de un meta tag ``property=prop``."""
    m = re.search(
        r'<meta\s+[^>]*?(?:property|name)=["\']' + re.escape(prop)
        + r'["\'][^>]*?content=["\']([^"\']+)',
        html, re.I,
    )
    if not m:
        m = re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\']'
            r'[^>]*?(?:property|name)=["\']' + re.escape(prop) + r'["\']',
            html, re.I,
        )
    return m.group(1).strip() if m else None


def _has_video_extension(url):
    """Comprueba si la URL tiene una extensión de vídeo conocida."""
    try:
        path = urlparse(url).path.lower()
    except (ValueError, AttributeError):
        return False
    return any(path.endswith(ext) for ext in _VIDEO_EXTENSIONS)


def _is_playable_url(url):
    """True si la URL es reproducible: magnet, acestream, extensión de vídeo o dominio conocido."""
    if url.startswith(('magnet:', 'acestream://')):
        return True
    if _has_video_extension(url):
        return True
    try:
        host = urlparse(url).netloc.lower()
        if host.startswith('www.'):
            host = host[4:]
        return any(host == d or host.endswith('.' + d) for d in _KNOWN_VIDEO_DOMAINS)
    except (ValueError, AttributeError):
        return False


def _get_extension(url):
    """Devuelve la extensión de vídeo de la URL, sin el punto."""
    try:
        path = urlparse(url).path.lower()
    except (ValueError, AttributeError):
        return ''
    for ext in _VIDEO_EXTENSIONS:
        if path.endswith(ext):
            return ext.lstrip('.')
    return ''


def _title_from_url(url):
    """Genera un título legible a partir de la URL."""
    try:
        path = urlparse(url).path
    except (ValueError, AttributeError):
        return url[:80]
    name = path.rstrip('/').rsplit('/', 1)[-1]
    if '.' in name:
        name = name.rsplit('.', 1)[0]
    name = name.replace('-', ' ').replace('_', ' ')
    return name[:80] if name else url[:80]


def _clean_anchor_text(raw):
    """Texto visible de un elemento <a>, limpio y acotado; '' si no es útil."""
    text = re.sub(r'<[^>]+>', ' ', raw)
    text = _html.unescape(text)
    text = ' '.join(text.split())
    if not text or text.lower().startswith(('http://', 'https://', 'magnet:', 'acestream://')):
        return ''
    return text[:80]


_ANCHOR_HREF_RE = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)


def _build_anchor_map(html, predicate=None):
    """Mapea href→texto del ancla escaneando con str.find (sin backtracking).

    `predicate(href)` opcional filtra qué hrefs incluir. First-occurrence wins:
    si la misma URL aparece en varios `<a>`, gana la primera (suele ser el
    título principal).

    Por qué no regex `(.*?)</a>`: HTML real con muchos `<a` sin cerrar provoca
    backtracking O(n²) (1000 tags = ~2s; 10000 = >60s). `str.find` es O(n).
    """
    out = {}
    n = len(html)
    if n == 0:
        return out
    # Buscamos posiciones en lowercase para soportar `<A HREF>` (HTML5 es
    # case-insensitive en nombres de tag); extraemos contenido del original.
    hl = html.lower()
    i = 0
    while i < n:
        open_pos = hl.find('<a', i)
        if open_pos < 0:
            break
        # Bordeamos: <a debe ir seguido de espacio/tab/newline (no <abbr>, <area>).
        if open_pos + 2 < n and not hl[open_pos + 2].isspace():
            i = open_pos + 2
            continue
        gt = hl.find('>', open_pos)
        if gt < 0:
            break
        close = hl.find('</a>', gt + 1)
        if close < 0:
            i = gt + 1
            continue
        href_m = _ANCHOR_HREF_RE.search(html, open_pos, gt)
        if href_m:
            href = href_m.group(1).strip()
            if not predicate or predicate(href):
                if href not in out:
                    text = _clean_anchor_text(html[gt + 1:close])
                    if text:
                        out[href] = text
        i = close + 4
    return out


def _get_filesize(url):
    """Obtiene el tamaño del archivo mediante petición HEAD.

    Devuelve el número de bytes (int) o ``None`` si no se pudo obtener.
    """
    try:
        req = Request(url, method='HEAD', headers={'User-Agent': _UA})
        with urlopen(req, timeout=_HEAD_TIMEOUT) as resp:
            cl = resp.headers.get('Content-Length')
            if cl and cl.isdigit():
                return int(cl)
    except Exception:
        return None
    return None


def _parse_iso_duration(iso):
    """Convierte duración ISO 8601 (``PT1H30M15S``) a segundos.

    Devuelve ``None`` si el formato no es reconocido.
    """
    if not iso:
        return None
    m = re.match(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$', iso, re.I)
    if not m:
        return None
    hours = int(m.group(1) or 0)
    mins = int(m.group(2) or 0)
    secs = int(m.group(3) or 0)
    total = hours * 3600 + mins * 60 + secs
    return total if total > 0 else None
