"""Punto de entrada único para arrancar grabaciones HLS.

Este módulo centraliza la lógica de validación + creación de recorder
que antes vivía dentro del handler HTTP ``_handle_hls_start`` en
``lib/remote/server_permanent.py``. Lo extrajimos para que el scheduler
de grabaciones programadas reutilice exactamente la misma lógica (mismos
límites de concurrencia, mismas validaciones de disco, mismo formato de
historial) y para poder testearlo sin levantar un servidor HTTP.

Contrato: ``start_recording_now(params, origin)`` devuelve siempre un
``dict`` y nunca propaga excepciones. El caller (handler HTTP o scheduler)
decide cómo notificar el resultado.

El handler HTTP es ahora un wrapper fino: parsea el body, llama a esta
función y serializa el resultado en JSON. El scheduler llama la función
directamente cuando una grabación programada llega a su hora.
"""
import os
import shutil
import urllib.parse
from typing import Dict

import xbmcaddon

from lib import log


# Códigos de error devueltos en el dict. Mapeo a HTTP status (cuando el
# caller es el handler) lo hace el wrapper.
ERROR_DISABLED = 'hls_disabled'
ERROR_MISSING_URL = 'missing_url'
ERROR_INVALID_SCHEME = 'invalid_scheme'
ERROR_DEST_UNAVAILABLE = 'dest_unavailable'
ERROR_LOW_DISK = 'low_disk_space'
ERROR_RESERVE = 'reserve_failed'
ERROR_TOO_MANY = 'too_many_active'
ERROR_START_FAILED = 'start_failed'


def validate_url(url: str):
    """Valida que `url` sea http/https y no esté vacía.

    Devuelve ``(True, '')`` o ``(False, error_code)``. Misma normalización
    que el handler antiguo (strip + lower del scheme).

    Rechazo del formato Kodi `URL|Header=Value`: el grabador (ni TS via
    urllib ni compress via FFmpeg `-i`) procesa esos pipe-headers hoy. Si
    los aceptáramos silenciosamente, FFmpeg trataría el `|...` como parte
    de la URL y el upstream respondería 4xx, dando un fallo opaco. Mejor
    rechazar antes con un código semántico.
    """
    if not url or not url.strip():
        return False, ERROR_MISSING_URL
    u = url.strip()
    if '|' in u:
        return False, ERROR_INVALID_SCHEME
    scheme = urllib.parse.urlparse(u).scheme.lower()
    if scheme not in ('http', 'https'):
        return False, ERROR_INVALID_SCHEME
    return True, ''


def _get_setting_bool(key: str, default: bool) -> bool:
    try:
        return xbmcaddon.Addon().getSettingBool(key)
    except (TypeError, RuntimeError):
        return default


def _get_setting_int(key: str, default: int) -> int:
    try:
        return xbmcaddon.Addon().getSettingInt(key) or default
    except (TypeError, RuntimeError):
        return default


def start_recording_now(params: Dict, origin: str = 'api') -> Dict:
    """Arranca una grabación HLS aplicando todas las validaciones.

    ``params``: dict con keys
        url            (str, requerido)
        quality        (int, default 0) bandwidth máximo en bps
        max_duration_mins (int, default 0=usa setting; 0 efectivo=ilimitado)
        filename       (str, opcional) nombre sugerido
        name           (str, opcional) etiqueta legible
        compress       (bool, opcional) si None usa setting
        compress_crf   (int, opcional) si None usa setting

    ``origin``: 'api' | 'scheduler' (solo para logging).

    Devuelve un dict con forma:
        {'ok': True, 'recording_id', 'history_entry_id', 'output_file'}
      o
        {'ok': False, 'error': <ERROR_*>, 'detail'?, 'free_mb'?, 'required_mb'?, 'limit'?}
    """
    # Imports diferidos: estos módulos importan xbmc* y al cargarse arrastran
    # mocks pesados en tests. Mantenemos la carga del módulo barata.
    from lib.remote.server_permanent import _sanitize_filename
    from lib.transfers import hls_recorder, history, storage

    # 1. Toggle global del addon.
    if not _get_setting_bool('transfer.hls.enabled', True):
        return {'ok': False, 'error': ERROR_DISABLED}

    # 2. URL.
    url = (params.get('url') or '').strip()
    ok, err = validate_url(url)
    if not ok:
        if err == ERROR_INVALID_SCHEME:
            scheme = urllib.parse.urlparse(url).scheme.lower()
            log.security(
                f'hls/start [{origin}] rechazado: scheme={scheme!r} url={url[:80]!r}'
            )
        return {'ok': False, 'error': err}

    # 3. Cap de concurrencia (clamp defensivo igual que antes).
    max_concurrent = _get_setting_int('transfer.hls.max_concurrent', 3)
    max_concurrent = max(1, min(10, max_concurrent or 3))

    # 4. Preflight de destino.
    try:
        dest_dir = storage.get_dest_dir()
    except storage.StorageError as e:
        return {'ok': False, 'error': ERROR_DEST_UNAVAILABLE, 'detail': str(e)}

    # 5. Espacio mínimo libre.
    min_mb = max(100, _get_setting_int('transfer.hls.min_free_space_mb', 500) or 500)
    try:
        free_b = shutil.disk_usage(dest_dir).free
        if free_b < min_mb * 1024 * 1024:
            return {
                'ok': False, 'error': ERROR_LOW_DISK,
                'free_mb': free_b // (1024 * 1024),
                'required_mb': min_mb,
            }
    except OSError as e:
        # disk_usage puede fallar en VFS exóticos. Igual que el handler
        # antiguo: log y seguimos (no aborta el start por un fallo de stat).
        log.warning(f'hls/start [{origin}]: disk_usage falló: {e!r}')

    # 6. Compresión: param explícito gana sobre setting global.
    compress_param = params.get('compress')
    if compress_param is None:
        compress = _get_setting_bool('transfer.hls.compress', False)
    else:
        compress = bool(compress_param)

    # Si pidió compress pero FFmpeg no está disponible, hacemos fallback a
    # TS aquí mismo. Sin esto el flujo decidía .mp4 como extensión y luego
    # el recorder caía al modo TS escribiendo bytes .ts en un archivo .mp4 —
    # archivo no reproducible y historial mintiendo el formato.
    if compress:
        try:
            from lib.remote import transcode as _tc
            if not _tc.find_ffmpeg():
                log.warning(
                    f'[HLS] [{origin}] compress solicitado pero ffmpeg no '
                    f'disponible; grabando como TS sin reencode'
                )
                compress = False
        except Exception as e:
            log.warning(f'[HLS] [{origin}] find_ffmpeg falló: {e!r}; degradando a TS')
            compress = False

    crf_param = params.get('compress_crf')
    if crf_param is None:
        crf = _get_setting_int('transfer.hls.compress_crf', 26)
    else:
        try:
            crf = int(crf_param)
        except (TypeError, ValueError):
            crf = 26
    # Clamp del CRF al rango razonable de libx264.
    crf = max(18, min(35, crf))

    # 7. Calidad / duración: parseo con clamp defensivo.
    try:
        max_bandwidth = max(0, int(params.get('quality', 0) or 0))
    except (TypeError, ValueError):
        max_bandwidth = 0
    try:
        max_duration_mins = max(0, int(params.get('max_duration_mins', 0) or 0))
    except (TypeError, ValueError):
        max_duration_mins = 0
    if max_duration_mins == 0:
        max_duration_mins = _get_setting_int('transfer.hls.max_duration_mins', 180)
    max_duration_mins = max(0, max_duration_mins or 0)

    # 8. Nombre de archivo. Extensión depende del modo: .mp4 si compress
    # (FFmpeg produce MP4 fragmentado), .ts si no (concatenación de
    # segmentos HLS sin reencode).
    raw_name = (params.get('filename') or '').strip()
    if not raw_name:
        tail = urllib.parse.urlparse(url).path.rstrip('/').rsplit('/', 1)[-1]
        raw_name = tail.rsplit('.', 1)[0] if '.' in tail else (tail or 'recording')
    safe_name = _sanitize_filename(raw_name)
    # Quitar cualquier extensión que ya pueda traer y poner la correcta
    # según modo. Sin esto un filename "clip.ts" en modo compress
    # produciría "clip.ts.mp4". Loop necesario para casos compuestos como
    # "clip.ts.partial" → "clip" tras dos splits.
    _strippable = {'.ts', '.mp4', '.m3u8', '.m3u', '.mpd', '.aac', '.partial'}
    for _ in range(4):  # bound defensivo; en la práctica 1-2 iteraciones
        base, ext_existing = os.path.splitext(safe_name)
        if not base or ext_existing.lower() not in _strippable:
            break
        safe_name = base
    if not safe_name:
        safe_name = 'recording'
    safe_name += '.mp4' if compress else '.ts'

    candidate = os.path.join(dest_dir, safe_name)
    try:
        output_file = storage.reserve_unique_path(candidate)
    except OSError as e:
        return {'ok': False, 'error': ERROR_RESERVE, 'detail': str(e)}

    display_name = (params.get('name') or '').strip() or safe_name

    # 9. Entrada en historial.
    entry = history.add(
        filepath=output_file,
        name=display_name,
        size=0,
        kind='hls_recording',
        source='hls',
        action_taken='recorded',
    )
    history.update(entry['id'], recording_state='active', bytes=0)

    # 10. Crear recorder. Los kwargs `compress`/`compress_crf` son
    # kw-only en HLSRecorder para no romper callers antiguos.
    recorder = hls_recorder.HLSRecorder(
        m3u8_url=url,
        output_file=output_file,
        name=display_name,
        max_duration_mins=max_duration_mins,
        max_bandwidth=max_bandwidth,
        history_entry_id=entry['id'],
        compress=compress,
        compress_crf=crf,
    )

    # 11. Register atómico bajo el cap. Si se rechaza, marcar history como
    # 'declined' (no 'error': el sistema funcionó correctamente, fue policy).
    if not hls_recorder.register_if_under_limit(recorder, max_concurrent):
        history.update(
            entry['id'],
            recording_state='declined',
            error_msg='Límite de grabaciones simultáneas alcanzado',
        )
        return {
            'ok': False, 'error': ERROR_TOO_MANY,
            'limit': max_concurrent,
        }

    # 12. Arrancar el thread. Si falla, hay que desregistrar para que
    # `list_active` no quede mintiendo.
    try:
        recorder.start()
    except Exception as e:
        log.error(f'[HLS] recorder.start() [{origin}] falló: {e!r}')
        hls_recorder.unregister(recorder.recording_id)
        history.update(
            entry['id'],
            recording_state='error',
            error_msg=f'No se pudo arrancar el hilo de grabación: {e}',
        )
        return {'ok': False, 'error': ERROR_START_FAILED, 'detail': str(e)}

    log.info(
        f'[HLS] start [{origin}]: id={recorder.recording_id} '
        f'name={display_name!r} url={url[:80]!r} compress={compress}'
    )
    return {
        'ok': True,
        'recording_id': recorder.recording_id,
        'history_entry_id': entry['id'],
        'output_file': output_file,
    }
