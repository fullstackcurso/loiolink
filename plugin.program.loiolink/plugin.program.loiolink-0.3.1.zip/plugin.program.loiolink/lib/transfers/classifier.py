"""Clasifica un archivo por su contenido. Para ZIPs distingue addon vs repo.

kind devuelto:
- 'video' / 'audio' / 'image' / 'torrent' / 'apk'
- 'addon_zip' / 'repo_zip' / 'unknown_zip'
- 'other'

Para ZIPs, también devuelve el addon_id extraído de la carpeta raíz.

Validación reforzada (sec 1.4 del plan de fixes):
- Parsear addon.xml con ElementTree. Si no es XML válido o el root no es
  <addon> o el atributo id no coincide con la carpeta raíz, devolver
  'unknown_zip' (evita marcar como addon válido un ZIP corrupto).
"""
import os
import re
import xml.etree.ElementTree as ET
import zipfile


_VIDEO_EXTS = {'.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.flv', '.wmv'}
_AUDIO_EXTS = {'.mp3', '.flac', '.aac', '.m4a', '.ogg', '.opus', '.wav'}
_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
_APK_EXTS = {'.apk'}

_REPO_EXTENSION_RE = re.compile(
    r'<extension\s+point="xbmc\.addon\.repository"', re.I,
)

# addon.xml legítimo nunca pasa de ~100 KB. Leer con tope evita que un ZIP
# con addon.xml comprimido a ratio extremo agote la RAM al descomprimir.
_MAX_ADDON_XML_BYTES = 1024 * 1024


def classify(filepath):
    """Devuelve (kind, addon_id_or_None)."""
    ext = os.path.splitext(filepath)[1].lower()
    if ext in _VIDEO_EXTS:
        return 'video', None
    if ext in _AUDIO_EXTS:
        return 'audio', None
    if ext in _IMAGE_EXTS:
        return 'image', None
    if ext in _APK_EXTS:
        return 'apk', None
    if ext == '.torrent':
        return 'torrent', None
    if ext == '.zip':
        return _classify_zip(filepath)
    return 'other', None


def _classify_zip(filepath):
    try:
        with zipfile.ZipFile(filepath, 'r') as zf:
            entries = [
                n for n in zf.namelist()
                if n.endswith('/addon.xml') and n.count('/') == 1
            ]
            if not entries:
                return 'unknown_zip', None
            xml_path = entries[0]
            folder_id = xml_path.split('/')[0]
            with zf.open(xml_path) as fp:
                raw = fp.read(_MAX_ADDON_XML_BYTES + 1)
            if len(raw) > _MAX_ADDON_XML_BYTES:
                return 'unknown_zip', None
            content = raw.decode('utf-8', errors='replace')
    except (zipfile.BadZipFile, OSError, KeyError):
        return 'unknown_zip', None

    # Validar XML y obtener el id REAL del addon (puede diferir del nombre
    # de carpeta: releases GitHub usan tag-prefix tipo "myaddon-v1.2.3/").
    real_id = _addon_xml_id(content, folder_id)
    if not real_id:
        return 'unknown_zip', None

    if _REPO_EXTENSION_RE.search(content):
        return 'repo_zip', real_id
    return 'addon_zip', real_id


def _addon_xml_id(xml_text, folder_id):
    """Devuelve el id del addon si el XML es válido y consistente con la
    carpeta, o None si no lo es.

    Aceptamos dos formas de match folder ↔ xml id:
    - exacto: folder == xml_id (caso ideal)
    - sufijo: folder == xml_id + '-' + cualquier-cosa (releases GitHub
      con tag prefix tipo "addon-v1.2.3"). La extracción renombra al id
      real más tarde para que Kodi lo reconozca."""
    # Defensa XXE / billion-laughs: ET.fromstring expande entidades por
    # defecto. Los addon.xml legítimos de Kodi nunca declaran DOCTYPE;
    # rechazar cualquiera que lo haga.
    if '<!doctype' in xml_text[:512].lower():
        return None
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return None
    if root.tag != 'addon':
        return None
    xml_id = root.get('id')
    if not xml_id:
        return None
    if folder_id == xml_id:
        return xml_id
    if folder_id.startswith(xml_id + '-'):
        return xml_id
    return None
