"""Parser multipart/form-data en streaming.

Lee chunks de la conexión, detecta el boundary, escribe el cuerpo del primer
file part al disco sin pasar por memoria. cgi.FieldStorage carga en memoria
por defecto y el email parser es engorroso para streaming.

Features tras auditoría:
- RFC 5987 filename*=UTF-8''nombre (Chrome moderno y fetch API lo usan
  para nombres no-ASCII; el cliente puede mandar SOLO filename* sin filename).
- Salto de parts sin filename hasta encontrar el primero con archivo
  (formularios con campos extra antes del file).
- Sanitización Unicode: elimina bidi-override (U+202A..U+202E,
  U+2066..U+2069) y NUL para evitar spoofing visual `evil‮gpj.exe`.

Limitaciones conocidas:
- Solo procesa el PRIMER file part. loiolink solo recibe uno por request.
- No soporta Content-Encoding: gzip sobre multipart (raro en clientes web).
"""
import os
import re
import socket
import unicodedata
import urllib.parse

from lib.transfers import storage


_FILENAME_RE = re.compile(rb'filename="([^"]*)"', re.I)
_FILENAME_STAR_RE = re.compile(rb"filename\*=([^;\r\n]+)", re.I)

# Bidi-override + NUL: vector de spoofing visual en filename
_BAD_CHARS = ''.join(chr(c) for c in (
    0x00, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
    0x2066, 0x2067, 0x2068, 0x2069,
))
_BAD_CHARS_TRANS = str.maketrans('', '', _BAD_CHARS)
# Caracteres ilegales en Windows/FAT/NTFS y problemáticos en muchos shells.
# `:` en NTFS abre Alternate Data Streams (foo.txt:hidden).
_OS_BAD_CHARS_RE = re.compile(r'[:*?"<>|]')
# Nombres reservados en Windows (devices DOS legacy). os.open(O_CREAT) sobre
# ellos puede redirigir a la consola/device en lugar de crear el archivo, o
# lanzar OSError según versión. Ref: Microsoft Learn — Naming a File.
_WINDOWS_RESERVED_RE = re.compile(
    r'^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(\.|$)',
    re.IGNORECASE,
)

_CHUNK = 64 * 1024
# Topes defensivos contra clientes raros o malformados: preamble y headers
# de un multipart normal son <1 KB; aceptamos 64 KB / 16 KB con margen
# generoso. Sin estos topes un cliente que mande basura indefinidamente
# antes del primer boundary haría crecer `buf` sin límite en RAM.
_MAX_PREAMBLE = 64 * 1024
_MAX_HEADERS = 16 * 1024


class MultipartLimitExceeded(Exception):
    """El archivo supera el tamaño permitido (escrito parcialmente)."""


def stream_multipart_to_disk(rfile, content_type, dest_dir, max_bytes,
                             on_first_write=None, on_first_write_after=0,
                             read_timeout_s=120):
    """Lee multipart desde rfile y escribe el primer file part a dest_dir.

    on_first_write_after: mínimo de bytes en disco antes de llamar on_first_write.
    read_timeout_s: timeout aplicado al socket subyacente entre lecturas.
    Sin esto, un cliente que abre conexión y deja de enviar bloquea el
    handler thread hasta el timeout HTTP global (5 min); DoS efectivo.
    Devuelve (filepath, filename, size, truncated). truncated=True si se
    cortó al alcanzar max_bytes.
    """
    # Aplicar timeout al socket subyacente del rfile si es posible. El
    # http.server expone el socket vía rfile._sock (CPython 3.x) o el
    # buffer interno. Mejor effort: si no podemos, seguimos sin timeout.
    _sock = getattr(rfile, '_sock', None)
    if _sock is None:
        _raw = getattr(rfile, 'raw', None)
        if _raw is not None:
            _sock = getattr(_raw, '_sock', None)
    _old_timeout = None
    if _sock is not None and hasattr(_sock, 'gettimeout'):
        try:
            _old_timeout = _sock.gettimeout()
            _sock.settimeout(read_timeout_s)
        except OSError:
            _sock = None

    m = re.search(r'boundary=([^;]+)', content_type)
    if not m:
        raise ValueError('No boundary en Content-Type')
    boundary = b'--' + m.group(1).strip('"').encode()

    buf = b''

    # Saltar preamble hasta primer boundary
    while boundary not in buf:
        if len(buf) > _MAX_PREAMBLE:
            raise ValueError('preamble too large')
        chunk = rfile.read(_CHUNK)
        if not chunk:
            raise ValueError('Stream cerrado antes de primer boundary')
        buf += chunk
    buf = buf.split(boundary, 1)[1]

    # Iterar parts hasta encontrar uno con filename (el primer file part)
    filename = None
    while filename is None:
        if buf.startswith(b'--'):
            raise ValueError('Multipart sin file part')
        if buf.startswith(b'\r\n'):
            buf = buf[2:]

        while b'\r\n\r\n' not in buf:
            if len(buf) > _MAX_HEADERS:
                raise ValueError('headers too large')
            chunk = rfile.read(_CHUNK)
            if not chunk:
                raise ValueError('Headers incompletos')
            buf += chunk
        headers_raw, buf = buf.split(b'\r\n\r\n', 1)

        filename = _extract_filename(headers_raw)
        if filename is None:
            # Es un campo de formulario sin filename; saltar su body hasta el
            # siguiente boundary.
            while boundary not in buf:
                chunk = rfile.read(_CHUNK)
                if not chunk:
                    raise ValueError('Stream cerrado en field part')
                buf += chunk
            buf = buf.split(boundary, 1)[1]

    filename = _sanitize_filename(filename)
    filepath = storage.reserve_unique_path(os.path.join(dest_dir, filename))

    # Volcar body del file part hasta el siguiente boundary.
    # Retener \r\n + boundary entre chunks por si el match está partido.
    # boundary ya incluye los dos guiones, así que retenemos len(boundary) + 2.
    written = 0
    truncated = False
    first_write_done = False
    keep = len(boundary) + 2

    # reserve_unique_path ya creó el archivo vacío; cualquier fallo durante el
    # volcado debe limpiar el parcial para no acumular huérfanos si el cliente
    # corta la subida o el disco se llena a mitad.
    try:
        with open(filepath, 'wb') as out:
            while True:
                idx = buf.find(boundary)
                if idx != -1:
                    tail = buf[:idx]
                    if tail.endswith(b'\r\n'):
                        tail = tail[:-2]
                    to_write = min(len(tail), max_bytes - written)
                    out.write(tail[:to_write])
                    written += to_write
                    if not first_write_done and on_first_write and written >= on_first_write_after:
                        out.flush()
                        on_first_write(filepath)
                        first_write_done = True
                    if to_write < len(tail):
                        truncated = True
                    break

                if len(buf) > keep:
                    writable = buf[:-keep]
                    to_write = min(len(writable), max_bytes - written)
                    out.write(writable[:to_write])
                    written += to_write
                    if not first_write_done and on_first_write and written >= on_first_write_after:
                        out.flush()
                        on_first_write(filepath)
                        first_write_done = True
                    if to_write < len(writable):
                        truncated = True
                        break
                    buf = buf[-keep:]

                chunk = rfile.read(_CHUNK)
                if not chunk:
                    raise ValueError('Stream cerrado antes de boundary final')
                buf += chunk
            # Forzar al OS a flushear al disco físico ANTES de que el caller
            # llame a Player.Open. Sin fsync, close() solo entrega el Python
            # buffer al OS, que puede mantener los datos en cache 1-30s antes
            # de escribirlos. Kodi entonces abre un archivo "incompleto" y
            # se queda con un BusyDialog esperando bytes que aún no están
            # en disco. Coste: ~10-100ms para 2MB en NTFS. Aceptable.
            try:
                os.fsync(out.fileno())
            except OSError:
                pass   # no fatal: peor caso = el bug que arreglamos
    except socket.timeout:
        try:
            os.remove(filepath)
        except OSError:
            pass
        raise ValueError(
            f'Upload sin datos durante {read_timeout_s}s: abortado')
    except (OSError, ValueError):
        try:
            os.remove(filepath)
        except OSError:
            pass
        raise
    finally:
        # Restaurar timeout original al socket (si lo cambiamos).
        if _sock is not None and _old_timeout is not None:
            try:
                _sock.settimeout(_old_timeout)
            except OSError:
                pass

    return filepath, filename, written, truncated


def _extract_filename(headers_raw):
    """filename* (RFC 5987) tiene prioridad sobre filename (legacy).

    RFC 5987: charset'language'value. `language` puede venir vacío o con
    un tag (`UTF-8''name` o `UTF-8'es'name`). Las comillas simples dentro
    de `value` van como %27 por RFC, así que split por `'` con maxsplit=2
    nunca rompe un nombre legítimo.
    """
    star = _FILENAME_STAR_RE.search(headers_raw)
    if star:
        raw = star.group(1).strip().decode('latin-1', errors='replace')
        parts = raw.split("'", 2)
        value = parts[2] if len(parts) == 3 else parts[-1]
        return urllib.parse.unquote(value.strip(' "'))

    legacy = _FILENAME_RE.search(headers_raw)
    if legacy:
        return legacy.group(1).decode('utf-8', errors='replace')
    return None


def _sanitize_filename(filename):
    """Reduce filename a basename seguro: sin paths, sin bidi-override,
    sin NUL, sin caracteres ilegales del filesystem, sin trailing dots/
    spaces (Windows trunca silenciosamente y permite spoofing) y sin
    coincidir con nombres reservados Windows (CON, NUL, COM1, ...)."""
    filename = filename.replace('\\', '/').split('/')[-1]
    filename = unicodedata.normalize('NFKC', filename).translate(_BAD_CHARS_TRANS)
    filename = _OS_BAD_CHARS_RE.sub('_', filename)
    # Windows: "evil.exe." se guarda como "evil.exe" (silent truncation),
    # vector de spoofing. Igual con espacios finales.
    filename = filename.rstrip('. ')
    # '.' y '..' tras el split apuntan al directorio destino o a su padre;
    # os.open(O_CREAT|O_EXCL) sobre ellos lanza IsADirectoryError, no
    # FileExistsError, así que reserve_unique_path no los maneja.
    if filename in ('', '.', '..'):
        return 'archivo'
    if _WINDOWS_RESERVED_RE.match(filename):
        filename = '_' + filename
    return filename
