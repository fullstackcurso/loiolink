"""Resolución de la carpeta de destino para archivos recibidos.

Setting `transfer.dest_folder` (categoría Transferencias). Cubre los 3 flujos
de entrada: descarga URL, descarga por código numérico y upload del panel
móvil; para que el usuario configure una sola vez dónde aterriza todo.

Vacío  -> carpeta del perfil del addon (comportamiento previo, nunca falla).
Con valor -> intenta crear/validar; si no es usable -> StorageError. Sin
fallback silencioso: el caller decide cómo avisar al usuario.

Rechazamos rutas VFS no-locales (smb://, nfs://, ftp://, http://). El
downloader y multipart_stream escriben con `open()` Python, que no las
soporta; sin validar aquí el fallo aparecería a mitad del volcado y
dejaría un archivo a medias en disco.
"""
import os
import time

import xbmcaddon
import xbmcvfs


_DEFAULT_VFS = 'special://profile/addon_data/plugin.program.loiolink/transfers/'
_SETTING_KEY = 'transfer.dest_folder'


class StorageError(OSError):
    """La carpeta de destino configurada no se puede usar."""


def _read_setting():
    try:
        raw = xbmcaddon.Addon().getSetting(_SETTING_KEY)
    except (RuntimeError, ValueError, TypeError):
        return ''
    return (raw or '').strip()


def get_dest_dir():
    """Devuelve la ruta real (string, no VFS) lista para escribir.

    Garantiza que el directorio existe al volver. Lanza StorageError si el
    usuario configuró una ruta que no se puede crear, usar o no es local.
    """
    custom = _read_setting()
    if not custom:
        xbmcvfs.mkdirs(_DEFAULT_VFS)
        return xbmcvfs.translatePath(_DEFAULT_VFS)

    # Normaliza a forma con trailing slash (xbmcvfs.mkdirs lo requiere para
    # rutas tipo URL como special:// o smb://).
    vfs_path = custom if custom.endswith(('/', '\\')) else custom + '/'

    if not xbmcvfs.exists(vfs_path):
        if not xbmcvfs.mkdirs(vfs_path):
            raise StorageError(f'no se pudo crear la carpeta: {custom}')

    real = xbmcvfs.translatePath(vfs_path)

    # special:// y rutas locales se traducen a filesystem real. smb://, nfs://,
    # ftp://, http://... se devuelven tal cual; downloader usa open() Python
    # que no entiende esas URIs, así que las rechazamos antes de empezar.
    if '://' in real:
        raise StorageError(
            f'destino no soportado (solo carpetas locales): {custom}',
        )

    # Smoke test de escritura: cubre permisos y USB de solo lectura, casos
    # que xbmcvfs.exists() no detecta. Nombre único (PID + ns) para evitar
    # colisiones si dos transferencias se solapan.
    probe = f'{vfs_path}.loiolink_probe.{os.getpid()}.{time.monotonic_ns()}'
    f = xbmcvfs.File(probe, 'wb')
    try:
        ok = f.write(bytearray(b'x'))
    finally:
        f.close()
        if xbmcvfs.exists(probe):
            xbmcvfs.delete(probe)
    if ok is False:
        raise StorageError(f'sin permisos de escritura en: {custom}')

    return real


def reserve_unique_path(path):
    """Reserva atómicamente un path libre en disco.

    Dos escrituras concurrentes con el mismo filename hacen ambas open('wb')
    sobre el mismo path y el contenido queda mezclado. Aquí usamos
    O_CREAT|O_EXCL para que el primero gane el nombre original y el segundo
    reintente con sufijo numérico hasta encontrar uno libre. El archivo queda
    creado vacío (0 bytes) y el open('wb') posterior lo trunca y escribe;
    semántica idéntica al flujo previo, pero sin TOCTOU.
    """
    base, ext = os.path.splitext(path)
    candidate = path
    n = 1
    while True:
        try:
            fd = os.open(
                candidate,
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                0o644,
            )
            os.close(fd)
            return candidate
        except FileExistsError:
            candidate = f'{base}-{n}{ext}'
            n += 1
