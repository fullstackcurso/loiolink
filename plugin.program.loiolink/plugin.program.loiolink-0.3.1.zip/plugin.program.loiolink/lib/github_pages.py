"""Asistente para añadir una fuente de GitHub Pages.

Pide usuario y repo por separado, construye https://usuario.github.io/repo/,
verifica que responde y permite reintentar. Lo usan los dos botones de
"añadir fuente" del addon.
"""
import xbmcgui

from lib import url_utils
from lib.ui_select import confirm


def prompt_source_url():
    """Pide usuario y repo, verifica la URL y permite reintentar.

    Devuelve (url, repo) o None si el usuario cancela. `repo` sirve como
    nombre sugerido para la fuente.
    """
    prev_user, prev_repo = '', ''
    while True:
        user = xbmcgui.Dialog().input(
            f'https://[USUARIO].github.io/{prev_repo or "repo"}/',
            defaultt=prev_user,
        ).strip().strip('/')
        if not user:
            return None
        repo = xbmcgui.Dialog().input(
            f'https://{user}.github.io/[REPO]/',
            defaultt=prev_repo,
        ).strip().strip('/')
        if not repo:
            return None
        url = f'https://{user}.github.io/{repo}/'

        progress = xbmcgui.DialogProgress()
        progress.create('loiolink', f'Comprobando si {url} responde...')
        try:
            ok, info = url_utils.test_http_reachable(url)
        finally:
            progress.close()
        if ok:
            return url, repo
        if confirm(
            f'{url}\n\n{info}\n\n¿Guardar la fuente igualmente, o volver atrás '
            'para corregir el usuario y el repositorio?',
            title='La URL no responde',
            yes='Guardar igualmente',
            no='Editar',
            default_no=True,
        ):
            return url, repo
        prev_user, prev_repo = user, repo
