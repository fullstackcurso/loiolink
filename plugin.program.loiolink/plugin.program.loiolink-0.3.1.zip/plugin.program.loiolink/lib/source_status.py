"""Etiquetas e iconos compartidos para visualizar el estado de una fuente.

Antes vivía solo en `sources_repos_menu` como helpers privados; ahora el
file browser también quiere pintar el tag `[CAIDA]` o `[CAMBIOS]` junto
al nombre, así que la lógica se sube a un módulo público compartido para
que ambos sitios produzcan exactamente la misma decoración.
"""
from lib import source_state


def _http_only(path):
    return path.startswith('http://') or path.startswith('https://')


def status_tag(path):
    """Devuelve el tag BBCode-coloreado para mostrar junto al nombre."""
    if not _http_only(path):
        return '[COLOR gray][Sin URL HTTP][/COLOR]'
    st = source_state.get(path)
    if not st:
        return '[COLOR gray][Sin comprobar][/COLOR]'
    if int(st.get('errors', 0)) >= 3:
        return '[COLOR red][Caída][/COLOR]'
    if st.get('kind') == 'generic':
        return '[COLOR yellow][Fuente genérica][/COLOR]'
    if st.get('kind') == 'repo':
        if not st.get('acknowledged', True):
            return '[COLOR orange][Cambios][/COLOR]'
        return '[COLOR green][Repo monitorizado][/COLOR]'
    return ''


def status_icon(path):
    """Nombre de icono (`sources.png` / `notification.png`) según el estado."""
    if not _http_only(path):
        return 'sources.png'
    st = source_state.get(path)
    if not st:
        return 'sources.png'
    if int(st.get('errors', 0)) >= 3:
        return 'notification.png'
    if st.get('kind') == 'repo' and not st.get('acknowledged', True):
        return 'notification.png'
    return 'sources.png'
