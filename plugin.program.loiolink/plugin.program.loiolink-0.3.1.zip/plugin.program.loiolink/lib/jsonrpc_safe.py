"""Wrapper sobre `xbmc.executeJSONRPC` con timeout y error detection.

Problema: `xbmc.executeJSONRPC` es síncrono, sin timeout. Si Kodi está
saturado (UpdateLibrary corriendo, deadlock en otro addon...), una
llamada puede colgarse indefinidamente. Si el caller es un thread daemon
de `backup_jobs`, el thread queda zombi y el mutex de backup también.

Solución: `concurrent.futures.ThreadPoolExecutor` con timeout. NO usar
`signal.alarm` (no funciona en Windows ni dentro de threads).

Además, la respuesta de Kodi tiene 3 modos de fallo silencioso:
  - Devuelve '' (string vacío) → JSON inválido
  - Devuelve `{"error": {...}}` → ningún `result`
  - Excepción durante la llamada (raro pero posible si Kodi está down)

`call(method, params, timeout_s, default)` los normaliza todos a un
único resultado: si todo OK, devuelve `result`. Si algo falla, devuelve
`default` (configurable) y logea el motivo.

Uso:

    from lib import jsonrpc_safe

    addons = jsonrpc_safe.call(
        'Addons.GetAddons',
        {'enabled': True, 'properties': ['version', 'author']},
        timeout_s=10.0, default={'addons': []},
    )
    for a in addons.get('addons', []):
        ...
"""
import concurrent.futures
import json

import xbmc

from lib import log


_DEFAULT_TIMEOUT_S = 15.0

# Pool compartido para evitar crear/destruir threads en cada call. Tamaño
# pequeño porque solo nos protege del cuelgue: dos JSON-RPC en paralelo
# no se aceleran (Kodi serializa internamente).
_executor = concurrent.futures.ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix='jsonrpc-safe',
)


# Shutdown del pool en cierre normal del proceso (no protege contra crash de
# Kodi). wait=False: no esperamos a calls colgados; el timeout ya los corta.
import atexit as _atexit


def _shutdown_executor():
    try:
        _executor.shutdown(wait=False)
    except Exception:  # noqa: BLE001
        pass


_atexit.register(_shutdown_executor)


def call(method, params=None, *, timeout_s=_DEFAULT_TIMEOUT_S, default=None,
         log_label=None):
    """Llamada JSON-RPC defensiva.

    method: nombre del método ('Addons.GetAddons', etc.).
    params: dict de params. None => no params.
    timeout_s: máximo a esperar. Si vence, devuelve `default`.
    default: valor a devolver en cualquier path de fallo. None por defecto.
    log_label: prefijo para los logs (default: el método).

    Devuelve el campo `result` de la respuesta JSON-RPC, o `default` si:
      - timeout
      - empty response
      - JSON inválido
      - error key presente
      - excepción durante la ejecución
    """
    label = log_label or method
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': method,
    }
    if params is not None:
        payload['params'] = params
    body = json.dumps(payload)

    def _do_call():
        return xbmc.executeJSONRPC(body)

    try:
        fut = _executor.submit(_do_call)
        try:
            raw = fut.result(timeout=timeout_s)
        except concurrent.futures.TimeoutError:
            # NO cancelar fut: xbmc.executeJSONRPC no responde a cancel
            # y la llamada seguirá ocupando un slot del pool hasta que
            # Kodi termine. Mejor dejarla y aceptar la pérdida temporal
            # de un worker; el pool tiene 2.
            log.warning(f'[jsonrpc] {label} timeout {timeout_s}s')
            return default
    except Exception as e:  # noqa: BLE001
        log.warning(f'[jsonrpc] {label} excepción: {e!r}')
        return default

    if not raw:
        log.warning(f'[jsonrpc] {label} respuesta vacía')
        return default
    try:
        data = json.loads(raw)
    except ValueError as e:
        log.warning(f'[jsonrpc] {label} JSON inválido: {e}')
        return default
    if not isinstance(data, dict):
        log.warning(f'[jsonrpc] {label} respuesta no-objeto')
        return default
    if 'error' in data:
        log.warning(f'[jsonrpc] {label} error: {data["error"]!r}')
        return default
    return data.get('result', default)


def call_void(method, params=None, *, timeout_s=_DEFAULT_TIMEOUT_S):
    """Llamada sin esperar resultado significativo (e.g. SetAddonEnabled).

    Devuelve True si la llamada se completó sin errores, False en cualquier
    otro caso. Útil para acciones donde solo importa éxito/fracaso.
    """
    res = call(method, params, timeout_s=timeout_s, default=None)
    return res is not None
