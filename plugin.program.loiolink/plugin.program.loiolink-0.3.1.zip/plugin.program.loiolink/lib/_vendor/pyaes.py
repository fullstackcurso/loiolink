"""AES-256-CBC implementación pura Python según FIPS-197.

Adaptado de https://github.com/ricmoo/pyaes (MIT license, Richard Moore).
Versión minimalista: solo AES-256-CBC con PKCS#7 padding. Sin C extensions
ni dependencias.

Verificado contra test vectors NIST SP 800-38A para AES-256-CBC.

Uso:
    from lib._vendor import pyaes
    cipher = pyaes.AES256CBC(key=b'\\x00'*32, iv=b'\\x00'*16)
    ciphertext = cipher.encrypt(b'plaintext')  # con PKCS#7 padding interno
    plaintext = pyaes.AES256CBC(key=b'\\x00'*32, iv=b'\\x00'*16).decrypt(ciphertext)

Performance: ~0.3-0.5 MB/s en Python puro. Solo usar para cifrar archivos
pequeños (manifests, <100KB). NO usar para cifrar ZIPs completos.
"""
import os


# S-box (Substitution box) FIPS-197 Figure 7
_S_BOX = bytes((
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b,
    0xfe, 0xd7, 0xab, 0x76, 0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0,
    0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, 0xb7, 0xfd, 0x93, 0x26,
    0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2,
    0xeb, 0x27, 0xb2, 0x75, 0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0,
    0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, 0x53, 0xd1, 0x00, 0xed,
    0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f,
    0x50, 0x3c, 0x9f, 0xa8, 0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
    0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, 0xcd, 0x0c, 0x13, 0xec,
    0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14,
    0xde, 0x5e, 0x0b, 0xdb, 0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c,
    0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 0xe7, 0xc8, 0x37, 0x6d,
    0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f,
    0x4b, 0xbd, 0x8b, 0x8a, 0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e,
    0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, 0xe1, 0xf8, 0x98, 0x11,
    0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f,
    0xb0, 0x54, 0xbb, 0x16,
))

# Inverse S-box
_INV_S_BOX = bytes((
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e,
    0x81, 0xf3, 0xd7, 0xfb, 0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87,
    0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb, 0x54, 0x7b, 0x94, 0x32,
    0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
    0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49,
    0x6d, 0x8b, 0xd1, 0x25, 0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16,
    0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92, 0x6c, 0x70, 0x48, 0x50,
    0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
    0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05,
    0xb8, 0xb3, 0x45, 0x06, 0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02,
    0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b, 0x3a, 0x91, 0x11, 0x41,
    0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
    0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8,
    0x1c, 0x75, 0xdf, 0x6e, 0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89,
    0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b, 0xfc, 0x56, 0x3e, 0x4b,
    0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
    0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59,
    0x27, 0x80, 0xec, 0x5f, 0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d,
    0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef, 0xa0, 0xe0, 0x3b, 0x4d,
    0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63,
    0x55, 0x21, 0x0c, 0x7d,
))

# Round constants para AES-256
_RCON = (
    0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36,
    0x6c, 0xd8, 0xab, 0x4d, 0x9a,
)


def _xtime(a):
    """Multiplicación por 2 en GF(2^8)."""
    return ((a << 1) ^ 0x1b) & 0xff if a & 0x80 else (a << 1) & 0xff


def _expand_key_256(key):
    """Expansión de clave AES-256. Devuelve 15 round keys (240 bytes)."""
    if len(key) != 32:
        raise ValueError(f'AES-256 requiere clave de 32 bytes, recibido {len(key)}')
    # Nb=4, Nk=8, Nr=14 para AES-256
    # Total: 4*(14+1) = 60 words = 240 bytes
    w = list(key)
    i = 32
    rcon_i = 1
    while i < 240:
        # temp = w[i-4..i-1]
        t0, t1, t2, t3 = w[i - 4], w[i - 3], w[i - 2], w[i - 1]
        if i % 32 == 0:
            # RotWord + SubWord + Rcon
            t0, t1, t2, t3 = t1, t2, t3, t0
            t0 = _S_BOX[t0] ^ _RCON[rcon_i]
            t1 = _S_BOX[t1]
            t2 = _S_BOX[t2]
            t3 = _S_BOX[t3]
            rcon_i += 1
        elif i % 32 == 16:
            # SubWord (sin RotWord ni Rcon, especial AES-256)
            t0 = _S_BOX[t0]
            t1 = _S_BOX[t1]
            t2 = _S_BOX[t2]
            t3 = _S_BOX[t3]
        w.append(w[i - 32] ^ t0)
        w.append(w[i - 31] ^ t1)
        w.append(w[i - 30] ^ t2)
        w.append(w[i - 29] ^ t3)
        i += 4
    return w


def _sub_bytes(state):
    return [_S_BOX[b] for b in state]


def _inv_sub_bytes(state):
    return [_INV_S_BOX[b] for b in state]


def _shift_rows(state):
    # State es 16 bytes en orden column-major (col0_row0..3, col1_row0..3, ...)
    # Equivale a matriz 4x4: state[col*4 + row]
    return [
        state[0], state[5], state[10], state[15],
        state[4], state[9], state[14], state[3],
        state[8], state[13], state[2], state[7],
        state[12], state[1], state[6], state[11],
    ]


def _inv_shift_rows(state):
    return [
        state[0], state[13], state[10], state[7],
        state[4], state[1], state[14], state[11],
        state[8], state[5], state[2], state[15],
        state[12], state[9], state[6], state[3],
    ]


def _mix_columns(state):
    out = [0] * 16
    for c in range(4):
        s0 = state[c * 4 + 0]
        s1 = state[c * 4 + 1]
        s2 = state[c * 4 + 2]
        s3 = state[c * 4 + 3]
        out[c * 4 + 0] = _xtime(s0) ^ _xtime(s1) ^ s1 ^ s2 ^ s3
        out[c * 4 + 1] = s0 ^ _xtime(s1) ^ _xtime(s2) ^ s2 ^ s3
        out[c * 4 + 2] = s0 ^ s1 ^ _xtime(s2) ^ _xtime(s3) ^ s3
        out[c * 4 + 3] = _xtime(s0) ^ s0 ^ s1 ^ s2 ^ _xtime(s3)
    return out


def _gmul(a, b):
    """Multiplicación en GF(2^8)."""
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xff
        if hi:
            a ^= 0x1b
        b >>= 1
    return p


def _inv_mix_columns(state):
    out = [0] * 16
    for c in range(4):
        s0 = state[c * 4 + 0]
        s1 = state[c * 4 + 1]
        s2 = state[c * 4 + 2]
        s3 = state[c * 4 + 3]
        out[c * 4 + 0] = _gmul(s0, 0x0e) ^ _gmul(s1, 0x0b) ^ _gmul(s2, 0x0d) ^ _gmul(s3, 0x09)
        out[c * 4 + 1] = _gmul(s0, 0x09) ^ _gmul(s1, 0x0e) ^ _gmul(s2, 0x0b) ^ _gmul(s3, 0x0d)
        out[c * 4 + 2] = _gmul(s0, 0x0d) ^ _gmul(s1, 0x09) ^ _gmul(s2, 0x0e) ^ _gmul(s3, 0x0b)
        out[c * 4 + 3] = _gmul(s0, 0x0b) ^ _gmul(s1, 0x0d) ^ _gmul(s2, 0x09) ^ _gmul(s3, 0x0e)
    return out


def _add_round_key(state, round_key):
    return [a ^ b for a, b in zip(state, round_key)]


def _encrypt_block_256(plaintext_block, expanded_key):
    """Cifra UN bloque de 16 bytes con AES-256. Devuelve bytes."""
    state = list(plaintext_block)
    # Round 0: AddRoundKey
    state = _add_round_key(state, expanded_key[0:16])
    # Rounds 1..13: SubBytes + ShiftRows + MixColumns + AddRoundKey
    for r in range(1, 14):
        state = _sub_bytes(state)
        state = _shift_rows(state)
        state = _mix_columns(state)
        state = _add_round_key(state, expanded_key[r * 16:(r + 1) * 16])
    # Round 14 (final): SubBytes + ShiftRows + AddRoundKey (sin MixColumns)
    state = _sub_bytes(state)
    state = _shift_rows(state)
    state = _add_round_key(state, expanded_key[14 * 16:15 * 16])
    return bytes(state)


def _decrypt_block_256(ciphertext_block, expanded_key):
    """Descifra UN bloque de 16 bytes con AES-256."""
    state = list(ciphertext_block)
    # Round 14 inverso: AddRoundKey
    state = _add_round_key(state, expanded_key[14 * 16:15 * 16])
    # Rounds 13..1 inverso
    for r in range(13, 0, -1):
        state = _inv_shift_rows(state)
        state = _inv_sub_bytes(state)
        state = _add_round_key(state, expanded_key[r * 16:(r + 1) * 16])
        state = _inv_mix_columns(state)
    # Round 0 inverso (final): InvShiftRows + InvSubBytes + AddRoundKey
    state = _inv_shift_rows(state)
    state = _inv_sub_bytes(state)
    state = _add_round_key(state, expanded_key[0:16])
    return bytes(state)


def _pkcs7_pad(data, block_size=16):
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)


def _pkcs7_unpad(data, block_size=16):
    if not data or len(data) % block_size != 0:
        raise ValueError('datos no son múltiplo de block_size')
    pad_len = data[-1]
    if pad_len < 1 or pad_len > block_size:
        raise ValueError('PKCS#7 padding inválido')
    # Verificar todos los bytes de padding (anti malformed)
    if data[-pad_len:] != bytes([pad_len] * pad_len):
        raise ValueError('PKCS#7 padding malformado')
    return data[:-pad_len]


class AES256CBC:
    """Cifrador AES-256 en modo CBC con PKCS#7 padding.

    Estado mínimo: solo guarda key expandida e IV. Una instancia se puede
    usar para encrypt() O decrypt() pero NO ambos (el IV se consume).
    Para encrypt + decrypt: crear dos instancias.
    """

    BLOCK_SIZE = 16

    def __init__(self, key, iv):
        if len(key) != 32:
            raise ValueError('AES-256 key debe ser 32 bytes')
        if len(iv) != 16:
            raise ValueError('CBC IV debe ser 16 bytes')
        self._expanded_key = _expand_key_256(key)
        self._iv = bytes(iv)

    def encrypt(self, plaintext):
        """Cifra plaintext con PKCS#7 padding. Devuelve ciphertext."""
        padded = _pkcs7_pad(plaintext, self.BLOCK_SIZE)
        out = bytearray()
        prev = self._iv
        for i in range(0, len(padded), self.BLOCK_SIZE):
            block = padded[i:i + self.BLOCK_SIZE]
            xored = bytes(a ^ b for a, b in zip(block, prev))
            encrypted = _encrypt_block_256(xored, self._expanded_key)
            out.extend(encrypted)
            prev = encrypted
        return bytes(out)

    def decrypt(self, ciphertext):
        """Descifra ciphertext. Asume PKCS#7 padding. Devuelve plaintext."""
        if not ciphertext or len(ciphertext) % self.BLOCK_SIZE != 0:
            raise ValueError('ciphertext no múltiplo de block_size')
        out = bytearray()
        prev = self._iv
        for i in range(0, len(ciphertext), self.BLOCK_SIZE):
            block = ciphertext[i:i + self.BLOCK_SIZE]
            decrypted = _decrypt_block_256(block, self._expanded_key)
            xored = bytes(a ^ b for a, b in zip(decrypted, prev))
            out.extend(xored)
            prev = block
        return _pkcs7_unpad(bytes(out), self.BLOCK_SIZE)


def random_iv():
    """Genera un IV criptográficamente random (16 bytes)."""
    return os.urandom(16)


def random_salt(n=16):
    """Genera un salt criptográficamente random."""
    return os.urandom(n)
