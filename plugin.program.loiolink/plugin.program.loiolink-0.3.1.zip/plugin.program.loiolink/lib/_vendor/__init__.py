"""Bundle local de librerías sin C extensions.

Las librerías aquí son puro-Python y se cargan via imports relativos
del addon. Nunca se instalan via pip ni se descargan en runtime.
"""
