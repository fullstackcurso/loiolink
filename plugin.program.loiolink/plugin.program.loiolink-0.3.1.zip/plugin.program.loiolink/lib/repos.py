"""Enumeración y escaneo de repositorios Kodi instalados.

Un repositorio en Kodi es un addon de tipo repository.* que vive en
`special://home/addons/repository.<id>/`. Su `addon.xml` declara una URL
`<datadir>` que apunta a la carpeta remota donde está publicado el index
de addons (`addons.xml`) y los ZIPs de cada addon.

Este módulo ofrece:

- `list_installed_repos()`: enumera los repos detectados.
- `fetch_remote_index(repo_id)`: descarga el addons.xml del datadir.
- `parse_addons_xml(text)`: extrae el mapa {addon_id: version}.
- `scan_installed_repos(progress_cb=None)`: recorre todo y compara las
  versiones remotas con las que están instaladas localmente vía JSON-RPC
  Addons.GetAddons. Devuelve un dict con las actualizaciones encontradas.

Tres patrones reutilizados de lib/installer.py para no duplicar lógica de
red: misma manera de leer <datadir>, mismos timeouts, mismo regex para
extraer versiones.
"""
import json
import os
import re
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs


_ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
_DATADIR_RE = re.compile(r'<datadir[^>]*>\s*([^<\s]+)\s*</datadir>')
_FETCH_TIMEOUT = 10
_MAX_INDEX_BYTES = 10 * 1024 * 1024


class ScanCancelled(Exception):
    """Se lanza desde el callback de progreso cuando el usuario cancela."""


def list_installed_repos():
    """Devuelve los IDs de los repos encontrados en special://home/addons/.

    Solo detecta los que están en `addons/` (instalados por el usuario o por
    Kodi). No incluye los del sistema (`system/`), porque esos son los
    metaregistros base de Kodi y no aportan addons del usuario.
    """
    if not os.path.isdir(_ADDONS_DIR):
        return []
    out = []
    for name in sorted(os.listdir(_ADDONS_DIR)):
        if not name.startswith('repository.'):
            continue
        if os.path.isdir(os.path.join(_ADDONS_DIR, name)):
            out.append(name)
    return out


def get_datadir(repo_id):
    """Lee <datadir> del addon.xml del repo instalado. None si no se puede."""
    repo_xml = os.path.join(_ADDONS_DIR, repo_id, 'addon.xml')
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, 'r', encoding='utf-8') as fh:
            content = fh.read()
    except OSError:
        return None
    m = _DATADIR_RE.search(content)
    if not m:
        return None
    url = m.group(1).strip()
    return url if url.endswith('/') else url + '/'


def fetch_remote_index(datadir):
    """Descarga addons.xml del datadir. Devuelve texto o lanza URLError/OSError."""
    url = datadir + 'addons.xml'
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
    })
    with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as r:
        data = r.read(_MAX_INDEX_BYTES)
        if len(data) == _MAX_INDEX_BYTES:
            xbmc.log(
                f'[loiolink] addons.xml truncado al límite '
                f'({_MAX_INDEX_BYTES // (1024 * 1024)} MB) en {url}; '
                f'el parseo XML puede fallar',
                xbmc.LOGWARNING,
            )
        return data.decode('utf-8', errors='replace')


def parse_addons_xml(text):
    """Devuelve {addon_id: version} a partir del contenido de addons.xml.

    Si el documento no se puede parsear como XML o no tiene la raíz
    esperada, devuelve {} (en vez de lanzar) para que el caller maneje el
    caso sin try/except adicional.
    """
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return {}
    if root.tag != 'addons':
        return {}
    out = {}
    for addon in root.findall('addon'):
        aid = addon.get('id')
        ver = addon.get('version')
        if aid and ver:
            out[aid] = ver
    return out


def looks_like_addons_xml(text):
    """Indica si el documento es un addons.xml válido (raíz <addons>)."""
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return False
    return root.tag == 'addons'


def _installed_versions():
    """Mapa {addon_id: version} de los addons activos vía JSON-RPC."""
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Addons.GetAddons',
        'params': {'enabled': True, 'properties': ['version']},
    }
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(raw)
    except (ValueError, RuntimeError):
        return {}
    out = {}
    for entry in data.get('result', {}).get('addons', []):
        aid = entry.get('addonid')
        ver = entry.get('version')
        if aid and ver:
            out[aid] = ver
    return out


def _version_tuple(v):
    """Convierte '1.10.2' en (1, 10, 2) para comparar numéricamente.

    Partes no numéricas se descartan al final (suficiente para la práctica
    totalidad de versiones de addons Kodi, que siguen semver más o menos).
    """
    parts = []
    for part in re.split(r'[.-]', v):
        m = re.match(r'^(\d+)', part)
        if m:
            parts.append(int(m.group(1)))
        else:
            break
    return tuple(parts)


def is_newer(remote, local):
    """True si remote > local en orden semántico."""
    return _version_tuple(remote) > _version_tuple(local)


def scan_installed_repos(progress_cb=None):
    """Recorre cada repo instalado y compara versiones con lo local.

    Devuelve {repo_id: {'updates': [...], 'error': str|None}}. Cada update
    es {'addon_id': str, 'local': str, 'remote': str}. Si el repo no tiene
    datadir o el index no responde, se rellena 'error'.

    progress_cb(done, total, current_name) se llama antes de procesar cada
    repo. Si lanza ScanCancelled, el escaneo aborta y devuelve los
    resultados parciales recogidos hasta ese momento.
    """
    repos = list_installed_repos()
    if not repos:
        return {}

    installed = _installed_versions()
    out = {}
    total = len(repos)

    for i, repo_id in enumerate(repos):
        if progress_cb is not None:
            progress_cb(i, total, repo_id)
        out[repo_id] = {'updates': [], 'error': None}
        datadir = get_datadir(repo_id)
        if not datadir:
            out[repo_id]['error'] = 'No se pudo leer datadir del repo'
            continue
        try:
            text = fetch_remote_index(datadir)
        except (urllib.error.URLError, OSError, ValueError) as e:
            out[repo_id]['error'] = f'No responde: {e}'
            continue
        remote = parse_addons_xml(text)
        if not remote:
            out[repo_id]['error'] = 'addons.xml vacío o no válido'
            continue
        for aid, rver in remote.items():
            lver = installed.get(aid)
            if lver and is_newer(rver, lver):
                out[repo_id]['updates'].append({
                    'addon_id': aid, 'local': lver, 'remote': rver,
                })

    if progress_cb is not None:
        progress_cb(total, total, '')

    return out
