"""Acción 'Regenerar certificado HTTPS'.

Llamada desde Ajustes → Avanzado. Borra el cert autofirmado cached y
genera uno nuevo para la IP local actual. Útil si el usuario ha cambiado
de red (la IP nueva no estará en el SAN del cert antiguo).

Tras regenerar hay que reiniciar el service (o Kodi) para que el server
permanente reabra el socket con el nuevo cert.
"""
from lib import accessibility
from lib.remote import server_permanent, tls
from lib.ui_select import info


def run():
    if not accessibility.confirm_destructive(
        '¿Regenerar el certificado HTTPS?\n\n'
        'Tras regenerar, reinicia Kodi para que el panel sirva con el '
        'nuevo certificado. Los navegadores volverán a mostrar el aviso '
        'de seguridad la primera vez.',
    ):
        return
    ip = server_permanent.get_local_ip()
    if not ip:
        info(
            'No se pudo detectar la IP local.\n\n'
            'Asegúrate de estar conectado a WiFi o Ethernet.',
            title='loiolink',
        )
        return
    if tls.regenerate_cert(ip):
        accessibility.notify('Certificado regenerado. Reinicia Kodi.', ms=4000)
    else:
        info(
            'No se pudo regenerar el certificado.\n\n'
            'Comprueba que openssl está instalado. En Windows: instala '
            'git-for-windows (se buscará automáticamente) o añade openssl '
            'al PATH. En Linux/macOS suele estar preinstalado.',
            title='loiolink',
        )
