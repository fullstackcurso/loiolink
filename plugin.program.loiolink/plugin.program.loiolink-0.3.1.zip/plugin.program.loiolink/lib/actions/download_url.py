"""Acción 'Descargar desde URL': pide URL y delega a lib/transfers/pipeline.py."""
import xbmcgui

from lib.transfers import pipeline


def run():
    url = xbmcgui.Dialog().input('URL del archivo:')
    if not url:
        return
    pipeline.download_and_register(url, source='url')
