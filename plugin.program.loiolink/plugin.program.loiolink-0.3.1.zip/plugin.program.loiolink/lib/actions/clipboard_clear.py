"""Acción 'Limpiar portapapeles': borra el clipboard interno y notifica."""
import clipboard
from lib import accessibility


def run():
    clipboard.clear()
    accessibility.notify('Portapapeles limpiado', ms=1500)
