"""Submenu 'Marcadores': URLs favoritas curadas por el usuario.

A diferencia del historial:
- El usuario nombra cada marcador (auto-generado al añadir, renombrable luego).
- No hay bring-to-front al usarlo; el orden lo controla solo el usuario.
- Eliminación individual y renombrar disponibles via context menu.

Las URLs se añaden desde el context menu del historial ("Guardar en
marcadores") o desde "Pegar URL" eligiendo "Solo guardar en marcadores" o
"Guardar en marcadores y reproducir".
"""
import xbmc
import xbmcgui
import xbmcplugin

from lib import accessibility, url_bookmarks, url_input_history
from lib.actions._menu_common import HANDLE, begin, end, icon_path, make_item, url


_LABEL_TRUNC = 80
_NAME_MAX = 80


def run():
    begin('Marcadores')
    entries = url_bookmarks.load()
    if not entries:
        make_item(
            'No hay marcadores', url('noop'),
            'Añade marcadores desde el historial (pulsa "Menú" sobre una URL) '
            'o desde "Pegar URL" eligiendo "Solo guardar en marcadores".',
            icon='flowfav.png',
        )
        end()
        return
    make_item(
        '[COLOR red]Borrar todos los marcadores[/COLOR]',
        url('url_bookmarks_clear'),
        'Vacía la lista. La acción pide confirmación.',
        icon='delete.png',
    )
    fallback_icon = icon_path('flowfav.png')
    for entry in entries:
        u = entry.get('url', '')
        if not u:
            continue
        raw_name = entry.get('name') or u
        if len(raw_name) > _LABEL_TRUNC:
            raw_name = raw_name[:_LABEL_TRUNC - 1] + '…'
        name = accessibility.strip_bbcode(raw_name)
        plot = accessibility.strip_bbcode(u)
        thumb = entry.get('thumb') or ''

        li = xbmcgui.ListItem(accessibility.apply_label(name))
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
        if thumb:
            li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
        elif fallback_icon:
            li.setArt({'icon': fallback_icon, 'thumb': fallback_icon})

        cm = [
            ('Renombrar', f'RunPlugin({url("url_bookmark_rename", url=u)})'),
            ('Eliminar marcador', f'RunPlugin({url("url_bookmark_remove", url=u)})'),
        ]
        if u.startswith(('http://', 'https://')):
            cm.insert(0, ('Descargar', f'RunPlugin({url("url_history_download", url=u)})'))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(
            handle=HANDLE, url=url('open_url_input', url=u),
            listitem=li, isFolder=False,
        )
    end()


def clear():
    if not xbmcgui.Dialog().yesno('loiolink', '¿Borrar todos los marcadores?'):
        return
    if url_bookmarks.clear():
        accessibility.notify('Marcadores borrados', ms=2000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        accessibility.notify('No se pudo borrar los marcadores', ms=3000)


def add_from_history(url_param):
    """Acción `url_bookmark_add_from_history`: copia thumb/label de la entry
    del historial al marcador. Notifica según el resultado.
    """
    url_param = (url_param or '').strip()
    if not url_param:
        return
    entry = url_input_history.get(url_param)
    if entry is None:
        accessibility.notify('URL no encontrada en historial', ms=3000)
        return
    name = entry.get('label') or url_param
    thumb = entry.get('thumb') or ''
    added = url_bookmarks.add(url_param, name=name, thumb=thumb)
    accessibility.notify(
        'Añadido a marcadores' if added else 'Ya estaba en marcadores',
        ms=2000,
    )
    xbmc.executebuiltin('Container.Refresh')


def remove(url_param):
    """Acción `url_bookmark_remove`: elimina marcador y refresca."""
    if url_bookmarks.remove(url_param or ''):
        accessibility.notify('Marcador eliminado', ms=2000)
        xbmc.executebuiltin('Container.Refresh')


def rename(url_param):
    """Acción `url_bookmark_rename`: pide nuevo nombre con el actual pre-rellenado."""
    url_param = (url_param or '').strip()
    if not url_param:
        return
    entry = url_bookmarks.get(url_param)
    if entry is None:
        accessibility.notify('Marcador no encontrado', ms=3000)
        return
    new_name = xbmcgui.Dialog().input(
        'Nuevo nombre', defaultt=entry.get('name', ''),
    )
    if not new_name or not new_name.strip():
        return
    new_name = new_name.strip()[:_NAME_MAX]
    if url_bookmarks.rename(url_param, new_name):
        accessibility.notify('Marcador renombrado', ms=2000)
        xbmc.executebuiltin('Container.Refresh')
