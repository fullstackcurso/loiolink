"""Acción 'Revocar todas las sesiones del panel'.

Llamada desde el botón de Ajustes → Avanzado. Borra todas las sesiones
activas. Cualquier navegador pareado dejará de funcionar hasta que se
vuelva a escanear el QR.

Mantiene el nombre `regenerate_token` por compatibilidad con el ID del
setting (action="RunPlugin(plugin://plugin.program.loiolink/?action=
regenerate_token)"), pero el comportamiento es ahora "revocar todas
las sesiones"; el modelo de un único token global ya no existe.
"""
from lib import accessibility
from lib.remote import sessions


def run():
    count = len(sessions.load_all())
    if not accessibility.confirm_destructive(
        f'¿Revocar todas las sesiones del panel?\n\n'
        f'Hay {count} dispositivo(s) pareado(s). Todos dejarán de tener '
        'acceso al panel hasta que escaneen el QR otra vez.',
    ):
        return
    sessions.revoke_all()
    accessibility.notify('Sesiones revocadas', ms=3000)
