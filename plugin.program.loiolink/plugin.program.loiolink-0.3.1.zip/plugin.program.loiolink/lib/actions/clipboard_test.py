"""Submenú 'Test': depuración del flujo de pegado del menú contextual.

Cubre el mismo terreno que script.test.kbpaste pero integrado en el addon
y usando exactamente el `keyboard_input.send_text` que usa el menú
contextual en producción.

Cobertura:
  Copy buttons: 7 textos con distintos formatos (acentos, símbolos,
    unicode/emoji, largo, saltos).
  Pegar y ver: simula el flujo real; abre xbmc.Keyboard, inyecta el
    clipboard con send_text(done=True), compara getText() y isConfirmed().
  Suite quick: cada texto 1 vez con done=True (rápida, ~1 min).
  Suite flakiness: cada texto 3 veces con done=True, muestra pass rate
    (revela el bug Kodi 21+ intermitente).
  Comparativa done modes: texto del clipboard inyectado con done=True y
    done=False, lado a lado.
  Mutex stress: dos send_text concurrentes, verifica que el segundo
    aborta limpiamente.
"""
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcplugin

import clipboard
from lib import accessibility
from lib.remote import keyboard_input

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'

LOG_PREFIX = '[loiolink.clipboard_test]'


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{LOG_PREFIX} {msg}', level)

# (label visible, texto a inyectar)
_TEST_TEXTS = [
    ('Simple (mega)', 'mega'),
    ('Con espacios (mad max fury road)', 'mad max fury road'),
    ('Acentos (el niño)', 'el niño'),
    ('Símbolos ("doble" & noño)', 'Test "doble" \'simple\' & noño'),
    ('Unicode/emoji (中文 🎬)', 'mega 中文 🎬'),
    ('Texto largo (200 chars)', 'a' * 200),
    ('Con saltos (sanea)', 'línea1\nlínea2\tindented'),
]

_FLAKINESS_RUNS = 3


def _item(label, action, **params):
    li = xbmcgui.ListItem(label)
    parts = [f'action={action}']
    for k, v in params.items():
        parts.append(f'{k}={v}')
    url = f'{_BASE_URL}?{"&".join(parts)}'
    xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)


def run():
    _log('submenu render')
    for idx, (label, _text) in enumerate(_TEST_TEXTS):
        _item(f'Copiar: {label}', 'clipboard_test_copy', idx=idx)
    _item('=> Pegar clipboard en teclado simulado (1 pasada)',
          'clipboard_test_paste')
    _item('=> Suite quick (cada texto × 1, done=True)',
          'clipboard_test_suite')
    _item(f'=> Suite flakiness (cada texto × {_FLAKINESS_RUNS}, pass rate)',
          'clipboard_test_flakiness')
    _item('=> Comparativa done=True vs done=False (clipboard actual)',
          'clipboard_test_compare')
    _item('=> EJECUTAR TODOS (excepto mutex) + diagnóstico',
          'clipboard_test_all')
    _item('=> Mutex stress (test del mutex directo)',
          'clipboard_test_mutex')
    _item('=> IsActive vs IsVisible (qué detección dispara antes)',
          'clipboard_test_detection')
    # SORT_METHOD_UNSORTED preserva el orden de inserción. Sin esto Kodi
    # alfabetiza y el botón "Acentos" salta a posición 0, descolocando al
    # usuario sobre qué se copia con cada item.
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)


def copy(idx):
    try:
        i = int(idx or 0)
    except (TypeError, ValueError):
        _log(f'copy: idx inválido {idx!r}', xbmc.LOGWARNING)
        return
    if not (0 <= i < len(_TEST_TEXTS)):
        _log(f'copy: idx fuera de rango {i}', xbmc.LOGWARNING)
        return
    label, text = _TEST_TEXTS[i]
    clipboard.set(text)
    _log(f'copy idx={i} label={label!r} len={len(text)} text={text!r}')
    # Sin !r: si la fuente de Kodi no renderiza algún char (ñ, emoji), !r
    # devolvía 'el ni?o' con interrogantes que parecen X. Texto plano es
    # más legible y refleja exactamente lo que está en el clipboard.
    accessibility.notify(f'Copiado ({len(text)} chars): {text[:60]}',
                         ms=2500)


def _inject_into_kb(text, done=True, acquire_mutex=True, heading='Test'):
    """Abre xbmc.Keyboard en thread, inyecta `text` con send_text desde
    el main thread, espera al cierre y devuelve qué quedó.

    Si done=False, fuerza el cierre del keyboard con Action(Select) tras
    inyectar (kbpaste-style T1). Si no, el thread se quedaría colgado.

    Returns dict con kb_appeared, kb_text, confirmed, elapsed_ms.
    """
    _log(f'inject begin heading={heading!r} done={done} '
         f'acquire_mutex={acquire_mutex} text={text!r}')
    result = {'kb_appeared': False, 'kb_text': None,
              'confirmed': False, 'elapsed_ms': 0}

    def kb_runner():
        kb = xbmc.Keyboard('', heading)
        kb.doModal()
        result['confirmed'] = kb.isConfirmed()
        result['kb_text'] = kb.getText()

    t = threading.Thread(target=kb_runner, daemon=True)
    t.start()

    t0 = time.time()
    monitor = xbmc.Monitor()
    ok = keyboard_input.send_text(
        text, done=done,
        wait_appear_ms=8000, preview_delay_ms=0,
        monitor=monitor, acquire_mutex=acquire_mutex,
    )
    result['kb_appeared'] = ok

    if ok and not done:
        # done=False deja el kb abierto; cerrar con Aceptar para liberar.
        xbmc.sleep(500)
        xbmc.executebuiltin('Action(Select)')
    elif not ok:
        # Teclado no detectado: forzar cierre por si quedó algo.
        xbmc.executebuiltin('Action(PreviousMenu)')

    t.join(timeout=12)
    if t.is_alive():
        # Último recurso: si sigue vivo, lanzar Action(Close) y abandonar.
        _log('kb_runner sigue vivo tras 12s, forzando Action(Close)',
             xbmc.LOGWARNING)
        xbmc.executebuiltin('Action(Close)')
        t.join(timeout=2)
    result['elapsed_ms'] = int((time.time() - t0) * 1000)
    _log(f'inject end kb_appeared={result["kb_appeared"]} '
         f'confirmed={result["confirmed"]} '
         f'kb_text={result["kb_text"]!r} '
         f'elapsed_ms={result["elapsed_ms"]}')
    return result


def _verdict(text, r):
    if not r['kb_appeared']:
        return 'FAIL', 'teclado no apareció'
    if r['confirmed'] and r['kb_text'] == text:
        return 'PASS', f'{r["elapsed_ms"]}ms'
    if r['confirmed'] and not r['kb_text']:
        return 'FAIL', f'BUG buffer vacío ({r["elapsed_ms"]}ms)'
    if r['kb_text'] == text and not r['confirmed']:
        return 'PARCIAL', 'texto OK sin confirmar'
    return 'FAIL', f'got={r["kb_text"]!r} ({r["elapsed_ms"]}ms)'


def paste_and_see():
    _log('==== paste_and_see ====')
    text = clipboard.get()
    if not text:
        _log('paste_and_see: clipboard vacío, abortando')
        xbmcgui.Dialog().ok(
            'Test',
            'Clipboard vacío.\nCopia primero un texto de prueba.',
        )
        return
    r = _inject_into_kb(text, done=True, heading='Test: pegar clipboard')
    verdict, detail = _verdict(text, r)
    _log(f'paste_and_see VERDICTO: {verdict}: {detail}')
    lines = [
        'Pegar y ver: resultado',
        '=' * 40,
        '',
        f'Esperado:  {text!r}',
        f'Recibido:  {r["kb_text"]!r}',
        f'Keyboard apareció: {r["kb_appeared"]}',
        f'isConfirmed():     {r["confirmed"]}',
        f'Tiempo:            {r["elapsed_ms"]}ms',
        '',
        f'VEREDICTO: {verdict}: {detail}',
    ]
    if verdict == 'FAIL' and 'buffer vacío' in detail:
        lines.append('')
        lines.append('(bug Kodi 21+: Input.SendText cierra el kb con')
        lines.append(' buffer vacío. Suele pasar cuando el foco abre en')
        lines.append(' "Aceptar". El bug es INTERMITENTE; prueba de nuevo.)')
    _show_and_log('paste_and_see', 'Resultado', '\n'.join(lines))


def _render_report(title, rows):
    lines = [title, '=' * 60, '']
    pass_count = sum(1 for _, v, _ in rows if v == 'PASS')
    fail_count = sum(1 for _, v, _ in rows if v == 'FAIL')
    partial_count = sum(1 for _, v, _ in rows if v == 'PARCIAL')
    lines.append(
        f'Total: {len(rows)} | PASS: {pass_count} | '
        f'FAIL: {fail_count} | PARCIAL: {partial_count}'
    )
    lines.append('')
    for name, verdict, detail in rows:
        lines.append(name)
        lines.append(f'  {verdict}: {detail}')
        lines.append('')
    return '\n'.join(lines)


def _dump_to_log(title, text):
    """Vuelca el texto completo del report al log, línea a línea, para que
    quede grabado aunque el usuario cierre el textviewer sin guardarlo."""
    _log(f'---- REPORTE: {title} ----')
    for line in text.splitlines():
        _log(f'| {line}')
    _log(f'---- FIN REPORTE: {title} ----')


def _show_and_log(title, dialog_title, text):
    _dump_to_log(title, text)
    xbmcgui.Dialog().textviewer(dialog_title, text)


def _log_diagnostics():
    """Vuelca info del sistema relevante para depurar el bug Kodi 21+."""
    import xbmcaddon
    try:
        kodi_ver = xbmc.getInfoLabel('System.BuildVersion') or '?'
        kodi_build = xbmc.getInfoLabel('System.BuildDate') or '?'
        skin = xbmc.getInfoLabel('System.CurrentSkin') or '?'
        lang = xbmc.getInfoLabel('System.Language') or '?'
        addon = xbmcaddon.Addon()
        auto_conf = addon.getSettingBool('auto_confirm_search')
        preview = addon.getSetting('paste.preview_delay_s') or '0'
        only_search = addon.getSettingBool('only_on_search_items')
        kb_wait = addon.getSetting('keyboard_wait_seconds') or '8'
    except Exception as e:
        _log(f'diag: error leyendo info: {e}', xbmc.LOGWARNING)
        return
    _log('---- DIAGNÓSTICO ----')
    _log(f'| Kodi: {kodi_ver} build={kodi_build}')
    _log(f'| Skin: {skin} | Idioma: {lang}')
    _log(f'| Settings:')
    _log(f'|   auto_confirm_search={auto_conf}')
    _log(f'|   paste.preview_delay_s={preview}')
    _log(f'|   only_on_search_items={only_search}')
    _log(f'|   keyboard_wait_seconds={kb_wait}')
    _log(f'|   POST_KB_DETECT_DELAY_MS={keyboard_input.POST_KB_DETECT_DELAY_MS}')
    _log(f'|   MUTEX_STALE_SECONDS={keyboard_input.MUTEX_STALE_SECONDS}')
    _log('---- FIN DIAGNÓSTICO ----')


def _suite_rows(heading_prefix='Suite'):
    """Core: cada texto × 1 pasada con done=True. Returns rows."""
    rows = []
    for label, text in _TEST_TEXTS:
        _log(f'--- {label} ---')
        r = _inject_into_kb(text, done=True,
                            heading=f'{heading_prefix}: {label[:30]}')
        verdict, detail = _verdict(text, r)
        _log(f'{label}: {verdict}: {detail}')
        rows.append((label, verdict, detail))
        xbmc.sleep(500)
    return rows


def suite():
    """Cada texto × 1 pasada con done=True."""
    _log('==== suite quick INICIO ====')
    if not xbmcgui.Dialog().yesno(
        'Suite quick',
        f'Lanzará {len(_TEST_TEXTS)} teclados (~{len(_TEST_TEXTS) * 5}s).\n'
        'NO uses el mando durante la suite.\n\nContinuar?',
    ):
        _log('suite cancelada por usuario')
        return
    rows = _suite_rows()
    _log('==== suite quick FIN ====')
    _show_and_log('suite quick', 'Resultados',
                  _render_report('Suite quick: resultados', rows))


def _flakiness_rows(heading_prefix='Flak'):
    """Core: cada texto × N pasadas con done=True. Returns rows."""
    rows = []
    for label, text in _TEST_TEXTS:
        _log(f'--- {label} ({_FLAKINESS_RUNS} runs) ---')
        pass_n = 0
        fails = []
        for run_i in range(_FLAKINESS_RUNS):
            _log(f'  run {run_i + 1}/{_FLAKINESS_RUNS}')
            r = _inject_into_kb(text, done=True,
                                heading=f'{heading_prefix}: {label[:30]}')
            v, d = _verdict(text, r)
            _log(f'  run {run_i + 1}: {v}: {d}')
            if v == 'PASS':
                pass_n += 1
            else:
                fails.append(d)
            xbmc.sleep(500)
        verdict = ('PASS' if pass_n == _FLAKINESS_RUNS
                   else 'FAIL' if pass_n == 0
                   else 'FLAKY')
        detail = f'{pass_n}/{_FLAKINESS_RUNS}'
        if fails:
            detail += f' | fails: {"; ".join(fails[:2])}'
        _log(f'{label}: {verdict}: {detail}')
        rows.append((label, verdict, detail))
    return rows


def flakiness():
    """Cada texto × N pasadas. Pass rate por texto."""
    _log(f'==== suite flakiness INICIO ({_FLAKINESS_RUNS} runs) ====')
    total = len(_TEST_TEXTS) * _FLAKINESS_RUNS
    if not xbmcgui.Dialog().yesno(
        'Suite flakiness',
        f'Lanzará {total} teclados (~{total * 5}s).\n'
        f'Cada texto se prueba {_FLAKINESS_RUNS} veces.\n'
        'NO uses el mando durante la suite.\n\nContinuar?',
    ):
        _log('flakiness cancelada por usuario')
        return
    rows = _flakiness_rows()
    _log('==== suite flakiness FIN ====')
    _show_and_log(
        'suite flakiness', 'Resultados',
        _render_report(f'Suite flakiness ({_FLAKINESS_RUNS}× cada texto)',
                       rows),
    )


def _compare_one(text, heading_prefix):
    """Core: una pasada done=True + una pasada done=False para `text`.
    Returns ((v_true, d_true, r_true), (v_false, d_false, r_false))."""
    _log(f'compare done=True text={text!r}')
    r_true = _inject_into_kb(text, done=True,
                             heading=f'{heading_prefix} done=True')
    xbmc.sleep(500)
    _log(f'compare done=False text={text!r}')
    r_false = _inject_into_kb(text, done=False,
                              heading=f'{heading_prefix} done=False')
    v_true, d_true = _verdict(text, r_true)
    v_false, d_false = _verdict(text, r_false)
    _log(f'compare done=True VERDICTO: {v_true}: {d_true}')
    _log(f'compare done=False VERDICTO: {v_false}: {d_false}')
    return (v_true, d_true, r_true), (v_false, d_false, r_false)


def _compare_rows():
    """Core: compara done=True/False para CADA texto. Returns rows."""
    rows = []
    for label, text in _TEST_TEXTS:
        _log(f'--- compare {label} ---')
        (vt, dt, _), (vf, df, _) = _compare_one(
            text, f'CompAll: {label[:20]}'
        )
        rows.append((f'{label} | done=True', vt, dt))
        rows.append((f'{label} | done=False', vf, df))
        xbmc.sleep(500)
    return rows


def compare():
    """Compara done=True vs done=False para el clipboard actual."""
    _log('==== compare INICIO ====')
    text = clipboard.get()
    if not text:
        _log('compare: clipboard vacío, abortando')
        xbmcgui.Dialog().ok(
            'Test', 'Clipboard vacío. Copia primero un texto.',
        )
        return
    if not xbmcgui.Dialog().yesno(
        'Comparativa',
        f'Lanzará 2 teclados con el clipboard ({text[:40]!r}).\n'
        'Continuar?',
    ):
        _log('compare cancelada por usuario')
        return
    (v_true, d_true, r_true), (v_false, d_false, r_false) = _compare_one(
        text, 'Compare:'
    )
    _log('==== compare FIN ====')
    lines = [
        'Comparativa done=True vs done=False',
        '=' * 60,
        '',
        f'Texto: {text!r}',
        '',
        f'done=True:  {v_true}: {d_true}',
        f'  text={r_true["kb_text"]!r} confirmed={r_true["confirmed"]}',
        '',
        f'done=False: {v_false}: {d_false}',
        f'  text={r_false["kb_text"]!r} confirmed={r_false["confirmed"]}',
        '',
        '(done=False cierra el kb con Action(Select) tras 500ms; sirve',
        ' para comprobar si el texto AL MENOS llega al buffer.)',
    ]
    _show_and_log('compare', 'Comparativa', '\n'.join(lines))


def mutex():
    """Test del mutex de keyboard_input directo, SIN abrir keyboards.

    El diseño anterior abría 2 xbmc.Keyboard concurrentes pero Kodi solo
    permite UN modal activo: el primero bloqueaba el segundo en doModal()
    indefinidamente y el resultado era siempre "ambos kb_appeared=False"
    porque send_text no llegaba a detectar ningún teclado (los modals
    chocaban antes). El test era un falso positivo de "mutex roto".

    Ahora testeamos las 4 propiedades reales del mutex:
      A) acquire en estado limpio devuelve True
      B) acquire mientras está tomado devuelve False (incluso desde otro hilo)
      C) release lo libera y permite re-acquire
      D) stale (>MUTEX_STALE_SECONDS antiguo) se reclama automáticamente
    """
    _log('==== mutex test INICIO ====')
    if not xbmcgui.Dialog().yesno(
        'Mutex test',
        'Verifica el comportamiento del mutex de keyboard_input\n'
        '(adquirir, bloquear, liberar, reclamar stale).\n'
        'NO abre teclados, dura ~1s.\n\nContinuar?',
    ):
        _log('mutex cancelada por usuario')
        return

    # Limpiar estado previo por si quedó algo de un test anterior.
    keyboard_input._mutex_release()

    rows = []

    # A) acquire en estado limpio → True
    a_ok = keyboard_input._mutex_acquire()
    rows.append((
        'A) acquire en estado limpio',
        'PASS' if a_ok is True else 'FAIL',
        f'got={a_ok!r} (esperado True)',
    ))
    _log(f'A) acquire limpio → {a_ok}')

    # B) acquire mientras está tomado (desde otro hilo) → False
    held = [None]

    def try_acquire():
        held[0] = keyboard_input._mutex_acquire()

    t = threading.Thread(target=try_acquire, daemon=True)
    t.start()
    t.join(timeout=2)
    b_ok = held[0]
    rows.append((
        'B) acquire bloqueado por otro hilo',
        'PASS' if b_ok is False else 'FAIL',
        f'got={b_ok!r} (esperado False)',
    ))
    _log(f'B) acquire bloqueado → {b_ok}')

    # C) release + re-acquire desde otro hilo → True
    keyboard_input._mutex_release()
    held[0] = None
    t = threading.Thread(target=try_acquire, daemon=True)
    t.start()
    t.join(timeout=2)
    c_ok = held[0]
    rows.append((
        'C) re-acquire tras release',
        'PASS' if c_ok is True else 'FAIL',
        f'got={c_ok!r} (esperado True)',
    ))
    _log(f'C) re-acquire tras release → {c_ok}')

    # Limpiar para D.
    keyboard_input._mutex_release()

    # D) stale (mutex viejo > MUTEX_STALE_SECONDS) se reclama
    # Falseamos un mutex "viejo" escribiendo un timestamp del pasado.
    win = xbmcgui.Window(10000)
    stale_ts = int(time.time()) - keyboard_input.MUTEX_STALE_SECONDS - 1
    win.setProperty(keyboard_input.MUTEX_PROP, str(stale_ts))
    d_ok = keyboard_input._mutex_acquire()
    rows.append((
        f'D) mutex stale (>{keyboard_input.MUTEX_STALE_SECONDS}s) reclamado',
        'PASS' if d_ok is True else 'FAIL',
        f'got={d_ok!r} (esperado True, ts era {stale_ts})',
    ))
    _log(f'D) stale reclamado → {d_ok}')

    # Cleanup final.
    keyboard_input._mutex_release()
    _log('==== mutex test FIN ====')

    _show_and_log(
        'mutex', 'Mutex',
        _render_report('Mutex (test directo, 4 propiedades)', rows),
    )


def detection():
    """T5 estilo kbpaste: compara cuál condition dispara antes para el
    mismo teclado: Window.IsActive(virtualkeyboard) vs IsVisible.

    Útil para diagnosticar si nuestra detección actual (IsActive) está
    perdiendo ventana de oportunidad para inyectar el texto.
    """
    _log('==== detection test INICIO ====')
    if not xbmcgui.Dialog().yesno(
        'Detección IsActive vs IsVisible',
        'Lanza un teclado y mide cuántos ms tarda en dispararse cada\n'
        'condition. NO inyecta texto.\n'
        'Tarda ~3s. NO uses el mando.\n\nContinuar?',
    ):
        _log('detection cancelada por usuario')
        return

    timings = {'IsActive': None, 'IsVisible': None}
    kb_closed = threading.Event()

    def kb_runner():
        kb = xbmc.Keyboard('', 'Detection test (cierra con ESC)')
        kb.doModal()
        kb_closed.set()

    t = threading.Thread(target=kb_runner, daemon=True)
    t.start()
    t0 = time.time()

    # Polling rápido (10ms) para captar cuál se activa primero.
    timeout_ms = 5000
    elapsed = 0
    while elapsed < timeout_ms and (timings['IsActive'] is None
                                     or timings['IsVisible'] is None):
        now_ms = int((time.time() - t0) * 1000)
        if timings['IsActive'] is None:
            if xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'):
                timings['IsActive'] = now_ms
                _log(f'IsActive disparó a {now_ms}ms')
        if timings['IsVisible'] is None:
            if xbmc.getCondVisibility('Window.IsVisible(virtualkeyboard)'):
                timings['IsVisible'] = now_ms
                _log(f'IsVisible disparó a {now_ms}ms')
        xbmc.sleep(10)
        elapsed += 10

    # Cerrar el kb para liberar al usuario.
    xbmc.executebuiltin('Action(PreviousMenu)')
    t.join(timeout=3)
    _log('==== detection test FIN ====')

    ta = timings['IsActive']
    tv = timings['IsVisible']
    lines = [
        'Detección IsActive vs IsVisible',
        '=' * 60,
        '',
        f'Window.IsActive(virtualkeyboard):  '
        f'{ta}ms' if ta is not None else 'NO disparó (timeout)',
        f'Window.IsVisible(virtualkeyboard): '
        f'{tv}ms' if tv is not None else 'NO disparó (timeout)',
        '',
    ]
    if ta is not None and tv is not None:
        diff = abs(ta - tv)
        first = 'IsActive' if ta <= tv else 'IsVisible'
        lines.append(f'Primero: {first} (diferencia {diff}ms)')
        if diff > 200:
            lines.append(f'⚠ Diferencia >200ms: considerar usar {first}')
        else:
            lines.append('Diferencia despreciable, da igual cuál.')
    elif ta is None and tv is None:
        lines.append('⚠ Ninguna detección disparó; algo raro pasa.')
    else:
        lines.append('⚠ Solo una disparó: usar esa.')
    _log(f'detection IsActive={ta}ms IsVisible={tv}ms')
    _show_and_log('detection', 'Detection', '\n'.join(lines))


def run_all_no_mutex():
    """Ejecuta quick + flakiness + compare (todos los textos), excluyendo
    mutex. Vuelca diagnóstico del sistema y reporte agregado al log."""
    _log('==== run_all_no_mutex INICIO ====')
    _log_diagnostics()
    total_kb = (
        len(_TEST_TEXTS)               # quick
        + len(_TEST_TEXTS) * _FLAKINESS_RUNS  # flakiness
        + len(_TEST_TEXTS) * 2         # compare (done=True + done=False)
    )
    eta_s = total_kb * 5
    if not xbmcgui.Dialog().yesno(
        'Ejecutar todos',
        f'Lanzará {total_kb} teclados (~{eta_s // 60}m {eta_s % 60}s).\n'
        f'Incluye: quick + flakiness ({_FLAKINESS_RUNS}×) + compare\n'
        '(done=True/False por cada texto).\n'
        'Excluye mutex.\n\n'
        'NO uses el mando durante la suite.\n\nContinuar?',
    ):
        _log('run_all_no_mutex cancelada por usuario')
        return

    _log('---- bloque QUICK ----')
    quick_rows = _suite_rows('All-Q')
    _log('---- bloque FLAKINESS ----')
    flak_rows = _flakiness_rows('All-F')
    _log('---- bloque COMPARE ----')
    comp_rows = _compare_rows()
    _log('==== run_all_no_mutex FIN ====')

    # Reporte combinado
    parts = [
        _render_report('BLOQUE 1: Suite quick', quick_rows),
        '',
        _render_report(
            f'BLOQUE 2: Suite flakiness ({_FLAKINESS_RUNS}x cada texto)',
            flak_rows,
        ),
        '',
        _render_report(
            'BLOQUE 3: Comparativa done=True/False por texto',
            comp_rows,
        ),
    ]
    combined = '\n'.join(parts)
    _show_and_log('run_all_no_mutex', 'Resultados', combined)
