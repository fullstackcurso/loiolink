"""Acciones sobre una entrada del historial.

Se invoca desde el router con ?action=entry&id=<entry_id>. Muestra un
contextmenu con las opciones disponibles según el tipo del archivo.
"""
import json

import xbmc
import xbmcgui

from lib import accessibility, log
from lib.transfers import checksums, history
from lib.ui_select import CloseMenu, SelectItem, confirm, info, menu, show_text


def run(entry_id):
    if not entry_id:
        return
    entry = history.get(entry_id)
    if entry is None:
        accessibility.notify('Entrada no encontrada', xbmcgui.NOTIFICATION_WARNING, 2000)
        return

    options = _options_for(entry)
    chosen = {'fn': None}

    def _make_action(fn):
        def _do():
            chosen['fn'] = fn
            raise CloseMenu()
        return _do

    def _build():
        return [SelectItem(opt['label'], plot=opt.get('plot', ''), action=_make_action(opt['action']))
                for opt in options]

    menu(f"Acciones: {entry['name']}", _build, show_icons=False)
    if chosen['fn']:
        chosen['fn'](entry)


_PLOT_PLAY = 'Lanza el archivo en el reproductor de Kodi.'
_PLOT_VIEW_IMAGE = 'Abre la imagen en pantalla completa.'
_PLOT_INSTALL_ADDON = 'Instala el ZIP como addon de Kodi. Disponible al momento sin reiniciar.'
_PLOT_INSTALL_REPO = 'Añade el repositorio a Kodi para instalar o actualizar addons desde él.'
_PLOT_INSTALL_APK = (
    'Lanza el instalador nativo de Android. '
    'Requiere tener activada la opción "Instalar apps desconocidas" para Kodi en '
    'Ajustes del dispositivo. Solo funciona en Android (Fire TV, Android TV).'
)
_PLOT_PLAY_TORRENT = 'Carga el torrent en Elementum para streaming directo, sin esperar la descarga completa.'
_PLOT_STREAM = 'Muestra un QR para abrir el archivo en el navegador de cualquier dispositivo de la misma red.'
_PLOT_CHECKSUMS = 'Calcula y muestra MD5 y SHA-256. Útil para verificar que el archivo no está corrupto.'
_PLOT_COPY_NAME = 'Copia el nombre del archivo al portapapeles del sistema.'
_PLOT_DELETE = 'Elimina la entrada del historial y borra el archivo del disco de forma permanente.'


def _options_for(entry):
    opts = []
    kind = entry['kind']

    if kind in ('video', 'audio'):
        opts.append({'label': 'Reproducir', 'plot': _PLOT_PLAY, 'action': _act_play})
    elif kind == 'image':
        opts.append({'label': 'Ver imagen', 'plot': _PLOT_VIEW_IMAGE, 'action': _act_show_picture})
    elif kind in ('addon_zip', 'repo_zip'):
        label = 'Instalar addon' if kind == 'addon_zip' else 'Instalar repositorio'
        plot = _PLOT_INSTALL_ADDON if kind == 'addon_zip' else _PLOT_INSTALL_REPO
        opts.append({'label': label, 'plot': plot, 'action': _act_install})
    elif kind == 'apk':
        opts.append({'label': 'Instalar APK', 'plot': _PLOT_INSTALL_APK, 'action': _act_install_apk})
    elif kind == 'torrent':
        opts.append({'label': 'Reproducir con Elementum', 'plot': _PLOT_PLAY_TORRENT, 'action': _act_play_torrent})

    if kind in ('video', 'audio', 'image'):
        opts.append({'label': 'Ver en otro dispositivo', 'plot': _PLOT_STREAM, 'action': _act_stream_to_mobile})

    opts.append({'label': 'Ver checksums (MD5 / SHA-256)', 'plot': _PLOT_CHECKSUMS, 'action': _act_show_checksums})
    opts.append({'label': 'Copiar nombre al portapapeles', 'plot': _PLOT_COPY_NAME, 'action': _act_copy_name})
    opts.append({'label': 'Borrar entrada', 'plot': _PLOT_DELETE, 'action': _act_delete})
    return opts


def _play_via_jsonrpc(path):
    """Player.Open evita el bug de PlayMedia con comas (kodi#14838)."""
    req = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
        'params': {'item': {'file': path}},
    }
    xbmc.executeJSONRPC(json.dumps(req))


def _file_missing_handle(entry):
    """Si el archivo de la entry ya no existe en disco, ofrece borrar la
    entrada huérfana del historial. Devuelve True si el archivo falta (el
    caller debe abortar la acción).
    """
    import xbmcvfs
    if xbmcvfs.exists(entry['path']):
        return False
    if confirm(
        f"Archivo no encontrado:\n{entry['name']}\n\n"
        '¿Borrar entrada del historial?',
        title='loiolink',
        default_no=True,
    ):
        history.delete(entry['id'], remove_file=False)
        xbmc.executebuiltin('Container.Refresh')
    else:
        history.update(entry['id'], action_taken='missing')
    return True


def _act_play(entry):
    if _file_missing_handle(entry):
        return
    _play_via_jsonrpc(entry['path'])
    history.update(entry['id'], action_taken='played')


def _act_show_picture(entry):
    if _file_missing_handle(entry):
        return
    escaped = entry['path'].replace('"', '\\"')
    xbmc.executebuiltin(f'ShowPicture("{escaped}")')
    history.update(entry['id'], action_taken='played')


def _act_install(entry):
    if _file_missing_handle(entry):
        return
    from lib import installer
    kind = 'repo' if entry['kind'] == 'repo_zip' else 'addon'
    try:
        ok = installer.install_zip(entry['path'], entry['addon_id'], kind=kind)
    except installer.InstallBusyError:
        accessibility.notify(
            'Ya hay una instalación en curso. Espera a que termine.', ms=3500,
        )
        return
    except installer.InstallError as e:
        log.error(f'InstallError: {e}')
        info(f'Error instalando: {e}', title='loiolink')
        history.update(entry['id'], action_taken='install_failed')
        return
    history.update(entry['id'],
                   action_taken='installed' if ok else 'install_failed')
    if ok:
        accessibility.notify(f"{entry['addon_id']} instalado.", ms=2000)
    else:
        info(
            f"Instalación de {entry['addon_id']} falló. Ver kodi.log.",
            title='loiolink',
        )


def _act_install_apk(entry):
    if _file_missing_handle(entry):
        return
    from lib import installer
    if not installer.is_android():
        info(
            'La instalación de APK solo funciona en Android (Fire TV, Android TV).\n\n'
            'En Windows o Linux puedes copiar el archivo y transferirlo manualmente.',
            title='loiolink',
        )
        return
    if not confirm(
        f"{entry['name']}\n\n"
        '¿Instalar este APK? Se abrirá el instalador de Android.\n\n'
        'Requiere activar la instalación de apps desconocidas '
        'en los Ajustes de Android.',
        title='loiolink',
        default_no=False,
    ):
        history.update(entry['id'], action_taken='declined')
        return
    try:
        public_path = installer.install_apk(entry['path'])
    except installer.InstallBusyError:
        accessibility.notify(
            'Ya hay una instalación en curso. Espera a que termine.', ms=3500,
        )
        return
    except installer.InstallError as e:
        log.error(f'install_apk falló: {e}')
        info(
            f'No se pudo lanzar el instalador.\n\n{e}\n\n'
            + installer.HINT_ANDROID_PERMISSIONS,
            title='loiolink',
        )
        history.update(entry['id'], action_taken='install_failed')
        return
    history.update(entry['id'], action_taken='install_launched')
    # Fallback informativo: en Kodi 21- con Android 7+ el installer puede
    # fallar silenciosamente. Avisamos de dónde está el APK por si hay
    # que abrirlo manualmente desde un gestor de archivos.
    accessibility.notify(
        f'APK preparado en {public_path}. Si el instalador no aparece, '
        f'ábrelo desde un gestor de archivos.',
        ms=7000,
    )


def _act_play_torrent(entry):
    if _file_missing_handle(entry):
        return
    from lib.remote import elementum
    if not elementum.is_installed():
        from lib.actions import elementum as elementum_install
        if not elementum_install.install_with_progress():
            return
        if not elementum.is_installed():
            return
    elementum.play(entry['path'])
    history.update(entry['id'], action_taken='played_elementum')


def _act_stream_to_mobile(entry):
    """Muestra QR con /stream-page/<id> para verlo en el navegador del móvil.

    El service permanente sirve el HTML5 player con seek + sincronización.
    Si el navegador no soporta el códec, el <video> mostrará error y el
    usuario tendrá que usar otro reproductor.
    """
    import xbmcgui as _xbmcgui

    val = _xbmcgui.Window(10000).getProperty('loiolink.remote.port')
    try:
        port = int(val) if val else None
    except (TypeError, ValueError):
        port = None
    if port is None:
        info(
            'El servicio de control remoto aún no está disponible.\n\n'
            'Asegúrate de que Kodi terminó de arrancar y vuelve a intentar.',
            title='loiolink',
        )
        return

    from lib.remote import server_permanent
    ip = server_permanent.get_local_ip()
    if not ip:
        info(
            'No se pudo detectar la IP local.\n\n'
            'Asegúrate de estar conectado a WiFi o Ethernet.',
            title='loiolink',
        )
        return

    # URL corta (sin token) para texto visible. El QR sí lleva ?t= con un
    # token de sesión ad-hoc para que el primer acceso del móvil cuaje la
    # cookie persistente y los accesos posteriores a la URL corta funcionen.
    from lib.remote import sessions, tls
    sessions.purge_unscanned()
    session = sessions.add(label=sessions.UNSCANNED_LABEL, ua='')
    token = session['token']
    session_id = session['id']
    short_url = f'{tls.scheme()}://{ip}:{port}/stream-page/{entry["id"]}'
    qr_url = f'{short_url}?t={token}'
    log.info(f'Stream QR: short={short_url} sesion_id={session_id}')

    # Reutilizamos el modal info-only de remote_qr. show_pin_option=False
    # porque el PIN del panel raíz no redirige a /stream-page/<id> tras
    # emparejar (iría a /), confundiendo al usuario.
    from lib.actions import remote_qr
    dlg = remote_qr._QRInfoDialog(short_url, qr_url=qr_url, show_pin_option=False)
    try:
        dlg.doModal()
    finally:
        dlg.cleanup()
        sessions.revoke_if_unscanned(session_id)


def _act_show_checksums(entry):
    if not entry.get('sha256') and _file_missing_handle(entry):
        return
    if not entry.get('sha256'):
        progress = xbmcgui.DialogProgress()
        progress.create('loiolink', 'Calculando checksums...')
        try:
            md5, sha = checksums.compute_hashes(entry['path'])
        except OSError as e:
            progress.close()
            info(f'Error leyendo archivo: {e}', title='loiolink')
            return
        progress.close()
        history.update(entry['id'], md5=md5, sha256=sha)
        entry['md5'] = md5
        entry['sha256'] = sha

    show_text(
        'loiolink: checksums',
        f"MD5:\n{entry['md5']}\n\nSHA-256:\n{entry['sha256']}",
    )


def _act_copy_name(entry):
    from lib import os_clipboard
    import clipboard as internal
    # Mejor esfuerzo: intentar clipboard del SO, fallback al interno.
    try:
        ok = os_clipboard.set_system_clipboard(entry['name'])
    except os_clipboard.NotSupportedError:
        ok = False
    if not ok:
        internal.set(entry['name'])
    accessibility.notify('Nombre copiado', ms=1500)


def _act_delete(entry):
    if not accessibility.confirm_destructive(
        f"Borrar {entry['name']}?\n\nTambién borra el archivo del disco.",
    ):
        return
    history.delete(entry['id'], remove_file=True)
    xbmc.executebuiltin('Container.Refresh')
