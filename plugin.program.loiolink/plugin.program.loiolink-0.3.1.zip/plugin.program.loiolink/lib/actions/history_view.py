"""Visor del historial de transferencias. Ordenado por fecha desc."""
import datetime
import os
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from lib import i18n
from lib.transfers import history


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'

_ICONS_DIR = os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'),
    'resources', 'media', 'historial',
)

_ICONS = {
    'video': 'video.png', 'audio': 'audio.png', 'image': 'image.png',
    'torrent': 'torrent.png',
    'addon_zip': 'addon.png', 'repo_zip': 'repo.png',
    'unknown_zip': 'zip.png', 'other': 'file.png',
}


def run():
    entries = history.list_all()
    if not entries:
        from lib import accessibility
        accessibility.notify(i18n.L(30021), ms=2000)  # 'Historial (vacío)'
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=True)
        return

    for entry in entries:
        _render_entry(entry)
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)


def _render_entry(entry):
    label = entry['name']
    plot = _build_plot(entry)

    li = xbmcgui.ListItem(label)
    li.setInfo('video', {'plot': plot})

    icon_name = _ICONS.get(entry['kind'], 'file.png')
    icon_path = os.path.join(_ICONS_DIR, icon_name)
    if os.path.isfile(icon_path):
        li.setArt({'icon': icon_path, 'thumb': icon_path})

    url = f"{_BASE_URL}?action=entry&id={entry['id']}"
    xbmcplugin.addDirectoryItem(
        handle=_HANDLE, url=url, listitem=li, isFolder=False,
    )


def _build_plot(entry):
    parts = [
        entry['kind'],
        _human_size(entry['size']),
        _human_age(entry['created_at']),
    ]
    if entry.get('truncated'):
        parts.append('[truncado]')
    path = entry.get('path')
    if path and not xbmcvfs.exists(path):
        parts.append('[no disponible]')
    if entry.get('action_taken'):
        parts.append(f"[{entry['action_taken']}]")
    return ' · '.join(parts)


def _human_size(n):
    n = float(n or 0)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024:
            return f'{n:.0f} {unit}' if unit == 'B' else f'{n:.1f} {unit}'
        n /= 1024
    return f'{n:.1f} PB'


def _human_age(ts):
    delta = datetime.datetime.now() - datetime.datetime.fromtimestamp(ts)
    if delta.days > 0:
        return f'hace {delta.days} día{"s" if delta.days > 1 else ""}'
    h = delta.seconds // 3600
    if h > 0:
        return f'hace {h} h'
    m = max(1, delta.seconds // 60)
    return f'hace {m} min'
