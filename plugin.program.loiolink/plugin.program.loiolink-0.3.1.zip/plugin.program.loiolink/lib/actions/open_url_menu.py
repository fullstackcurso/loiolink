"""Submenu 'Abrir URL': pegar URL, historial y StreamNinja.

Agrupa el flujo de introducir URLs a mano (con su historial persistente) junto
con StreamNinja, que es la alternativa potente para casos que paste_clipboard
no resuelve (YouTube/DM cuando no hay addon resolver, Twitch, etc.).
"""
from lib import i18n, url_bookmarks, url_input_history
from lib.actions import streamninja
from lib.actions._menu_common import begin, end, make_item, url


_PLOT_PASTE_URL = (
    'Abre el teclado de Kodi y escribes o pegas una URL. Si tienes algo '
    'copiado en el portapapeles del sistema que parece una URL reproducible, '
    'el cuadro aparece pre-rellenado con ella; basta con pulsar OK. Tras '
    'introducir la URL, el addon detecta el tipo (YouTube, Dailymotion, '
    'magnet...) y te ofrece reproducir, guardar en marcadores o ambas cosas.'
)
_PLOT_HISTORY = (
    'Lista de las últimas URLs introducidas en "Pegar URL", con sus '
    'carátulas cuando es posible (YouTube, Dailymotion, Vimeo, RTVE y webs '
    'con og:image). Pulsa "Menú" sobre una entrada para descargar, guardar '
    'en marcadores o eliminar.'
)
_PLOT_BOOKMARKS = (
    'URLs que has marcado como favoritas. A diferencia del historial, los '
    'marcadores son curados: tú decides cuáles guardar y con qué nombre. '
    'Renombrar o eliminar disponible en "Menú" sobre cada marcador.'
)
_PLOT_STREAMNINJA = (
    'Si necesitas enviar URLs a Kodi de forma remota, StreamNinja es el addon '
    'más especializado y completo para eso. Permite recibirlas desde un '
    'móvil o PC mediante una web local, o bien directamente desde otros '
    'addons. Soporta Dailymotion, YouTube, AceStream, Torrents y casi '
    'cualquier enlace de vídeo.'
    '\n\n'
    'Si está instalado se abre directamente. Si no, te guiará para '
    'instalarlo en un solo paso.'
)


def _history_label():
    n = url_input_history.count()
    if n == 0:
        return 'Historial de URLs (vacío)'
    return f'Historial de URLs ({n})'


def _bookmarks_label():
    n = url_bookmarks.count()
    if n == 0:
        return 'Marcadores (vacío)'
    return f'Marcadores ({n})'


def _streamninja_label():
    return i18n.L(30006) if streamninja.is_installed() else i18n.L(30007)


def run():
    begin('Abrir URL')
    make_item(
        'Pegar URL', url('open_url_input'),
        _PLOT_PASTE_URL, icon='url.png',
    )
    make_item(
        _history_label(), url('url_input_history_menu'),
        _PLOT_HISTORY, icon='history.png', is_folder=True,
    )
    make_item(
        _bookmarks_label(), url('url_bookmarks_menu'),
        _PLOT_BOOKMARKS, icon='flowfav.png', is_folder=True,
    )
    make_item(
        _streamninja_label(), url('streamninja'),
        _PLOT_STREAMNINJA, icon='streamninja.png',
    )
    end()
