import os
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui


def run():
    path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'index.html')
    if not os.path.isfile(path):
        xbmcgui.Dialog().notification('loiolink', 'Manual no encontrado', xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    url = Path(path).as_uri()
    if xbmc.getCondVisibility('System.Platform.Android'):
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","text/html","{url}")')
        xbmcgui.Dialog().notification('loiolink', 'Abriendo manual de usuario...', xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        import webbrowser
        try:
            ok = webbrowser.open(url)
        except webbrowser.Error:
            ok = False
        if ok:
            xbmcgui.Dialog().notification('loiolink', 'Abriendo manual de usuario...', xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification('loiolink', 'No se pudo abrir el navegador', xbmcgui.NOTIFICATION_ERROR, 4000)
