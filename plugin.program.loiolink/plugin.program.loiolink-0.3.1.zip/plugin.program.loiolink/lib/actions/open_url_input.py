"""Acción 'Pegar URL': abre teclado Kodi, procesa la URL y la guarda.

Dos rutas distintas:

A) `url` viene como parámetro (click en una URL del historial o de marcadores):
   - Skip diálogos.
   - `url_input_history.touch(url)` para bring-to-front si la URL ya estaba en
     el historial. Si era de marcadores y NO estaba en historial, no se añade
     (los marcadores son curados aparte).
   - Procesa con `paste_clipboard.process_text`.

B) `url is None` (botón "Pegar URL" del menú):
   - Dialog.input pre-rellenado con clipboard del SO si parece URL.
   - DialogProgressBG mientras se resuelven thumb/label (hasta 6s peor caso).
   - Dialog.select con 3 opciones: reproducir / marcador+reproducir / solo marcador.
   - Cancel del select → no toca ni historial ni marcadores.
"""
import xbmc
import xbmcgui

from lib import (
    accessibility,
    os_clipboard,
    thumb_resolver,
    url_bookmarks,
    url_input_history,
    url_utils,
)
from lib.actions import paste_clipboard


def run(url=None):
    if url:
        _run_from_existing(url)
        return
    _run_from_keyboard()


def _run_from_existing(url):
    url = url.strip()
    if not url:
        return
    url_input_history.touch(url)
    xbmc.executebuiltin('Container.Refresh')
    paste_clipboard.process_text(url)


def _run_from_keyboard():
    prefill = (os_clipboard.get_system_clipboard() or '').strip()
    if not url_utils.mux(prefill):
        prefill = ''
    new_url = xbmcgui.Dialog().input('URL de vídeo:', defaultt=prefill)
    if not new_url or not new_url.strip():
        return
    new_url = new_url.strip()

    # Resolver metadatos con feedback no bloqueante. Peor caso ~6s (Vimeo o
    # web genérica que hace HTTP de thumb + label). YouTube/DM/RTVE solo
    # hacen HTTP del label (~3s); magnet/acestream/stream directo: 0 HTTP.
    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Resolviendo URL…')
    # Algunos skins de Kodi solo muestran el BG tras el primer update();
    # solo con create() la barra puede no aparecer. Forzar visibilidad.
    bg.update(0, 'loiolink', 'Resolviendo URL…')
    try:
        thumb = thumb_resolver.auto_thumb(new_url)
        label = thumb_resolver.auto_label(new_url) or new_url[:60]
        kind = thumb_resolver.detect_kind(new_url)
    finally:
        bg.close()

    opts = [
        f'Reproducir ahora ({kind})',
        'Guardar en marcadores y reproducir',
        'Solo guardar en marcadores',
    ]
    sel = xbmcgui.Dialog().select('URL detectada', opts)
    if sel == -1:
        return

    play = False
    if sel == 0:
        url_input_history.add(new_url, label=label, thumb=thumb)
        play = True
    elif sel == 1:
        url_input_history.add(new_url, label=label, thumb=thumb)
        added = url_bookmarks.add(new_url, name=label, thumb=thumb)
        if not added:
            accessibility.notify('Ya estaba en marcadores', ms=2000)
        play = True
    elif sel == 2:
        added = url_bookmarks.add(new_url, name=label, thumb=thumb)
        accessibility.notify(
            'Añadido a marcadores' if added else 'Ya estaba en marcadores',
            ms=2000,
        )

    xbmc.executebuiltin('Container.Refresh')

    if play:
        paste_clipboard.process_text(new_url)
