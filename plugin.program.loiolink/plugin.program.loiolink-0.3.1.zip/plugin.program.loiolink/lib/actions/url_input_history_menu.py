"""Submenu 'Historial de URLs': lista las URLs introducidas en 'Abrir URL'.

Cada entrada se renderiza con su thumb (si lo hay) y un context menu con:
- Descargar (si la URL es http(s); delega en transfers.pipeline)
- Guardar en marcadores (copia thumb/label a url_bookmarks)
- Eliminar del historial

Pulsar la entrada (no el menú contextual) re-invoca open_url_input con
`url=<valor>`, que reprocesa la URL y hace bring-to-front via `touch()`.

Nota 1: NO pre-encodear la URL al pasarla como param. _menu_common.url() ya
hace urlencode() de los kwargs; pasar quote(u) extra produce doble encoding
y la URL llega rota al handler.

Nota 2: el context menu añadido con `addContextMenuItems` solo se ve cuando
el plugin se navega en una ventana de media (caso típico de este addon).
Si en el futuro se renderiza como widget de skin, Kodi no muestra el
context menu (limitación conocida xbmc#21843). Para ese escenario habría
que usar el extension point `kodi.context.item` en addon.xml.
"""
import xbmc
import xbmcgui
import xbmcplugin

from lib import accessibility, url_input_history
from lib.actions._menu_common import HANDLE, begin, end, icon_path, make_item, url


_LABEL_TRUNC = 80


def run():
    begin('Historial de URLs')
    entries = url_input_history.load()
    if not entries:
        make_item(
            'No hay URLs en el historial', url('noop'),
            'El historial se llena al introducir URLs en "Pegar URL".',
            icon='history.png',
        )
        end()
        return
    make_item(
        '[COLOR red]Borrar historial[/COLOR]', url('url_input_history_clear'),
        'Vacía el historial. La acción pide confirmación.',
        icon='delete.png',
    )
    fallback_icon = icon_path('url.png')
    for entry in entries:
        u = entry.get('url', '')
        if not u:
            continue
        raw_label = entry.get('label') or u
        if len(raw_label) > _LABEL_TRUNC:
            raw_label = raw_label[:_LABEL_TRUNC - 1] + '…'
        # Defensa en profundidad: si url_history.json se editó a mano y la
        # URL contiene BBCode (`[B]`, `[COLOR red]`...), Kodi lo
        # interpretaría como markup. strip_bbcode limpia marcas conocidas.
        label = accessibility.strip_bbcode(raw_label)
        plot = accessibility.strip_bbcode(u)
        thumb = entry.get('thumb') or ''

        li = xbmcgui.ListItem(accessibility.apply_label(label))
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
        if thumb:
            li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
        elif fallback_icon:
            li.setArt({'icon': fallback_icon, 'thumb': fallback_icon})

        cm = []
        if u.startswith(('http://', 'https://')):
            cm.append(('Descargar', f'RunPlugin({url("url_history_download", url=u)})'))
        cm.append(('Guardar en marcadores', f'RunPlugin({url("url_bookmark_add_from_history", url=u)})'))
        cm.append(('Eliminar del historial', f'RunPlugin({url("url_history_remove", url=u)})'))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(
            handle=HANDLE, url=url('open_url_input', url=u),
            listitem=li, isFolder=False,
        )
    end()


def clear():
    if not xbmcgui.Dialog().yesno('loiolink', '¿Borrar todo el historial de URLs?'):
        return
    if url_input_history.clear():
        accessibility.notify('Historial borrado', ms=2000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        accessibility.notify('No se pudo borrar el historial', ms=3000)


def remove_one(url_param):
    """Acción `url_history_remove`: elimina una entrada concreta y refresca."""
    if url_input_history.remove(url_param or ''):
        accessibility.notify('Eliminado del historial', ms=2000)
        xbmc.executebuiltin('Container.Refresh')


def download(url_param):
    """Acción `url_history_download`: lanza la URL al pipeline de descargas."""
    url_param = (url_param or '').strip()
    if not url_param:
        return
    from lib.transfers import pipeline
    pipeline.download_and_register(url_param, source='url')
