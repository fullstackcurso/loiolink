"""Sub-carpeta de Opciones: ajustes del sistema de backup."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()

_PROGRESS_VALUES = ['Silencioso', 'Notificaciones', 'Diálogo (bloqueante)']
_TEXTURES_VALUES = [
    'Respaldar y restaurar',
    'Respaldar pero no restaurar (recomendado: Kodi las reconstruye)',
    'Ignorar (ni respaldar ni restaurar)',
]
_COMPRESSION_VALUES = ['Sin comprimir', 'Rápido', 'Normal', 'Máximo']


def _safe_enum_label(values, idx):
    if 0 <= idx < len(values):
        return values[idx]
    return '?'


def run():
    mc.begin('Backup')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    keep = _ADDON.getSettingInt('backup.snapshots.keep')
    add(
        f'Copias locales a mantener: [COLOR yellow]{keep}[/COLOR]',
        mc.url('opt_num', key='backup.snapshots.keep', lo=1, hi=50,
               heading='Copias locales a mantener'),
        'Número de backups manuales que se conservan en la carpeta de backups. '
        'Al crear uno nuevo, si se supera este número, el más antiguo se borra '
        'automáticamente. Los snapshots automáticos pre-restore se cuentan aparte '
        '(ver "Snapshots pre-restore a mantener" más abajo). '
        f'Valor actual: {keep}. Rango: 1-50.',
        icon='history.png',
    )

    include_data = _ADDON.getSettingBool('backup.include_addon_data_default')
    add(
        f'Datos de usuario de addons por defecto: {mc.color_bool(include_data)}',
        mc.url('opt_toggle', key='backup.include_addon_data_default'),
        'Valor por defecto de la casilla "Incluir datos de usuario" al crear un backup. '
        'Si está activado, los nuevos backups incluyen las carpetas userdata/addon_data '
        'de cada addon (sesiones, preferencias, caché). '
        'Esto hace los backups más grandes pero permite restaurar el estado completo '
        'de los addons. Puedes cambiarlo en cada backup individual desde el menú.',
        icon='check.png',
    )

    exclude_skins = _ADDON.getSettingBool('backup.exclude_skins_default')
    add(
        f'Excluir skins por defecto: {mc.color_bool(exclude_skins)}',
        mc.url('opt_toggle', key='backup.exclude_skins_default'),
        'Si está activado, los skins (xbmc.gui.skin.*) se excluyen de los backups '
        'por defecto. Suelen pesar varios MB y Kodi los reinstala automáticamente '
        'desde su repositorio si hace falta, así que respaldarlos rara vez compensa.',
        icon='check.png',
    )

    exclude_sys = _ADDON.getSettingBool('backup.exclude_system_default')
    add(
        f'Excluir addons del sistema Kodi: {mc.color_bool(exclude_sys)}',
        mc.url('opt_toggle', key='backup.exclude_system_default'),
        'Si está activado, los addons que vienen de serie con Kodi '
        '(xbmc.*, metadata.*, scrapers nativos, servicios del core...) no se '
        'incluyen en los backups por defecto. Kodi los reinstala solo, no hace '
        'falta respaldarlos.',
        icon='check.png',
    )

    custom = _ADDON.getSetting('backup.custom_path') or '(carpeta del addon)'
    add(
        f'Carpeta de backups: [COLOR yellow]{custom}[/COLOR]',
        mc.url('opt_folder', key='backup.custom_path',
               heading='Carpeta personalizada para los backups'),
        'Carpeta donde se guardan los backups. Déjalo vacío para usar la carpeta '
        'del perfil del addon (dentro de Kodi). Útil para guardar los backups '
        'fuera de Kodi: USB, NAS por SMB, disco externo... Los backups antiguos '
        'no se mueven automáticamente al cambiar la carpeta; si necesitas moverlos, '
        'usa "Migrar backups entre carpetas" desde el menú de backup.',
        icon='sources.png',
    )

    hashes = _ADDON.getSettingBool('backup.compute_hashes')
    add(
        f'Verificación SHA256 de archivos: {mc.color_bool(hashes)}',
        mc.url('opt_toggle', key='backup.compute_hashes'),
        'Si está activado, calcula un hash SHA256 de cada archivo respaldado y lo '
        'guarda en el manifest. Al restaurar se vuelve a calcular y se compara, '
        'lo que permite detectar si el ZIP se corrompió en disco, durante una '
        'subida a SMB/NAS o por un error de copia. Añade unos segundos al crear el '
        'backup; muy recomendable mantenerlo activado.',
        icon='shield.png',
    )

    comp_idx = _ADDON.getSettingInt('backup.compression_level')
    comp_label = _safe_enum_label(_COMPRESSION_VALUES, comp_idx)
    add(
        f'Nivel de compresión: [COLOR yellow]{comp_label}[/COLOR]',
        mc.url('opt_enum', key='backup.compression_level',
               values='|'.join(_COMPRESSION_VALUES),
               heading='Nivel de compresión del backup ZIP'),
        'Cómo de fuerte se comprime el ZIP de backup. '
        '"Normal" (default) es el equilibrio histórico: ratio razonable y '
        'rápido en CPUs lentas tipo Raspberry Pi o ATV. '
        '"Sin comprimir" no comprime nada (método "Store"): es lo más rápido '
        'posible y el ZIP queda hasta 3-4x más grande; útil cuando lo guardas '
        'en un disco local con espacio de sobra y quieres acabar cuanto antes. '
        '"Rápido" es un punto intermedio con un poco de compresión y muy poco '
        'coste. "Máximo" recorta otro 5-10 % de tamaño a cambio de bastante '
        'más CPU; tiene sentido si vas a subir el backup a un NAS o nube y el '
        'ancho de banda importa más que la CPU.',
        icon='download.png',
    )

    exclude_garbage = _ADDON.getSettingBool('backup.exclude_garbage')
    add(
        f'Excluir archivos basura: {mc.color_bool(exclude_garbage)}',
        mc.url('opt_toggle', key='backup.exclude_garbage'),
        'Si está activado, ciertos archivos y directorios que no aportan nada a '
        'un restore se saltan al crear el backup, ahorrando espacio y tiempo. '
        'Lo excluido es siempre la misma lista: directorios __pycache__, .git, '
        '.svn, .hg, .idea, .vscode, node_modules; archivos *.pyc, *.pyo, *.tmp, '
        '*.bak, *.swp, *.swo, *.orig, *~; y archivos de metadatos de sistema '
        'operativo (.DS_Store, Thumbs.db, desktop.ini). '
        'Desactivar solo si necesitas un backup bit-exact que conserve también '
        'estos archivos por algún motivo concreto.',
        icon='check.png',
    )

    pre_restore = _ADDON.getSettingBool('backup.auto_pre_restore.enabled')
    add(
        f'Snapshot automático antes de restaurar: {mc.color_bool(pre_restore)}',
        mc.url('opt_toggle', key='backup.auto_pre_restore.enabled'),
        'Si está activado, justo antes de cada restore se crea un snapshot del estado '
        'actual de Kodi como rollback de emergencia. Si el restore va mal, puedes '
        'volver al estado previo restaurando ese snapshot. Se guardan en la misma '
        'carpeta que los backups manuales pero con prefijo "prerestore_".',
        icon='auto.png',
    )

    pre_keep = _ADDON.getSettingInt('backup.auto_pre_restore.keep')
    add(
        f'Snapshots pre-restore a mantener: [COLOR yellow]{pre_keep}[/COLOR]',
        mc.url('opt_num', key='backup.auto_pre_restore.keep', lo=1, hi=10,
               heading='Snapshots de seguridad pre-restore a mantener'),
        'Cuántos snapshots automáticos pre-restore se conservan (los marcados con '
        'prefijo "prerestore_"). Los más antiguos se rotan al superar este número. '
        'Cuenta aparte del límite de copias manuales de arriba. '
        f'Valor actual: {pre_keep}. Rango: 1-10.',
        icon='history.png',
    )

    prog_idx = _ADDON.getSettingInt('backup.progress_mode_manual')
    prog_label = _safe_enum_label(_PROGRESS_VALUES, prog_idx)
    add(
        f'Progreso en TV: [COLOR yellow]{prog_label}[/COLOR]',
        mc.url('opt_enum', key='backup.progress_mode_manual',
               values='|'.join(_PROGRESS_VALUES),
               heading='Modo de progreso para backups manuales en la TV'),
        'Cómo se muestra el progreso al crear o restaurar un backup desde el menú '
        'de la TV. "Silencioso": el trabajo va por debajo y solo avisa al terminar. '
        '"Notificaciones": muestra avisos discretos en una esquina cada cierto tiempo. '
        '"Diálogo (bloqueante)": ventana modal en el centro con barra de progreso que '
        'tapa el menú hasta que termina. Esta opción solo afecta a la interfaz de la '
        'TV; el panel web siempre usa su propia barra de progreso integrada.',
        icon='dialog.png',
    )

    verbose = _ADDON.getSettingBool('backup.verbose_logging')
    add(
        f'Logging detallado de archivos: {mc.color_bool(verbose)}',
        mc.url('opt_toggle', key='backup.verbose_logging'),
        'Si está activado, escribe en el log una línea por cada archivo procesado '
        'durante backup y restore. Llena bastante el log de Kodi y ralentiza un poco '
        'el proceso, así que solo conviene activarlo para diagnosticar un fallo '
        'concreto y desactivarlo después.',
        icon='diagnostics.png',
    )

    tex_idx = _ADDON.getSettingInt('backup.textures.policy')
    tex_label = _safe_enum_label(_TEXTURES_VALUES, tex_idx)
    add(
        f'Política de Textures: [COLOR yellow]{tex_label}[/COLOR]',
        mc.url('opt_enum', key='backup.textures.policy',
               values='|'.join(_TEXTURES_VALUES),
               heading='Política para Textures (cache de miniaturas)'),
        'Qué hacer con la carpeta Textures de Kodi (la caché de miniaturas que '
        'genera Kodi a partir de los pósteres, fondos y fanart de tu biblioteca). '
        'Puede pesar varios GB en bibliotecas grandes. '
        '"Respaldar y restaurar": backup más grande pero al restaurar Kodi muestra '
        'las miniaturas al instante. '
        '"Respaldar pero no restaurar": se incluye en el ZIP por si acaso, pero al '
        'restaurar se descarta y Kodi reconstruye la caché en segundo plano '
        '(recomendado, balance entre tamaño y comodidad). '
        '"Ignorar": no se incluye ni al respaldar ni al restaurar (backup más '
        'pequeño; Kodi reconstruirá la caché igualmente la primera vez que abras '
        'la biblioteca).',
        icon='download.png',
    )

    enc_on = _ADDON.getSettingBool('backup.encryption.enabled')
    add(
        f'Cifrado AES-256 del manifest: {mc.color_bool(enc_on)}',
        mc.url('opt_toggle', key='backup.encryption.enabled'),
        'Si está activado, el manifest del backup se cifra con AES-256 + PBKDF2 al '
        'crear el ZIP. El manifest es el archivo interno que lista qué addons, '
        'rutas y hashes contiene cada backup; sin él, el ZIP es opaco y no se puede '
        'restaurar aunque alguien lo abra. Los archivos individuales del ZIP NO se '
        'cifran (sería demasiado lento en Kodi), pero sin manifest no se pueden '
        'mapear a su destino. Útil si los backups van a un NAS o nube compartida.\n\n'
        'IMPORTANTE: si pierdes el password, los backups cifrados no se pueden '
        'recuperar.',
        icon='shield.png',
    )

    pwd_hex = _ADDON.getSetting('backup.encryption.password')
    if pwd_hex:
        pwd_state = '[COLOR yellow](configurada)[/COLOR]'
    else:
        pwd_state = '[COLOR red](no configurada)[/COLOR]'
    add(
        f'Password de cifrado: {pwd_state}',
        mc.url('opt_backup_password'),
        'Password con el que se cifra el manifest cuando el cifrado está activo. '
        'Mínimo 8 caracteres. Se guarda obfuscada (no en claro) en los ajustes del '
        'addon, no se muestra nunca en pantalla y no se loguea. Al pulsar este item '
        'pedirá la password en un cuadro oculto (estilo password); deja el campo '
        'vacío y confirma para borrarla.\n\n'
        'AVISO: si pierdes la password, los backups cifrados creados con ella NO se '
        'pueden restaurar. Anótala en un gestor de contraseñas o sitio seguro.',
        icon='shield.png',
    )

    mc.end()
