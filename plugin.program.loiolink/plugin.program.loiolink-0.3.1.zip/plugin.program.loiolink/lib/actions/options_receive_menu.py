"""Sub-carpeta de Opciones: ajustes del servidor de recepción de texto."""
import xbmcaddon
import xbmcgui

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Recibir texto')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    relay_enabled = False
    try:
        relay_enabled = _ADDON.getSettingBool('relay_ntfy_enabled')
    except RuntimeError:
        pass
    color = 'green' if relay_enabled else 'red'
    estado = 'activo' if relay_enabled else 'inactivo'
    add(
        f'Recibir texto sin WiFi, por internet: [COLOR {color}]{estado}[/COLOR]',
        mc.url('opt_toggle', key='relay_ntfy_enabled'),
        'Cuando está activo, el menú "Recibir texto" muestra un QR a ntfy.sh '
        'en lugar de la IP local. El texto llega desde cualquier red sin '
        'necesidad de estar en el mismo WiFi. Solo aplica a texto desde ese '
        'menú: uploads, magnets y el panel web remoto siguen necesitando LAN.',
        icon='remote.png',
    )

    ephemeral = True
    try:
        ephemeral = _ADDON.getSettingBool('server_ephemeral_mode')
    except RuntimeError:
        pass
    ephemeral_label = 'efimero (se cierra con la ventana)' if ephemeral else 'persistente (siempre activo)'
    add(
        f'Servidor de recepción: [COLOR yellow]{ephemeral_label}[/COLOR]',
        mc.url('opt_toggle', key='server_ephemeral_mode'),
        'En modo efimero, el servidor de recepción arranca al abrir "Recibir texto" '
        'y se para al cerrar esa ventana. '
        'En modo persistente permanece activo mientras el panel web remoto esté '
        'encendido, sin necesidad de mantener la ventana abierta. '
        'El cambio tiene efecto en la próxima apertura de la ventana.',
        icon='remote.png',
    )

    if not ephemeral:
        win = xbmcgui.Window(10000)
        stopped = win.getProperty('loiolink.text.user_stopped') == '1'
        running = bool(win.getProperty('loiolink.text.port'))
        # El label refleja qué hará el click (mantener coherencia con la acción,
        # que togglea según `user_stopped`). El estado real va en la descripción.
        action_label = '[COLOR green]Encender[/COLOR]' if stopped else '[COLOR red]Apagar[/COLOR]'
        if running:
            state_desc = 'Estado actual: activo.'
        elif stopped:
            state_desc = 'Estado actual: apagado manualmente.'
        else:
            state_desc = 'Estado actual: arrancando o sin servicio.'
        add(
            f'Servidor de recepción ahora: {action_label}',
            mc.url('toggle_text_server'),
            f'{state_desc} Para o inicia el servidor sin cambiar la '
            'configuración. El cambio se aplica en menos de 1 segundo.',
            icon='remote.png',
        )

    port = _ADDON.getSettingInt('server_port')
    add(
        f'Puerto recepción: [COLOR yellow]{port}[/COLOR]',
        mc.url('opt_num', key='server_port', lo=1, hi=65535,
               heading='Puerto recepción'),
        'Puerto del servidor efímero que recibe texto enviado desde otro dispositivo (móvil, tableta, PC...). '
        f'Cámbialo si el puerto {port} está ocupado por otra aplicación. '
        'Rango válido: 1-65535.',
        icon='port.png',
    )

    timeout = _ADDON.getSettingInt('server_timeout_seconds')
    add(
        f'Tiempo de espera del servidor: [COLOR yellow]{timeout} s[/COLOR]',
        mc.url('opt_num', key='server_timeout_seconds', lo=30, hi=1800,
               heading='Tiempo de espera del servidor (s)'),
        'Segundos que el servidor efímero permanece activo esperando texto de un dispositivo externo. '
        'Valores más altos dan más tiempo para abrir la app y enviar el texto. '
        f'Valor actual: {timeout} s. Rango: 30-1800 s.',
        icon='timer.png',
    )

    mc.end()
