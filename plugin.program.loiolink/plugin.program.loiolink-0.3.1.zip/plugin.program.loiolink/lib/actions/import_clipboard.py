"""Acción 'Importar contenido del portapapeles del SO'.

Lanzada desde la entrada destacada del menú principal cuando
clipboard_detect.detect_importable() devuelve algo. Lee el clipboard de
nuevo (puede haber cambiado entre construir el menú y pulsar) y despacha
según el kind:

- acestream → ace.play() (acepta URL completa o ID desnudo normalizado).
- magnet → encolar evento magnet_received (service abre Elementum o pide
  instalarlo en su main thread).
- stream_url → stream_player.play() (RTMP/RTSP/HLS/DASH).
- url    → pipeline.download_and_register con source='clipboard'.
- aftvnews_code → aftvnews.resolve(code) + pipeline.download_and_register.
"""
import urllib.error

from lib import clipboard_detect
from lib.ui_select import info


def run():
    from lib import accessibility
    detected = clipboard_detect.detect_importable()
    if detected is None:
        accessibility.notify('No hay contenido importable en el portapapeles', ms=2500)
        return

    kind, value, _preview = detected

    if kind == 'acestream':
        from lib.remote import acestream as ace
        try:
            ace.play(value)
            accessibility.notify('Acestream: lanzando...', ms=2500)
            # Diagnóstico post-play: si el motor externo no responde,
            # avisamos para evitar el error opaco "can not get transport file".
            if not ace.engine_running():
                accessibility.notify(
                    'AceStream Engine no responde en 127.0.0.1:6878. '
                    'Si no reproduce, inicia el motor.',
                    ms=5000,
                )
        except RuntimeError:
            info(
                'Acestream requiere Plexus/Horus instalado y\n'
                'AceStream Engine corriendo en 127.0.0.1:6878.',
                title='loiolink',
            )
        except ValueError as e:
            info(f'Acestream inválido: {e}', title='loiolink')
        return

    if kind == 'magnet':
        from lib.transfers import history
        history.queue_event({'kind': 'magnet_received', 'uri': value})
        accessibility.notify('Magnet importado, abriendo Elementum...', ms=2500)
        return

    if kind == 'stream_url':
        from lib.remote import stream_player
        try:
            stream_player.play(value)
            accessibility.notify('Stream: reproduciendo...', ms=2500)
        except RuntimeError as e:
            msg = str(e)
            if msg.startswith('missing_inputstream:'):
                iid = msg.split(':', 1)[1]
                info(f'Instala {iid} para reproducir este stream', title='loiolink')
            else:
                info(f'Stream falló: {e}', title='loiolink')
        return

    if kind == 'url':
        from lib.transfers import pipeline
        try:
            pipeline.download_and_register(value, source='clipboard')
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Descarga falló: {e}', title='loiolink')
        return

    if kind == 'aftvnews_code':
        from lib.transfers import aftvnews, pipeline
        try:
            url = aftvnews.resolve(value)
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Código inválido: {e}', title='loiolink')
            return
        try:
            pipeline.download_and_register(url, source='clipboard')
        except (ValueError, urllib.error.URLError, OSError) as e:
            info(f'Descarga falló: {e}', title='loiolink')
