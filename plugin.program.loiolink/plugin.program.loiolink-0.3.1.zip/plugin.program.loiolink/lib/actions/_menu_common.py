"""Helpers compartidos por los menús-folder de plugin (addDirectoryItem).

Los usan options_menu y sus sub-carpetas. Centralizar aquí evita repetir el
mismo url/icon_path/color_bool/make_item en cada módulo de menú.
"""
import os
import sys
from urllib.parse import urlencode

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility

HANDLE = (
    int(sys.argv[1])
    if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit()
    else -1
)
BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
MENU_ICONS = os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'menu',
)


def icon_path(filename):
    if not filename:
        return None
    full = os.path.join(MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def url(action, **params):
    if params:
        return f'{BASE_URL}?action={action}&{urlencode(params)}'
    return f'{BASE_URL}?action={action}'


def color_bool(v):
    return '[COLOR green]ACTIVADO[/COLOR]' if v else '[COLOR red]DESACTIVADO[/COLOR]'


def acc_kwargs():
    """Lee los 4 settings de accesibilidad una vez por render del menú."""
    return {
        'bold': accessibility.get_force_bold(),
        'strip': accessibility.get_strip_symbols(),
        'color_mode': accessibility.get_color_mode(),
        'font_size': accessibility.get_font_size(),
    }


def make_item(label, item_url, plot, icon='settings.png', acc=None, is_folder=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label, **(acc or {})))
    # setInfo está deprecated desde Kodi 20 (Nexus). El reemplazo
    # getVideoInfoTag().setPlot() no existe en Kodi 19 (Matrix), target del
    # addon (xbmc.python 3.0.0). Migrar al subir el target a Kodi 20+.
    li.setInfo('video', {'plot': plot})
    icon_p = icon_path(icon)
    if icon_p:
        li.setArt({'icon': icon_p, 'thumb': icon_p})
    xbmcplugin.addDirectoryItem(
        handle=HANDLE, url=item_url, listitem=li, isFolder=is_folder,
    )


def begin(category):
    xbmcplugin.setPluginCategory(HANDLE, category)


def end():
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
