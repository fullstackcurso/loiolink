"""Submenú 'Portapapeles interno': ver / limpiar.

Antes estas dos opciones estaban como entradas de primer nivel del menú
principal (heredadas), pero confundían al usuario nuevo. Ahora viven aquí
agrupadas bajo Avanzado.
"""
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import i18n


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'


def _item(label, action, is_folder=False):
    li = xbmcgui.ListItem(label)
    url = f'{_BASE_URL}?action={action}'
    xbmcplugin.addDirectoryItem(
        handle=_HANDLE, url=url, listitem=li, isFolder=is_folder,
    )


def run():
    _item(i18n.L(30100), 'clipboard_view')
    _item(i18n.L(30101), 'clipboard_clear')
    if xbmcaddon.Addon().getSettingBool('debug.clipboard_test'):
        _item('Test (depurar pegado)', 'clipboard_test', is_folder=True)
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
