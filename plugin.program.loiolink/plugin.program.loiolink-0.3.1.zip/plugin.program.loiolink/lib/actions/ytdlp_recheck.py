"""Acción 'Re-comprobar yt-dlp': invalida el cache y fuerza re-detección.

Útil cuando el usuario acaba de instalar yt-dlp en el sistema sin
reiniciar Kodi y quiere que loiolink lo detecte de inmediato.
"""
import xbmc
import xbmcgui

from lib import accessibility, ytdlp_resolver
from lib.ui_select import info


def _platform_install_hint():
    """Instrucciones de instalación específicas por plataforma. Devuelve
    string multilínea listo para mostrar en textviewer/info().
    """
    if xbmc.getCondVisibility('System.Platform.Android'):
        return (
            'Plataforma: Android\n\n'
            'En Android no se puede usar yt-dlp (Kodi no expone subprocess '
            'al sistema operativo). loiolink usa dm_gujal interno como '
            'fallback para Dailymotion, y el regex scanner cubre los sitios '
            'mainstream (YouTube, Vimeo, Twitch...) cuando hay un plugin '
            'instalado para resolverlos.'
        )
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return (
            'Plataforma: Windows\n\n'
            'Instalación recomendada (PowerShell con permisos de usuario):\n\n'
            '  winget install Python.Python.3.12\n'
            '  python -m pip install -U yt-dlp\n\n'
            'Verifica abriendo PowerShell o cmd y ejecutando:\n'
            '  python --version    (debe imprimir 3.10 o superior)\n'
            '  python -m yt_dlp --version    (debe imprimir 2024.x.x o similar)\n\n'
            'Si Python ya estaba instalado, asegúrate que está en el PATH del '
            'usuario que ejecuta Kodi (Variables de entorno → Path).'
        )
    if xbmc.getCondVisibility('System.Platform.OSX'):
        return (
            'Plataforma: macOS\n\n'
            'Instalación recomendada (Terminal con Homebrew):\n\n'
            '  brew install yt-dlp\n\n'
            'Alternativa con pipx (más limpia):\n\n'
            '  brew install pipx\n'
            '  pipx install yt-dlp\n\n'
            'Verifica:\n'
            '  python3 --version\n'
            '  yt-dlp --version'
        )
    # Linux/LibreELEC/CoreELEC y resto.
    return (
        'Plataforma: Linux (o similar)\n\n'
        'Instalación recomendada (Terminal):\n\n'
        '  sudo apt install python3 python3-pip      # Debian/Ubuntu\n'
        '  sudo dnf install python3 python3-pip      # Fedora\n'
        '  sudo pacman -S python python-pip          # Arch\n\n'
        '  pipx install yt-dlp     (recomendado, evita pisar paquetes de sistema)\n'
        '  # o si pipx no está:\n'
        '  pip install --user -U yt-dlp\n\n'
        'Verifica:\n'
        '  python3 --version    (debe imprimir 3.10 o superior)\n'
        '  yt-dlp --version\n\n'
        'En LibreELEC/CoreELEC el sistema es read-only y NO suele haber '
        'Python del sistema disponible para Kodi: yt-dlp no es posible ahí, '
        'pero loiolink usa dm_gujal interno y los plugins de Kodi (YouTube, '
        'Dailymotion, Vimeo) como fallback.'
    )


def run():
    ytdlp_resolver.invalidate_installed_cache()
    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Detectando yt-dlp…')
    bg.update(0, 'loiolink', 'Detectando yt-dlp…')
    try:
        installed = ytdlp_resolver.is_installed()
    finally:
        bg.close()
    if installed:
        accessibility.notify('yt-dlp detectado correctamente', ms=3000)
        return
    # Mensaje detallado con instrucciones de la plataforma actual. Usamos
    # textviewer (no notification) para que el usuario pueda leerlo entero
    # y copiar los comandos.
    body = (
        'No se ha encontrado yt-dlp utilizable en el sistema.\n\n'
        'yt-dlp es OPCIONAL — loiolink funciona sin él, usando regex scanner '
        'y dm_gujal interno como fallback. Sin embargo, instalarlo añade '
        'soporte para más de 1800 sitios web (YouTube, TikTok, Instagram, '
        'sitios de streaming, redes sociales) con resolución de JavaScript '
        'dinámico que el regex no cubre.\n\n'
        'Requisitos:\n'
        '- Python >= 3.10 accesible desde el PATH (python3, python o py).\n'
        '- yt-dlp instalado vía pip/pipx.\n\n'
        + _platform_install_hint() +
        '\n\nTras instalar yt-dlp, vuelve a Opciones avanzadas → '
        '"Re-comprobar yt-dlp" para forzar la detección sin reiniciar Kodi.'
    )
    xbmcgui.Dialog().textviewer('Cómo instalar yt-dlp', body)
    # Bonus: si el usuario quiere acceso rápido sin re-entrar al menú.
    info(
        'yt-dlp no detectado. Instálalo siguiendo las instrucciones que se '
        'acaban de mostrar y vuelve a este menú.',
        title='loiolink',
    )
