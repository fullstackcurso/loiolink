"""Acción 'Ajustes': abre la ventana de settings del addon."""
import xbmcaddon


def run():
    xbmcaddon.Addon().openSettings()
