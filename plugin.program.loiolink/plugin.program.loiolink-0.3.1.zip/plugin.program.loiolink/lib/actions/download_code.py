"""Acción 'Descargar desde código numérico' (estilo Downloader).

Pide código, resuelve con aftvnews, descarga.
"""
import urllib.error

import xbmcgui

from lib.transfers import aftvnews, pipeline
from lib.ui_select import info


def run():
    code = xbmcgui.Dialog().input('Código numérico:', type=xbmcgui.INPUT_NUMERIC)
    if not code:
        return
    try:
        url = aftvnews.resolve(code)
    except (ValueError, urllib.error.URLError, OSError) as e:
        info(f'Código inválido: {e}', title='loiolink')
        return
    pipeline.download_and_register(url, source='aftvnews_code')
