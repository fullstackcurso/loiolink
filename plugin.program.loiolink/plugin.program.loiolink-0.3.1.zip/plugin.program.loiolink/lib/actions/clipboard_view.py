"""Acción 'Ver portapapeles actual': muestra el contenido en un textviewer."""
import clipboard
from lib.ui_select import info, show_text


def run():
    text = clipboard.get()
    if not text:
        info('Portapapeles vacío', title='loiolink')
        return
    show_text('Portapapeles loiolink', text)
