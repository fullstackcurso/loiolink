"""Sub-carpeta de Opciones: ajustes para usuarios avanzados."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Opciones avanzadas')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png', is_folder=False):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc, is_folder=is_folder)

    sn = _ADDON.getSetting('streamninja_repo_url_override') or '(por defecto)'
    add(
        f'URL repo StreamNinja: [COLOR yellow]{sn}[/COLOR]',
        mc.url('opt_text', key='streamninja_repo_url_override',
               heading='URL repo StreamNinja'),
        'URL personalizada del repositorio desde el que se instala StreamNinja. '
        'Déjalo vacío para usar la URL oficial. '
        'Cambia esto solo si tienes un mirror propio o necesitas probar una versión específica. '
        'URL por defecto: https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip',
        icon='url.png',
    )

    el = _ADDON.getSetting('elementum_repo_url_override') or '(por defecto)'
    add(
        f'URL repo Elementum: [COLOR yellow]{el}[/COLOR]',
        mc.url('opt_text', key='elementum_repo_url_override',
               heading='URL repo Elementum'),
        'URL personalizada del repositorio desde el que se instala Elementum '
        'cuando llega un magnet o un .torrent y Elementum no está disponible. '
        'Déjalo vacío para usar la URL oficial. '
        'URL por defecto: https://elementumorg.github.io/repository.elementumorg-1.0.6.zip',
        icon='url.png',
    )

    ll = _ADDON.getSetting('loiolog_repo_url_override') or '(por defecto)'
    add(
        f'URL repo LoioLog: [COLOR yellow]{ll}[/COLOR]',
        mc.url('opt_text', key='loiolog_repo_url_override',
               heading='URL repo LoioLog'),
        'URL personalizada del repositorio desde el que se instala LoioLog (visor de logs). '
        'Déjalo vacío para usar la URL oficial. '
        'URL por defecto: https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip',
        icon='url.png',
    )

    inst_t = _ADDON.getSettingInt('network.timeout_install_s')
    add(
        f'Timeout instalación addon: [COLOR yellow]{inst_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_install_s', lo=10, hi=300,
               heading='Timeout instalación de addons (s)'),
        f'Segundos sin recibir datos al descargar el zip de un addon externo antes de cancelar. '
        f'No es el tiempo total; una instalación lenta pero continua no se cancela. '
        f'Valor actual: {inst_t} s. Rango: 10-300 s.',
        icon='timer.png',
    )

    tc_t = _ADDON.getSettingInt('network.timeout_transcode_s')
    add(
        f'Timeout transcodificación: [COLOR yellow]{tc_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_transcode_s', lo=2, hi=60,
               heading='Timeout transcodificación FFmpeg (s)'),
        f'Tiempo máximo total para la transcodificación FFmpeg antes de matar el proceso. '
        f'Valor actual: {tc_t} s. Rango: 2-60 s.',
        icon='timer.png',
    )

    auto_scan = _ADDON.getSettingBool('library.auto_scan')
    add(
        f'Escanear biblioteca al añadir archivos: {mc.color_bool(auto_scan)}',
        mc.url('opt_toggle', key='library.auto_scan'),
        'Si está activado, loiolink lanza un escaneo de biblioteca de Kodi cada vez que '
        'mueves un archivo a una fuente de vídeo o música. '
        'Desactívalo si el escaneo automático de Kodi ya está configurado o si el '
        'escaneo constante resulta molesto.',
        icon='sync.png',
    )

    lib_cache = _ADDON.getSettingBool('library.cache_enabled')
    add(
        f'Cache de biblioteca para el panel: {mc.color_bool(lib_cache)}',
        mc.url('opt_toggle', key='library.cache_enabled'),
        'Si está activado, los listados de biblioteca que pide el panel web se '
        'cachean en memoria para evitar consultas repetidas a Kodi. Útil solo si '
        'tu biblioteca es grande (miles de items) y notas el panel lento al '
        'paginar. Desactivado por defecto: con bibliotecas pequeñas no aporta nada.',
        icon='sync.png',
    )

    lib_ttl = _ADDON.getSettingInt('library.cache_ttl_min')
    add(
        f'TTL del cache de biblioteca: [COLOR yellow]{lib_ttl} min[/COLOR]',
        mc.url('opt_num', key='library.cache_ttl_min', lo=5, hi=1440,
               heading='TTL del cache de biblioteca (minutos)'),
        f'Minutos que vive cada entrada del cache antes de re-consultar Kodi. '
        f'Más alto = menos consultas pero mayor desfase si añades contenido. '
        f'El monitor invalida selectivamente al detectar OnScanFinished, así que '
        f'el TTL es una red de seguridad, no el mecanismo principal. '
        f'Valor actual: {lib_ttl} min. Rango: 5-1440 min (24 h). '
        f'Solo aplica si el cache está activado.',
        icon='timer.png',
    )

    fs_browse = _ADDON.getSettingBool('file_browser.allow_fs_browse')
    add(
        f'Examinar filesystem completo desde el panel: {mc.color_bool(fs_browse)}',
        mc.url('opt_toggle', key='file_browser.allow_fs_browse'),
        'Si está activado, al añadir fuentes desde el panel web puedes navegar '
        'por TODO el filesystem visible a Kodi (no solo las fuentes ya configuradas). '
        'PELIGROSO: cualquiera con el token podría enumerar archivos personales. '
        'Desactivado por defecto.',
        icon='shield.png',
    )

    trash_on = _ADDON.getSettingBool('file_browser.trash.enabled')
    add(
        f'Papelera al borrar desde el panel: {mc.color_bool(trash_on)}',
        mc.url('opt_toggle', key='file_browser.trash.enabled'),
        'Si está activado, los archivos borrados desde el panel web (solo fuentes '
        'locales) se mueven a una papelera dentro del addon en vez de borrarse '
        'definitivamente. Las fuentes de red (smb://, nfs://, ftp://, http(s)://) '
        'borran siempre directamente porque la papelera local no las cubre.',
        icon='sources.png',
    )

    trash_max = _ADDON.getSettingInt('file_browser.trash.max_items')
    add(
        f'Máximo de elementos en la papelera: [COLOR yellow]{trash_max}[/COLOR]',
        mc.url('opt_num', key='file_browser.trash.max_items', lo=1, hi=100,
               heading='Máximo de elementos en la papelera'),
        f'Cuando la papelera supera este número, los elementos más antiguos se '
        f'purgan automáticamente para no consumir disco indefinidamente. '
        f'Valor actual: {trash_max}. Rango: 1-100. '
        f'Solo aplica si la papelera está activada.',
        icon='sources.png',
    )

    add(
        'Re-comprobar yt-dlp',
        mc.url('ytdlp_recheck'),
        'Invalida el cache de detección de yt-dlp y vuelve a buscarlo en el '
        'sistema. Útil si acabas de instalar yt-dlp (pip install -U yt-dlp) y '
        'no quieres reiniciar Kodi para que loiolink lo detecte. '
        'En Android no aplica (yt-dlp requiere Python del sistema); '
        'loiolink usa dm_gujal interno como fallback para Dailymotion.',
        icon='sync.png',
    )

    add(
        'Debug',
        mc.url('debug_menu'),
        'Opciones de depuración: log de datos sensibles y test del pegado.',
        icon='diagnostics.png',
        is_folder=True,
    )

    mc.end()
