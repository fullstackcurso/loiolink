"""Acción 'Iniciar / parar servidor de recepción' (sin cambiar el setting).

Usa la Window property loiolink.text.user_stopped para pedir al service que
arranque o detenga el servidor de texto. El service lo detecta en su loop
(<= 1 s) y actúa. Solo tiene efecto en modo persistente (server_ephemeral_mode=False).
"""
import xbmc
import xbmcgui

from lib import accessibility


_STOPPED_PROP = 'loiolink.text.user_stopped'


def run():
    win = xbmcgui.Window(10000)
    currently_stopped = win.getProperty(_STOPPED_PROP) == '1'
    if currently_stopped:
        win.clearProperty(_STOPPED_PROP)
        accessibility.notify('Servidor de recepción iniciado', ms=2500)
    else:
        win.setProperty(_STOPPED_PROP, '1')
        accessibility.notify('Servidor de recepción apagado', ms=2500)
    xbmc.executebuiltin('Container.Refresh')
