"""Sub-carpeta de Opciones: cómo se pega el texto en los buscadores."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Pegar texto en buscadores')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    confirm_paste = _ADDON.getSettingBool('confirm_before_paste')
    add(
        f'Confirmar antes de pegar: {mc.color_bool(confirm_paste)}',
        mc.url('opt_toggle', key='confirm_before_paste'),
        'Si está activado, muestra un cuadro de confirmación antes de inyectar el texto '
        'en el cuadro de búsqueda. Útil si quieres revisar qué se va a pegar antes de hacerlo.',
        icon='check.png',
    )

    auto_confirm = _ADDON.getSettingBool('auto_confirm_search')
    add(
        f'Confirmar búsqueda automáticamente al pegar: {mc.color_bool(auto_confirm)}',
        mc.url('opt_toggle', key='auto_confirm_search'),
        'Si está activado, después de pegar el texto pulsa Enter automáticamente '
        'para lanzar la búsqueda sin que tengas que confirmar manualmente.',
        icon='keyboard.png',
    )

    preview_s = _ADDON.getSettingInt('paste.preview_delay_s')
    preview_label = f'{preview_s} s' if preview_s > 0 else 'desactivado'
    add(
        f'Vista previa del texto pegado: [COLOR yellow]{preview_label}[/COLOR]',
        mc.url('opt_num', key='paste.preview_delay_s', lo=0, hi=10,
               heading='Vista previa del texto pegado (s)'),
        'Segundos que el teclado permanece visible con el texto ya pegado '
        'antes de confirmar la busqueda automaticamente. '
        'Solo tiene efecto si "Confirmar busqueda automaticamente al pegar" esta activado. '
        f'Valor actual: {preview_label}. 0 = desactivado. Rango: 0-10 s.',
        icon='timer.png',
    )

    only_search = _ADDON.getSettingBool('only_on_search_items')
    add(
        f'Pegar solo en items de búsqueda: {mc.color_bool(only_search)}',
        mc.url('opt_toggle', key='only_on_search_items'),
        'Si está activado, la opción "Pegar" del menú contextual solo aparece en elementos '
        'cuya etiqueta contiene palabras como "buscar", "search", "find", etc. '
        'Si está desactivado, aparece en cualquier elemento del menú contextual.',
        icon='search.png',
    )

    kw = _ADDON.getSetting('paste.search_keywords') or '(por defecto)'
    add(
        f'Palabras clave de búsqueda: [COLOR yellow]{kw}[/COLOR]',
        mc.url('opt_text', key='paste.search_keywords',
               heading='Palabras clave para detectar items de búsqueda'),
        'Lista de palabras separadas por | que identifican items de búsqueda. '
        'Si el label del item contiene alguna de estas palabras, se considera un item de búsqueda. '
        'Déjalo vacío para restaurar el valor por defecto.',
        icon='search.png',
    )

    ctx_copy = _ADDON.getSettingBool('context_copy.enabled')
    add(
        f'Mostrar "Copiar a loiolink" en menu contextual: {mc.color_bool(ctx_copy)}',
        mc.url('opt_toggle', key='context_copy.enabled'),
        'Si está activado, aparece la opción "Copiar a loiolink" en el menú contextual '
        'de cualquier item con texto, que copia su label al portapapeles del addon '
        '(y al del sistema operativo si la sincronización está activada). '
        'Si está desactivado, la entrada se oculta tras ~1 s. '
        'Útil para mantener el menú contextual de Kodi sin ruido.',
        icon='search.png',
    )

    sync_os = _ADDON.getSettingBool('clipboard.sync_to_os')
    add(
        f'Sincronizar portapapeles al SO: {mc.color_bool(sync_os)}',
        mc.url('opt_toggle', key='clipboard.sync_to_os'),
        'Si está activado, el texto recibido de forma remota se copia también al portapapeles '
        'del sistema operativo (Ctrl+V en cualquier app). '
        'Si está desactivado, el texto solo queda en el portapapeles interno del addon.',
        icon='sync.png',
    )

    detect_clip = _ADDON.getSettingBool('menu.detect_clipboard')
    add(
        f'Detectar portapapeles al abrir menú: {mc.color_bool(detect_clip)}',
        mc.url('opt_toggle', key='menu.detect_clipboard'),
        'Si está activado, al abrir el menú principal del addon se comprueba si '
        'el portapapeles contiene un magnet, torrent o URL para ofrecerlo automáticamente. '
        'Si está desactivado, el menú se abre sin inspeccionar el portapapeles.',
        icon='search.png',
    )

    kb_wait = _ADDON.getSettingInt('keyboard_wait_seconds')
    add(
        f'Espera máxima al teclado virtual: [COLOR yellow]{kb_wait} s[/COLOR]',
        mc.url('opt_num', key='keyboard_wait_seconds', lo=2, hi=30,
               heading='Espera al teclado virtual (s)'),
        'Segundos que el addon espera a que aparezca el teclado virtual de Kodi '
        'antes de intentar pegar el texto. '
        f'Valor actual: {kb_wait} s. Si el teclado tarda más, el pegado se cancela. Rango: 2-30 s.',
        icon='timer.png',
    )

    mc.end()
