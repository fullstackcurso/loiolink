"""Submenu 'loioloio addons': FlowFav, LoioLog, TopZilla y EspaTV con estado de instalación."""
import os
import sys
from urllib.parse import urlencode

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MENU_ICONS = os.path.join(_ADDON_PATH, 'resources', 'media', 'menu')
_ADDONS_DIR = os.path.dirname(_ADDON_PATH)

# (addon_id, nombre_visible, plot, fallback_icon)
_ADDONS = [
    (
        'plugin.program.flowfavmanager',
        'Flow FavManager',
        'Gestor avanzado de favoritos para Kodi. Permite organizar, exportar e importar '
        'colecciones de favoritos con etiquetas y categorías personalizadas. '
        'Si no está instalado, pulsa para descargarlo e instalarlo automáticamente.',
        'flowfav.png',
    ),
    (
        'plugin.program.loiolog',
        'LoioLog',
        'Visor avanzado de logs de Kodi con filtros por nivel, búsqueda en tiempo real '
        'y exportación. Útil para depurar addons y diagnosticar problemas del sistema. '
        'Si no está instalado, pulsa para descargarlo e instalarlo automáticamente.',
        'loiolog.png',
    ),
    (
        'plugin.video.topzilla',
        'TopZilla',
        'TopZilla muestra rankings, información y vídeos relacionados de películas y series. '
        'Permite buscarlas, filtrarlas y guardar en tu biblioteca o consultar su ficha en dos clics. '
        'Si no está instalado, pulsa para descargarlo e instalarlo automáticamente.',
        'loioloio_addons.png',
    ),
    (
        'plugin.video.espatv',
        'EspaTV',
        'TDT, RTVE a la carta, búsqueda en YouTube y Dailymotion, catálogo de vídeos, radio, podcasts, '
        'reproducción de enlaces, noticias, meteorología, agenda deportiva y mucho más. '
        'Si no está instalado, pulsa para descargarlo e instalarlo automáticamente.',
        'loioloio_addons.png',
    ),
]


def _is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return os.path.isfile(os.path.join(_ADDONS_DIR, addon_id, 'addon.xml'))


def _addon_icon(addon_id, fallback_icon):
    try:
        ad = xbmcaddon.Addon(addon_id)
        path = ad.getAddonInfo('path')
    except RuntimeError:
        path = os.path.join(_ADDONS_DIR, addon_id)
    for name in ('icon.png', 'icon.jpg'):
        p = os.path.join(path, name)
        if os.path.exists(p):
            return p
    return os.path.join(_MENU_ICONS, fallback_icon)


def run():
    for addon_id, name, plot, fallback_icon in _ADDONS:
        installed = _is_installed(addon_id)
        status = '[COLOR lime]Instalado[/COLOR]' if installed else '[COLOR orange]No instalado[/COLOR]'
        label = f'{name}: {status}'
        li = xbmcgui.ListItem(accessibility.apply_label(label))
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
        icon = _addon_icon(addon_id, fallback_icon)
        li.setArt({'icon': icon, 'thumb': icon})
        url = f'{_BASE_URL}?' + urlencode({'action': 'loioloio_install', 'addon_id': addon_id})
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
