"""Asistente de primer uso.

Se ejecuta automáticamente la primera vez que el usuario abre loiolink.
Detecta el estado del sistema (red, orígenes desconocidos, plataforma) y
guía al usuario paso a paso hasta dejarle con el QR del panel web listo
para escanear.

El wizard se marca como completado en el setting `_first_run_completed`.
Puede relanzarse desde Opciones → Asistente de configuración inicial.

Diseño:
- Cada paso es un Dialog nativo de Kodi (Dialog().yesno, Dialog().select,
  Dialog().ok). No usamos WindowDialog custom para mantener compatibilidad
  con todos los skins y accesibilidad.
- Si el usuario pulsa Cancelar/Atrás en cualquier paso, el wizard se
  aborta sin marcar completado; volverá a aparecer al abrir el addon.
- El paso final muestra el QR del panel remoto (reutiliza remote_qr.run).
"""
import xbmc
import xbmcaddon
import xbmcgui

from lib import accessibility, log


SETTING_COMPLETED = '_first_run_completed'


def is_completed():
    """True si el wizard ya se ejecutó."""
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_COMPLETED)
    except (RuntimeError, TypeError):
        return False


def _mark_completed():
    try:
        xbmcaddon.Addon().setSettingBool(SETTING_COMPLETED, True)
    except RuntimeError:
        pass


def _has_network():
    """Detecta si hay red disponible (misma lógica que server.py)."""
    import socket
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != '127.0.0.1' and not ip.startswith('0.'):
            return True
    except RuntimeError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(('8.8.8.8', 80))
            return True
        finally:
            s.close()
    except OSError:
        pass
    return False


def _is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def _unknown_sources_enabled():
    """Detecta si 'Orígenes desconocidos' está activo en Kodi.

    No existe API directa. Leemos el setting interno de Kodi vía JSON-RPC.
    Si no se puede leer (Kodi viejo, permiso denegado), asumimos que está
    desactivado para ofrecer activarlo.
    """
    import json
    try:
        payload = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Settings.GetSettingValue',
            'params': {'setting': 'addons.unknownsources'},
            'id': 1,
        })
        raw = xbmc.executeJSONRPC(payload)
        resp = json.loads(raw)
        return resp.get('result', {}).get('value', False)
    except (ValueError, AttributeError, KeyError):
        return False


def _enable_unknown_sources():
    """Intenta activar 'Orígenes desconocidos' vía JSON-RPC."""
    import json
    try:
        payload = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'addons.unknownsources', 'value': True},
            'id': 1,
        })
        raw = xbmc.executeJSONRPC(payload)
        resp = json.loads(raw)
        return resp.get('result') == True
    except (ValueError, AttributeError):
        return False


def run(force=False):
    """Ejecuta el wizard. Si force=True, ignora el flag de completado."""
    if not force and is_completed():
        return

    dlg = xbmcgui.Dialog()

    # Paso 1: bienvenida
    ok = dlg.yesno(
        'Bienvenido a loiolink',
        'loiolink convierte tu móvil en el compañero perfecto '
        'de Kodi: envía texto, controla la reproducción, sube '
        'archivos e instala addons, todo desde el navegador.'
        '\n\n'
        'Este asistente te preparará todo en unos segundos.'
        '\n\n'
        '¿Empezamos?',
        yeslabel='Empezar',
        nolabel='Más tarde',
    )
    if not ok:
        return

    addon = xbmcaddon.Addon()

    # Paso 2: comprobar red
    if not _has_network():
        dlg.ok(
            'Sin conexión de red',
            'loiolink necesita que Kodi esté conectado a WiFi o '
            'Ethernet para que tu móvil pueda comunicarse con él.'
            '\n\n'
            'Conecta Kodi a la red y vuelve a abrir el addon.',
        )
        return

    # Paso 3: orígenes desconocidos
    if not _unknown_sources_enabled():
        enable = dlg.yesno(
            'Orígenes desconocidos',
            'Para instalar addons, repositorios y APKs desde el '
            'panel web de loiolink, Kodi necesita tener activada '
            'la opción "Orígenes desconocidos" en sus ajustes.'
            '\n\n'
            'Sin esta opción, podrás usar loiolink para enviar texto '
            'y controlar la reproducción, pero no para instalar nada.'
            '\n\n'
            '¿Activar "Orígenes desconocidos" ahora?',
            yeslabel='Activar',
            nolabel='No, ya lo haré',
        )
        if enable:
            if _enable_unknown_sources():
                accessibility.notify(
                    'Orígenes desconocidos activado', ms=2500,
                )
            else:
                # Algunas builds de Kodi bloquean el cambio vía JSON-RPC.
                dlg.ok(
                    'No se pudo activar automáticamente',
                    'Ve a Ajustes → Sistema → Addons → Orígenes '
                    'desconocidos y actívalo manualmente.'
                    '\n\n'
                    'El resto del addon funciona mientras tanto.',
                )

    # Paso 4: elegir modo de servidor
    mode = dlg.select(
        '¿Cómo quieres usar loiolink?',
        [
            'Siempre activo (recomendado)',
            'Bajo demanda',
        ],
    )
    if mode == -1:
        return  # Cancelado

    if mode == 0:
        # Siempre activo: modo persistente
        addon.setSettingBool('server_ephemeral_mode', False)
        addon.setSettingBool('remote_server_enabled', True)
        log.info('[wizard] configurado modo persistente')
    else:
        # Bajo demanda: modo efímero (ya es el default)
        addon.setSettingBool('server_ephemeral_mode', True)
        addon.setSettingBool('remote_server_enabled', True)
        log.info('[wizard] configurado modo efímero')

    # Paso 5: info específica de Android
    if _is_android():
        dlg.ok(
            'Nota para Android',
            'loiolink puede instalar APKs en tu Fire TV o '
            'Android TV directamente desde el navegador del móvil.'
            '\n\n'
            'Si el instalador no aparece, comprueba que Kodi '
            'tiene permiso para instalar apps en Ajustes del '
            'dispositivo → Opciones de desarrollador → Apps de '
            'fuentes desconocidas.',
        )

    # Paso 6: resumen y QR
    show_qr = dlg.yesno(
        '¡Todo listo!',
        'loiolink está configurado y funcionando.'
        '\n\n'
        'Para conectar tu móvil escanea el QR desde el navegador. '
        'El móvil debe estar en la misma red WiFi que Kodi. '
        'Si el QR no carga, comprueba que el cortafuegos permite '
        'conexiones entrantes en los puertos del addon y que ningún '
        'dispositivo tiene una VPN activa.'
        '\n\n'
        'Si no, siempre puedes encontrarlo en la primera opción '
        'del menú: "Panel web remoto".',
        yeslabel='Ver QR ahora',
        nolabel='Ir al menú',
    )

    _mark_completed()
    log.info('[wizard] completado')

    if show_qr:
        # Dar un momento al service.py para que arranque el servidor
        # si es la primera vez (recién configurado).
        xbmc.sleep(1500)
        from lib.actions import remote_qr
        remote_qr.run()
