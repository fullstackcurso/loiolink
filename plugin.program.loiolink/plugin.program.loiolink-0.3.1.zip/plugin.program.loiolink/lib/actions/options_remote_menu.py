"""Sub-carpeta de Opciones: panel web de control remoto."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Panel web remoto')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    server_on = True
    try:
        server_on = _ADDON.getSettingBool('remote_server_enabled')
    except RuntimeError:
        pass
    add(
        f'Panel web remoto: {mc.color_bool(server_on)}',
        mc.url('toggle_remote_server'),
        'Activa o desactiva el servidor que sirve el panel web de control remoto (para móvil, tablet, PC...). '
        'Si lo apagas, los marcadores del navegador dejarán de responder '
        'hasta que lo vuelvas a encender. La decisión se recuerda entre '
        'arranques de Kodi.',
        icon='remote.png',
    )

    auto_inject = _ADDON.getSettingBool('remote.auto_inject_text')
    add(
        f'Inyectar texto recibido: {mc.color_bool(auto_inject)}',
        mc.url('opt_toggle', key='remote.auto_inject_text'),
        'Si está activado, el texto recibido de forma remota se inyecta automáticamente '
        'en el teclado virtual si hay uno abierto en Kodi. '
        'Si está desactivado, solo se guarda en el clipboard del addon.',
        icon='keyboard.png',
    )

    auto_browser = False
    try:
        auto_browser = _ADDON.getSettingBool('remote.auto_open_browser')
    except RuntimeError:
        pass
    add(
        f'Abrir navegador automaticamente: {mc.color_bool(auto_browser)}',
        mc.url('opt_toggle', key='remote.auto_open_browser'),
        'Si esta activado, al pulsar "Controlar Kodi" el navegador del propio '
        'dispositivo se abre con la URL del panel (ya autenticada por token). '
        'El QR sigue apareciendo en Kodi por si el navegador no abre correctamente '
        'o quieres usar otro dispositivo. Util cuando Kodi corre en PC. '
        'Desactivado por defecto.',
        icon='remote.png',
    )

    watch_on = True
    try:
        watch_on = _ADDON.getSettingBool('watch_prompt.enabled')
    except RuntimeError:
        pass
    add(
        f'Banner "Ver aquí" en el panel: {mc.color_bool(watch_on)}',
        mc.url('opt_toggle', key='watch_prompt.enabled'),
        'Si está activado, cuando Kodi reproduzca un stream compatible (HLS/MP4) '
        'el panel web muestra un banner que ofrece "Ver aquí" para reproducirlo '
        'también en el navegador del dispositivo. '
        'Desactívalo si te molesta el aviso.',
        icon='remote.png',
    )

    rport = _ADDON.getSettingInt('remote_port')
    add(
        f'Puerto control remoto: [COLOR yellow]{rport}[/COLOR]',
        mc.url('opt_num', key='remote_port', lo=1, hi=65535,
               heading='Puerto control remoto'),
        'Puerto del servidor permanente que sirve el panel web de control remoto. '
        f'Valor actual: {rport}. Rango: 1-65535. '
        'Requiere reiniciar Kodi para que el cambio tenga efecto.',
        icon='remote.png',
    )

    add(
        'Regenerar token de control remoto',
        mc.url('regenerate_token'),
        'Genera un nuevo token de autenticación para el panel web de control remoto. '
        'Los marcadores del navegador con el token anterior dejarán de funcionar; '
        'tendrás que escanear el QR de nuevo desde "Panel web remoto".',
        icon='remote.png',
    )

    https_on = False
    try:
        https_on = _ADDON.getSettingBool('remote_https_enabled')
    except RuntimeError:
        pass
    add(
        f'HTTPS en el panel: {mc.color_bool(https_on)}',
        mc.url('toggle_https'),
        'Sirve el panel web por HTTPS en lugar de HTTP. '
        'Requiere openssl instalado en el sistema. '
        'Al activarlo el navegador mostrará "Conexión no privada" la primera vez; '
        'pulsa Avanzado y Continuar para entrar. '
        'Desactivado por defecto. Reinicia Kodi para aplicar el cambio.',
        icon='shield.png',
    )

    add(
        'Regenerar certificado HTTPS',
        mc.url('regenerate_https_cert'),
        'Genera un nuevo certificado HTTPS autofirmado para el panel web. '
        'Úsalo si has cambiado de red WiFi o si el navegador sigue mostrando '
        'errores de certificado. Requiere HTTPS activado y openssl disponible.',
        icon='shield.png',
    )

    addon_mgmt = False
    try:
        addon_mgmt = _ADDON.getSettingBool('remote.allow_addon_management')
    except RuntimeError:
        pass
    add(
        f'Gestión de addons desde el panel remoto: {mc.color_bool(addon_mgmt)}',
        mc.url('opt_toggle', key='remote.allow_addon_management'),
        'Permite habilitar y deshabilitar addons de Kodi desde el panel web de control remoto. '
        'PELIGROSO: cualquiera con acceso al QR podría dejar Kodi inutilizable. '
        'Desactivado por defecto.',
        icon='shield.png',
    )

    power = False
    try:
        power = _ADDON.getSettingBool('remote.allow_power_actions')
    except RuntimeError:
        pass
    add(
        f'Apagar/reiniciar desde el panel remoto: {mc.color_bool(power)}',
        mc.url('opt_toggle', key='remote.allow_power_actions'),
        'Permite apagar, reiniciar o suspender Kodi desde el panel web de control remoto. '
        'PELIGROSO: cualquiera con el QR podría apagar Kodi sin querer. '
        'Desactivado por defecto.',
        icon='shield.png',
    )

    mc.end()
