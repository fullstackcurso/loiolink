"""Acción 'Activar/desactivar el panel del móvil'.

Invierte el setting `remote_server_enabled`. El service del addon
detecta el cambio en su loop (<= 1 s) y arranca o para el HTTP
correspondiente. No tocamos el server desde aquí: ese trabajo es del
service (que vive en otro proceso Python que es quien tiene la
referencia al objeto del socket).
"""
import xbmc
import xbmcaddon

from lib import accessibility


SETTING = 'remote_server_enabled'


def run():
    addon = xbmcaddon.Addon()
    try:
        enabled = addon.getSettingBool(SETTING)
    except RuntimeError:
        enabled = True
    new = not enabled
    addon.setSettingBool(SETTING, new)
    if new:
        accessibility.notify('Panel web remoto encendido', ms=2500)
    else:
        accessibility.notify('Panel web remoto apagado', ms=2500)
    xbmc.executebuiltin('Container.Refresh')
