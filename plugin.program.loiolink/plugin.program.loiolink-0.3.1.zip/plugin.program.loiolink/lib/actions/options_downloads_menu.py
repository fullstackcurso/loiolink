"""Sub-carpeta de Opciones: descargas y transferencias."""
import xbmcaddon

from lib.actions import _menu_common as mc

_ADDON = xbmcaddon.Addon()


def run():
    mc.begin('Descargas')
    acc = mc.acc_kwargs()

    def add(label, item_url, plot, icon='settings.png'):
        mc.make_item(label, item_url, plot, icon=icon, acc=acc)

    dest = _ADDON.getSetting('transfer.dest_folder') or '(perfil del addon)'
    add(
        f'Carpeta de destino: [COLOR yellow]{dest}[/COLOR]',
        mc.url('opt_folder', key='transfer.dest_folder',
               heading='Carpeta de destino para archivos recibidos'),
        'Carpeta donde se guardan los archivos recibidos de forma remota. '
        'Déjalo vacío para usar la carpeta del perfil del addon.',
        icon='sources.png',
    )

    auto = _ADDON.getSettingBool('transfer.auto_action')
    add(
        f'Acción automática tras descarga: {mc.color_bool(auto)}',
        mc.url('opt_toggle', key='transfer.auto_action'),
        'Si está activado, al completar una descarga se ejecuta automáticamente '
        'la acción correspondiente (reproducir, instalar addon, etc.) sin preguntar. '
        'Si está desactivado, aparece un menú para elegir qué hacer.',
        icon='auto.png',
    )

    dlg_always = _ADDON.getSettingBool('transfer.always_use_dialog')
    add(
        f'Siempre mostrar diálogo tras descarga: {mc.color_bool(dlg_always)}',
        mc.url('opt_toggle', key='transfer.always_use_dialog'),
        'Si está activado, siempre aparece un diálogo de descarga completada al terminar una transferencia, '
        'aunque la acción sea obvia. '
        'Si está desactivado, usa notificaciones discretas cuando puede.',
        icon='dialog.png',
    )

    maxgb = _ADDON.getSettingInt('transfer_max_size_gb')
    add(
        f'Límite por descarga: [COLOR yellow]{maxgb} GB[/COLOR]',
        mc.url('opt_num', key='transfer_max_size_gb', lo=1, hi=50,
               heading='Límite por descarga (GB)'),
        'Tamaño máximo permitido por archivo descargado. '
        f'Archivos más grandes que {maxgb} GB se rechazan antes de empezar. '
        'Rango: 1-50 GB.',
        icon='download_limit.png',
    )

    dl_t = _ADDON.getSettingInt('network.timeout_download_s')
    add(
        f'Timeout descarga: [COLOR yellow]{dl_t} s[/COLOR]',
        mc.url('opt_num', key='network.timeout_download_s', lo=5, hi=180,
               heading='Timeout descarga de archivos (s)'),
        f'Segundos sin recibir datos del servidor antes de cancelar una descarga. '
        f'No es el tiempo total; una descarga lenta pero continua no se cancela. '
        f'Súbelo en redes inestables. Valor actual: {dl_t} s. Rango: 5-180 s.',
        icon='timer.png',
    )

    action_panel = _ADDON.getSettingBool('transfer.action_in_panel')
    add(
        f'Confirmar acción tras subida EN el panel: {mc.color_bool(action_panel)}',
        mc.url('opt_toggle', key='transfer.action_in_panel'),
        'Si está activado, cuando subes un archivo desde el panel web la pregunta '
        '"¿qué hago con esto?" aparece EN el navegador (no en la TV). Anula la '
        'auto-acción y el diálogo en Kodi para esos uploads concretos. '
        'Recomendado: deja activado para que el usuario que sube decida sin '
        'tener que mirar la TV.',
        icon='dialog.png',
    )

    chunk = _ADDON.getSettingInt('upload.chunk_size_mb')
    add(
        f'Tamaño de chunk para subidas grandes: [COLOR yellow]{chunk} MB[/COLOR]',
        mc.url('opt_num', key='upload.chunk_size_mb', lo=1, hi=50,
               heading='Tamaño de chunk para subidas grandes (MB)'),
        f'Las subidas grandes se trocean en chunks de este tamaño. Chunks más '
        f'pequeños pierden menos progreso si la conexión falla pero añaden más '
        f'overhead. Si subes mayoritariamente vídeo en LAN estable, sube a 10-20 MB. '
        f'Valor actual: {chunk} MB. Rango: 1-50 MB.',
        icon='download_limit.png',
    )

    ttl = _ADDON.getSettingInt('upload.session_ttl_hours')
    add(
        f'TTL de subidas incompletas: [COLOR yellow]{ttl} h[/COLOR]',
        mc.url('opt_num', key='upload.session_ttl_hours', lo=1, hi=168,
               heading='TTL de sesiones de subida incompletas (horas)'),
        f'Cuántas horas se conservan los chunks ya recibidos cuando una subida '
        f'se interrumpe (cliente cierra el navegador, se cae la red). Pasado el '
        f'TTL, el servicio limpia los chunks huérfanos para no consumir disco. '
        f'Valor actual: {ttl} h. Rango: 1-168 h (1 semana).',
        icon='timer.png',
    )

    threshold = _ADDON.getSettingInt('upload.incremental_threshold_mb')
    add(
        f'MB mínimos antes de reproducir (modo "Mientras sube"): [COLOR yellow]{threshold} MB[/COLOR]',
        mc.url('opt_num', key='upload.incremental_threshold_mb', lo=1, hi=100,
               heading='MB mínimos en disco antes de reproducir'),
        f'En el modo "Mientras sube", Kodi empieza a reproducir cuando ya hay '
        f'este margen de MB en disco. Demasiado bajo: el reproductor alcanza al '
        f'descargador y se atasca. Demasiado alto: tarda más en arrancar la '
        f'reproducción. Valor actual: {threshold} MB. Rango: 1-100 MB.',
        icon='auto.png',
    )

    # Grabación HLS al disco. Misma categoría que descargas: el flujo
    # produce un .ts en la carpeta de destino y aparece en el historial.
    hls_on = _ADDON.getSettingBool('transfer.hls.enabled')
    add(
        f'Grabación de streams HLS: {mc.color_bool(hls_on)}',
        mc.url('opt_toggle', key='transfer.hls.enabled'),
        'Si está activado, el panel web muestra el botón "Grabar" junto a "Cast" '
        'cuando pegas una URL de stream (.m3u8/.mpd/.m3u/.ts o rtmp/rtsp). '
        'La grabación se guarda en la carpeta de destino y aparece en el historial.',
        icon='download_limit.png',
    )

    hls_max = _ADDON.getSettingInt('transfer.hls.max_concurrent')
    add(
        f'Grabaciones HLS simultáneas máximas: [COLOR yellow]{hls_max}[/COLOR]',
        mc.url('opt_num', key='transfer.hls.max_concurrent', lo=1, hi=10,
               heading='Grabaciones HLS simultáneas máximas'),
        f'Cuántas grabaciones puede haber activas a la vez. Una grabación HLS '
        f'consume CPU+RAM+disco y red sostenidos. Valor actual: {hls_max}. Rango: 1-10.',
        icon='download_limit.png',
    )

    hls_dur = _ADDON.getSettingInt('transfer.hls.max_duration_mins')
    add(
        f'Duración máxima por grabación HLS: [COLOR yellow]{hls_dur} min[/COLOR]',
        mc.url('opt_num', key='transfer.hls.max_duration_mins', lo=0, hi=720,
               heading='Duración máxima por grabación HLS (min)'),
        f'Tope de tiempo por grabación. 0 = sin límite (la grabación termina '
        f'cuando el stream pone #EXT-X-ENDLIST, cuando paras desde el panel '
        f'o cuando el canal deja de emitir). Valor actual: {hls_dur} min. '
        f'Rango: 0-720 min (12 h).',
        icon='timer.png',
    )

    hls_free = _ADDON.getSettingInt('transfer.hls.min_free_space_mb')
    add(
        f'Espacio libre mínimo para grabar HLS: [COLOR yellow]{hls_free} MB[/COLOR]',
        mc.url('opt_num', key='transfer.hls.min_free_space_mb',
               lo=100, hi=50000,
               heading='Espacio libre mínimo para iniciar grabación HLS (MB)'),
        f'Comprobación previa: si la carpeta de destino tiene menos de este '
        f'espacio libre, la grabación no arranca (devuelve error en el panel). '
        f'Durante la grabación, si se llena el disco (ENOSPC), la grabación '
        f'aborta limpia y el archivo .partial queda como está. '
        f'Valor actual: {hls_free} MB. Rango: 100-50000 MB.',
        icon='sources.png',
    )

    mc.end()
