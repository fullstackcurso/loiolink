"""Acción 'Importar texto del portapapeles del sistema'.

Lee el clipboard del SO. Caminos en orden de preferencia:
- vacío / Android sin JNI → notificación discreta.
- acestream URI o ID desnudo (40 hex) → reproducir vía Plexus o Horus.
- magnet URI → encolar evento magnet_received (el service abre Elementum
  o pide instalarlo).
- stream URL (RTMP/RTSP/HLS/DASH o http con pipe-headers) → reproducir
  directamente con Player.Open.
- URL de servicio conocido (YouTube/Twitch/Vimeo/SoundCloud/Dailymotion)
  → resolver a plugin:// con la cadena de fallback de plugins instalados.
- URL de página http(s) cualquiera → escanear HTML buscando vídeos
  embebidos; si hay resultados, ofrecer selector. Si no, caer a texto.
- texto normal → vuelca al clipboard interno y notifica.

El input pasa primero por `mux()` para tolerar URLs sin esquema
("youtube.com/watch?v=X") sin romper los clasificadores anteriores.

Android: get_system_clipboard devuelve None (Kodi no expone ClipboardManager
sin JNI). La notificación lo indica al usuario.
"""
import xbmcgui

import clipboard
from lib import accessibility, log, os_clipboard, url_utils
from lib.actions import url_resolver
from lib.remote import acestream as ace
from lib.remote import elementum
from lib.remote import player as kodi_player
from lib.remote import stream_player
from lib.transfers import history, video_scanner


def run():
    text = os_clipboard.get_system_clipboard()

    if not text or not text.strip():
        accessibility.notify('Portapapeles vacío o no soportado', ms=3000)
        return

    process_text(text)


def process_text(text):
    """Clasifica y procesa un texto como si viniera del clipboard del SO.

    Usado por run() (clipboard del SO) y por open_url_input (URL tecleada
    manualmente o repetida desde el historial). Maneja vacío silenciosamente:
    quien quiera notificar al usuario "input vacío" debe hacerlo antes de llamar.
    """
    if not text or not text.strip():
        return

    text = text.strip()

    # Normalizamos antes de clasificar: el usuario pega a menudo
    # "youtube.com/watch?..." sin esquema. mux() devuelve la URL con
    # http:// añadido (o None si la entrada no es URL reproducible). Si
    # mux rechaza, conservamos el texto original para el camino
    # "texto normal" más abajo.
    normalized = url_utils.mux(text)
    if normalized:
        text = normalized

    if ace.is_acestream(text):
        try:
            ace.play(text)
            accessibility.notify('Acestream: lanzando...', ms=2500)
            log.info(f'paste_clipboard: acestream -> play ({len(text)} chars)')
            # Diagnóstico post-play: el error típico "can not get transport
            # file" viene del motor AceStream Engine externo (no del addon).
            # Si no responde en 127.0.0.1:6878, avisamos al usuario para
            # ahorrarle el tiempo de descubrirlo por error opaco de Plexus.
            if not ace.engine_running():
                accessibility.notify(
                    'AceStream Engine no responde en 127.0.0.1:6878. '
                    'Si no reproduce, inicia el motor.',
                    ms=5000,
                )
                log.warning('paste_clipboard: acestream engine no detectado')
        except RuntimeError:
            accessibility.notify(
                'Acestream requiere Plexus/Horus + AceStream Engine corriendo',
                ms=5000,
            )
            log.warning('paste_clipboard: acestream sin cliente (Plexus/Horus)')
        return

    # Magnet URI → derivar a Elementum (no tiene sentido meterlo en el
    # clipboard interno, no es texto para pegar en cuadros de búsqueda).
    if elementum.is_magnet(text):
        history.queue_event({'kind': 'magnet_received', 'uri': text})
        accessibility.notify('Magnet detectado, abriendo Elementum...', ms=2500)
        log.info(f'paste_clipboard: magnet -> service ({len(text)} chars)')
        return

    # Stream URL (RTMP, RTSP, HLS, DASH, pipe-headers) → Player.Open directo.
    if stream_player.is_stream_url(text):
        try:
            stream_player.play(text)
            accessibility.notify('Stream: reproduciendo...', ms=2500)
            log.info(f'paste_clipboard: stream_url -> player ({len(text)} chars)')
        except RuntimeError as e:
            msg = str(e)
            if msg.startswith('missing_inputstream:'):
                iid = msg.split(':', 1)[1]
                accessibility.notify(f'Instala {iid} para reproducir', ms=4000)
                log.warning(f'paste_clipboard: stream sin {iid}')
            else:
                accessibility.notify(f'Stream falló: {e}', ms=4000)
                log.warning(f'paste_clipboard: stream falló: {e}')
        return

    # URL de servicio conocido (YouTube/Twitch/Vimeo/SoundCloud) →
    # convertir a plugin:// y reproducir vía Player.Open. La cadena de
    # fallback se evalúa contra los addons instalados; si ninguno está
    # disponible, devuelve None y el texto cae a clipboard interno
    # como cualquier otro contenido sin destino reproducible.
    plugin_url = url_resolver.resolve(text)
    if plugin_url is not None:
        kodi_player.play_file(plugin_url)
        accessibility.notify('Servicio: reproduciendo...', ms=2500)
        log.info(f'paste_clipboard: resolver -> {plugin_url[:120]!r}')
        return

    # URL http(s) que no es stream ni servicio conocido: la página puede
    # contener vídeos embebidos, magnets o .torrent. video_scanner orquesta
    # html_scanner regex + yt-dlp (si disponible), fusiona resultados con
    # dedup. Peor caso ~30-60s con yt-dlp activo → DialogProgressBG visible.
    if text.startswith(('http://', 'https://')):
        bg = xbmcgui.DialogProgressBG()
        bg.create('loiolink', 'Escaneando vídeos…')
        bg.update(0, 'loiolink', 'Escaneando vídeos…')
        try:
            videos = video_scanner.scan_videos(text, timeout=8)
        except Exception as e:
            log.warning(f'paste_clipboard: scanner falló: {e!r}')
            videos = []
        finally:
            bg.close()
        if videos:
            titles = [v.get('title') or v.get('url', '')[:80] for v in videos]
            idx = xbmcgui.Dialog().select(
                'Vídeos encontrados en la página', titles,
            )
            if idx < 0:
                log.info('paste_clipboard: scanner cancelado por usuario')
                return
            _play_scanner_pick(videos[idx])
            return

    # Texto normal → clipboard interno (con sync al SO via clipboard.py).
    clipboard.set(text)
    preview = text[:50] + ('...' if len(text) > 50 else '')
    accessibility.notify(f'Copiado: {preview}', ms=3000)
    log.info(f'paste_clipboard: texto -> interno ({len(text)} chars)')


def _play_scanner_pick(entry):
    """Despacha un resultado del scanner según su `kind`.

    - 'magnet': llama a Elementum directamente. Si no está instalado,
      cae al evento `magnet_received` del service (que tiene fallback
      Horus + auto-install Elementum).
    - 'torrent' (URL http://...torrent): Elementum.play() acepta paths
      y URLs http a .torrent. Si Elementum no está, notificamos: el
      service NO maneja torrent URLs (play_magnet_with_fallback rechaza
      no-magnets con ValueError).
    - 'video' (default): pasa por url_resolver (iframe YT → plugin://...)
      y luego al player.
    """
    from lib.remote import elementum
    chosen_url = (entry.get('url') or '').strip()
    if not chosen_url:
        return
    kind = entry.get('kind', 'video')

    if kind == 'magnet':
        if elementum.is_installed():
            elementum.play(chosen_url)
            accessibility.notify('Magnet abierto en Elementum', ms=2500)
        else:
            # Delegar al service (UI de install + fallback Horus).
            history.queue_event({'kind': 'magnet_received', 'uri': chosen_url})
            accessibility.notify('Magnet detectado, abriendo Elementum...', ms=2500)
        log.info(f'paste_clipboard: scanner magnet -> {chosen_url[:120]!r}')
        return

    if kind == 'torrent':
        if elementum.is_installed():
            elementum.play(chosen_url)
            accessibility.notify('Torrent abierto en Elementum', ms=2500)
        else:
            accessibility.notify(
                'Elementum no está instalado (necesario para .torrent)',
                ms=4000,
            )
        log.info(f'paste_clipboard: scanner torrent -> {chosen_url[:120]!r}')
        return

    # kind == 'video' (o desconocido): pipeline original.
    chosen_resolved = url_resolver.resolve(chosen_url) or chosen_url
    kodi_player.play_file(chosen_resolved)
    accessibility.notify('Reproduciendo vídeo detectado…', ms=2500)
    log.info(f'paste_clipboard: scanner pick -> {chosen_url[:120]!r}')
