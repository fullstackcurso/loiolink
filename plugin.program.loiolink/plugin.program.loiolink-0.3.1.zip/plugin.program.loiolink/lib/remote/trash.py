"""Papelera del file browser. Mueve archivos/carpetas borrados a
addon_data/trash/ con manifest JSON y permite restaurar o purgar.

Layout:
  special://profile/addon_data/plugin.program.loiolink/trash/
    <trash_id>/
      payload/<basename>     (archivo o subárbol)
      manifest.json          (metadata)

trash_id: 'YYYYMMDDHHMMSSmmm_xxxx' (ordenable lexicográficamente + 16 bits
de entropía contra colisiones en deletes simultáneos).

LIMITACIONES (deliberadas):
- Solo fuentes LOCALES (_is_local_path). Sources de red (smb://, nfs://, etc.)
  hacen borrado directo; el caller decide tras leer el setting y consultar
  el path.
- Cross-device (rename con EXDEV): fallback shutil.copytree + rmtree. Lento
  para archivos grandes; el caller debe mostrar busy mientras.
- max_items por número, NO por bytes. Un usuario con max_items=100 puede
  acumular muchos GB. Documentado en el label del setting.

Concurrencia: RLock global. Operaciones son cortas excepto move_to_trash
cross-device. Tradeoff aceptado (single-user típico).
"""
import errno
import json
import os
import re
import secrets
import shutil
import threading
import time

from lib import log

# Formato estricto del trash_id producido por _new_trash_id: 17 dígitos
# (YYYYMMDDHHMMSSmmm) + '_' + 8 hex chars. Defensa anti path traversal:
# sin esto, un cliente que pase id='../../etc' en /trash/restore podría
# hacer que _entry_dir genere una ruta fuera de addon_data/trash/.
_TRASH_ID_RE = re.compile(r'^\d{17}_[0-9a-f]{8}$')


def is_valid_trash_id(tid):
    """¿tid coincide con el formato producido por _new_trash_id?

    Caller obligatorio en cualquier endpoint que reciba id del cliente.
    """
    return bool(tid and isinstance(tid, str) and _TRASH_ID_RE.match(tid))


_LOCK = threading.RLock()
_TRASH_DIRNAME = 'trash'
_MANIFEST_NAME = 'manifest.json'
_PAYLOAD_DIRNAME = 'payload'

# Archivos cuyo borrado puede romper Kodi. is_critical_path los marca SOLO
# cuando están dentro de special://home: un archivo llamado igual en una
# fuente del usuario no es crítico. Comparación case-insensitive para que
# Windows (FS case-insensitive) y typos en bases de datos legacy también
# entren; Linux/Android suelen tener case fijo pero no hace daño.
_CRITICAL_BASENAMES = frozenset({
    'addons33.db',
    'textures13.db',
    'myvideos131.db',
    'mymusic82.db',
    'guisettings.xml',
    'sources.xml',
    'advancedsettings.xml',
    'passwords.xml',
    'mediasources.xml',
    'profiles.xml',
    'favourites.xml',
    'kodi.log',
})


def is_critical_path(path):
    """¿path apunta a un archivo crítico de Kodi dentro de special://home?

    Caller en el endpoint de delete debe llamar a esto ANTES de move_to_trash
    para mostrar un warning extra al usuario. La función NO bloquea; solo
    informa. El bypass se hace pasando `force=True` desde el frontend.

    Solo considera críticos los archivos DENTRO de special://home: un fichero
    llamado guisettings.xml que el usuario ha hecho copia a Descargas no es
    crítico, solo el del directorio de Kodi.

    Usamos abspath (no realpath): la decisión depende del path LÓGICO que el
    usuario ve en el file browser, no del target del symlink. Si el usuario
    clica un symlink dentro de Kodi home cuyo target está fuera, igual quiere
    el warning porque está borrando un alias DENTRO de Kodi.
    """
    if not path:
        return False
    try:
        basename = os.path.basename(path.rstrip('/\\'))
    except (AttributeError, TypeError):
        return False
    if basename.lower() not in _CRITICAL_BASENAMES:
        return False
    try:
        import xbmcvfs
        kodi_home = xbmcvfs.translatePath('special://home/')
    except (ImportError, OSError):
        return False
    try:
        abs_path = os.path.abspath(path)
        abs_home = os.path.abspath(kodi_home)
        # commonpath lanza ValueError en Windows si los paths están en drives
        # distintos (C: vs D:); capturado abajo. En POSIX no aplica.
        common = os.path.commonpath([abs_path, abs_home])
        return os.path.normcase(common) == os.path.normcase(abs_home)
    except (OSError, ValueError):
        return False


def trash_dir():
    """Devuelve la ruta de la papelera. La crea si no existe.

    Llamada perezosa: si el usuario borra addon_data/trash entero con un
    explorador, la siguiente operación lo recrea sin error.
    """
    import xbmcvfs
    base = xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.program.loiolink/')
    d = os.path.join(base, _TRASH_DIRNAME)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError as e:
        log.warning(f'[trash] no se pudo crear {d}: {e}')
    return d


def _new_trash_id():
    # token_hex(4) → 32 bits de entropía. Con 16 bits (token_hex(2)) la
    # probabilidad de colisión con 10 deletes paralelos en el mismo ms es
    # ~0.08% (birthday paradox). Con 32 bits es despreciable (<1e-7).
    now = time.time()
    ms = int(now * 1000)
    ts = time.strftime('%Y%m%d%H%M%S', time.localtime(now))
    return f'{ts}{ms % 1000:03d}_{secrets.token_hex(4)}'


def _entry_dir(trash_id):
    return os.path.join(trash_dir(), trash_id)


def _write_manifest_atomic(entry_dir, data):
    """Escribe manifest.json atómicamente (tmp + os.replace + fsync).

    fsync sobre el tmp antes del replace evita que tras un crash quede el
    archivo final con contenido truncado.
    """
    target = os.path.join(entry_dir, _MANIFEST_NAME)
    tmp = target + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            # fsync puede no estar soportado (algunos FS); el atomic replace
            # sigue siendo seguro para el cambio simbólico.
            pass
    os.replace(tmp, target)


def _read_manifest(entry_dir):
    """Lee manifest.json. Devuelve dict o None si corrupto/no existe."""
    target = os.path.join(entry_dir, _MANIFEST_NAME)
    try:
        with open(target, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        log.warning(f'[trash] manifest corrupto en {entry_dir!r}: {e}')
        return None


def _size_of(path):
    """Tamaño en bytes para ARCHIVOS. Carpetas devuelven -1 (la UI muestra "?").

    Decisión consistente con F9 del plan: NO recorrer subárboles. En sources
    con millones de archivos o SMB lentos, un os.walk previo al rename
    bloquearía move_to_trash durante segundos. La UI ya está preparada
    para size=-1 mostrando "?".
    """
    try:
        if os.path.isfile(path) and not os.path.islink(path):
            return os.path.getsize(path)
    except OSError:
        pass
    return -1


def _cleanup_partial(entry_dir):
    """Borra un entry parcial (move falló a la mitad). ignore_errors=True
    porque puede haber estado inconsistente sin garantía de readability."""
    try:
        if os.path.isdir(entry_dir):
            shutil.rmtree(entry_dir, ignore_errors=True)
    except OSError:
        pass


def move_to_trash(src_path):
    """Mueve src_path a la papelera. Devuelve trash_id o None si falló.

    - Si src no es local → None (caller debe ofrecer borrado directo).
    - lexists (no exists): captura symlinks rotos también, OK borrarlos.
    - Symlinks: se mueve el LINK, no el target (islink check explícito).
    - Intenta os.rename primero (atómico, mismo FS).
    - Cross-device (EXDEV / ENOTSUP) → shutil.copytree + rmtree.
    - Si copy parcial falla, _cleanup_partial borra el payload incompleto.
    - Manifest se escribe DESPUÉS del payload (atómico). Si manifest falla,
      el entry se borra (preferible perder el archivo que dejar huérfano).
    """
    from lib.remote import library
    clean = src_path.rstrip('/\\')
    if not library._is_local_path(clean):
        return None
    # lexists: True también para symlinks rotos. exists devolvería False
    # y bloquearíamos legítimos borrados de links rotos.
    if not os.path.lexists(clean):
        return None

    # Clasificación: un symlink a directorio NO debe tratarse como dir
    # (so pena de seguir el link en _size_of/copytree). islink primero.
    is_symlink = os.path.islink(clean)
    is_dir = (not is_symlink) and os.path.isdir(clean)
    basename = os.path.basename(clean) or 'sin_nombre'
    # Tamaño solo para archivos (instantáneo). Carpetas y links → -1.
    size = _size_of(clean) if not is_dir and not is_symlink else -1

    with _LOCK:
        trash_id = _new_trash_id()
        entry = _entry_dir(trash_id)
        payload_root = os.path.join(entry, _PAYLOAD_DIRNAME)
        try:
            os.makedirs(payload_root, exist_ok=True)
        except OSError as e:
            log.warning(f'[trash] no se pudo crear {payload_root}: {e}')
            return None

        target = os.path.join(payload_root, basename)

        # 1) Intento rápido: os.rename. Atómico, sin overhead.
        # Cubre file, dir y symlink (mueve el link, no el target).
        try:
            os.rename(clean, target)
        except OSError as e:
            # EXDEV = cross-device. ENOTSUP = el FS rechaza rename. Resto =
            # error real (FileNotFoundError si el archivo desapareció entre
            # el lexists y aquí; PermissionError si está en uso Windows;
            # OSError genérico) → no recover, devolver None.
            if e.errno not in (errno.EXDEV, getattr(errno, 'ENOTSUP', -1)):
                log.warning(f'[trash] rename falló ({e}); src={clean!r}')
                _cleanup_partial(entry)
                return None
            # 2) Cross-device: copy + delete. Puede tardar minutos.
            try:
                if is_symlink:
                    # Recreamos el link en destino y borramos el original.
                    # shutil.copy2 con follow_symlinks=False copia el link,
                    # pero entre filesystems la semántica varía; usamos
                    # readlink+symlink para garantía.
                    link_target = os.readlink(clean)
                    os.symlink(link_target, target)
                    os.unlink(clean)
                elif is_dir:
                    # symlinks=True: mover los links internos COMO links,
                    # no seguirlos. Evita ciclos infinitos y duplicación.
                    shutil.copytree(clean, target, symlinks=True)
                    shutil.rmtree(clean)
                else:
                    shutil.copy2(clean, target)
                    os.remove(clean)
            except OSError as e2:
                log.warning(f'[trash] copy+delete falló: {e2}; src={clean!r}')
                _cleanup_partial(entry)
                return None

        # 3) Manifest atómico DESPUÉS de mover.
        # deleted_at en MILISEGUNDOS: con segundos, 5+ deletes seguidos
        # comparten timestamp y enforce_limit no puede ordenar bien quién
        # es "el más viejo". El frontend divide por 1000 para fmtDate.
        manifest = {
            'id': trash_id,
            'original_path': clean,
            'name': basename,
            # is_symlink se guarda en el dict por si lo necesita el
            # restore para recrear con symlink en cross-device.
            'is_dir': is_dir,
            'is_symlink': is_symlink,
            'size': size,
            'deleted_at': int(time.time() * 1000),
        }
        try:
            _write_manifest_atomic(entry, manifest)
        except OSError as e:
            log.warning(f'[trash] manifest write falló: {e}; rollback')
            # No podemos restaurar sin manifest. Mejor borrar el entry
            # (perdemos el archivo) que dejar payload huérfano.
            _cleanup_partial(entry)
            return None

        log.sensitive(f'[trash] move {clean!r} → {trash_id}')
        return trash_id


def list_trash():
    """[{id, original_path, name, size, deleted_at, is_dir}, ...] desc por fecha.

    Items con manifest corrupto o sin payload se ignoran con log warning.
    """
    out = []
    with _LOCK:
        root = trash_dir()
        try:
            ids = os.listdir(root)
        except OSError:
            return []
        for tid in ids:
            # Ignora dirs con nombres que NO son ID válido (basura externa).
            if not is_valid_trash_id(tid):
                continue
            entry = os.path.join(root, tid)
            if not os.path.isdir(entry):
                continue
            m = _read_manifest(entry)
            if not m:
                continue
            payload = os.path.join(entry, _PAYLOAD_DIRNAME)
            if not os.path.isdir(payload):
                log.warning(f'[trash] payload missing: {tid}')
                continue
            out.append(m)
    # Sort por deleted_at desc + id como desempate (lexicográficamente
    # ordenable, contiene ms+entropía). Sin secondary sort, dos items con
    # mismo deleted_at podrían reordenarse según el orden de os.listdir.
    out.sort(key=lambda x: (x.get('deleted_at', 0), x.get('id', '')), reverse=True)
    return out


def _find_free_name(path):
    """Si path no existe, devuelve path. Si existe, añade '(restaurado N)'
    antes de la extensión hasta encontrar uno libre (N de 1 a 999)."""
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    for i in range(1, 1000):
        candidate = f'{base} (restaurado {i}){ext}'
        if not os.path.exists(candidate):
            return candidate
    raise OSError('No se encontró nombre libre tras 999 intentos.')


def restore(trash_id):
    """Devuelve (ok, mensaje_o_path_destino).

    Si el dst está ocupado, añade sufijo "(restaurado N)" antes de la extensión.
    Si el parent del original_path ya no existe (source borrada), error claro.
    """
    if not is_valid_trash_id(trash_id):
        return False, 'ID inválido.'
    with _LOCK:
        entry = _entry_dir(trash_id)
        m = _read_manifest(entry)
        if not m:
            return False, 'Item no encontrado o corrupto.'
        payload_root = os.path.join(entry, _PAYLOAD_DIRNAME)
        if not os.path.isdir(payload_root):
            return False, 'Payload no encontrado.'
        items_in_payload = os.listdir(payload_root)
        if not items_in_payload:
            return False, 'Payload vacío (papelera corrupta).'
        src = os.path.join(payload_root, items_in_payload[0])

        original = m['original_path']
        parent = os.path.dirname(original.rstrip('/\\'))
        if not parent or not os.path.isdir(parent):
            return False, (
                'La carpeta original ya no existe. '
                f'Ruta: {original}')

        try:
            dst = _find_free_name(original)
        except OSError as e:
            return False, str(e)

        # Rename, con fallback copy+delete si cross-device.
        # is_symlink en el manifest cubre el caso de symlinks restaurados
        # cross-device (readlink+symlink en vez de copy2).
        try:
            os.rename(src, dst)
        except OSError as e:
            if e.errno not in (errno.EXDEV, getattr(errno, 'ENOTSUP', -1)):
                return False, f'No se pudo restaurar ({e}).'
            try:
                if m.get('is_symlink'):
                    link_target = os.readlink(src)
                    os.symlink(link_target, dst)
                    os.unlink(src)
                elif m.get('is_dir'):
                    shutil.copytree(src, dst, symlinks=True)
                    shutil.rmtree(src)
                else:
                    shutil.copy2(src, dst)
                    os.remove(src)
            except OSError as e2:
                return False, f'No se pudo restaurar ({e2}).'

        # Limpiar el trash entry: manifest + payload (vacío) + dir.
        _cleanup_partial(entry)
        log.sensitive(f'[trash] restore {trash_id} → {dst}')
        return True, dst


def purge(trash_id):
    """Borra definitivamente un item. True si se borró, False si no existía."""
    if not is_valid_trash_id(trash_id):
        return False
    with _LOCK:
        entry = _entry_dir(trash_id)
        if not os.path.isdir(entry):
            return False
        try:
            shutil.rmtree(entry)
            log.info(f'[trash] purge {trash_id}')
            return True
        except OSError as e:
            log.warning(f'[trash] purge falló {trash_id}: {e}')
            return False


def purge_all():
    """Vacía la papelera. Devuelve nº items con ID válido purgados.

    Solo borra dirs cuyo nombre matchea is_valid_trash_id. Cualquier otro
    contenido (basura externa, archivos sueltos, dirs con nombres raros
    de un proceso externo) se ignora; no es papelera nuestra y no
    queremos tocarlo aunque el usuario nos dé "vaciar todo".
    """
    n = 0
    with _LOCK:
        root = trash_dir()
        try:
            entries = os.listdir(root)
        except OSError:
            return 0
        for name in entries:
            if not is_valid_trash_id(name):
                continue
            p = os.path.join(root, name)
            if not os.path.isdir(p):
                continue
            try:
                shutil.rmtree(p)
                n += 1
            except OSError as e:
                log.warning(f'[trash] purge_all dir falló {name}: {e}')
    log.info(f'[trash] purge_all: {n} items')
    return n


def enforce_limit(max_items):
    """Aplica límite, purgando los más antiguos. Devuelve nº expulsados.

    Defensa: max_items < 1 se trata como 1; nunca purgar todo accidentalmente
    por un setting corrupto o un bug del frontend.
    """
    max_items = max(1, int(max_items or 1))
    items = list_trash()  # ya ordenado desc por deleted_at
    if len(items) <= max_items:
        return 0
    n = 0
    with _LOCK:
        for m in items[max_items:]:
            if purge(m['id']):
                n += 1
    return n


def cleanup_orphans():
    """Barrido de items inconsistentes. Llamada perezosa al primer list_trash
    desde el panel. Borra:
    - entries con manifest pero sin payload (o payload vacío),
    - entries con payload pero sin manifest.

    NO toca dirs con nombre fuera de is_valid_trash_id (basura externa) ni
    archivos sueltos en root; solo gestionamos lo que claramente es nuestro.
    """
    with _LOCK:
        root = trash_dir()
        try:
            ids = os.listdir(root)
        except OSError:
            return
        for tid in ids:
            if not is_valid_trash_id(tid):
                continue
            entry = os.path.join(root, tid)
            if not os.path.isdir(entry):
                continue
            m = _read_manifest(entry)
            payload = os.path.join(entry, _PAYLOAD_DIRNAME)
            payload_ok = os.path.isdir(payload) and bool(os.listdir(payload))
            if not m or not payload_ok:
                log.warning(f'[trash] cleanup orphan: {tid}')
                _cleanup_partial(entry)
