"""Subclase de `xbmc.Monitor` que conecta los eventos JSON-RPC de Kodi
con los caches y long-polls del addon.

Reemplaza la instancia plana `xbmc.Monitor()` usada en `service.py`. La
API pública es la misma (`abortRequested`, `waitForAbort`); por dentro,
los hooks `onNotification`, `onSettingsChanged`, `onScanFinished` y
`onCleanFinished` despachan a callbacks registrados.

Diseño:

- El monitor NO conoce el cache. Llama a `notify.bump_status` y
  `library_cache.invalidate_*`; estos módulos publican lo que pasa.
- Los callbacks específicos (settings hot-reload, etc.) se pasan en
  `__init__` para evitar imports cíclicos y mantener el monitor
  reutilizable en otros contextos.
- Excepciones en callbacks NO se propagan a Kodi (sería un crash del
  service); se loguean y se traga el error.
"""
import json
from typing import Callable, Optional

import xbmc

from lib import log
from lib.remote import notify


class LoiolinkMonitor(xbmc.Monitor):
    """Monitor con callbacks tipados.

    Parámetros del constructor:

    on_settings_changed: invocado cuando el usuario guarda settings del
        addon. Útil para hot-reload del servidor sin esperar al polling
        1 Hz de `service.run`. None desactiva el callback.

    on_library_scan_finished: invocado con ('video'|'music') tras el
        evento `OnScanFinished` correspondiente. Pensado para invalidar
        el library_cache. None desactiva.

    on_library_clean_finished: idem para `OnCleanFinished`.

    on_video_library_update / on_audio_library_update: invocados con el
        payload `data` de `VideoLibrary.OnUpdate` / `AudioLibrary.OnUpdate`
        ya deserializado. Permiten invalidación granular del cache cuando
        sólo cambia un item.
    """

    def __init__(
        self,
        on_settings_changed: Optional[Callable[[], None]] = None,
        on_library_scan_finished: Optional[Callable[[str], None]] = None,
        on_library_clean_finished: Optional[Callable[[str], None]] = None,
        on_video_library_update: Optional[Callable[[dict], None]] = None,
        on_audio_library_update: Optional[Callable[[dict], None]] = None,
    ) -> None:
        super().__init__()
        self._on_settings_changed = on_settings_changed
        self._on_scan_finished = on_library_scan_finished
        self._on_clean_finished = on_library_clean_finished
        self._on_video_update = on_video_library_update
        self._on_audio_update = on_audio_library_update

    def onNotification(self, sender: str, method: str, data: str) -> None:
        if notify.is_status_relevant(method):
            notify.bump_status(method)

        if method in ('VideoLibrary.OnUpdate', 'AudioLibrary.OnUpdate'):
            payload = _parse_data(data)
            cb = (
                self._on_video_update
                if method.startswith('Video')
                else self._on_audio_update
            )
            self._invoke(cb, payload, where=method)

    def onSettingsChanged(self) -> None:
        self._invoke(self._on_settings_changed, where='onSettingsChanged')

    def onScanFinished(self, library: str) -> None:
        self._invoke(self._on_scan_finished, library, where='onScanFinished')

    def onCleanFinished(self, library: str) -> None:
        self._invoke(self._on_clean_finished, library, where='onCleanFinished')

    @staticmethod
    def _invoke(cb, *args, where: str) -> None:
        if cb is None:
            return
        try:
            cb(*args)
        except Exception as e:
            log.warning(f'[monitor] callback {where} falló: {e!r}')


def _parse_data(data) -> dict:
    """Devuelve el JSON decodificado o {} si no se pudo parsear.

    Kodi pasa el data como string JSON; en tests algunos mocks lo
    entregan ya como dict. Aceptamos ambos.
    """
    if isinstance(data, dict):
        return data
    if not data:
        return {}
    try:
        result = json.loads(data)
    except (ValueError, TypeError) as e:
        log.warning(f'[monitor] data no parseable: {e!r}')
        return {}
    return result if isinstance(result, dict) else {}
