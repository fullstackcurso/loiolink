"""Acceso a biblioteca + sources de Kodi para el panel del móvil.

Capas:
- Wrappers JSON-RPC sobre VideoLibrary/AudioLibrary/Files.* (devuelven
  dicts limpios, listos para serializar a JSON al cliente).
- Validación de path: get_allowed_roots() + is_path_allowed().

Validación de path: realpath + commonpath contra raíces declaradas en
Kodi (Files.GetSources). Sin esto, alguien con el token podría pedir
`C:\\Windows\\System32\\config\\SAM`. Pattern calcado de installer.py.

Restricción v1: solo paths LOCALES (drive letter o slash absoluto).
Sources de red (smb://, nfs://, http://) no se aceptan para stream
porque os.path.realpath no las resuelve. Se siguen listando en /browse
para que el usuario pueda navegarlas vía Kodi (play en la tele),
pero stream al móvil queda restringido a archivos locales.
"""
import os
import re
import threading
import time

from lib import accessibility, log
from lib.remote import library_cache
from lib.remote.rpc import call as _rpc


def _sanitize(items):
    """Quita BBCode de los labels antes de devolverlos al panel web.

    El regex de `accessibility.strip_bbcode` solo afecta a strings con
    marcas conocidas (`[B]`, `[COLOR ...]`, ...): paths reales o títulos
    sin decoración salen idénticos. Aplicado recursivamente para cubrir
    los campos en cualquier nivel del dict de Kodi (`art.poster`,
    `streamdetails`, etc.) sin mantener listas exhaustivas que rotan
    con cada versión del API.
    """
    return accessibility.strip_bbcode_in(items)


def _cached(method, params, fetch):
    """Delega en library_cache: si el setting está off, llama a `fetch`
    directamente y devuelve. Si está on, aplica TTL e invalidación.
    """
    return library_cache.cached(method, params, fetch)


_MEDIA_EXTS = frozenset({
    '.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.flv', '.wmv',
    '.ts', '.m2ts', '.mpg', '.mpeg', '.3gp',
    '.mp3', '.flac', '.aac', '.m4a', '.ogg', '.opus', '.wav',
    # SVG va servido vía <img> (browser no ejecuta scripts en este contexto).
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg',
})

_SOURCES_CACHE_TTL_S = 30
_sources_cache = {'expires_at': 0, 'source_paths': [], 'roots_local': []}
_sources_lock = threading.Lock()


# Path validación 

def _is_local_path(path):
    if not path:
        return False
    if '://' in path[:16]:
        return False
    return os.path.isabs(path)


def _norm(path):
    return os.path.normcase(os.path.normpath(path))


def _fetch_sources():
    """RPC para todas las medias. SIN lock; el caller lo gestiona.

    Devuelve (source_paths, roots_local):
    - source_paths: paths raw tal como los devuelve Kodi (con prefijos de
      red incluidos), para prefix-match en /browse y /play.
    - roots_local: paths locales canónicos vía realpath, para validar
      streaming con commonpath.
    """
    source_paths = []
    roots_local = []
    for media in ('video', 'music', 'pictures', 'files'):
        for src in get_sources(media):
            f = src.get('file', '')
            if not f:
                continue
            if f not in source_paths:
                source_paths.append(f)
            if _is_local_path(f.rstrip('/\\')):
                try:
                    real = os.path.realpath(f.rstrip('/\\'))
                except OSError:
                    continue
                roots_local.append(_norm(real))
    # Dedup roots_local manteniendo orden.
    seen = set()
    unique_roots = []
    for r in roots_local:
        if r not in seen:
            seen.add(r)
            unique_roots.append(r)
    return source_paths, unique_roots


def _get_sources_cached():
    """(source_paths, roots_local) con TTL. RPC fuera del lock; no cachea vacío.

    Si Kodi devuelve [] (fallo transitorio o sin sources), NO se cachea:
    el siguiente call vuelve a intentar. Sin esto, un fallo de RPC bloquea
    todos los `is_path_allowed` durante 30s.
    """
    now = time.time()
    with _sources_lock:
        if now < _sources_cache['expires_at']:
            return (list(_sources_cache['source_paths']),
                    list(_sources_cache['roots_local']))

    # Fetch fuera del lock. Posible doble RPC si dos requests llegan a la
    # vez con cache expirada; preferible a serializar JSON-RPC bajo lock.
    source_paths, roots_local = _fetch_sources()
    if not source_paths and not roots_local:
        return [], []

    with _sources_lock:
        _sources_cache['source_paths'] = source_paths
        _sources_cache['roots_local'] = roots_local
        _sources_cache['expires_at'] = now + _SOURCES_CACHE_TTL_S
    return list(source_paths), list(roots_local)


def get_allowed_roots():
    """Raíces locales canónicas. Para validación de streaming (commonpath)."""
    _, roots = _get_sources_cached()
    return roots


def get_source_paths():
    """Source paths raw (incluye smb://, nfs://, etc.). Para /browse y /play."""
    paths, _ = _get_sources_cached()
    return paths


def _has_dotdot_component(path):
    """¿El path contiene '..' como componente? Bloqueo de traversal explícito."""
    parts = re.split(r'[/\\]+', path)
    return '..' in parts


def is_path_under_source(path):
    """¿El path empieza por alguna source? Acepta paths de red.

    Usado para /browse y /play, donde Kodi resuelve internamente paths
    SMB/NFS/etc. No usa realpath (no aplicable a paths de red); prefix-match
    estricto contra source.file tal como lo declaró Kodi.

    En Windows admitimos `\\` y `/` como separadores: tanto la source como
    el path pueden venir con cualquiera de los dos, y queremos que coincidan.

    Rechaza '..' como componente para mitigar traversal en paths de red.
    """
    if not path:
        return False
    if _has_dotdot_component(path):
        log.security(f'path con .. rechazado: {path[:120]!r}')
        return False
    # Normalizar separadores: sources.xml en Windows usa \ pero Kodi JSON-RPC
    # puede devolver / en algunas versiones. Comparar siempre con /.
    path_n = path.replace('\\', '/')
    for src in get_source_paths():
        bare_n = src.rstrip('/\\').replace('\\', '/')
        if path_n == bare_n or path_n.rstrip('/') == bare_n:
            return True
        # Subpath: continuación con / evita falsos positivos ("/share" vs "/share2").
        if path_n.startswith(bare_n + '/'):
            return True
    log.security(f'path fuera de sources: {path[:120]!r}')
    return False


def is_path_allowed(path, *, media_only=True):
    """¿El path local está dentro de una source y es seguro servirlo?

    Para STREAMING al móvil (range_http + transcode). Requiere path local
    porque os.path.realpath no resuelve URIs de red.

    - Resuelve symlinks con realpath (evita bypass tipo source/../etc/passwd).
    - Compara con commonpath: si el real path está exactamente bajo una root,
      pasa.
    - media_only: además exige extensión en _MEDIA_EXTS (rechaza .nfo, etc.).
    """
    if not _is_local_path(path):
        log.security(f'path rechazado (no local): {(path or "")[:120]!r}')
        return False
    try:
        real = _norm(os.path.realpath(path))
    except OSError:
        return False
    if not os.path.exists(real):
        return False

    roots = get_allowed_roots()
    inside = False
    for root in roots:
        try:
            if os.path.commonpath([real, root]) == root:
                inside = True
                break
        except ValueError:
            # commonpath lanza ValueError si paths están en drives distintos
            # (Windows). No es match, pasamos al siguiente root.
            continue
    if not inside:
        log.security(f'path fuera de sources: {path[:120]!r} → {real[:120]!r}')
        return False

    if media_only:
        ext = os.path.splitext(real)[1].lower()
        if ext not in _MEDIA_EXTS:
            log.security(f'extensión no media: {ext!r} en {real[:120]!r}')
            return False
    return True


# Fuentes / exploracion

def get_sources(media):
    """media ∈ {'video','music','pictures','files'}. Devuelve [{file,label}]."""
    if media not in ('video', 'music', 'pictures', 'files'):
        return []
    resp = _rpc('Files.GetSources', {'media': media})
    return _sanitize(resp.get('result', {}).get('sources', []) or [])


def browse(path, media='files'):
    """Lista archivos/directorios. media decide qué properties pide Kodi."""
    if not path:
        return []
    resp = _rpc('Files.GetDirectory', {
        'directory': path,
        'media': media,
        'properties': ['title', 'mimetype', 'size', 'lastmodified', 'thumbnail'],
    })
    return _sanitize(resp.get('result', {}).get('files', []) or [])


# Video libreria

_MOVIE_PROPS = [
    'title', 'art', 'year', 'plot', 'runtime', 'rating', 'genre',
    'file', 'playcount', 'lastplayed', 'resume', 'imdbnumber',
]

_TVSHOW_PROPS = [
    'title', 'art', 'year', 'plot', 'genre', 'rating', 'studio',
    'playcount', 'episode', 'watchedepisodes', 'imdbnumber',
]

_EPISODE_PROPS = [
    'title', 'art', 'plot', 'runtime', 'rating', 'season', 'episode',
    'firstaired', 'file', 'playcount', 'lastplayed', 'resume',
    'showtitle', 'tvshowid',
]


def _sort(field='title', order='ascending'):
    return {'method': field, 'order': order}


def list_movies(limit=200, offset=0, sort_field='title', q=''):
    params = {
        'properties': _MOVIE_PROPS,
        'limits': {'start': offset, 'end': offset + limit},
        'sort': _sort(sort_field),
    }
    if q:
        params['filter'] = {'field': 'title', 'operator': 'contains', 'value': q}

    def _fetch():
        resp = _rpc('VideoLibrary.GetMovies', params)
        return _sanitize(resp.get('result', {}).get('movies', []) or [])

    return _cached('VideoLibrary.GetMovies', params, _fetch)


def get_movie(movieid):
    params = {'movieid': int(movieid), 'properties': _MOVIE_PROPS}

    def _fetch():
        resp = _rpc('VideoLibrary.GetMovieDetails', params)
        return _sanitize(resp.get('result', {}).get('moviedetails') or {})

    return _cached('VideoLibrary.GetMovieDetails', params, _fetch)


def list_tvshows(limit=200, offset=0, sort_field='title', q=''):
    params = {
        'properties': _TVSHOW_PROPS,
        'limits': {'start': offset, 'end': offset + limit},
        'sort': _sort(sort_field),
    }
    if q:
        params['filter'] = {'field': 'title', 'operator': 'contains', 'value': q}

    def _fetch():
        resp = _rpc('VideoLibrary.GetTVShows', params)
        return _sanitize(resp.get('result', {}).get('tvshows', []) or [])

    return _cached('VideoLibrary.GetTVShows', params, _fetch)


def get_tvshow(tvshowid):
    params = {'tvshowid': int(tvshowid), 'properties': _TVSHOW_PROPS}

    def _fetch():
        resp = _rpc('VideoLibrary.GetTVShowDetails', params)
        return _sanitize(resp.get('result', {}).get('tvshowdetails') or {})

    return _cached('VideoLibrary.GetTVShowDetails', params, _fetch)


def list_seasons(tvshowid):
    params = {
        'tvshowid': int(tvshowid),
        'properties': ['season', 'art', 'episode', 'watchedepisodes', 'showtitle'],
        'sort': _sort('season'),
    }

    def _fetch():
        resp = _rpc('VideoLibrary.GetSeasons', params)
        return _sanitize(resp.get('result', {}).get('seasons', []) or [])

    return _cached('VideoLibrary.GetSeasons', params, _fetch)


def list_episodes(tvshowid, season=None):
    params = {
        'tvshowid': int(tvshowid),
        'properties': _EPISODE_PROPS,
        'sort': _sort('episode'),
    }
    if season is not None:
        params['season'] = int(season)

    def _fetch():
        resp = _rpc('VideoLibrary.GetEpisodes', params)
        return _sanitize(resp.get('result', {}).get('episodes', []) or [])

    return _cached('VideoLibrary.GetEpisodes', params, _fetch)


# Libreria de audio

_ARTIST_PROPS = ['thumbnail', 'fanart', 'description']
_ALBUM_PROPS = ['title', 'artist', 'year', 'art', 'genre', 'rating', 'playcount']
_SONG_PROPS = ['title', 'artist', 'album', 'duration', 'track', 'art', 'file',
               'playcount', 'lastplayed']


def list_artists(limit=200, offset=0, q=''):
    params = {
        'properties': _ARTIST_PROPS,
        'limits': {'start': offset, 'end': offset + limit},
        'sort': _sort('artist'),
    }
    if q:
        params['filter'] = {'field': 'artist', 'operator': 'contains', 'value': q}

    def _fetch():
        resp = _rpc('AudioLibrary.GetArtists', params)
        return _sanitize(resp.get('result', {}).get('artists', []) or [])

    return _cached('AudioLibrary.GetArtists', params, _fetch)


def list_albums(artistid=None, limit=200, offset=0, q=''):
    params = {
        'properties': _ALBUM_PROPS,
        'limits': {'start': offset, 'end': offset + limit},
        'sort': _sort('title'),
    }
    flt = None
    if artistid is not None:
        flt = {'artistid': int(artistid)}
    elif q:
        flt = {'field': 'album', 'operator': 'contains', 'value': q}
    if flt:
        params['filter'] = flt

    def _fetch():
        resp = _rpc('AudioLibrary.GetAlbums', params)
        return _sanitize(resp.get('result', {}).get('albums', []) or [])

    return _cached('AudioLibrary.GetAlbums', params, _fetch)


def list_songs(albumid=None, artistid=None, limit=500, offset=0):
    params = {
        'properties': _SONG_PROPS,
        'limits': {'start': offset, 'end': offset + limit},
        'sort': _sort('track'),
    }
    if albumid is not None:
        params['filter'] = {'albumid': int(albumid)}
    elif artistid is not None:
        params['filter'] = {'artistid': int(artistid)}

    def _fetch():
        resp = _rpc('AudioLibrary.GetSongs', params)
        return _sanitize(resp.get('result', {}).get('songs', []) or [])

    return _cached('AudioLibrary.GetSongs', params, _fetch)


# Contadores (para /api/library/status)

def counts():
    movies = _rpc('VideoLibrary.GetMovies',
                  {'limits': {'start': 0, 'end': 1}}).get('result', {})
    shows = _rpc('VideoLibrary.GetTVShows',
                 {'limits': {'start': 0, 'end': 1}}).get('result', {})
    artists = _rpc('AudioLibrary.GetArtists',
                   {'limits': {'start': 0, 'end': 1}}).get('result', {})
    albums = _rpc('AudioLibrary.GetAlbums',
                  {'limits': {'start': 0, 'end': 1}}).get('result', {})
    return {
        'movies': movies.get('limits', {}).get('total', 0),
        'tvshows': shows.get('limits', {}).get('total', 0),
        'artists': artists.get('limits', {}).get('total', 0),
        'albums': albums.get('limits', {}).get('total', 0),
    }


# Operaciones de explorador de archivos

def _invalidate_sources_cache():
    with _sources_lock:
        _sources_cache['expires_at'] = 0


def path_exists(path):
    """¿Existe el path? Comprueba con y sin trailing slash."""
    import xbmcvfs
    if not path:
        return False
    if xbmcvfs.exists(path):
        return True
    stripped = path.rstrip('/\\')
    if stripped and stripped != path and xbmcvfs.exists(stripped):
        return True
    if not path.endswith('/') and not path.endswith('\\'):
        if xbmcvfs.exists(path + '/'):
            return True
    return False


def is_within(parent, candidate):
    """¿candidate está dentro de parent (o es exactamente parent)?

    Normaliza separadores. Bloquea mover/copiar una carpeta dentro de sí
    misma (caso clásico que causaría recursión infinita en _fb_copy_dir).
    """
    p = parent.replace('\\', '/').rstrip('/') + '/'
    c = candidate.replace('\\', '/').rstrip('/') + '/'
    return c == p or c.startswith(p)


def fb_mkdir(path):
    clean = path.rstrip('/\\')
    if _is_local_path(clean):
        try:
            os.makedirs(clean, exist_ok=True)
            return True
        except OSError:
            return False
    import xbmcvfs
    return bool(xbmcvfs.mkdirs(clean + '/'))


def fb_delete(path):
    import xbmcvfs
    is_dir = path.endswith('/') or path.endswith('\\')
    clean = path.rstrip('/\\')
    if is_dir:
        if _is_local_path(clean):
            import shutil
            try:
                shutil.rmtree(clean)
                return True
            except OSError:
                pass
        try:
            return bool(xbmcvfs.rmdir(clean, True))
        except TypeError:
            return bool(xbmcvfs.rmdir(clean))
    return bool(xbmcvfs.delete(path))


def fb_rename(src, dst):
    import xbmcvfs
    return bool(xbmcvfs.rename(src.rstrip('/\\'), dst.rstrip('/\\')))


def fb_copy(src, dst):
    import xbmcvfs
    if src.endswith('/') or src.endswith('\\'):
        return _fb_copy_dir(src, dst)
    return bool(xbmcvfs.copy(src, dst))


def _vfs_norm(path):
    return path.replace('\\', '/').rstrip('/') + '/'


def _fb_copy_dir(src, dst):
    import xbmcvfs
    src = _vfs_norm(src)
    dst = _vfs_norm(dst)
    if not xbmcvfs.mkdirs(dst):
        return False
    folders, files = xbmcvfs.listdir(src)
    ok = True
    for f in (x for x in files if x and x not in ('.', '..')):
        ok = bool(xbmcvfs.copy(src + f, dst + f)) and ok
    for d in (x for x in folders if x and x not in ('.', '..')):
        ok = _fb_copy_dir(src + d + '/', dst + d + '/') and ok
    return ok


def fb_move(src, dst):
    import xbmcvfs
    src_clean = src.rstrip('/\\')
    dst_clean = dst.rstrip('/\\')
    if bool(xbmcvfs.rename(src_clean, dst_clean)):
        return True
    if not (src.endswith('/') or src.endswith('\\')):
        if bool(xbmcvfs.copy(src_clean, dst_clean)):
            xbmcvfs.delete(src_clean)
            return True
    return False
