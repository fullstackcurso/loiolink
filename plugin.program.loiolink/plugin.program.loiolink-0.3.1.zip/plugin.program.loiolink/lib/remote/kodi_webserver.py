"""Detección y URL building del webserver interno de Kodi.

Kodi expone un servidor HTTP en 127.0.0.1:<port> (default 8080) cuando
"Servicios → Control → Permitir control remoto vía HTTP" está activo.
Lo usamos solo para resolver artwork (`image://...` → JPEG/PNG) que
es la única vía estándar para servir esos URI a navegadores externos.

Sin webserver, no hay posters. El panel detecta esto al cargar
`/library/` y muestra un banner con la opción de activarlo.
"""
import urllib.parse

import xbmcaddon
import xbmcgui

from lib import log
from lib.remote.rpc import call as _rpc
from lib.ui_select import confirm, info


_SETTING_ENABLED = 'services.webserver'
_SETTING_PORT = 'services.webserverport'
_SETTING_USER = 'services.webserverusername'
_SETTING_PASS = 'services.webserverpassword'
_DEFAULT_PORT = 8080

# Marca persistente en los settings del addon: ya configuramos credenciales
# del webserver con éxito en alguna sesión. Settings.GetSettingValue puede
# dejar de devolver services.webserverpassword (devuelve vacío) aunque el
# valor siga guardado en Kodi y el webserver lo siga usando; sin esta marca
# tendríamos que volver a pasar por el setup completo cada vez que el server
# se reactive. La marca se establece SOLO tras un setup exitoso con verify,
# nunca en el shortcut de is_enabled() ni cuando saltamos el setup.
_ADDON_FLAG_CONFIGURED = 'http_credentials_configured'


def _credentials_flag():
    try:
        return xbmcaddon.Addon().getSettingBool(_ADDON_FLAG_CONFIGURED)
    except RuntimeError:
        return False


def _mark_credentials_flag():
    try:
        xbmcaddon.Addon().setSettingBool(_ADDON_FLAG_CONFIGURED, True)
    except RuntimeError:
        pass


def _get_setting(name):
    resp = _rpc('Settings.GetSettingValue', {'setting': name})
    return resp.get('result', {}).get('value')


def _set_setting(name, value, verify=False):
    """SetSettingValue con check de resultado. True si Kodi aceptó.

    Con verify=True, además relee el setting para confirmar que el cambio
    se persistió: Kodi puede devolver result:true pero rechazar el valor
    en silencio para settings protegidos (caso conocido: contraseñas).
    """
    resp = _rpc('Settings.SetSettingValue',
                {'setting': name, 'value': value})
    if resp.get('result') is not True:
        return False
    if verify and _get_setting(name) != value:
        return False
    return True


def is_enabled():
    val = _get_setting(_SETTING_ENABLED)
    log.debug(f'kodi_webserver.is_enabled → setting={val!r} → {bool(val)}')
    return bool(val)


def get_port():
    val = _get_setting(_SETTING_PORT)
    try:
        return int(val) if val else _DEFAULT_PORT
    except (TypeError, ValueError):
        return _DEFAULT_PORT


def get_credentials():
    """(user, pass) o (None, None) si no hay auth configurada."""
    user = _get_setting(_SETTING_USER) or None
    pwd = _get_setting(_SETTING_PASS) or None
    return user, pwd


def image_url(kodi_image_url):
    """Construye URL HTTP local que sirve el `image://...` original.

    Kodi resuelve image:// internamente: solo hay que pegar la URL Kodi
    encodeada después de /image/. El propio Kodi se encarga de la caché.
    """
    if not kodi_image_url:
        return None
    encoded = urllib.parse.quote(kodi_image_url, safe='')
    return f'http://127.0.0.1:{get_port()}/image/{encoded}'


def disable():
    return _set_setting(_SETTING_ENABLED, False)


def _prompt_password():
    """Pide una contraseña al usuario con el input nativo de Kodi (oculto).

    Devuelve la contraseña o None si el usuario cancela o la deja vacía.
    """
    pwd = xbmcgui.Dialog().input(
        'Contraseña para el servidor HTTP de Kodi',
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    return pwd or None


def _run_password_setup():
    """Diálogos para configurar user + pass del webserver de Kodi.

    Devuelve True si user/pass quedaron persistidos en Kodi (verify=True
    confirmó la re-lectura) y la flag interna se marcó. False si el usuario
    cancela algún diálogo o Kodi rechaza algún SetSettingValue.
    """
    proceed = confirm(
        'Para mostrar carátulas, loiolink necesita activar el servidor '
        'HTTP de Kodi.\n\n'
        'Cualquier dispositivo de tu red local puede controlar Kodi por '
        'completo a través de él. Debe protegerse con contraseña: en '
        'red local también hay riesgo, porque una app o web maliciosa '
        'abierta en cualquier dispositivo de la red puede aprovecharlo.\n\n'
        'Pasos:\n'
        '1) Te pediré una contraseña.\n'
        '2) Kodi mostrará después una advertencia genérica de '
        'seguridad: acéptala dándole a Sí; la contraseña ya estará '
        'puesta aunque el texto diga lo contrario.\n\n'
        '¿Continuar?',
        title='loiolink',
        default_no=False,
    )
    if not proceed:
        return False
    new_pass = _prompt_password()
    if not new_pass:
        return False
    # Kodi exige user+pass en pareja: si no había user, fijamos uno por
    # defecto. Verificamos con re-lectura porque Kodi puede aceptar el RPC
    # y rechazar el cambio en silencio para settings sensibles.
    user, _ = get_credentials()
    if not user and not _set_setting(_SETTING_USER, 'kodi', verify=True):
        log.security(f'{_SETTING_USER} no se persistió tras SetSettingValue')
        info('No se pudo guardar el usuario del servidor HTTP. Kodi '
             'puede estar bloqueando cambios de credenciales por API; '
             'configúralo manualmente en Ajustes → Servicios → Control.',
             title='loiolink')
        return False
    if not _set_setting(_SETTING_PASS, new_pass, verify=True):
        log.security(f'{_SETTING_PASS} no se persistió tras SetSettingValue')
        info('No se pudo guardar la contraseña del servidor HTTP. Kodi '
             'puede estar bloqueando cambios de credenciales por API; '
             'configúrala manualmente en Ajustes → Servicios → Control.',
             title='loiolink')
        return False
    _mark_credentials_flag()
    return True


def _enable_and_confirm():
    """Activa el webserver vía SetSettingValue y verifica que quedó activo.

    Devuelve True si quedó activo, 'kodi_rejected' si Kodi rechazó el RPC
    o el usuario canceló el diálogo nativo de advertencia (en cuyo caso
    is_enabled() sigue False). En ambos casos de rechazo, info() ya se
    mostró al usuario.
    """
    if not _set_setting(_SETTING_ENABLED, True):
        log.security(f'SetSettingValue {_SETTING_ENABLED}=True rechazado')
        info(
            'No se pudo activar el servidor HTTP. Inténtalo manualmente '
            'en Ajustes → Servicios → Control.',
            title='loiolink',
        )
        return 'kodi_rejected'
    # Kodi puede aceptar el SetSettingValue pero interceptar el cambio
    # con un dialog nativo que el usuario cancele. Si is_enabled() sigue
    # False, el cambio no se aplicó.
    if not is_enabled():
        log.security(f'{_SETTING_ENABLED} sigue False tras SetSettingValue')
        info(
            'El servidor HTTP no quedó activo. Si Kodi mostró una '
            'advertencia, repite la operación aceptándola.',
            title='loiolink',
        )
        return 'kodi_rejected'
    return True


def request_enable_via_dialog():
    """Pide confirmación en Kodi y, si OK, activa el webserver.

    Sin contraseña el webserver da control total de Kodi a cualquier
    cliente HTTP en la red. Si no detectamos credenciales, ofrecemos
    configurarlas antes de activar. Devuelve True si quedó activado,
    False si el usuario canceló o Kodi rechazó el cambio.

    Detección en dos señales: `user` se lee siempre fiable por API, pero
    `pwd` puede devolver vacío aunque esté guardado (campo protegido en
    algunas builds). Saltamos el setup si user está Y o bien la API
    devuelve pwd, o bien la marca interna confirma que ya configuramos
    credenciales en alguna sesión anterior.
    """
    if is_enabled():
        return True

    user, pwd = get_credentials()
    have_credentials = bool(user) and (bool(pwd) or _credentials_flag())

    if not have_credentials:
        if not _run_password_setup():
            return False
    else:
        # Kodi muestra su advertencia nativa al activar el webserver
        # aunque la contraseña esté guardada. Además no podemos verificar
        # de forma fiable si sigue puesta (la API la enmascara y el flag
        # interno puede estar obsoleto si el usuario la borró a mano).
        # Por eso el mensaje no afirma nada como hecho: avisa del diálogo
        # de Kodi y deja la ruta a Ajustes para configurar/comprobar.
        if not confirm(
            'Kodi mostrará un aviso que dice "Debe establecer una '
            'contraseña a continuación". Es un mensaje genérico '
            'engañoso, no hay ningún campo para introducirla ahí.\n\n'
            'Pulsa Sí en ese aviso y el servidor se activará.\n\n'
            'Para configurarla o comprobarla ve a '
            'Ajustes → Servicios → Control.',
            title='loiolink',
            default_no=False,
        ):
            return False
    return _enable_and_confirm() is True
