"""Generación y cache de certificado autofirmado para HTTPS en LAN.

LoioLink corre servidores HTTP propios en Python (server.py y
server_permanent.py). Para servirlos por HTTPS necesitan cert/key. La
stdlib no genera X.509, así que delegamos en `openssl` como subprocess.

Disponibilidad de openssl por plataforma:
- Linux/macOS: preinstalado en /usr/bin/openssl, encontrado con `which`.
- Windows: requiere openssl en PATH; git-for-windows lo incluye en
  `Program Files\\Git\\mingw64\\bin\\` y `\\usr\\bin\\` pero NO en el
  PATH del sistema (el instalador solo expone `git.exe`). `_openssl_path`
  busca esas rutas como fallback.
- Android/Fire TV/Shield: típicamente no disponible, sin solución.

El cert se cachea en addon_data/tls/ y se regenera si:
- No existe.
- El SAN no incluye la IP local actual (cambio de red).
- Está a <30 días de caducar.

Si openssl no está disponible, get_or_generate_cert devuelve (None, None)
y el caller hace fallback a HTTP con warning.
"""
import calendar
import os
import shutil
import ssl
import subprocess
import sys
import time

import xbmcaddon
import xbmcvfs

from lib import log


def _no_window():
    if sys.platform == 'win32':
        return {'creationflags': subprocess.CREATE_NO_WINDOW}
    return {}


_TLS_VFS = 'special://profile/addon_data/plugin.program.loiolink/tls/'
_CERT_NAME = 'cert.pem'
_KEY_NAME = 'key.pem'
_RENEW_BEFORE_DAYS = 30
_OPENSSL_TIMEOUT_S = 20


def is_https_enabled():
    try:
        val = xbmcaddon.Addon().getSetting('remote_https_enabled')
    except RuntimeError:
        return False
    return val.strip().lower() == 'true'


def scheme():
    """'https' si el setting está activo, 'http' en caso contrario."""
    return 'https' if is_https_enabled() else 'http'


def _tls_dir():
    real = xbmcvfs.translatePath(_TLS_VFS)
    os.makedirs(real, exist_ok=True)
    return real


def _cert_paths():
    d = _tls_dir()
    return os.path.join(d, _CERT_NAME), os.path.join(d, _KEY_NAME)


def get_cert_path():
    """Ruta al cert público del addon. None si aún no se ha generado.

    Pensado para exponer el cert por HTTP (`/loiolink-ca.crt`) sin
    exponer la clave privada nunca. El caller debe verificar
    `os.path.isfile` antes de leerlo.
    """
    cert, _key = _cert_paths()
    return cert if os.path.isfile(cert) else None


def _openssl_path():
    """Devuelve la ruta absoluta al binario openssl, o None si no se encuentra.

    En Linux/macOS basta shutil.which. En Windows, si openssl no esta en
    el PATH del sistema, prueba ubicaciones tipicas de git-for-windows
    (caso muy comun: el instalador de Git solo pone git.exe en el PATH,
    no los binarios mingw/usr).
    """
    found = shutil.which('openssl')
    if found or not sys.platform.startswith('win'):
        return found
    candidates = [
        r'C:\Program Files\Git\mingw64\bin\openssl.exe',
        r'C:\Program Files\Git\usr\bin\openssl.exe',
        r'C:\Program Files (x86)\Git\mingw64\bin\openssl.exe',
        r'C:\Program Files (x86)\Git\usr\bin\openssl.exe',
    ]
    for env_var in ('ProgramFiles', 'ProgramFiles(x86)'):
        pf = os.environ.get(env_var)
        if pf:
            candidates.append(os.path.join(pf, 'Git', 'mingw64', 'bin', 'openssl.exe'))
            candidates.append(os.path.join(pf, 'Git', 'usr', 'bin', 'openssl.exe'))
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def _cert_matches_ip(cert_path, ip, openssl_path):
    """True si el cert lista `ip` en sus SubjectAltName."""
    if not os.path.exists(cert_path):
        return False
    try:
        out = subprocess.check_output(
            [openssl_path, 'x509', '-in', cert_path, '-noout', '-text'],
            stderr=subprocess.DEVNULL, timeout=_OPENSSL_TIMEOUT_S,
            **_no_window(),
        ).decode('utf-8', 'replace')
    except (OSError, subprocess.SubprocessError):
        return False
    # Buscar IP exacta: el texto de openssl tiene "IP Address:x.x.x.x"
    # seguido de coma, espacio o fin de línea. La comprobación con `in`
    # causaría un falso positivo si 192.168.1.1 es substring de 192.168.1.10.
    import re
    return bool(re.search(r'IP Address:' + re.escape(ip) + r'(?:[,\s]|$)', out))


def _cert_expires_soon(cert_path, openssl_path):
    """True si caduca en <_RENEW_BEFORE_DAYS días o no se puede leer."""
    try:
        out = subprocess.check_output(
            [openssl_path, 'x509', '-in', cert_path, '-noout', '-enddate'],
            stderr=subprocess.DEVNULL, timeout=_OPENSSL_TIMEOUT_S,
            **_no_window(),
        ).decode('utf-8', 'replace').strip()
    except (OSError, subprocess.SubprocessError):
        return True
    if '=' not in out:
        return True
    date_str = out.split('=', 1)[1]
    try:
        t = time.strptime(date_str, '%b %d %H:%M:%S %Y %Z')
        end_ts = calendar.timegm(t)
    except ValueError:
        return True
    return (end_ts - time.time()) < _RENEW_BEFORE_DAYS * 86400


def _cleanup_partials():
    cert, key = _cert_paths()
    for p in (cert, key):
        try:
            os.unlink(p)
        except OSError:
            pass


def _generate(ip, openssl_path):
    """Ejecuta openssl req. Devuelve True si los ficheros se escribieron."""
    cert, key = _cert_paths()
    # SAN: el navegador valida contra IP literal, no contra CN.
    san = f'subjectAltName=IP:{ip},IP:127.0.0.1,DNS:localhost'
    cmd = [
        openssl_path, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
        '-days', '3650', '-sha256',
        '-keyout', key, '-out', cert,
        '-subj', '/CN=loiolink',
        '-addext', san,
    ]
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=_OPENSSL_TIMEOUT_S,
            **_no_window(),
        )
        if result.returncode != 0:
            err = result.stderr.decode('utf-8', 'replace').strip()
            log.warning(f'tls: openssl req falló (rc={result.returncode}): {err}')
            _cleanup_partials()
            return False
    except (OSError, subprocess.SubprocessError) as e:
        log.warning(f'tls: openssl req falló: {e}')
        _cleanup_partials()
        return False
    try:
        os.chmod(key, 0o600)
    except OSError:
        pass
    return True


def get_or_generate_cert(ip):
    """Devuelve (cert_path, key_path) o (None, None) si no se pudo preparar."""
    if not ip:
        return None, None
    openssl_path = _openssl_path()
    if not openssl_path:
        log.warning(
            'tls: openssl no encontrado, HTTPS no disponible. '
            'En Windows: instala git-for-windows (se buscara automaticamente '
            'en Program Files\\Git\\mingw64\\bin\\ y \\usr\\bin\\) o anade '
            'openssl al PATH. En Linux/macOS suele estar preinstalado. '
            'En Android/Fire TV/Shield no es soportado.',
        )
        return None, None
    cert, key = _cert_paths()
    needs_gen = (
        not os.path.exists(cert)
        or not os.path.exists(key)
        or not _cert_matches_ip(cert, ip, openssl_path)
        or _cert_expires_soon(cert, openssl_path)
    )
    if needs_gen:
        log.info(f'tls: generando cert autofirmado para IP {ip}')
        if not _generate(ip, openssl_path):
            return None, None
    return cert, key


def regenerate_cert(ip):
    """Borra cert cached y genera uno nuevo. Devuelve True si OK."""
    _cleanup_partials()
    if not ip:
        return False
    openssl_path = _openssl_path()
    if not openssl_path:
        return False
    return _generate(ip, openssl_path)


def build_ssl_context(cert_path, key_path):
    """ssl.SSLContext servidor con TLS 1.2+, o None si la carga falla."""
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=cert_path, keyfile=key_path)
        return ctx
    except (ssl.SSLError, OSError) as e:
        log.warning(f'tls: load_cert_chain falló: {e}')
        return None
