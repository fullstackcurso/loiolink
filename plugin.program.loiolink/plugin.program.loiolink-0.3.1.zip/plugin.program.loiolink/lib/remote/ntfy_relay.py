"""Relay de texto via ntfy.sh.

Alternativa al servidor HTTP local para recibir texto desde fuera de la LAN.
Solo se activa si `relay_ntfy_enabled` está a True en ajustes.

Flujo:
  1. load_or_create_topic() devuelve un ID persistente (token URL-safe, ~128 bits).
  2. El QR apunta a https://ntfy.sh/{topic} (web app de ntfy.sh con botón Publish).
  3. NtfySubscriber.run() abre SSE a https://ntfy.sh/{topic}/sse y llama
     proxy.notify_text() cuando llega un mensaje de tipo 'message'.
  4. NtfySubscriber.stop() cierra la conexión SSE bloqueante para que el thread
     responda al cierre del modal en <100ms.
"""
import json
import os
import re
import secrets
import threading
import urllib.request

import xbmc
import xbmcvfs


_TOPIC_VPATH = 'special://profile/addon_data/plugin.program.loiolink/ntfy_topic.json'
_TOPIC_PREFIX = 'loiolink-'
_NTFY_BASE = 'https://ntfy.sh'
_SSE_TIMEOUT_S = 45         # 1.5x keepalive de ntfy.sh (~30s)
_RECONNECT_DELAY_S = 3
_LOG_PREFIX = '[loiolink.ntfy_relay]'

_VALID_TOPIC_RE = re.compile(r'^[A-Za-z0-9_-]{5,64}$')


def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(f'{_LOG_PREFIX} {msg}', level)


def _topic_path() -> str:
    return xbmcvfs.translatePath(_TOPIC_VPATH)


def _is_valid_topic(t: str) -> bool:
    return bool(t) and bool(_VALID_TOPIC_RE.match(t))


def _save_topic(topic: str) -> None:
    path = _topic_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump({'topic': topic}, fh)
        os.replace(tmp, path)
    except OSError as e:
        # No es crítico: la próxima vez se generará otro topic.
        _log(f'no se pudo guardar topic: {e}', xbmc.LOGWARNING)


def load_or_create_topic() -> str:
    """Carga o genera el topic ID persistente."""
    path = _topic_path()
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            topic = data.get('topic', '')
            if _is_valid_topic(topic):
                return topic
    except (OSError, ValueError):
        pass
    topic = _TOPIC_PREFIX + secrets.token_urlsafe(16)
    _save_topic(topic)
    return topic


def get_sender_url(topic: str) -> str:
    return f'{_NTFY_BASE}/{topic}'


class NtfySubscriber:
    """Suscriptor SSE a un topic de ntfy.sh con stop() interrumpible."""

    def __init__(self) -> None:
        self._resp = None
        self._lock = threading.Lock()

    def stop(self) -> None:
        """Cierra la conexión SSE activa. Idempotente."""
        with self._lock:
            resp, self._resp = self._resp, None
        if resp is not None:
            try:
                resp.close()
            except OSError:
                pass

    def run(self, topic: str, proxy, stop_event: threading.Event) -> None:
        """Loop SSE con reconexión automática. Corre en thread daemon."""
        url = f'{_NTFY_BASE}/{topic}/sse'
        monitor = xbmc.Monitor()
        while not stop_event.is_set():
            try:
                req = urllib.request.Request(url, headers={
                    'Accept': 'text/event-stream',
                    'User-Agent': 'loiolink-kodi/1.0',
                })
                resp = urllib.request.urlopen(req, timeout=_SSE_TIMEOUT_S)
                with self._lock:
                    # stop() pudo llamarse mientras urlopen() bloqueaba.
                    # Cerramos aquí en lugar de entrar al loop.
                    if stop_event.is_set():
                        try:
                            resp.close()
                        except OSError:
                            pass
                        return
                    self._resp = resp
                try:
                    for raw_line in resp:
                        if stop_event.is_set():
                            return
                        line = raw_line.decode('utf-8', errors='replace').strip()
                        if not line.startswith('data: '):
                            continue
                        try:
                            msg = json.loads(line[6:])
                        except ValueError:
                            continue
                        if not isinstance(msg, dict):
                            continue   # ntfy.sh siempre manda dict; defensa.
                        if msg.get('event') != 'message':
                            continue
                        text = (msg.get('message') or '').strip()
                        if text:
                            proxy.notify_text(text)
                finally:
                    with self._lock:
                        self._resp = None
                    try:
                        resp.close()
                    except OSError:
                        pass
            except OSError as e:
                if stop_event.is_set():
                    return
                _log(f'SSE error ({e}); reconectando en {_RECONNECT_DELAY_S}s',
                     xbmc.LOGWARNING)
            if not stop_event.is_set():
                if monitor.waitForAbort(_RECONNECT_DELAY_S):
                    return
