"""Emparejamiento por PIN para el panel web.

El QR del modal "Controlar Kodi desde el móvil" ya lleva el token vía
`?t=`. Este módulo es el carril alternativo para cuando no se puede
escanear: el modal genera un PIN de 6 cifras, el usuario lo teclea en
el formulario que sirve el server cuando llega a `/` sin auth, y la
respuesta del server cambia el PIN por la cookie persistente con el
token real.

**Por qué el estado vive en Window property** (no en globals):

En Kodi el `service.py` del addon corre como un proceso Python aparte
del `default.py` (el script del menú). El `_QRInfoDialog` que genera
el PIN se ejecuta en el proceso del plugin; el handler HTTP que lo
valida vive en el thread del service. Como son procesos distintos
sus variables globales NO se comparten: un PIN escrito en el plugin
no se ve desde el service.

Window(10000) (Home window) es accesible y persistente desde
cualquier proceso de Kodi, por eso lo usamos como canal de IPC.

**Reloj**: `time.time()` (wall clock) en lugar de `time.monotonic()`.
Monotonic no es comparable entre procesos: uno arranca antes que el
otro y sus relojes empiezan en cero distintos.

**Concurrencia**: el lock de threading solo protege dentro de un
proceso. Entre procesos hay una pequeña carrera teórica si dos
POST /pair llegan simultáneamente, pero el peor caso es que un
intento legítimo se solape con un fallo. El rate-limit sigue
cumpliéndose porque ambos leen el contador antes de incrementar.

Decisiones de diseño:
- 6 dígitos (10^6 espacio) con expiración 5 min + rate-limit 5/60 s
  → bruteforce LAN no es viable.
- `secrets.choice('0123456789')` por dígito (distribución uniforme).
- `hmac.compare_digest` para comparación constant-time (paranoia
  consistente con auth.py).
- One-shot: tras éxito el PIN se invalida.
- `generate_pin()` es idempotente mientras haya un PIN vigente. Sin
  esto, abrir/cerrar la vista PIN del modal regeneraría un PIN que
  el usuario ya está tecleando.
"""
import hmac
import json
import secrets
import threading
import time

import xbmcgui


_PIN_TTL_S = 300
_RATE_LIMIT_MAX = 5
_RATE_LIMIT_WINDOW_S = 60
_PIN_LEN = 6

_WINDOW_ID = 10000
_PROP_KEY = 'loiolink.pair.state'

# Lock local del proceso. Entre procesos no protege, pero serializa
# los read-modify-write dentro del service (varios POST /pair) y
# dentro del plugin (improbable pero por consistencia).
_lock = threading.Lock()


def _now():
    """Wall clock en segundos. Mockeable desde tests."""
    return time.time()


def _read_state():
    raw = xbmcgui.Window(_WINDOW_ID).getProperty(_PROP_KEY)
    if not raw:
        return _empty_state()
    try:
        st = json.loads(raw)
        if not isinstance(st, dict):
            return _empty_state()
        # Defensa: si la property tiene un schema viejo o corrupto,
        # devolvemos estado vacío en vez de propagar el lío.
        return {
            'pin': st.get('pin') if isinstance(st.get('pin'), str) else None,
            'expires_at': float(st.get('expires_at') or 0.0),
            'fail_count': int(st.get('fail_count') or 0),
            'fail_window_start': float(st.get('fail_window_start') or 0.0),
        }
    except (ValueError, TypeError):
        return _empty_state()


def _write_state(state):
    xbmcgui.Window(_WINDOW_ID).setProperty(_PROP_KEY, json.dumps(state))


def _empty_state():
    return {
        'pin': None,
        'expires_at': 0.0,
        'fail_count': 0,
        'fail_window_start': 0.0,
    }


def _generate_digits():
    return ''.join(secrets.choice('0123456789') for _ in range(_PIN_LEN))


def generate_pin():
    """Devuelve un PIN vigente, generando uno nuevo si no hay o caducó.

    Idempotente mientras el PIN siga válido: dos llamadas seguidas
    devuelven el mismo string. Resetea el contador de fallos del
    rate-limit al crear uno nuevo.
    """
    with _lock:
        st = _read_state()
        now = _now()
        if st['pin'] is not None and now < st['expires_at']:
            return st['pin']
        st['pin'] = _generate_digits()
        st['expires_at'] = now + _PIN_TTL_S
        st['fail_count'] = 0
        st['fail_window_start'] = now
        _write_state(st)
        return st['pin']


def current_pin_if_valid():
    """PIN vigente o None. No genera."""
    with _lock:
        st = _read_state()
        if st['pin'] is None or _now() >= st['expires_at']:
            return None
        return st['pin']


def validate_and_consume(received):
    """True si `received` coincide con el PIN vigente.

    Invalida el PIN tras un acierto (one-shot). Aplica rate-limit:
    si se superan `_RATE_LIMIT_MAX` fallos en `_RATE_LIMIT_WINDOW_S`,
    el PIN se invalida y este intento ya devuelve False, forzando a
    pedir un PIN nuevo desde Kodi.
    """
    if not isinstance(received, str) or len(received) != _PIN_LEN:
        return _register_fail()
    with _lock:
        st = _read_state()
        now = _now()
        if st['pin'] is None or now >= st['expires_at']:
            return False
        if now - st['fail_window_start'] > _RATE_LIMIT_WINDOW_S:
            st['fail_count'] = 0
            st['fail_window_start'] = now
        if hmac.compare_digest(st['pin'], received):
            st['pin'] = None
            st['expires_at'] = 0.0
            _write_state(st)
            return True
        st['fail_count'] += 1
        if st['fail_count'] >= _RATE_LIMIT_MAX:
            st['pin'] = None
            st['expires_at'] = 0.0
        _write_state(st)
        return False


def _register_fail():
    with _lock:
        st = _read_state()
        now = _now()
        if now - st['fail_window_start'] > _RATE_LIMIT_WINDOW_S:
            st['fail_count'] = 0
            st['fail_window_start'] = now
        st['fail_count'] += 1
        if st['fail_count'] >= _RATE_LIMIT_MAX:
            st['pin'] = None
            st['expires_at'] = 0.0
        _write_state(st)
        return False


def _reset_for_tests():
    """Solo tests. Reinicia el estado completo (memoria + Window property)."""
    with _lock:
        xbmcgui.Window(_WINDOW_ID).clearProperty(_PROP_KEY)
