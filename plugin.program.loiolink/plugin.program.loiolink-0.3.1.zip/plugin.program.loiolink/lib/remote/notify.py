"""Despertador del long-poll del panel web.

Permite que el monitor de Kodi (`xbmc.Monitor.onNotification`) invalide
inmediatamente el cache de status y desbloquee las conexiones long-poll
activas, sin esperar al siguiente tick del polling interno (1 s).

Latencia objetivo: del evento Kodi al cliente, ~50 ms en LAN.

El módulo expone primitivas pequeñas porque el resto del sistema lee
`_STATUS_CACHE` directamente desde `server_permanent`; aquí solo se
publican operadores que pueden invocarse desde callbacks externos
(Monitor) sin riesgo de import circular.
"""
import threading
from typing import Callable, Iterable, List

from lib import log


_BUMP_EVENT = threading.Event()
_INVALIDATORS: List[Callable[[], None]] = []
_INVALIDATORS_LOCK = threading.Lock()


def register_cache_invalidator(fn: Callable[[], None]) -> None:
    """Registra una función que se invocará en cada `bump_status`.

    El cache de status vive en `server_permanent` y no podemos importarlo
    desde aquí (ciclo). El módulo lo registra al cargar; tests pueden
    registrar invalidadores adicionales o sustituirlo.
    """
    with _INVALIDATORS_LOCK:
        _INVALIDATORS.append(fn)


def reset_for_tests() -> None:
    """Limpia el estado interno. SOLO para tests."""
    _BUMP_EVENT.clear()
    with _INVALIDATORS_LOCK:
        _INVALIDATORS.clear()


def bump_status(reason: str = '') -> None:
    """Invalida los caches registrados y despierta los long-polls vivos.

    `reason` se loguea para diagnóstico ('Player.OnPause', 'manual'...).
    Pasado como string para evitar coupling con tipos de Kodi.
    """
    if reason:
        log.debug(f'[notify] bump_status: {reason}')
    with _INVALIDATORS_LOCK:
        snapshot = list(_INVALIDATORS)
    for fn in snapshot:
        try:
            fn()
        except Exception as e:
            log.warning(f'[notify] invalidator {fn!r} falló: {e!r}')
    _BUMP_EVENT.set()


def wait_for_bump(timeout: float) -> bool:
    """Bloquea hasta que llegue un bump o expire `timeout` (segundos).

    Devuelve True si fue desbloqueado por un bump, False si por timeout.
    Tras el wait, deja el event en estado *clear* para el próximo ciclo.
    Pensado para sustituir `time.sleep(timeout)` en bucles que reaccionan
    a cambios externos.

    Atómico para múltiples lectores: cada llamada hace su propio wait
    sobre el mismo evento, todos se desbloquean a la vez con el set().
    El clear() inmediato significa que si llegan dos bumps consecutivos
    muy juntos, sólo el primero despierta a los lectores existentes; el
    segundo despertará a los siguientes. Eso es correcto: el lector
    despierto leerá el estado fresco igual.
    """
    triggered = _BUMP_EVENT.wait(timeout=timeout)
    if triggered:
        _BUMP_EVENT.clear()
    return triggered


# Conjunto cerrado de notificaciones JSON-RPC que afectan al payload de
# status() o a las playlists. Mantener pequeño: cada método aquí dispara
# trabajo en TODOS los long-polls vivos. Eventos de biblioteca van por
# callbacks dedicados en LoiolinkMonitor (on_video_library_update, ...).
_PLAYER_AND_INPUT_EVENTS = frozenset({
    'Player.OnPlay',
    'Player.OnPause',
    'Player.OnResume',
    'Player.OnStop',
    'Player.OnSeek',
    'Player.OnSpeedChanged',
    'Player.OnAVStart',
    'Player.OnAVChange',
    'Player.OnPropertyChanged',
    'Application.OnVolumeChanged',
    'Playlist.OnAdd',
    'Playlist.OnRemove',
    'Playlist.OnClear',
    'Input.OnInputRequested',
    'Input.OnInputFinished',
})


def is_status_relevant(method: str) -> bool:
    """¿El `method` justifica despertar al long-poll de /remote/status?"""
    return method in _PLAYER_AND_INPUT_EVENTS


def status_event_methods() -> Iterable[str]:
    """Lectura sólo para inspección/tests."""
    return iter(_PLAYER_AND_INPUT_EVENTS)
