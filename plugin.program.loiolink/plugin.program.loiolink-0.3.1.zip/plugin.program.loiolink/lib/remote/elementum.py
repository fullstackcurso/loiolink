"""Helper para invocar plugin.video.elementum (torrents/magnets).

Patrón verificado en plugin.video.espatv/url_player.py:821-834 (mi addon):
    elem_url = 'plugin://plugin.video.elementum/play?' + urlencode({'uri': value})
    xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))

Aquí usamos Player.Open JSON-RPC en lugar de PlayMedia para evitar el bug
de parsing de comas en builtins (kodi#14838). La URL plugin:// va como
string JSON, sin riesgo.

Para magnets, `play_magnet_with_fallback` cae a Horus si Elementum no
está instalado. Horus reproduce magnets vía streaming P2P (engine de
Acestream); UX distinta a la de Elementum pero funcional.
"""
import json
import urllib.parse

import xbmc


ELEMENTUM_ID = 'plugin.video.elementum'


def is_installed():
    from lib import installer
    return installer.is_ready(ELEMENTUM_ID)


def play(uri):
    """Reproduce un magnet URI o path a .torrent con Elementum."""
    elem_url = f'plugin://{ELEMENTUM_ID}/play?' + urllib.parse.urlencode(
        {'uri': uri},
    )
    req = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
        'params': {'item': {'file': elem_url}},
    }
    xbmc.executeJSONRPC(json.dumps(req))


def search(query):
    """Lanza búsqueda en Elementum (UI con resultados)."""
    elem_url = f'plugin://{ELEMENTUM_ID}/search?' + urllib.parse.urlencode(
        {'q': query},
    )
    xbmc.executebuiltin(f'RunPlugin("{elem_url}")')


def is_magnet(text):
    """¿Este string es un magnet URI?"""
    return isinstance(text, str) and text.strip().lower().startswith('magnet:?')


def has_magnet_player():
    """True si hay algún reproductor de magnets disponible (Elementum o Horus)."""
    from lib.remote import horus
    return is_installed() or horus.is_installed()


def play_magnet_with_fallback(uri):
    """Intenta Elementum; si no está, cae a Horus. Devuelve 'elementum' o 'horus'.

    Lanza ValueError si `uri` no es un magnet (defensa contra .torrent
    paths que deben ir por `play()` directamente).
    Lanza RuntimeError('no_magnet_player') si ningún cliente disponible.
    """
    if not is_magnet(uri):
        raise ValueError(f'No es magnet: {uri!r}')
    if is_installed():
        play(uri)
        return 'elementum'
    from lib.remote import horus
    if horus.is_installed():
        horus.play_magnet(uri)
        return 'horus'
    raise RuntimeError('no_magnet_player')
