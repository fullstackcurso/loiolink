"""Cache opt-in de listados de biblioteca para el panel web.

Activado por el setting `library.cache_enabled`. Cuando está apagado (el
default), `cached(...)` invoca el fetch directamente y nunca toca el
diccionario; coste cero para usuarios que no lo quieren.

Cuando está activo, almacena el resultado de `_rpc` por clave
`(método, params normalizados)` con TTL configurable
(`library.cache_ttl_min`, en minutos). El monitor (1.1) invalida
selectivamente con `invalidate_list`/`invalidate_item` ante eventos
`VideoLibrary.OnUpdate` / `AudioLibrary.OnUpdate`.

Decisiones:

- El cache vive en memoria del proceso del addon. Reinicio de Kodi =
  cache vacío. Aceptable: el primer fetch tras reinicio repuebla.
- Invalidación selectiva: si llega `OnUpdate(item.id=42, type=movie,
  added=false)`, se descartan solo las entradas que listan películas o
  detallan `movieid=42`. Un scan masivo (`transaction=true` repetido)
  se debouncea con `invalidate_list(type)` agrupando.
- No serializamos los items para guardarlos: los dejamos como objetos
  Python (dict/list). La salida ya viene saneada por `_sanitize` de
  `library.py`, así que el cache contiene exactamente lo que el panel
  recibe.
"""
import hashlib
import json
import threading
import time
from typing import Any, Callable, Dict, Optional

import xbmcaddon

from lib import log


_CACHE_LOCK = threading.RLock()
_CACHE: Dict[str, dict] = {}

# Tope defensivo. En uso normal (TTL 1h + invalidación por OnScanFinished)
# el cache no debería acercarse a este número; el límite evita un crecimiento
# patológico (cliente que pagina con muchos sort+filter en biblioteca enorme)
# que terminara consumiendo memoria sin parar. Al excederlo, se elimina
# la entrada con `expires_at` más cercano.
_MAX_ENTRIES = 512


# Mapping (método RPC) -> 'video'|'audio' para invalidación por scope.
# Lo usamos al recibir OnScanFinished('video') / OnScanFinished('music').
_METHOD_SCOPE = {
    'VideoLibrary.GetMovies':   'video',
    'VideoLibrary.GetMovieDetails': 'video',
    'VideoLibrary.GetTVShows':  'video',
    'VideoLibrary.GetTVShowDetails': 'video',
    'VideoLibrary.GetSeasons':  'video',
    'VideoLibrary.GetEpisodes': 'video',
    'AudioLibrary.GetArtists':  'audio',
    'AudioLibrary.GetAlbums':   'audio',
    'AudioLibrary.GetSongs':    'audio',
}

# Mapping (media_type del evento OnUpdate) -> métodos a invalidar al
# crear/borrar un item nuevo. El detalle del item afectado se invalida
# por separado con `invalidate_item`.
_TYPE_TO_LIST_METHODS = {
    'movie':      ('VideoLibrary.GetMovies',),
    'tvshow':     ('VideoLibrary.GetTVShows', 'VideoLibrary.GetSeasons',
                   'VideoLibrary.GetEpisodes'),
    'season':     ('VideoLibrary.GetSeasons',),
    'episode':    ('VideoLibrary.GetEpisodes', 'VideoLibrary.GetSeasons'),
    'musicvideo': ('VideoLibrary.GetMovies',),
    'artist':     ('AudioLibrary.GetArtists', 'AudioLibrary.GetAlbums',
                   'AudioLibrary.GetSongs'),
    'album':      ('AudioLibrary.GetAlbums', 'AudioLibrary.GetSongs'),
    'song':       ('AudioLibrary.GetSongs',),
}


def _addon():
    return xbmcaddon.Addon()


def is_enabled() -> bool:
    """¿El usuario ha activado el cache desde Ajustes → Avanzado?"""
    try:
        return _addon().getSettingBool('library.cache_enabled')
    except (RuntimeError, AttributeError):
        return False


def _ttl_seconds() -> int:
    try:
        minutes = _addon().getSettingInt('library.cache_ttl_min')
    except (RuntimeError, ValueError, TypeError):
        minutes = 60
    # Clamp defensivo: si el setting está corrupto o vacío, usamos 60.
    # El rango del XML ya limita 5-1440 desde la UI; este clamp protege
    # del caso "setting puesto a mano fuera de rango".
    if minutes < 1:
        minutes = 60
    if minutes > 24 * 60:
        minutes = 24 * 60
    return minutes * 60


def _make_key(method: str, params: dict) -> str:
    """Clave estable de cache. Serializamos con sort_keys para que dos
    requests "iguales pero con orden de claves distinto" compartan
    entrada."""
    serialized = json.dumps(params or {}, sort_keys=True, default=str)
    digest = hashlib.md5(serialized.encode('utf-8')).hexdigest()[:16]
    return f'{method}:{digest}'


def cached(method: str, params: dict, fetch: Callable[[], Any]) -> Any:
    """Devuelve el resultado cacheado o invoca `fetch()` si no hay/expiró.

    Si el setting está apagado o cualquier error de lectura ocurre, se
    salta el cache: el fetch se invoca y su resultado se devuelve sin
    almacenarlo. Esto preserva el comportamiento previo a esta feature.
    """
    if not is_enabled():
        return fetch()

    key = _make_key(method, params)
    now = time.time()

    with _CACHE_LOCK:
        entry = _CACHE.get(key)
        if entry is not None and entry['expires_at'] > now:
            return entry['value']

    # Fetch FUERA del lock para no bloquear otras conexiones leyendo.
    # Posible doble-fetch concurrente: la última escritura gana, los
    # valores son equivalentes (mismo método + mismos params).
    value = fetch()

    with _CACHE_LOCK:
        _CACHE[key] = {
            'method': method,
            'expires_at': now + _ttl_seconds(),
            'value': value,
        }
        if len(_CACHE) > _MAX_ENTRIES:
            _evict_oldest_locked()
    return value


def _evict_oldest_locked() -> None:
    """Elimina la entrada con `expires_at` más cercano (la primera en
    caducar). El caller debe sostener `_CACHE_LOCK`. Una llamada por
    cada `_MAX_ENTRIES` desbordamiento; no merece estructura más rica.
    """
    if not _CACHE:
        return
    oldest_key = min(_CACHE, key=lambda k: _CACHE[k]['expires_at'])
    del _CACHE[oldest_key]


def invalidate_all() -> None:
    """Borra todo el cache. Para `Settings.Changed`, regenerate, etc."""
    with _CACHE_LOCK:
        n = len(_CACHE)
        _CACHE.clear()
    if n:
        log.debug(f'[library_cache] invalidate_all ({n} entradas)')


def invalidate_scope(scope: str) -> None:
    """Borra entradas cuyo método pertenece a `scope` ('video'/'audio').

    Llamada típica: `invalidate_scope('video')` tras `OnScanFinished`
    de la biblioteca de vídeo.
    """
    if scope not in ('video', 'audio'):
        return
    with _CACHE_LOCK:
        keys = [
            k for k, v in _CACHE.items()
            if _METHOD_SCOPE.get(v.get('method'), '') == scope
        ]
        for k in keys:
            del _CACHE[k]
    if keys:
        log.debug(f'[library_cache] invalidate_scope({scope}) ({len(keys)} entradas)')


def invalidate_list(media_type: str) -> None:
    """Borra los listados afectados por la creación o borrado de un item.

    Lookup conservador: si `media_type` no es conocido (Kodi añade tipos
    en versiones futuras), se invalida todo el scope correspondiente
    como medida defensiva.
    """
    methods = _TYPE_TO_LIST_METHODS.get(media_type)
    if methods is None:
        # Tipo desconocido: invalidar conservadoramente.
        log.debug(f'[library_cache] tipo desconocido {media_type!r}, '
                  f'invalido scopes completos')
        invalidate_scope('video')
        invalidate_scope('audio')
        return
    with _CACHE_LOCK:
        keys = [
            k for k, v in _CACHE.items()
            if v.get('method') in methods
        ]
        for k in keys:
            del _CACHE[k]
    if keys:
        log.debug(
            f'[library_cache] invalidate_list({media_type}) '
            f'({len(keys)} entradas)',
        )


def invalidate_item(media_type: str, item_id: Optional[int]) -> None:
    """Borra las entradas relacionadas con un item que ha cambiado.

    Pensado para `OnUpdate` con `added=false`: solo cambió el item
    `item_id`. Invalidamos los listados que podrían contenerlo (la
    cache no indexa el contenido del result, así que la decisión va por
    método). Granularidad mayor exigiría parsear el value cacheado;
    el TTL corta cualquier desync residual en el peor caso.

    `item_id` se acepta por simetría con la señal de Kodi pero no se
    usa para indexar: queda para diagnóstico.
    """
    if item_id is None:
        return
    affected_methods = _TYPE_TO_LIST_METHODS.get(media_type)
    if not affected_methods:
        return
    with _CACHE_LOCK:
        keys = [
            k for k, v in _CACHE.items()
            if v.get('method') in affected_methods
        ]
        for k in keys:
            del _CACHE[k]
    if keys:
        log.debug(
            f'[library_cache] invalidate_item({media_type}={item_id}) '
            f'({len(keys)} entradas)',
        )


def handle_video_update(data: dict) -> None:
    """Callback para `LoiolinkMonitor.on_video_library_update`."""
    _dispatch_update(data)


def handle_audio_update(data: dict) -> None:
    """Callback para `LoiolinkMonitor.on_audio_library_update`."""
    _dispatch_update(data)


def _dispatch_update(data: Optional[dict]) -> None:
    data = data or {}
    item = data.get('item') or {}
    media_type = item.get('type')
    item_id = item.get('id')
    added = bool(data.get('added'))
    if added:
        invalidate_list(media_type)
    else:
        invalidate_item(media_type, item_id)


# Kodi emite `onScanFinished` / `onCleanFinished` con los strings
# 'video' o 'music' (NO 'audio'). Mapeamos a nuestros scopes internos.
_KODI_LIBRARY_TO_SCOPE = {'video': 'video', 'music': 'audio'}


def _scope_from_kodi_library(library: str) -> str:
    """Mapea el string que Kodi pasa al callback a nuestro scope.

    Devuelve 'video' o 'audio'. Para libraries desconocidas (versión
    futura de Kodi con nuevo tipo) cae a 'video', invalidación segura
    aunque no granular.
    """
    return _KODI_LIBRARY_TO_SCOPE.get(library, 'video')


def handle_scan_finished(library: str) -> None:
    """Callback para `LoiolinkMonitor.on_library_scan_finished`."""
    invalidate_scope(_scope_from_kodi_library(library))


def handle_clean_finished(library: str) -> None:
    """Callback para `LoiolinkMonitor.on_library_clean_finished`."""
    invalidate_scope(_scope_from_kodi_library(library))


# Sólo para tests: vaciar TODO incluyendo metadata interna.
def _reset_for_tests() -> None:
    with _CACHE_LOCK:
        _CACHE.clear()


def _size_for_tests() -> int:
    with _CACHE_LOCK:
        return len(_CACHE)
