"""Helper para reproducir magnets vía script.module.horus.

Horus (`logon84/script.module.horus`) acepta `?action=play&url=<magnet>` y
extrae el `btih` con `xt=urn:btih:([a-f0-9]+)` internamente. Pasamos el
magnet completo en lugar de extraer el infohash a mano: si Horus añade
soporte de magnets v2 (`urn:btmh:`) en el futuro, no tenemos que tocar
nada. La contrapartida es que magnets v2-only fallan hoy sin manera de
detectarlo desde aquí (lo intercepta Horus después).

Invocación: `PlayMedia` builtin, no `Player.Open` JSON-RPC. Mismo motivo
que `acestream.py`: el flujo completo (busy dialog, plugin handler,
delegación al engine) es lo que hace que la reproducción funcione.
`urlencode` convierte las comas de los trackers a `%2C`, así que el bug
kodi#14838 de PlayMedia con comas no aplica.
"""
import urllib.parse

import xbmc

HORUS_ID = 'script.module.horus'


def is_installed():
    from lib import installer
    return installer.is_ready(HORUS_ID)


def play_magnet(magnet_uri):
    """Lanza `magnet_uri` con Horus. ValueError si no es un magnet."""
    if not isinstance(magnet_uri, str) or not magnet_uri.strip().lower().startswith('magnet:?'):
        raise ValueError(f'No es magnet: {magnet_uri!r}')
    plugin_url = f'plugin://{HORUS_ID}/?' + urllib.parse.urlencode(
        {'action': 'play', 'url': magnet_uri.strip()},
    )
    xbmc.executebuiltin(f'PlayMedia("{plugin_url}")')
