"""Wrapper genérico sobre xbmc.executeJSONRPC.

Consolida la versión que vivía duplicada en player.py y transfers/ui_context.py.

executeJSONRPC corre in-process, sin auth; pensado para llamarse desde
dentro del addon. `call()` devuelve dict siempre (nunca None) para que el
caller pueda hacer `.get('result', ...)` sin defensas extra; nunca lanza.
`call_or_raise()` es la variante estricta: propaga errores como RPCError
y devuelve el contenido de `result` directamente (sin envoltorio JSON-RPC).
"""
import json

import xbmc


class RPCError(Exception):
    """Error de JSON-RPC: la llamada llegó pero Kodi devolvió `error`,
    o la respuesta no se pudo parsear. `code` es el código JSON-RPC
    estándar (o -1 si fue fallo local de parseo)."""

    def __init__(self, code, message):
        super().__init__(f'JSON-RPC {code}: {message}')
        self.code = code
        self.message = message


def call(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        req['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except (ValueError, RuntimeError):
        return {}


def call_or_raise(method, params=None):
    """Variante estricta: devuelve `result` directamente o lanza RPCError.

    Pensada para los endpoints HTTP nuevos que necesitan distinguir éxito
    de fallo del lado del cliente (HTTP 4xx/5xx). Los callers viejos siguen
    usando `call()` para no romper su contrato.
    """
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        req['params'] = params
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except (ValueError, RuntimeError) as e:
        raise RPCError(-1, f'parse error: {e}')
    if 'error' in resp:
        err = resp['error'] or {}
        raise RPCError(err.get('code', -1), err.get('message', 'unknown'))
    return resp.get('result')
