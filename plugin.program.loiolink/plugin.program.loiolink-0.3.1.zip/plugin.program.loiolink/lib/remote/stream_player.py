"""Reproduce URLs de stream directamente en el player de Kodi.

Soporta: RTMP, RTMPS, RTSP, RTSPS, HLS (.m3u8/.m3u), DASH (.mpd), TS
y URLs HTTP con pipe-headers (`http://...url|Header=Val&H2=Val2`).

Kodi resuelve el tipo de stream por esquema/extensión y elige el
inputstream apropiado. Solo bloqueamos cuando inputstream.adaptive es
obligatorio (DASH `.mpd`); HLS y RTMP se intentan aunque no esté el
inputstream específico (FFmpeg nativo cubre la mayoría de casos).
"""
import json

import xbmc

from lib import installer

_STREAM_SCHEMES = ('rtmp://', 'rtmps://', 'rtsp://', 'rtsps://')
_STREAM_EXTS = ('.m3u8', '.m3u', '.mpd', '.ts')


def _has_addon(addon_id):
    # Indirección sobre installer.is_ready para compartir el cache TTL
    # con el resto del addon (resolver, acestream, etc.).
    return installer.is_ready(addon_id)


def _base_url(text):
    """Quita pipe-headers, query string y fragmento para examinar la extensión."""
    return text.split('|', 1)[0].split('?', 1)[0].split('#', 1)[0].lower()


def is_stream_url(text):
    if not isinstance(text, str):
        return False
    t = text.strip()
    tl = t.lower()
    if any(tl.startswith(s) for s in _STREAM_SCHEMES):
        return True
    if tl.startswith(('http://', 'https://')):
        # http url|key=val => stream con headers (Kodi protocol options)
        if '|' in t and '=' in t.split('|', 1)[1]:
            return True
        if any(_base_url(tl).endswith(ext) for ext in _STREAM_EXTS):
            return True
    return False


def _missing_inputstream(text):
    """Devuelve el addon id del inputstream necesario que falta, o None.

    `.mpd` (DASH) requiere `inputstream.adaptive` obligatoriamente.
    HLS y RTMP los soporta Kodi nativamente vía FFmpeg; no se bloquea por
    ellos para no rechazar streams reproducibles.
    """
    base = _base_url(text.strip())
    if base.endswith('.mpd') and not _has_addon('inputstream.adaptive'):
        return 'inputstream.adaptive'
    return None


def play(url):
    """Lanza Player.Open con el URL tal cual (incluyendo pipe-headers).

    Lanza `RuntimeError('missing_inputstream:<id>')` si falta un
    inputstream obligatorio. Devuelve None en éxito (la reproducción es
    asíncrona; el error real solo se ve en el log de Kodi).
    """
    text = url.strip()
    missing = _missing_inputstream(text)
    if missing:
        raise RuntimeError(f'missing_inputstream:{missing}')
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Player.Open',
        'params': {'item': {'file': text}},
    }))
