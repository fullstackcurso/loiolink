"""Resolución de carátula, título y tipo a partir de una URL.

Reutilizable. Tres niveles de coste:

- Regex pura (instantáneo): YouTube, Dailymotion, RTVE → URL del thumbnail
  derivable sin HTTP. detect_kind también es instantáneo.
- Oembed (HTTP ~3s): Vimeo (thumb), YouTube/Dailymotion/Vimeo (label).
- Scrape og:image (HTTP ~3s, 32 KB cap): cualquier URL http(s) no clasificada.

NUNCA propaga excepciones: cualquier fallo de red, parseo o caracter
inválido devuelve cadena vacía. Loggea warnings para diagnóstico.

DNS precheck obligatorio antes de urlopen: `urlopen(timeout=N)` NO acota
la fase de resolución DNS en Windows/Android (issues Python gh-78649,
gh-103998). Sin precheck, una pegada en red con DNS lento puede congelar
la UI 15-30s. Reutilizamos `url_utils._dns_precheck` que el resto del
addon ya usa (test_http_reachable, etc.).

Patrones inspirados en plugin.video.streamninja/url_player.py (líneas 314-460).
Stdlib `urllib.request` en vez de `requests` para no añadir dependencias.
"""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

from lib import log, url_utils


_YT_RE = re.compile(
    r'(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)'
    r'([A-Za-z0-9_-]{11})',
)
_DM_RE = re.compile(r'(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)')
_VIMEO_RE = re.compile(r'vimeo\.com/(\d+)')
_RTVE_RE = re.compile(r'rtve\.es/(?:play/videos/.+/|v/)(\d+)')
_RTVE_MPD_RE = re.compile(r'ztnr\.rtve\.es/ztnr/(\d+)\.mpd')
_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_STREAM_EXTS = ('.m3u8', '.mpd', '.mp4', '.mkv', '.ts', '.webm')

_TIMEOUT = 3
_MAX_BYTES = 32768
_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0'
)


def auto_thumb(url):
    """Devuelve URL de thumbnail o ''. Nunca lanza."""
    if not url:
        return ''
    m = _YT_RE.search(url)
    if m:
        return f'https://img.youtube.com/vi/{m.group(1)}/hqdefault.jpg'
    m = _DM_RE.search(url)
    if m:
        return f'https://www.dailymotion.com/thumbnail/video/{m.group(1)}'
    m = _RTVE_RE.search(url) or _RTVE_MPD_RE.search(url)
    if m:
        return f'https://img2.rtve.es/v/{m.group(1)}/?w=480'
    if _VIMEO_RE.search(url):
        return _vimeo_oembed(url, 'thumbnail_url')
    if url.startswith(('http://', 'https://')):
        return _og_thumb(url)
    return ''


def auto_label(url):
    """Devuelve título legible o ''. Nunca lanza."""
    if not url:
        return ''
    if _YT_RE.search(url):
        return _oembed_title('https://www.youtube.com/oembed', url)
    if _DM_RE.search(url):
        return _oembed_title('https://www.dailymotion.com/services/oembed', url)
    if _VIMEO_RE.search(url):
        return _vimeo_oembed(url, 'title')
    return ''


def detect_kind(url):
    """Etiqueta humana del tipo de URL para mostrar en el dialog. Sin HTTP."""
    if not url:
        return 'Texto'
    if _YT_RE.search(url):
        return 'YouTube'
    if _DM_RE.search(url):
        return 'Dailymotion'
    if _VIMEO_RE.search(url):
        return 'Vimeo'
    if _RTVE_RE.search(url) or _RTVE_MPD_RE.search(url):
        return 'RTVE'
    if url.startswith('magnet:'):
        return 'Magnet'
    if url.startswith('acestream:'):
        return 'AceStream'
    lower = url.lower().split('?', 1)[0]
    if lower.endswith(_STREAM_EXTS):
        return 'Stream directo'
    if url_utils.mux(url):
        return 'Web'
    return 'Texto'


def _http_get(url, label):
    """GET HTTP con pre-resolución DNS y timeout total acotado.

    Devuelve los primeros _MAX_BYTES (32 KB) o None si:
    - DNS no resuelve en _TIMEOUT (evita UI freeze 15-30s; `urlopen` por sí
      solo NO acota la fase DNS, ver doc del módulo).
    - HTTP timeout / 4xx / 5xx / URL malformada.

    `label` es solo para el log, identifica el caller (og:image / oembed).
    """
    _, dns_err = url_utils._dns_precheck(url, _TIMEOUT)
    if dns_err:
        log.warning(f'[thumb_resolver] {label} DNS falló: {dns_err}')
        return None
    try:
        req = urllib.request.Request(url, headers={'User-Agent': _USER_AGENT})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            return r.read(_MAX_BYTES)
    except (urllib.error.URLError, OSError, ValueError) as e:
        log.warning(f'[thumb_resolver] {label} HTTP falló: {type(e).__name__}')
        return None


def _oembed_title(endpoint, url):
    qs = urllib.parse.urlencode({'url': url, 'format': 'json'})
    raw = _http_get(f'{endpoint}?{qs}', label='oembed title')
    if raw is None:
        return ''
    try:
        data = json.loads(raw.decode('utf-8', errors='replace'))
    except ValueError:
        return ''
    title = data.get('title', '')
    return title if isinstance(title, str) else ''


def _vimeo_oembed(url, field):
    """Vimeo oembed devuelve ambos {title, thumbnail_url} en una llamada."""
    qs = urllib.parse.urlencode({'url': url, 'width': 480})
    raw = _http_get(f'https://vimeo.com/api/oembed.json?{qs}', label='vimeo oembed')
    if raw is None:
        return ''
    try:
        data = json.loads(raw.decode('utf-8', errors='replace'))
    except ValueError:
        return ''
    v = data.get(field, '')
    return v if isinstance(v, str) else ''


def _og_thumb(url):
    """Scrape de og:image limitado a 32 KB. Cualquier fallo → ''."""
    raw = _http_get(url, label='og:image')
    if raw is None:
        return ''
    text = raw.decode('utf-8', errors='replace')
    m = _OG_RE.search(text)
    if not m:
        return ''
    thumb = m.group(1) or m.group(2) or ''
    # og:image puede venir relativo (/img/x.jpg). Resolver contra la URL.
    if thumb and thumb.startswith('/'):
        thumb = urllib.parse.urljoin(url, thumb)
    return thumb
