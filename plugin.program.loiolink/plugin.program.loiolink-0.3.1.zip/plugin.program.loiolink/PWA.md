# PWA loiolink

El panel web se sirve como PWA (Progressive Web App). Documentación de la
API para otros addons en [`API.txt`](API.txt).

## Instalar el panel como app (PWA)

El panel de control web es instalable como aplicación independiente. La
opción depende del navegador y de cómo accedas al panel:

- **Android (Chrome/Edge)**: aparece automáticamente la opción "Instalar
  app" o "Añadir a pantalla de inicio" en el menú del navegador.
- **iPhone/iPad (Safari)**: usa "Compartir → Añadir a pantalla de inicio".
- **PC (Chrome/Edge desktop)**: el navegador solo permite instalar PWAs
  servidas por HTTPS válido (CA-trusted) o desde `localhost`. Como
  loiolink se sirve por HTTP en la LAN con cert autofirmado, el botón
  "Instalar" no aparece en Chrome desktop sobre la IP de LAN. El panel
  sigue funcionando igual abierto como pestaña normal del navegador.

Instalar la PWA solo cambia que el panel se abra en su propia ventana
sin barra de URL. Todas las funciones funcionan idénticamente desde el
navegador normal — instalarla es opcional y puramente cosmético.

## HTTPS opcional

Hay un setting avanzado `remote_https_enabled` (off por defecto) que
sirve el panel por HTTPS con un certificado autofirmado. Requiere
`openssl` disponible en el sistema:

- **Linux/macOS**: viene preinstalado.
- **Windows**: si tienes git-for-windows instalado, loiolink encuentra
  openssl automáticamente en `Program Files\Git\mingw64\bin\` o
  `\usr\bin\`. Si no, añade openssl al PATH del sistema.
- **Android (Fire TV, Shield)**: no soportado.

El cert autofirmado da pantalla roja la primera vez en cada navegador;
acepta el aviso para entrar. Esto NO desbloquea PWA install en Chrome
desktop (Chrome sigue marcando el origen como "Not Secure").
