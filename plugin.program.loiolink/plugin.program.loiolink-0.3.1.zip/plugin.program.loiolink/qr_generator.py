"""Genera QR PNG con segno (lib/segno). cleanup() es responsabilidad del llamador."""
import os
import sys
import tempfile

import xbmc

_QR_SCALE = 8


def generate(url):
    """Genera un QR PNG en /tmp y devuelve su path, o None si falla."""
    if not url:
        return None

    segno = _import_segno()
    if segno is None:
        return None

    # mkstemp evita colisiones entre invocaciones simultáneas; segno reabre el path.
    fd, output_path = tempfile.mkstemp(prefix='loiolink_qr_', suffix='.png')
    os.close(fd)
    try:
        qr = segno.make(url, micro=False, error="M")
        qr.save(
            output_path,
            kind="png",
            scale=_QR_SCALE,
            dark="#000000",
            light="#ffffff",
            border=2,
        )
        return output_path
    except (OSError, ValueError) as e:
        xbmc.log(f'[loiolink.qr_generator] segno error: {e}', xbmc.LOGWARNING)
        try:
            os.remove(output_path)
        except OSError:
            pass
        return None


def cleanup(path):
    """Borra el PNG. Idempotente: ignora None o archivos inexistentes."""
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass


def _import_segno():
    """Importa la copia empaquetada en lib/segno antes de la del sistema."""
    lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")

    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)

    try:
        import segno
        return segno
    except ImportError:
        return None
