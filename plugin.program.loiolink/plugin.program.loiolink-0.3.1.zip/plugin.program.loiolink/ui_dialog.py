# Adaptado de StreamNinja (RubénSDFA1laberot)
"""Modal con QR + cuenta atrás. run_qr_modal -> (received_payload, timed_out)."""
import os
import threading

import xbmc
import xbmcaddon
import xbmcgui

import qr_generator

_POLL_INTERVAL_MS = 500


class _QRDialog(xbmcgui.WindowDialog):
    # Geometría base 1280x720 (Kodi escala automáticamente al tamaño real).
    _W, _H = 1280, 720
    _PANEL_W, _PANEL_H = 680, 580
    _PANEL_X = (_W - _PANEL_W) // 2
    _PANEL_Y = (_H - _PANEL_H) // 2

    # Colores AARRGGBB
    _C_TITLE = '0xFFFFFFFF'
    _C_ADDR = '0xFF58A6FF'
    _C_DIM = '0xFF8B949E'
    _C_HINT = '0xFFD29922'

    _FONT_H1 = 'font20'
    _FONT_BODY = 'font16'
    _FONT_SM = 'font14'

    _CLOSE_ACTIONS = {
        xbmcgui.ACTION_PREVIOUS_MENU,
        xbmcgui.ACTION_NAV_BACK,
        xbmcgui.ACTION_STOP,
    }

    def __init__(self, server, addr, timeout_seconds=None, on_payload=None,
                 persistent=False):
        """Modal QR. Tres modos según parámetros:

        - Single-shot con timeout: pasa `timeout_seconds`. El modal cierra al
          primer payload o al timeout. Comportamiento original.
        - Multi-shot sin timeout: pasa `on_payload`. Cada payload invoca el
          callback y el modal sigue abierto. Cierra solo con Back/Esc o
          shutdown de Kodi; salvo que el callback devuelva truthy, en cuyo
          caso el modal cierra tras procesar ese payload (atajo para que el
          dialog post-transfer de un ZIP aparezca al instante).
        - Persistente: pasa `persistent=True` junto con `on_payload`. Igual
          que multi-shot pero el servidor lo gestiona service.py; este modal
          solo muestra la dirección y no procesa payloads propios.
        """
        super().__init__()

        self._server = server
        self._addr = addr
        self._timeout = timeout_seconds
        self._on_payload = on_payload
        self._multi_shot = on_payload is not None
        self._persistent = persistent

        self.received = None
        self.canceled = False
        self.timed_out = False
        self._payload_count = 0

        self._stop_event = threading.Event()
        self._qr_path = None

        self._build_ui()

        self._poll_thread = threading.Thread(
            target=self._poll_loop, daemon=True, name='loiolink-qr-poll'
        )
        self._poll_thread.start()

    def _ephemeral_toggle_label(self):
        try:
            ephemeral = xbmcaddon.Addon().getSettingBool('server_ephemeral_mode')
        except RuntimeError:
            ephemeral = True
        mode = 'efimero' if ephemeral else 'persistente'
        return f'[OK] Servidor: {mode} - pulsa para cambiar'

    def _build_ui(self):
        px, py = self._PANEL_X, self._PANEL_Y
        pw, ph = self._PANEL_W, self._PANEL_H

        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        media_dir = os.path.join(addon_path, 'resources', 'media')

        self._bg = xbmcgui.ControlImage(
            0, 0, self._W, self._H,
            os.path.join(media_dir, 'transparent.png'),
            aspectRatio=2, colorDiffuse='0xCC000000',
        )
        self.addControl(self._bg)

        self._panel = xbmcgui.ControlImage(
            px, py, pw, ph,
            os.path.join(media_dir, 'white.png'),
            aspectRatio=2, colorDiffuse='0xEE161B22',
        )
        self.addControl(self._panel)

        self._lbl_title = xbmcgui.ControlLabel(
            px, py + 20, pw, 36,
            'loiolink: recibir texto',
            font=self._FONT_H1,
            textColor=self._C_TITLE,
            alignment=0x00000002,  # XBFONT_CENTER_X
        )
        self.addControl(self._lbl_title)

        self._lbl_instr = xbmcgui.ControlLabel(
            px, py + 68, pw, 28,
            'Abre esta direccion en el navegador o escanea el QR:',
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_instr)

        self._lbl_addr = xbmcgui.ControlLabel(
            px, py + 100, pw, 36,
            f'[B]{self._addr}[/B]',
            font=self._FONT_BODY,
            textColor=self._C_ADDR,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_addr)

        self._qr_path = qr_generator.generate(self._addr)

        qr_size = 256
        qr_x = px + (pw - qr_size) // 2
        qr_y = py + 148

        if self._qr_path:
            self._img_qr = xbmcgui.ControlImage(
                qr_x, qr_y, qr_size, qr_size,
                self._qr_path,
                aspectRatio=0,
            )
            self.addControl(self._img_qr)

        label_y = qr_y + qr_size + 10

        try:
            relay_on = xbmcaddon.Addon().getSettingBool('relay_ntfy_enabled')
        except RuntimeError:
            relay_on = False
        if not relay_on:
            self._lbl_internet_hint = xbmcgui.ControlLabel(
                px, label_y, pw, 26,
                'Recibe texto por internet desde cualquier red (ver Ajustes)',
                font=self._FONT_SM,
                textColor=self._C_HINT,
                alignment=0x00000002,
            )
            self.addControl(self._lbl_internet_hint)

        status_y = label_y + 34
        initial_status = (
            'Servidor activo - envia texto desde el movil'
            if self._persistent
            else 'Esperando texto...'
        )
        self._lbl_status = xbmcgui.ControlLabel(
            px, status_y, pw, 28,
            initial_status,
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_status)

        # En multi-shot/persistent no hay cuenta atrás.
        if self._multi_shot:
            self._lbl_hint = xbmcgui.ControlLabel(
                px, status_y + 30, pw, 24,
                'Pulsa Atras o Esc para cerrar',
                font=self._FONT_SM,
                textColor=self._C_DIM,
                alignment=0x00000002,
            )
            self.addControl(self._lbl_hint)
            self._progress = None
        else:
            prog_margin = 60
            self._progress = xbmcgui.ControlProgress(
                px + prog_margin,
                status_y + 36,
                pw - prog_margin * 2,
                12,
            )
            self.addControl(self._progress)
            self._progress.setPercent(0)

        # Toggle efímero/persistente (siempre visible).
        self._lbl_ephemeral_toggle = xbmcgui.ControlLabel(
            px, py + 510, pw, 24,
            self._ephemeral_toggle_label(),
            font=self._FONT_SM,
            textColor=self._C_HINT,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_ephemeral_toggle)

    def _poll_loop(self):
        elapsed = 0.0
        poll_s = _POLL_INTERVAL_MS / 1000
        monitor = xbmc.Monitor()
        # Cache del label del toggle para detectar cambios externos del
        # setting (desde el menú Opciones) y refrescar la UI.
        last_toggle_label = self._ephemeral_toggle_label()

        while not self._stop_event.is_set():
            if monitor.abortRequested():
                self._stop_event.set()
                self.close()
                return

            # Refresco perezoso del label del toggle: si el usuario cambió
            # el setting desde Opciones mientras este modal estaba abierto,
            # mostramos el valor nuevo.
            current_toggle_label = self._ephemeral_toggle_label()
            if current_toggle_label != last_toggle_label:
                try:
                    self._lbl_ephemeral_toggle.setLabel(current_toggle_label)
                    last_toggle_label = current_toggle_label
                except RuntimeError:
                    return

            if self._server.text_event.wait(timeout=poll_s):
                payload = self._server.received_payload
                if self._multi_shot:
                    close_after = False
                    try:
                        if payload is not None:
                            # Convención: si el callback devuelve truthy,
                            # cerrar el modal tras procesar este payload.
                            # Usado por receive_text para que el dialog de
                            # instalación de ZIPs aparezca al instante en
                            # vez de esperar a que el usuario pulse Atrás.
                            close_after = bool(self._on_payload(payload))
                            self._payload_count += 1
                    except Exception as e:
                        xbmc.log(f'[loiolink.ui_dialog] on_payload error: {e}',
                                 xbmc.LOGWARNING)
                    self._server.received_payload = None
                    self._server.text_event.clear()
                    # Liberar el claim para que el siguiente upload no reciba
                    # 409 (mismo patrón que start_background._watcher en
                    # server.py). Sin esto el modal multi-shot solo aceptaba
                    # el PRIMER envío: bug pre-existente que rompía el
                    # comportamiento "envia varios archivos en serie".
                    with self._server._claim_lock:
                        self._server._payload_claimed = False
                    if close_after:
                        self._stop_event.set()
                        self.close()
                        return
                    try:
                        kind = (payload or {}).get('kind', '?')
                        self._lbl_status.setLabel(
                            f'Recibidos: {self._payload_count} (último: {kind})'
                        )
                    except RuntimeError:
                        return
                    continue
                # Single-shot.
                self.received = payload
                self.close()
                return

            if self._stop_event.is_set():
                return

            if self._multi_shot:
                continue

            elapsed += poll_s
            if elapsed >= self._timeout:
                self.timed_out = True
                self.close()
                return

            remaining = int(self._timeout - elapsed)
            try:
                self._lbl_status.setLabel(f'Esperando texto... ({remaining}s)')
                self._progress.setPercent((elapsed / self._timeout) * 100)
            except RuntimeError as e:
                xbmc.log(f'[loiolink.ui_dialog] poll_loop UI error: {e}', xbmc.LOGDEBUG)
                return

    def _toggle_ephemeral_mode(self):
        try:
            addon = xbmcaddon.Addon()
            new_val = not addon.getSettingBool('server_ephemeral_mode')
            addon.setSettingBool('server_ephemeral_mode', new_val)
            self._lbl_ephemeral_toggle.setLabel(self._ephemeral_toggle_label())
        except RuntimeError:
            pass

    def onAction(self, action):
        aid = action.getId()
        if aid in self._CLOSE_ACTIONS:
            self.canceled = True
            self._stop_event.set()
            self.close()
        elif aid == xbmcgui.ACTION_SELECT_ITEM:
            self._toggle_ephemeral_mode()

    def close(self):
        self._stop_event.set()
        super().close()

    def dispose(self):
        if self._qr_path:
            qr_generator.cleanup(self._qr_path)
            self._qr_path = None


def run_qr_modal(server, addr, timeout_seconds=None, on_payload=None,
                 persistent=False):
    """Lanza el modal.

    Single-shot (timeout_seconds dado): devuelve (received_payload, timed_out).
    Multi-shot (on_payload dado): devuelve (None, False). Cada payload se
    procesa por el callback; el modal vive hasta cierre manual/shutdown.
    Persistente (persistent=True): igual que multi-shot pero el servidor lo
    gestiona service.py; el modal solo muestra la dirección.
    """
    dlg = _QRDialog(server, addr, timeout_seconds=timeout_seconds,
                    on_payload=on_payload, persistent=persistent)
    try:
        dlg.doModal()
        return dlg.received, dlg.timed_out
    finally:
        dlg.dispose()
