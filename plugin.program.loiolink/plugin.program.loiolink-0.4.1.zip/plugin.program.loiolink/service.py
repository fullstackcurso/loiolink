"""Service en background.

Responsabilidades:
1. Drenar la cola de eventos UI de history.dequeue_event(). ÚNICO sitio
   seguro para mostrar Dialog en Kodi 19 (kodi#15378).
2. Mantener vivo el HTTP server permanente para control remoto desde el
   móvil (lib/remote/server_permanent).
3. Si el modo efímero está desactivado, mantener vivo también el servidor
   de recepción de texto (server.py) y procesar sus payloads.

Los puertos de ambos servidores se exponen via Window properties para que
las acciones del addon (remote_qr.py, receive_text.py) los lean sin
comunicación entre procesos por archivos o JSON-RPC.
"""
import time

import xbmc
import xbmcaddon
import xbmcgui

import server as text_server_module
from lib import log, settings_migrations
from lib.remote import server_permanent
from lib.remote.monitor import LoiolinkMonitor
from lib.transfers import history
from lib.ui_select import confirm


REMOTE_PORT_PROP = 'loiolink.remote.port'
# Scheme con el que el server bindeo DE VERDAD. El setting puede decir
# https y el server haber caido a http (sin openssl), o el usuario haber
# toggleado sin reiniciar: quien construye un QR debe leer esto.
REMOTE_SCHEME_PROP = 'loiolink.remote.scheme'
TEXT_PORT_PROP = 'loiolink.text.port'
# Scheme real con el que arrancó el servidor de texto persistente.
# Necesario porque tls.is_https_enabled() puede cambiar después del arranque
# y daría URLs con scheme incorrecto si se reconsulta al abrir el dialog.
TEXT_SCHEME_PROP = 'loiolink.text.scheme'
# Parada manual del servidor de texto (sin cambiar el setting persistente).
TEXT_STOPPED_PROP = 'loiolink.text.user_stopped'
# Gate del item "Copiar a loiolink" del menú contextual. Inversión a 'disabled'
# (ausencia=visible) para que sea safe cuando el service no ha arrancado.
CONTEXT_COPY_DISABLED_PROP = 'loiolink.context_copy.disabled'
SETTING_ENABLED = 'remote_server_enabled'
SETTING_EPHEMERAL = 'server_ephemeral_mode'
SETTING_CONTEXT_COPY_ENABLED = 'context_copy.enabled'
_BIND_BACKOFF_S = 30


def _read_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_ENABLED)
    except RuntimeError:
        return True


def _read_ephemeral_mode():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_EPHEMERAL)
    except RuntimeError:
        return True


def _read_context_copy_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool(SETTING_CONTEXT_COPY_ENABLED)
    except RuntimeError:
        return True


def _sync_context_copy_property(win):
    if _read_context_copy_enabled():
        win.clearProperty(CONTEXT_COPY_DISABLED_PROP)
    else:
        win.setProperty(CONTEXT_COPY_DISABLED_PROP, '1')


def _process_text_payload(payload):
    """Callback para el servidor de texto en modo persistente."""
    if not payload:
        return
    kind = payload.get('kind')
    if kind != 'text':
        # Magnets y uploads: el handler del server ya los encola en history;
        # _handle_event los mostrará. Solo necesitamos procesar texto.
        return
    import clipboard
    from lib import accessibility
    from lib.remote import keyboard_input
    text = payload['text']
    clipboard.set(text)
    accessibility.notify('Texto recibido y guardado', ms=2000)
    try:
        enabled = xbmcaddon.Addon().getSettingBool('remote.auto_inject_text')
    except (TypeError, RuntimeError):
        enabled = True
    if enabled:
        keyboard_input.try_inject(text, wait_appear_ms=1500)


def _handle_event(event):
    kind = event.get('kind')
    if kind == 'post_transfer':
        if event.get('confirm_upload'):
            entry = event['entry']
            name = entry.get('name', 'archivo')
            size = entry.get('size', 0)
            if size >= 1_048_576:
                size_str = f'{size / 1_048_576:.1f} MB'
            elif size >= 1024:
                size_str = f'{size // 1024} KB'
            else:
                size_str = f'{size} B'
            ip = event.get('sender_ip', 'red local')
            if not confirm(
                f'Archivo recibido desde {ip}:\n\n{name}  ({size_str})\n\n¿Aceptarlo?',
                title='loiolink',
                default_no=True,
            ):
                history.delete(entry['id'], remove_file=True)
                xbmc.executebuiltin('Container.Refresh')
                return
        from lib.transfers import post_transfer
        post_transfer.show_post_transfer_dialog(
            event['entry'],
            already_played=event.get('already_played', False),
            forced_action=event.get('forced_action'),
            force_confirm=event.get('force_confirm', False),
        )
        # Container.Refresh fuerza al skin a recargar el container activo.
        # Si justo se ha lanzado reproducción (ya sea mi código en modo wait
        # o el _play_file del post_transfer con auto_action=True), el menú
        # está oculto bajo el video; refrescarlo es ruido y dispara el
        # BusyDialog del skin sobre el video (widgets cargando thumbnails,
        # scrapers, etc.). Skipear cuando hay player activo.
        try:
            if not xbmc.Player().isPlaying():
                xbmc.executebuiltin('Container.Refresh')
        except RuntimeError:
            xbmc.executebuiltin('Container.Refresh')
        return
    if kind == 'magnet_received':
        from lib.remote import elementum
        uri = event.get('uri', '')
        if not elementum.has_magnet_player():
            from lib.actions import elementum as elementum_install
            if not elementum_install.install_with_progress():
                return
            if not elementum.has_magnet_player():
                return
        preview = uri[:80] + ('...' if len(uri) > 80 else '')
        if confirm(
            f'Magnet recibido:\n{preview}\n\n¿Reproducir?',
            title='loiolink', default_no=False,
        ):
            try:
                via = elementum.play_magnet_with_fallback(uri)
                log.info(f'magnet via {via}')
            except (RuntimeError, ValueError) as e:
                # RuntimeError: race condition entre has_magnet_player y el
                # helper (usuario desinstala en medio). ValueError: uri en
                # la cola está corrupto (no es magnet).
                log.warning(f'magnet_received: no se pudo reproducir: {e!r}')
        return
    if kind == 'notification':
        from lib import accessibility
        accessibility.notify(event.get('msg', ''))
        return
    log.warning(f'Evento desconocido en cola: {kind}')


def run():
    # LoiolinkMonitor sustituye a la instancia plana de xbmc.Monitor para
    # despertar el long-poll del panel web en cuanto Kodi emite eventos
    # JSON-RPC (Player.OnPause, OnVolumeChanged, etc.) y para invalidar
    # el library cache opcional cuando la biblioteca cambia.
    from lib.remote import library_cache
    monitor = LoiolinkMonitor(
        on_library_scan_finished=library_cache.handle_scan_finished,
        on_library_clean_finished=library_cache.handle_clean_finished,
        on_video_library_update=library_cache.handle_video_update,
        on_audio_library_update=library_cache.handle_audio_update,
    )
    win = xbmcgui.Window(10000)

    settings_migrations.apply_pending()

    from lib.remote import sessions
    sessions.migrate_legacy_token()

    import stats
    stats.ping()

    # Recovery de grabaciones HLS huérfanas: si Kodi crashea / se cierra
    # forzado mid-grabación, la entrada del historial queda con
    # recording_state='active' aunque el thread esté muerto. Marcarlas
    # como 'interrupted' para que el usuario vea el estado real. Los
    # archivos .partial se conservan: el usuario decide desde el panel.
    try:
        from lib.transfers import hls_recorder as _hls
        n_orphan = _hls.recover_orphan_recordings()
        if n_orphan:
            log.info(f'[service] {n_orphan} grabaciones HLS huérfanas marcadas interrupted')
    except Exception as _e:
        log.warning(f'[service] recovery HLS falló: {_e!r}')

    # Scheduler de grabaciones HLS programadas. Persistencia en JSON; las
    # entradas con start_time futuro se restauran al arrancar. Las muy
    # expiradas (>5 min) se descartan y se notifican una sola vez al user.
    scheduler = None
    try:
        from lib.transfers import hls_scheduler
        scheduler = hls_scheduler.RecordingScheduler()
        n_recovered, n_expired = scheduler.recover_pending()
        if n_recovered or n_expired:
            log.info(
                f'[service] scheduler: {n_recovered} programadas restauradas, '
                f'{n_expired} expiradas descartadas'
            )
        scheduler.start()
        hls_scheduler.set_instance(scheduler)
    except Exception as _e:
        log.warning(f'[service] scheduler HLS no arrancó: {_e!r}')
        scheduler = None

    # Detectar restore interrumpido (típico tras restart de Kodi forzado
    # por restauración de advancedsettings.xml). Si hay state válido y el
    # usuario acepta, continuar en background.
    try:
        from lib import backup
        _resume_state = backup.check_resume_pending()
        if _resume_state:
            import os as _os
            _zip_basename = _os.path.basename(_resume_state.get('zip_path', ''))
            _n_remaining = len(_resume_state.get('remaining_addon_ids') or [])
            if confirm(
                f'Hay un restore interrumpido del backup "{_zip_basename}".\n'
                f'Quedan {_n_remaining} addons por restaurar.\n\n'
                '¿Continuar ahora?',
                title='loiolink Backup',
                default_no=False,
            ):
                import threading as _t
                _t.Thread(
                    target=backup.resume_restore,
                    args=(_resume_state,),
                    daemon=True,
                    name='backup-resume',
                ).start()
            else:
                backup.clear_resume_pending()
    except Exception as _e:
        log.warning(f'[service] resume check falló: {_e!r}')

    server = None
    last_bind_fail = 0.0

    text_server = None
    text_http_thread = None
    last_text_bind_fail = 0.0
    # Tracking del setting ephemeral para detectar transiciones. Sin esto,
    # al cambiar efímero→persistente un user_stopped pegado bloquearía el
    # arranque automático del server.
    prev_ephemeral = _read_ephemeral_mode()
    # Cleanup periódico de sesiones de upload chunked huérfanas (cliente
    # abandona, el navegador se cierra y no llega a /upload/finalize ni a
    # /upload/cancel). TTL configurable en settings.
    last_upload_cleanup = 0.0
    _UPLOAD_CLEANUP_INTERVAL_S = 3600  # 1 hora

    _sync_context_copy_property(win)

    if _read_enabled():
        server, port = server_permanent.start()
        if server is not None:
            win.setProperty(REMOTE_SCHEME_PROP,
                            getattr(server, '_scheme', 'http'))
            win.setProperty(REMOTE_PORT_PROP, str(port))
            log.info(f'Service arrancado. Remote server en :{port}')
        else:
            log.error('No se pudo levantar el server remoto en ningún puerto')
            last_bind_fail = _time_now()
    else:
        log.info('Service arrancado con el panel del móvil DESACTIVADO')

    # Respetar user_stopped del addon-restart (Kodi sigue vivo, propiedad
    # persiste): si el usuario tenía el server apagado, no arrancarlo solo
    # para que el loop lo pare en <=1s (flap visible).
    if (_read_enabled() and not _read_ephemeral_mode()
            and win.getProperty(TEXT_STOPPED_PROP) != '1'):
        text_server, text_port, text_http_thread = (
            text_server_module.start_background(_process_text_payload)
        )
        if text_server is not None:
            win.setProperty(TEXT_PORT_PROP, str(text_port))
            win.setProperty(TEXT_SCHEME_PROP, getattr(text_server, '_scheme', 'http'))
            log.info(f'Servidor de texto persistente en :{text_port}')
        else:
            log.warning('No se pudo levantar el servidor de texto persistente')
            last_text_bind_fail = _time_now()

    try:
        while not monitor.abortRequested():
            _sync_context_copy_property(win)

            desired = _read_enabled()
            is_running = server is not None
            if desired and not is_running:
                if _time_now() - last_bind_fail >= _BIND_BACKOFF_S:
                    server, port = server_permanent.start()
                    if server is not None:
                        win.setProperty(REMOTE_SCHEME_PROP,
                                        getattr(server, '_scheme', 'http'))
                        win.setProperty(REMOTE_PORT_PROP, str(port))
                        log.info(f'Server reactivado en :{port}')
                        last_bind_fail = 0.0
                    else:
                        last_bind_fail = _time_now()
                        log.warning(
                            'Bind fallido al reactivar el server; '
                            f'reintento en {_BIND_BACKOFF_S}s',
                        )
            elif is_running and not desired:
                server_permanent.stop(server)
                server = None
                win.clearProperty(REMOTE_PORT_PROP)
                win.clearProperty(REMOTE_SCHEME_PROP)
                log.info('Server detenido por petición del usuario')

            # Reconciliación del servidor de texto (modo persistente).
            # Detectar transición efímero→persistente: el usuario cambió a
            # persistente queriendo el server activo. Si user_stopped persistía
            # de un apagado anterior, limpiarlo evita que bloquee el arranque.
            curr_ephemeral = _read_ephemeral_mode()
            if prev_ephemeral and not curr_ephemeral:
                win.clearProperty(TEXT_STOPPED_PROP)
            prev_ephemeral = curr_ephemeral

            user_stopped = win.getProperty(TEXT_STOPPED_PROP) == '1'
            desired_persistent = desired and not curr_ephemeral and not user_stopped
            text_running = text_server is not None
            if desired_persistent and not text_running:
                if _time_now() - last_text_bind_fail >= _BIND_BACKOFF_S:
                    text_server, text_port, text_http_thread = (
                        text_server_module.start_background(_process_text_payload)
                    )
                    if text_server is not None:
                        win.setProperty(TEXT_PORT_PROP, str(text_port))
                        win.setProperty(TEXT_SCHEME_PROP,
                                        getattr(text_server, '_scheme', 'http'))
                        log.info(f'Servidor de texto reactivado en :{text_port}')
                        last_text_bind_fail = 0.0
                    else:
                        last_text_bind_fail = _time_now()
                        log.warning('Bind fallido al reactivar el servidor de texto')
            elif text_running and not desired_persistent:
                text_server_module.stop_background(text_server, text_http_thread)
                text_server = None
                text_http_thread = None
                win.clearProperty(TEXT_PORT_PROP)
                win.clearProperty(TEXT_SCHEME_PROP)
                log.info('Servidor de texto detenido por cambio de configuración')

            # Drenar notificaciones de fallo del scheduler: el hilo del
            # scheduler NO puede llamar Dialog().notification (kodi#15378:
            # los Dialog desde threads que no son el main fallan), así que
            # encola mensajes y aquí los mostramos.
            if scheduler is not None:
                try:
                    messages = scheduler.drain_failure_notifications()
                    for msg in messages:
                        try:
                            xbmcgui.Dialog().notification(
                                'LoioLink', msg,
                                xbmcgui.NOTIFICATION_WARNING, 8000,
                            )
                        except Exception as e:
                            log.warning(f'[service] notification falló: {e!r}')
                except Exception as e:
                    log.warning(f'[service] drain scheduler notifs: {e!r}')

            # Cleanup chunked upload sessions stale (cada hora).
            if _time_now() - last_upload_cleanup >= _UPLOAD_CLEANUP_INTERVAL_S:
                last_upload_cleanup = _time_now()
                try:
                    from lib.transfers import upload_session
                    ttl_h = 24
                    try:
                        ttl_h = int(xbmcaddon.Addon().getSetting(
                            'upload.session_ttl_hours') or '24')
                    except (ValueError, RuntimeError):
                        pass
                    n = upload_session.cleanup_stale(ttl_hours=ttl_h)
                    if n:
                        log.info(f'upload_session: limpiadas {n} sesiones stale')
                except Exception as e:
                    log.warning(f'upload_session.cleanup_stale falló: {e}')

            event = history.dequeue_event(timeout=1)
            if event is not None:
                try:
                    _handle_event(event)
                except Exception as e:
                    log.error(f'Error procesando evento {event!r}: {e}')
    finally:
        log.info('Service apagando')
        # Parar el scheduler ANTES del stop_all del recorder: un fire en
        # vuelo encolaría un nuevo HLSRecorder justo cuando vamos a pararlos.
        if scheduler is not None:
            try:
                scheduler.stop(timeout=5.0)
                # Drenado final: fires durante el cierre pueden haber dejado
                # notificaciones encoladas. Las mostramos antes de salir
                # para que el usuario sepa que esas grabaciones no salieron.
                final_msgs = scheduler.drain_failure_notifications()
                for msg in final_msgs:
                    try:
                        xbmcgui.Dialog().notification(
                            'LoioLink', msg,
                            xbmcgui.NOTIFICATION_WARNING, 8000,
                        )
                    except Exception:
                        # Notificación best-effort durante el shutdown de Kodi:
                        # la UI puede estar ya cerrándose. No debe frenar la salida.
                        pass
            except Exception as _e:
                log.warning(f'[service] scheduler.stop falló: {_e!r}')
        # Parar grabaciones HLS activas con join 5s. Las que no terminen
        # quedan como 'active' en el historial; el siguiente arranque las
        # marcará 'interrupted' via recover_orphan_recordings().
        try:
            from lib.transfers import hls_recorder as _hls
            _hls.stop_all(timeout=5.0)
        except Exception as _e:
            log.warning(f'[service] HLS stop_all falló: {_e!r}')
        server_permanent.stop(server)
        if text_server is not None:
            text_server_module.stop_background(text_server, text_http_thread)
        win.clearProperty(REMOTE_PORT_PROP)
        win.clearProperty(REMOTE_SCHEME_PROP)
        win.clearProperty(TEXT_PORT_PROP)
        win.clearProperty(TEXT_SCHEME_PROP)
        win.clearProperty(CONTEXT_COPY_DISABLED_PROP)


def _time_now():
    return time.time()


if __name__ == '__main__':
    run()
