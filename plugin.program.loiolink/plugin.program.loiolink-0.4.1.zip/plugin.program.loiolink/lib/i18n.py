"""Atajo para getLocalizedString con formateo opcional. IDs propios: 30000-30999."""
import os
import re
import xbmcaddon

_ADDON = xbmcaddon.Addon()
_FALLBACK_CACHE = {}

# Diccionario de emergencia: strings hardcodeados en español usados en menús.
# Se consulta como ÚLTIMA red de seguridad cuando tanto getLocalizedString()
# como la lectura del .po fallan (p.ej. en Android con timing de addon context
# o rutas no disponibles en el momento del import).
_HARDCODED_ES = {
    30000: 'Pegar (loiolink)',
    30001: 'Recibir texto',
    30002: 'Importar texto del portapapeles',
    30003: 'Descargar archivos desde dirección web',
    30004: 'Descargar archivos desde código numérico',
    30005: 'Controlar Kodi, enviar contenido de forma remota y mucho más',
    30006: 'Abrir StreamNinja (ya instalado)',
    30007: 'Instalar StreamNinja',
    30008: 'Ajustes',
    30009: 'Descargar archivos desde Telegram',
    30010: 'Copiar a loiolink',
    30020: 'Historial de transferencias ({n})',
    30021: 'Historial (vacío)',
    30035: 'Portapapeles',
    30036: 'Descargar para abrir o instalar',
    30037: 'Explorador de archivos',
    30038: 'Backup y restauración de Kodi',
    30039: 'Limpieza y mantenimiento de Kodi',
    30040: 'Pegar enlace y reproducir',
    30041: 'Información, Manual y Ecosistema',
    30042: 'Información del addon y versión',
    30043: 'loioloio addons',
    30044: 'Acerca de loioloio',
    30045: 'Manual de usuario',
    30046: 'Universo EspaKodi',
    30047: 'Opciones',
    30048: 'Asistente de configuración inicial',
    30049: 'Pegar texto en buscadores',
    30050: 'Panel web remoto',
    30051: 'Descargas',
    30052: 'Backup',
    30053: 'Opciones avanzadas',
    30054: 'Accesibilidad',
    30055: 'Log y Diagnóstico',
    30056: 'Ajustes nativos de Kodi',
    30100: 'Ver portapapeles interno',
    30101: 'Limpiar portapapeles interno',
    30300: 'Gestor de fuentes y repositorios',
}


def _load_fallback():
    if _FALLBACK_CACHE:
        return
    try:
        addon_path = _ADDON.getAddonInfo('path')
        po_path = os.path.join(addon_path, 'resources', 'language', 'resource.language.es_es', 'strings.po')
        if os.path.isfile(po_path):
            with open(po_path, 'r', encoding='utf-8') as f:
                content = f.read()
            # Buscar msgctxt y msgstr
            pattern = re.compile(r'msgctxt\s+"#(\d+)"\s+msgid\s+""\s+msgstr\s+"([^"]+)"')
            for match in pattern.finditer(content):
                _FALLBACK_CACHE[int(match.group(1))] = match.group(2)
    except Exception:
        # Último fallback de i18n: si el .po no se puede leer/parsear, L()
        # cae a _HARDCODED_ES. No debe romper nunca la carga del addon.
        pass


def L(string_id, **kwargs):
    s = _ADDON.getLocalizedString(string_id)
    if not s:
        _load_fallback()
        s = _FALLBACK_CACHE.get(string_id, '')
    if not s:
        # Última red de seguridad: strings hardcodeados en español.
        s = _HARDCODED_ES.get(string_id, '')
    return s.format(**kwargs) if kwargs else s
