"""Lectura y escritura del bloque <files> de sources.xml de Kodi.

Kodi guarda las fuentes que el usuario añade desde su gestor de archivos en
`userdata/sources.xml` con esta estructura:

    <sources>
      <files>
        <source>
          <name>Mi Repo</name>
          <path pathversion="1">https://...</path>
          <allowsharing>true</allowsharing>
        </source>
        ...
      </files>
      <video>...</video>
      <music>...</music>
      <pictures>...</pictures>
      <programs>...</programs>
    </sources>

El addon opera SOLO sobre la sección <files>, que es donde el 99% de gente
añade repositorios y donde Kodi escribe las fuentes nuevas creadas desde el
file manager. Las otras secciones (video/music/...) las dejamos intactas
porque pertenecen al flujo de bibliotecas multimedia y editar ahí confundiría
más que ayudaría.

Las escrituras son atomic write (.tmp + rename) para no dejar el archivo a
medias si falla algo a mitad. Kodi solo recarga sources.xml al arrancar, así
que los cambios hechos en caliente requieren reiniciar Kodi para que el file
manager los vea.
"""
import os
import shutil
import threading
import time
import xml.etree.ElementTree as ET

import xbmcvfs

from lib import log


_SOURCES_PATH = xbmcvfs.translatePath('special://profile/sources.xml')
_SOURCES_TMP = _SOURCES_PATH + '.tmp'
_BACKUPS_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/backups/'
)
_MAX_BACKUPS = 10

# Serializa read-modify-write sobre sources.xml. Dos llamadas concurrentes
# (ej. dos clientes web cambiando fuentes a la vez) podrían perder cambios:
# ambas leen el árbol, ambas modifican, ambas escriben, el último gana y
# pierde los cambios del primero. El lock evita ese intercalado.
_lock = threading.RLock()


def _rotate_backups():
    try:
        entries = sorted(e for e in os.listdir(_BACKUPS_DIR) if e.endswith('.xml'))
        for old in entries[:-_MAX_BACKUPS]:
            try:
                os.remove(os.path.join(_BACKUPS_DIR, old))
            except OSError:
                pass
    except OSError:
        pass


def _backup_current():
    if not os.path.isfile(_SOURCES_PATH):
        return
    os.makedirs(_BACKUPS_DIR, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    dest = os.path.join(_BACKUPS_DIR, f'sources_{stamp}.xml')
    try:
        shutil.copy2(_SOURCES_PATH, dest)
    except OSError:
        return
    _rotate_backups()


def _newest_parseable_backup():
    """El backup de fuentes más reciente que sirva, o None si no hay ninguno.

    Se exige el prefijo `sources_` Y que la raíz sea `<sources>`: `backups/`
    es un directorio compartido (backup.py cuelga ahí `snapshots/` y
    `auto_pre_restore/`), y adoptar por error un XML ajeno sería peor que no
    recuperar nada, porque el siguiente `_save_tree` lo escribiría encima de
    sources.xml. El nombre lleva `AAAAMMDD_HHMMSS`, así que el orden
    lexicográfico inverso es el cronológico inverso.
    """
    try:
        entries = sorted(
            (e for e in os.listdir(_BACKUPS_DIR)
             if e.startswith('sources_') and e.endswith('.xml')),
            reverse=True,
        )
    except OSError:
        return None
    for name in entries:
        try:
            tree = ET.parse(os.path.join(_BACKUPS_DIR, name))
        except (ET.ParseError, OSError):
            continue
        if tree.getroot().tag == 'sources':
            return tree
    return None


def _load_tree():
    """Devuelve el ElementTree completo de sources.xml.

    Si no existe, crea uno vacío con las cinco secciones estándar para que
    cualquier operación posterior pueda añadir sin tener que comprobar nada.
    """
    if os.path.isfile(_SOURCES_PATH):
        try:
            return ET.parse(_SOURCES_PATH)
        except ET.ParseError as e:
            # ET.ParseError hereda de SyntaxError, NO de OSError, así que no
            # lo cazaba ningún caller y un sources.xml a medio escribir (Kodi
            # lo reescribe sin atomicidad) tumbaba el Explorador entero con un
            # traceback crudo. Las copias que _save_tree ya venía guardando en
            # backups/ no las leía nadie; es aquí donde sirven. Si tampoco hay
            # copia utilizable seguimos con el árbol vacío: el usuario recupera
            # el Explorador, y la siguiente escritura pasa por
            # _backup_current(), que preserva el fichero corrupto antes de
            # sustituirlo.
            log.warning(f'[sources] sources.xml ilegible: {e}')
            recovered = _newest_parseable_backup()
            if recovered is not None:
                log.warning('[sources] recuperado desde la copia más reciente')
                return recovered
            log.warning('[sources] sin copia utilizable; se parte de vacío')
    root = ET.Element('sources')
    for section in ('programs', 'video', 'music', 'pictures', 'files'):
        ET.SubElement(root, section)
    return ET.ElementTree(root)


def _files_node(tree):
    """Devuelve el nodo <files>, creándolo si no estaba."""
    root = tree.getroot()
    files = root.find('files')
    if files is None:
        files = ET.SubElement(root, 'files')
    return files


def _save_tree(tree):
    """Atomic write del árbol completo. Reescribe el XML entero.

    Limitación conocida: los comentarios XML que pudiera contener el archivo
    original se pierden porque ElementTree no los preserva. Kodi no añade
    comentarios a sources.xml en ningún flujo normal, así que en la práctica
    no es un problema.
    """
    _backup_current()
    # Abrimos el archivo explícitamente en vez de pasar la ruta como string
    # porque la firma de ElementTree.write con string cambió en Python 3.14.
    # Pasar el file object funciona igual en Python 3.8+ (target Kodi 19).
    os.makedirs(os.path.dirname(_SOURCES_TMP) or '.', exist_ok=True)
    with open(_SOURCES_TMP, 'wb') as fh:
        tree.write(fh, encoding='utf-8', xml_declaration=True)
    os.replace(_SOURCES_TMP, _SOURCES_PATH)


def list_files_sources():
    """Lista las fuentes del bloque <files>.

    Devuelve [{'name': str, 'path': str}, ...] en orden de aparición.
    """
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        out = []
        for source in files.findall('source'):
            name_el = source.find('name')
            path_el = source.find('path')
            name = (name_el.text or '').strip() if name_el is not None else ''
            path = (path_el.text or '').strip() if path_el is not None else ''
            if name or path:
                out.append({'name': name, 'path': path})
        return out


def add_source(name, path):
    """Añade una entrada nueva al bloque <files> con el formato de Kodi.

    No comprueba duplicados: el caller debe decidir qué hacer si hay otra
    fuente con el mismo path (rechazar, sobreescribir o pedir confirmación).
    """
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        source = ET.SubElement(files, 'source')
        name_el = ET.SubElement(source, 'name')
        name_el.text = name
        path_el = ET.SubElement(source, 'path')
        path_el.set('pathversion', '1')
        path_el.text = path
        allow = ET.SubElement(source, 'allowsharing')
        allow.text = 'true'
        _save_tree(tree)


def rename_source(old_name, new_name):
    """Modifica el <name> de la primera fuente cuyo nombre coincida.

    Devuelve True si encontró y modificó la entrada, False si no había
    ninguna con ese nombre.
    """
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        for source in files.findall('source'):
            name_el = source.find('name')
            if name_el is not None and (name_el.text or '').strip() == old_name:
                name_el.text = new_name
                _save_tree(tree)
                return True
        return False


def remove_source(name):
    """Elimina la primera fuente con ese nombre del bloque <files>.

    Devuelve True si la encontró y eliminó, False si no existía.
    """
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        for source in files.findall('source'):
            name_el = source.find('name')
            if name_el is not None and (name_el.text or '').strip() == name:
                files.remove(source)
                _save_tree(tree)
                return True
        return False


def change_source_url(name, new_url):
    """Modifica el <path> de la primera fuente cuyo nombre coincida.

    Devuelve True si la encontró y modificó, False si no existía.
    """
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        for source in files.findall('source'):
            name_el = source.find('name')
            if name_el is not None and (name_el.text or '').strip() == name:
                path_el = source.find('path')
                if path_el is None:
                    path_el = ET.SubElement(source, 'path')
                    path_el.set('pathversion', '1')
                path_el.text = new_url
                _save_tree(tree)
                return True
        return False


def move_source(name, direction):
    """Mueve la fuente `name` una posición arriba (`direction='up'`) o abajo
    (`direction='down'`) dentro del bloque <files>. Kodi respeta el orden.

    Devuelve True si movió la fuente, False si no existía o ya estaba en el
    extremo correspondiente.
    """
    if direction not in ('up', 'down'):
        return False
    with _lock:
        tree = _load_tree()
        files = _files_node(tree)
        children = list(files.findall('source'))
        idx = None
        for i, source in enumerate(children):
            name_el = source.find('name')
            if name_el is not None and (name_el.text or '').strip() == name:
                idx = i
                break
        if idx is None:
            return False
        new_idx = idx - 1 if direction == 'up' else idx + 1
        if new_idx < 0 or new_idx >= len(children):
            return False
        node = children[idx]
        # ElementTree no expone move(): borrar e insertar en la posición nueva.
        files.remove(node)
        files.insert(new_idx, node)
        _save_tree(tree)
        return True


def list_backups():
    """Lista las copias de seguridad ordenadas de más reciente a más antigua."""
    try:
        entries = sorted(
            (e for e in os.listdir(_BACKUPS_DIR) if e.endswith('.xml')),
            reverse=True,
        )
        return [os.path.join(_BACKUPS_DIR, e) for e in entries]
    except OSError:
        return []


def restore_backup(backup_path):
    """Restaura sources.xml desde una copia de seguridad. Devuelve True si ok."""
    if not os.path.isfile(backup_path):
        return False
    with _lock:
        try:
            with open(backup_path, 'rb') as fh:
                content = fh.read()
        except OSError:
            return False
        _backup_current()
        try:
            os.makedirs(os.path.dirname(_SOURCES_TMP) or '.', exist_ok=True)
            with open(_SOURCES_TMP, 'wb') as fh:
                fh.write(content)
            os.replace(_SOURCES_TMP, _SOURCES_PATH)
            return True
        except OSError:
            return False
