"""Handler HTTP con soporte de Range (RFC 7233) para servir archivos.

Crítico para que el reproductor HTML5 del móvil pueda hacer seek en
vídeos grandes. SimpleHTTPRequestHandler de stdlib NO soporta Range
nativamente (verificado contra source de Python 3.8 y 3.14).

API:
- serve_range(handler, filepath, content_type) → función pura para
  llamar desde CUALQUIER handler que reciba un GET/HEAD. La usa el
  server permanente para /stream/<id> sin construir un handler nuevo.
- make_handler(filepath, content_type) → subclase de BaseHTTPRequestHandler
  pensada para un servidor dedicado a UN archivo (no se usa actualmente
  pero la mantenemos para testing y casos futuros).

- 416 Range Not Satisfiable (no 400) para Range malformado o multipart
  (cumple RFC 7233).
"""
import os
import re
from http.server import BaseHTTPRequestHandler


# Dígitos acotados a 19 (lo que cabe en int64, muy por encima de cualquier
# tamaño de fichero real). Sin el tope, un `Range: bytes=0-<5000 dígitos>`
# llega a int() y en Python 3.11 -el de Kodi 21- lanza ValueError por el
# límite de conversión (CVE-2020-10735); esa excepción no la captura nadie y
# revienta el hilo del handler en vez de devolver el 416 que toca.
_RANGE_RE = re.compile(r'^bytes=(\d{0,19})-(\d{0,19})$')
_CHUNK = 64 * 1024
_SOCKET_TIMEOUT_S = 60


def serve_range(handler, filepath, content_type='video/mp4', extra_headers=()):
    """Sirve filepath con Range desde un handler ya construido.

    handler: instancia de BaseHTTPRequestHandler con self.headers/wfile/...
    filepath: ruta absoluta del archivo en disco.
    content_type: por defecto 'video/mp4'.
    extra_headers: iterable de (nombre, valor) que se emite en todas las
        respuestas. El caller decide su política; este módulo es transporte
        y no conoce la del servidor que lo usa.

    Maneja GET (con o sin Range) y HEAD según handler.command.
    """
    try:
        size = os.path.getsize(filepath)
    except OSError:
        handler.send_error(404)
        return

    if handler.command == 'HEAD':
        _send_headers(handler, 200, size, content_type,
                      extra_headers=extra_headers)
        return

    rng = handler.headers.get('Range')
    if not rng:
        _send_headers(handler, 200, size, content_type,
                      extra_headers=extra_headers)
        with open(filepath, 'rb') as f:
            _stream(handler, f, size)
        return

    if ',' in rng:
        _send_416(handler, size, extra_headers)
        return

    m = _RANGE_RE.match(rng.strip())
    if not m:
        _send_416(handler, size, extra_headers)
        return

    start_s, end_s = m.group(1), m.group(2)
    if start_s == '' and end_s == '':
        _send_416(handler, size, extra_headers)
        return
    if start_s == '':
        suffix = int(end_s)
        start = max(0, size - suffix)
        end = size - 1
    else:
        start = int(start_s)
        end = int(end_s) if end_s else size - 1

    if start >= size or end >= size or start > end:
        _send_416(handler, size, extra_headers)
        return

    length = end - start + 1
    _send_headers(handler, 206, length, content_type,
                  content_range=f'bytes {start}-{end}/{size}',
                  extra_headers=extra_headers)
    with open(filepath, 'rb') as f:
        f.seek(start)
        _stream(handler, f, length)


def _send_headers(handler, code, length, content_type, content_range=None,
                  extra_headers=()):
    handler.send_response(code)
    for name, value in extra_headers:
        handler.send_header(name, value)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Accept-Ranges', 'bytes')
    handler.send_header('Content-Length', str(length))
    if content_range:
        handler.send_header('Content-Range', content_range)
    handler.end_headers()


def _send_416(handler, size, extra_headers=()):
    handler.send_response(416)
    for name, value in extra_headers:
        handler.send_header(name, value)
    handler.send_header('Content-Range', f'bytes */{size}')
    handler.end_headers()


def _stream(handler, f, remaining):
    try:
        while remaining > 0:
            chunk = f.read(min(_CHUNK, remaining))
            if not chunk:
                break
            handler.wfile.write(chunk)
            remaining -= len(chunk)
    except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
        # Cliente hizo seek y cerró la conexión, o timeout: normal en
        # <video> HTML5. No es error.
        pass


def make_handler(filepath, content_type='video/mp4'):
    """Devuelve una subclase de BaseHTTPRequestHandler bound a filepath.

    Para tests o uso en un servidor dedicado a UN archivo. El server
    permanente NO usa esto; usa serve_range directamente desde su handler
    porque multiplexa varios endpoints (/stream/<id>, /remote/*, etc.).
    """
    class _Handler(_RangeFileHandlerBase):
        pass
    _Handler.filepath = filepath
    _Handler.content_type = content_type
    return _Handler


class _RangeFileHandlerBase(BaseHTTPRequestHandler):
    filepath = None
    content_type = 'video/mp4'

    def log_message(self, fmt, *args):
        pass

    def setup(self):
        super().setup()
        self.connection.settimeout(_SOCKET_TIMEOUT_S)

    def do_HEAD(self):
        serve_range(self, self.filepath, self.content_type)

    def do_GET(self):
        serve_range(self, self.filepath, self.content_type)
