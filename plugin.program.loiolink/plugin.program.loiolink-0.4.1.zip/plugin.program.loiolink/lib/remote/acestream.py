"""Helper para reproducir acestream:// vía Plexus o Horus.

Acepta dos formatos al entrar (`is_acestream`, `play`, `normalize`):
- URL completa `acestream://[40 hex]`
- ID desnudo `[40 hex]` (sin prefijo), útil para pegar IDs de foros

Invocación: `xbmc.executebuiltin('PlayMedia(...)')`, no `Player.Open`
JSON-RPC. Player.Open en async bypassa parte del ciclo de delegación al
plugin Plexus y el cliente acestream del SO reporta "can not get
transport file". PlayMedia ejecuta el flujo completo (busy dialog,
plugin handler, delegación) y funciona. Verificado contra espadaily.
"""
import re
import socket
import urllib.parse

import xbmc

PLEXUS_ID = 'program.plexus'
HORUS_ID = 'script.module.horus'

_RE = re.compile(r'^acestream://([a-fA-F0-9]{40})$', re.I)
_RE_ID = re.compile(r'^[a-fA-F0-9]{40}$', re.I)

# AceStream Engine HTTP API default. El usuario puede tenerlo en otro
# puerto si lo configuró; en ese caso el health check da falso negativo
# pero no rompe nada (es solo una pista informativa al usuario).
_ENGINE_HOST = '127.0.0.1'
_ENGINE_PORT = 6878


def is_acestream(text):
    if not isinstance(text, str):
        return False
    t = text.strip()
    return bool(_RE.match(t) or _RE_ID.match(t))


def normalize(text):
    """Devuelve `acestream://hash` en lowercase desde URL completa o ID desnudo.
    ValueError si no es string o no matchea ningún formato acestream."""
    if not isinstance(text, str):
        raise ValueError(f'No es acestream (tipo {type(text).__name__}): {text!r}')
    t = text.strip()
    if _RE_ID.match(t):
        return f'acestream://{t.lower()}'
    m = _RE.match(t)
    if m:
        return f'acestream://{m.group(1).lower()}'
    raise ValueError(f'No es acestream: {text!r}')


def _content_id(url):
    m = _RE.match(url.strip())
    return m.group(1).lower() if m else None


def _has_addon(addon_id):
    # Indirección sobre installer.is_ready para compartir el cache TTL
    # con el resto del addon (resolver, stream_player, etc.).
    from lib import installer
    return installer.is_ready(addon_id)


def engine_running(timeout=1.5):
    """Heurística: ¿AceStream Engine acepta TCP en 127.0.0.1:6878?

    No es determinístico: Plexus puede arrancar el engine bajo demanda y
    el usuario puede tenerlo en otro puerto. Sirve solo como pista al
    usuario cuando Plexus/Horus están instalados pero el playback falla
    con "can not get transport file" (típicamente: engine offline, sin
    conectividad a la red Ace, o bloqueado por firewall/ISP).
    """
    try:
        with socket.create_connection((_ENGINE_HOST, _ENGINE_PORT), timeout=timeout):
            return True
    except (OSError, ValueError):
        return False


def play(url):
    """Reproduce acestream URL o ID desnudo. Devuelve 'plexus' o 'horus'.
    Lanza RuntimeError si no hay cliente instalado, ValueError si no es acestream."""
    full_url = normalize(url)
    cid = _content_id(full_url)

    clients = [
        (PLEXUS_ID, {'url': f'acestream://{cid}', 'mode': '1', 'name': 'Acestream'}),
        (HORUS_ID, {'action': 'play', 'id': cid}),
    ]
    for addon_id, params in clients:
        if _has_addon(addon_id):
            ace_url = f'plugin://{addon_id}/?' + urllib.parse.urlencode(params)
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
            return addon_id.split('.')[-1]  # 'plexus' o 'horus'

    raise RuntimeError('no_acestream_client')
