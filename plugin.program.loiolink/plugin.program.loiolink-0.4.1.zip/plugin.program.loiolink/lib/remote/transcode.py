"""Detección de ffmpeg/ffprobe + heurística is_browser_playable.

Si el móvil no soporta el códec, preguntar al
usuario si transcodificar (cuando ffmpeg está disponible). Si no está
ffmpeg, avisar que el vídeo no se puede ver tal cual.

Whitelist de lo que reproducen los navegadores modernos (Chrome/Firefox/
Edge/Safari 14+ desktop y móvil sin extensiones). Contenedores: MP4 family
y WebM. Vídeo: H.264, VP8, VP9, AV1, MJPEG. Audio: AAC, Opus, Vorbis, MP3,
FLAC. Falsos negativos son aceptables (el usuario verá el motivo); falsos
positivos no.
"""
import json
import os
import shutil
import subprocess
import sys
import threading

from lib import network_config


_OK_VIDEO = {'h264', 'avc1', 'vp8', 'vp9', 'av1', 'mjpeg'}
_OK_AUDIO = {'aac', 'mp4a', 'opus', 'vorbis', 'mp3', 'flac'}
_OK_CONTAINERS = {'mov', 'mp4', 'm4a', '3gp', '3g2', 'mj2', 'webm'}
# Contenedores de audio puro que los navegadores reproducen en <audio>.
# 'aac' es el ADTS crudo; su códec (aac) ya está en _OK_AUDIO igual que en
# el contenedor m4a que ya se aceptaba, así que se incluye por coherencia.
_OK_AUDIO_CONTAINERS = {'mp3', 'flac', 'ogg', 'wav', 'aac'}

# Heurística sin ffprobe (solo extensión). True cuando casi seguro
# reproduce, False cuando casi seguro no. Los formatos de audio con soporte
# universal en navegadores modernos (Safari 11+/14+ incluido) van a True;
# ogg/opus quedan fuera del hint (soporte irregular en Safari) y caen al
# camino con ffprobe, donde se valida el códec.
_EXT_HINT = {
    '.mp4': True, '.m4v': True, '.mov': True, '.webm': True,
    '.mp3': True, '.m4a': True, '.flac': True, '.wav': True, '.aac': True,
    '.mkv': False, '.avi': False, '.wmv': False, '.flv': False,
}


def no_console_flags():
    """kwargs para subprocess que evitan el flash de consola en Windows."""
    if sys.platform == 'win32':
        return {'creationflags': subprocess.CREATE_NO_WINDOW}
    return {}


_MAX_CONCURRENT_TRANSCODES = 2
_transcode_slots = threading.Semaphore(_MAX_CONCURRENT_TRANSCODES)


def acquire_slot():
    """Reserva un slot de transcoding. Devuelve True si se obtuvo."""
    return _transcode_slots.acquire(blocking=False)


def release_slot():
    _transcode_slots.release()


def safe_path_arg(path):
    """Path seguro para pasar como argumento a ffmpeg/ffprobe.

    ffmpeg interpreta argumentos que empiezan por '-' como flags; un nombre
    de archivo como '-vf;...' inyectaría opciones. Prefijar con 'file:'
    fuerza la interpretación como URI local.
    """
    if isinstance(path, str) and path.startswith('-'):
        return f'file:{path}'
    return path


def find_ffmpeg():
    """Devuelve path a ffmpeg en el directorio local bin/ o en PATH o None."""
    addon_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    local_path = os.path.join(addon_dir, 'bin', 'ffmpeg.exe')
    if os.path.isfile(local_path):
        return local_path
    local_path_non_win = os.path.join(addon_dir, 'bin', 'ffmpeg')
    if os.path.isfile(local_path_non_win):
        return local_path_non_win
    return shutil.which('ffmpeg')


def find_ffprobe():
    """Devuelve path a ffprobe en el directorio local bin/ o en PATH o None."""
    addon_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    local_path = os.path.join(addon_dir, 'bin', 'ffprobe.exe')
    if os.path.isfile(local_path):
        return local_path
    local_path_non_win = os.path.join(addon_dir, 'bin', 'ffprobe')
    if os.path.isfile(local_path_non_win):
        return local_path_non_win
    return shutil.which('ffprobe')


def is_browser_playable(filepath):
    """Devuelve (bool, reason). Usa ffprobe si está; si no, heurística por extensión."""
    if not os.path.isfile(filepath):
        return False, 'archivo no existe'

    ffprobe = find_ffprobe()
    if not ffprobe:
        ext = os.path.splitext(filepath)[1].lower()
        hint = _EXT_HINT.get(ext)
        if hint is True:
            return True, f'extensión {ext} (sin ffprobe, heurística)'
        if hint is False:
            return False, f'extensión {ext} probablemente requiere transcodificación'
        return False, f'extensión {ext} desconocida (sin ffprobe)'

    try:
        out = subprocess.run(
            [ffprobe, '-v', 'quiet', '-print_format', 'json',
             '-show_streams', '-show_format', safe_path_arg(filepath)],
            capture_output=True, timeout=network_config.get_timeout('transcode'),
            check=True, **no_console_flags(),
        )
        info = json.loads(out.stdout)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired,
            OSError, json.JSONDecodeError) as e:
        return False, f'ffprobe falló: {e}'

    # ffmpeg comparte el demuxer "matroska,webm" entre .mkv y .webm, así que
    # format_name no los distingue. Solo WebM es reproducible en navegador;
    # filtramos MKV por extensión antes del check genérico.
    ext = os.path.splitext(filepath)[1].lower()
    if ext == '.mkv':
        return False, 'contenedor MKV no reproducible en navegador'

    container = (info.get('format', {}).get('format_name') or '').split(',')
    if not any(c in _OK_CONTAINERS or c in _OK_AUDIO_CONTAINERS for c in container):
        pretty = container[0] if container and container[0] else 'desconocido'
        return False, f'contenedor {pretty} no reproducible en navegador'

    has_video = False
    has_audio = False
    for s in info.get('streams', []):
        codec = s.get('codec_name', '')
        if s.get('codec_type') == 'video':
            # Carátula embebida en un archivo de audio (attached_pic): no es
            # vídeo reproducible, ignorarla en vez de rechazar el archivo.
            if s.get('disposition', {}).get('attached_pic'):
                continue
            if codec not in _OK_VIDEO:
                return False, f'códec vídeo {codec} no reproducible en navegador'
            has_video = True
        elif s.get('codec_type') == 'audio':
            # pcm_* cubre el WAV sin compresión, que los navegadores reproducen.
            if codec not in _OK_AUDIO and not codec.startswith('pcm_'):
                return False, f'códec audio {codec} no reproducible en navegador'
            has_audio = True

    if not has_video and not has_audio:
        return False, 'no hay streams reproducibles'
    return True, 'compatible con navegador'
