"""Gestión de sesiones por dispositivo del panel web permanente.

Cada navegador pareado tiene su propia sesión:
    {id, token, label, ua, created_at, last_seen_at, last_seen_ip}

Sustituye al modelo legacy "un único token global" que vivía en el setting
`remote_auth_token`. Beneficios:

- Revocar un dispositivo sin kickear a los demás.
- Ver desde el panel qué clientes están conectados y desde dónde.
- Detectar accesos extraños (IP nueva, hace 6 meses sin uso, etc.).

Storage: `addon_data/sessions.json` con atomic write (escribe a .tmp +
os.replace). Misma estrategia que `lib.transfers.history`.

Concurrencia:
- `_lock` (threading.Lock) protege dentro de un proceso.
- `_acquire_ipc_lock` (window property en Home/10000) protege entre
  procesos. Kodi tiene varios procesos Python independientes (service,
  default/plugin, context). Si dos hacen add() simultáneamente sin este
  lock, uno pisa al otro y se pierde una sesión.

Comparación de tokens: `hmac.compare_digest` (constant-time, mitiga
timing attacks).

Migración: al arrancar el service, `migrate_legacy_token()` busca el
setting legacy y, si tiene valor, crea una sesión "Sesión original" con
ese token y vacía el setting. Cero disrupción para clientes ya pareados.
"""
import glob
import hmac
import json
import os
import secrets
import threading
import time

import xbmcaddon
import xbmcgui
import xbmcvfs

from lib import log


SESSION_FILE = 'sessions.json'
LEGACY_SETTING = 'remote_auth_token'

# Label asignado a sesiones recién creadas para QR antes de ser escaneadas.
# Acoplado a touch() (lo sobrescribe al detectar UA real) y a
# purge_unscanned() (lo usa como discriminador). Constante única para que
# renombrarlo no rompa esos consumidores en silencio.
UNSCANNED_LABEL = 'QR (sin escanear)'

# Cap de defensa: muchas más es señal de acumulación accidental (varios
# QR sin escanear) o abuso. Cuando se supera, se eliminan las más antiguas
# por last_seen_at.
MAX_SESSIONS = 100

# touch() solo persiste si la última escritura fue hace al menos esto.
# Para un panel activo, evita un disk write por cada long-poll (cada 25s
# × N pestañas). El last_seen_at mostrado se queda atrás como máximo 5s,
# que para un display "hace X" es irrelevante.
_TOUCH_MIN_DELTA_S = 5

# Mutex IPC cross-process. Patrón heredado de pairing.py (window property
# en el Home window 10000, accesible desde cualquier proceso del addon).
_IPC_MUTEX_PROP = 'loiolink.sessions.ipc'
_IPC_MUTEX_TIMEOUT_S = 5
_IPC_MUTEX_STALE_S = 30
_IPC_RETRY_INTERVAL_S = 0.03

_lock = threading.Lock()


def _now():
    return time.time()


def _acquire_ipc_lock():
    """Adquiere el lock cross-process con reintentos. Devuelve True si lo
    tomó (o si está stale y lo reclamó).

    Esto NO es 100% atómico entre procesos (xbmcgui.Window setProperty es
    atómico individualmente pero el check-then-set no), pero la ventana
    de race se reduce a microsegundos. En condiciones reales del addon
    (humanos abriendo QR + canjeando PIN ocasionalmente) la colisión es
    extremadamente improbable.
    """
    win = xbmcgui.Window(10000)
    deadline = time.time() + _IPC_MUTEX_TIMEOUT_S
    while time.time() < deadline:
        raw = win.getProperty(_IPC_MUTEX_PROP) or ''
        if not raw:
            win.setProperty(_IPC_MUTEX_PROP, str(int(time.time() * 1000)))
            return True
        try:
            held_at_ms = int(raw)
        except (TypeError, ValueError):
            held_at_ms = 0
        if time.time() * 1000 - held_at_ms > _IPC_MUTEX_STALE_S * 1000:
            # Lock huérfano (proceso crasheado sin liberarlo).
            win.setProperty(_IPC_MUTEX_PROP, str(int(time.time() * 1000)))
            return True
        time.sleep(_IPC_RETRY_INTERVAL_S)
    return False


def _release_ipc_lock():
    xbmcgui.Window(10000).clearProperty(_IPC_MUTEX_PROP)


def _store_path():
    profile = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('profile'),
    )
    return os.path.join(profile, SESSION_FILE)


def _ensure_dir():
    path = _store_path()
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass


def _load_unlocked():
    path = _store_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        # JSON corrupto: renombrar a .bak para no perderlo silenciosamente
        # (debug forense + recovery manual). Solo si el archivo tiene
        # contenido: un archivo vacío no merece backup.
        try:
            if os.path.getsize(path) > 0:
                bak = path + f'.corrupt.{int(time.time())}.bak'
                os.replace(path, bak)
        except OSError:
            pass
        return []
    if not isinstance(data, list):
        return []
    return [s for s in data if isinstance(s, dict) and s.get('token')]


def _save_unlocked(sessions):
    """Atomic write: tmp file + os.replace. Devuelve True si se persistió.

    Antes se tragaba cualquier OSError en silencio, y eso convertía a
    `revoke()` en un mentiroso: devolvía True (“dispositivo expulsado”) aunque
    el fichero no se hubiera escrito, así que el dispositivo revocado seguía
    entrando. En Windows `os.replace` falla de forma transitoria si el
    antivirus o el indexador tienen el destino abierto (misma razón por la que
    `backup._replace_with_retry` existe), así que no es un caso teórico.

    El tmp lleva pid y thread en el nombre: sessions.json lo escriben VARIOS
    procesos de Kodi (service, plugin, context) y el lock IPC es best-effort
    (si expira, la operación sigue igualmente). Con un nombre fijo, dos
    procesos concurrentes se pisarían el fichero intermedio.
    """
    _ensure_dir()
    path = _store_path()
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    last_err = None
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(sessions, f)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        for attempt in range(3):
            try:
                os.replace(tmp, path)
                return True
            except OSError as e:
                last_err = e
                if attempt < 2:
                    time.sleep(0.1 * (2 ** attempt))
    except OSError as e:
        last_err = e
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass
    log.error(f'[sessions] no se pudieron guardar las sesiones: {last_err!r}')
    return False


def load_all():
    """Lista actual de sesiones con tokens. Uso interno."""
    with _lock:
        return list(_load_unlocked())


def token_eq(stored, received):
    """Comparación constant-time que tolera basura llegada de la red.

    `hmac.compare_digest` sobre `str` LANZA TypeError si algún operando
    lleva caracteres no ASCII, y los tokens llegan de la query string,
    donde `parse_qs` mete U+FFFD ante bytes inválidos. Sin esta guarda un
    `GET /?t=%C3%A9` de un cliente SIN autenticar reventaba el handler con
    un traceback en kodi.log y la conexión cortada. Un token nuestro es
    siempre `secrets.token_urlsafe`, o sea ASCII: descartar lo que no lo
    sea no rechaza nada legítimo.
    """
    if not stored or not received:
        return False
    if not (stored.isascii() and received.isascii()):
        return False
    return hmac.compare_digest(stored, received)


def find_by_token(token):
    """Sesión cuyo token coincide (constant-time), o None."""
    if not token:
        return None
    with _lock:
        for s in _load_unlocked():
            if token_eq(s.get('token', ''), token):
                return s
    return None


def short_ua(ua):
    """User-Agent → label corto y legible ('Chrome en Android')."""
    if not ua:
        return 'Desconocido'
    low = ua.lower()
    if 'edg/' in low or 'edge' in low:
        browser = 'Edge'
    elif 'chrome' in low:
        browser = 'Chrome'
    elif 'firefox' in low:
        browser = 'Firefox'
    elif 'safari' in low:
        browser = 'Safari'
    else:
        browser = 'Navegador'
    if 'android' in low:
        device = 'Android'
    elif 'iphone' in low:
        device = 'iPhone'
    elif 'ipad' in low:
        device = 'iPad'
    elif 'windows' in low:
        device = 'Windows'
    elif 'macintosh' in low or 'mac os' in low:
        device = 'Mac'
    elif 'linux' in low:
        device = 'Linux'
    else:
        device = 'PC'
    return f'{browser} en {device}'


def _with_ipc_lock(fn):
    """Adquiere lock IPC + thread lock antes de ejecutar fn(). Si no logra
    el IPC lock dentro del timeout, ejecuta sin él (degrade graceful con
    riesgo bajo de race, mejor que bloquear la operación completamente).
    """
    got = _acquire_ipc_lock()
    try:
        with _lock:
            return fn()
    finally:
        if got:
            _release_ipc_lock()


def _evict_oldest_unlocked(sessions):
    """Si supera MAX_SESSIONS, eliminar las más antiguas por last_seen_at
    (las nunca-usadas, last_seen_at=0, son las primeras en caer)."""
    if len(sessions) <= MAX_SESSIONS:
        return sessions
    sessions.sort(
        key=lambda s: (s.get('last_seen_at', 0) or 0,
                       s.get('created_at', 0) or 0))
    return sessions[-(MAX_SESSIONS - 1):]


def add(label=None, ua=''):
    """Crea una sesión nueva. Devuelve dict completo (incluye token).

    Levanta OSError si no se pudo persistir. Devolver una sesión que no está
    en disco produce un QR muerto: el móvil lo escanea, el server no encuentra
    el token y responde 401 sin que nadie pueda explicar por qué. Es mejor que
    el caller avise del fallo real.
    """
    token = secrets.token_urlsafe(24)
    session = {
        'id': secrets.token_urlsafe(9),
        'token': token,
        'label': (label or short_ua(ua))[:80],
        'ua': ua[:200] if ua else '',
        'created_at': _now(),
        'last_seen_at': 0.0,
        'last_seen_ip': '',
    }
    result = {'ok': False}

    def _do():
        sessions = _load_unlocked()
        sessions.append(session)
        sessions = _evict_oldest_unlocked(sessions)
        result['ok'] = _save_unlocked(sessions)

    _with_ipc_lock(_do)
    if not result['ok']:
        raise OSError('no se pudo guardar la sesión nueva')
    return session


def touch(token, ip='', ua=''):
    """Actualiza last_seen_at/ip/ua de la sesión con ese token. No-op si
    no existe. Si la última escritura fue hace <_TOUCH_MIN_DELTA_S y el
    estado (ip, ua) no cambia, NO persiste; evita disk write por request.
    """
    if not token:
        return

    def _do():
        sessions = _load_unlocked()
        for s in sessions:
            if not token_eq(s.get('token', ''), token):
                continue
            now = _now()
            need_label_update = (
                ua and not s.get('ua')
                and s.get('label') in ('', 'Desconocido', UNSCANNED_LABEL))
            ip_changed = ip and s.get('last_seen_ip') != ip
            ua_changed = ua and not s.get('ua')
            recent = now - (s.get('last_seen_at') or 0) < _TOUCH_MIN_DELTA_S
            # Skip si nada material ha cambiado Y la última persistencia
            # es reciente. Evita disk write spam con long-polls activos.
            if recent and not ip_changed and not ua_changed:
                return
            s['last_seen_at'] = now
            if ip:
                s['last_seen_ip'] = ip[:64]
            if ua_changed:
                s['ua'] = ua[:200]
                if need_label_update:
                    s['label'] = short_ua(ua)
            _save_unlocked(sessions)
            return

    _with_ipc_lock(_do)


def revoke(session_id):
    """Borra la sesión con ese id. True si borró algo."""
    if not session_id:
        return False
    result = {'ok': False}

    def _do():
        sessions = _load_unlocked()
        filtered = [s for s in sessions if s.get('id') != session_id]
        if len(filtered) == len(sessions):
            return
        # Solo decimos "revocada" si de verdad se persistió: si mentimos, el
        # usuario cree que ha expulsado un dispositivo que sigue entrando.
        result['ok'] = _save_unlocked(filtered)

    _with_ipc_lock(_do)
    return result['ok']


def rename(session_id, label):
    """Cambia el label. True si cambió algo."""
    if not session_id or not label:
        return False
    label = label.strip()[:80]
    if not label:
        return False
    result = {'ok': False}

    def _do():
        sessions = _load_unlocked()
        for s in sessions:
            if s.get('id') == session_id:
                s['label'] = label
                result['ok'] = _save_unlocked(sessions)
                return

    _with_ipc_lock(_do)
    return result['ok']


def revoke_if_unscanned(session_id):
    """Revoca la sesión solo si nunca fue escaneada (last_seen_at == 0)."""
    if not session_id:
        return

    def _do():
        sess = _load_unlocked()
        cleaned = [s for s in sess
                   if not (s.get('id') == session_id
                           and s.get('last_seen_at', 0) == 0.0)]
        if len(cleaned) < len(sess):
            _save_unlocked(cleaned)

    _with_ipc_lock(_do)


def purge_unscanned():
    """Borra sesiones QR creadas pero nunca escaneadas."""
    def _do():
        sess = _load_unlocked()
        cleaned = [s for s in sess
                   if not (s.get('last_seen_at', 0) == 0.0
                           and s.get('label') == UNSCANNED_LABEL)]
        if len(cleaned) < len(sess):
            _save_unlocked(cleaned)
    _with_ipc_lock(_do)


def revoke_all():
    """Borra TODAS las sesiones (incluida la actual). True si se persistió.

    Devuelve el resultado real por lo mismo que `revoke()`: decirle al usuario
    "he expulsado todos los dispositivos" cuando la escritura falló los deja
    dentro sin que se entere.
    """
    result = {'ok': False}

    def _do():
        result['ok'] = _save_unlocked([])

    _with_ipc_lock(_do)
    return result['ok']


def revoke_others(keep_token):
    """Borra todas EXCEPTO la que matchea keep_token. True si se persistió."""
    if not keep_token:
        return False
    result = {'ok': False}

    def _do():
        sessions = _load_unlocked()
        filtered = [s for s in sessions
                    if token_eq(s.get('token', ''), keep_token)]
        result['ok'] = _save_unlocked(filtered)

    _with_ipc_lock(_do)
    return result['ok']


def migrate_legacy_token():
    """Si el setting legacy tiene valor, crea sesión con ese token y vacía
    el setting. Idempotente. Devuelve el token migrado o None."""
    addon = xbmcaddon.Addon()
    legacy = (addon.getSetting(LEGACY_SETTING) or '').strip()
    if not legacy:
        return None

    def _do():
        sessions = _load_unlocked()
        already = any(s.get('token') == legacy for s in sessions)
        if not already:
            sessions.append({
                'id': secrets.token_urlsafe(9),
                'token': legacy,
                'label': 'Sesión original',
                'ua': '',
                'created_at': _now(),
                'last_seen_at': 0.0,
                'last_seen_ip': '',
            })
            sessions = _evict_oldest_unlocked(sessions)
            _save_unlocked(sessions)

    _with_ipc_lock(_do)
    addon.setSetting(LEGACY_SETTING, '')
    return legacy


def public_view(self_token=None):
    """Lista sin tokens (segura para enviar al frontend).

    Marca con is_self=True la sesión cuyo token coincide con self_token.
    """
    out = []
    for s in load_all():
        is_self = token_eq(s.get('token', ''), self_token)
        out.append({
            'id': s.get('id', ''),
            'label': s.get('label', ''),
            'ua': s.get('ua', ''),
            'created_at': s.get('created_at', 0.0),
            'last_seen_at': s.get('last_seen_at', 0.0),
            'last_seen_ip': s.get('last_seen_ip', ''),
            'is_self': is_self,
        })
    return out


def _reset_for_tests():
    """Solo tests. Vacía el storage, limpia residuos .tmp y libera el
    IPC lock por si algún test anterior crasheó sin liberarlo."""
    _release_ipc_lock()
    with _lock:
        _save_unlocked([])
        # Los tmp llevan pid+thread en el nombre, así que barremos por patrón.
        for tmp in glob.glob(_store_path() + '.*.tmp'):
            try:
                os.unlink(tmp)
            except OSError:
                pass
