"""Wrapper sobre Player.* JSON-RPC para control remoto desde móvil.

- active_player_id prioriza video > audio > picture (determinista cuando hay
  audio en background con vídeo activo).
- play_file usa options.resume (start position atómico, sin frames del
  principio antes del seek).
- seek_to_seconds usa {seconds: N} (válido Kodi 19+, más conciso que
  {time: {hours,minutes,seconds,milliseconds}}).
- PlayMedia builtin tiene bug con comas/paréntesis (kodi#14838); usamos
  Player.Open JSON-RPC en todo el flow.

xbmc.executeJSONRPC corre in-process, sin auth; pensado para llamarse
desde dentro del addon. Las funciones legacy (status, play_pause, stop,
seek_to_seconds, set_volume, play_file) usan `_rpc` (silencia errores).
Las funciones nuevas (next/prev/mute/shuffle/repeat/audio/sub/queue/
scan/clean/addons/notify) usan `_rpc_strict` y propagan RPCError para
que los endpoints HTTP devuelvan 4xx/5xx coherentes.
"""
import hashlib
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon

from lib import log
from lib.remote.rpc import RPCError
from lib.remote.rpc import call as _rpc
from lib.remote.rpc import call_or_raise as _rpc_strict

# Kodi interpreta BBCode (`[COLOR]`, `[B]`, `[CR]`, etc.) en las
# notificaciones de GUI. Un cliente con QR pareado podría enviar
# `[COLOR red][B]Tu addon ha caducado[/B][/COLOR] visita http://phish.com`
# y aparecería con formato en la TV: phishing visual. Strip cualquier tag
# `[XXX]` o `[/XXX]`. Y filtrar control chars (`\r`, `\n`, `NULL`...) que
# rompen el render del skin.
_BBCODE_TAG = re.compile(r'\[/?[A-Za-z][A-Za-z0-9]*[^\]]*\]')
_CONTROL_CHARS = re.compile(r'[\x00-\x1f\x7f]')


def _sanitize_persisted_text(s):
    """Saneado del texto del cliente que se GUARDA en favourites.xml.

    No sirve `_sanitize_notif_text`: su regex se come cualquier `[Palabra]`,
    lo cual es inofensivo en un toast de 5 s pero aquí destruiría el nombre
    del usuario ("[HD] Alcarràs" se guardaría como "Alcarràs"). Y encima de
    forma arbitraria, porque "[2026] Peli" sí sobrevive. `strip_bbcode` quita
    solo las marcas que Kodi interpreta de verdad al pintar, que son las del
    phishing visual. Los caracteres de control sí se van: un NUL deja el XML
    sin poder parsearse.
    """
    # Import diferido: accessibility trae xbmcgui, y este módulo lo mantiene
    # fuera del scope de import a propósito (lo importa dentro de las
    # funciones que lo necesitan).
    from lib import accessibility
    return _CONTROL_CHARS.sub(' ', accessibility.strip_bbcode(str(s or ''))).strip()


def _sanitize_notif_text(s):
    if not s:
        return ''
    s = _BBCODE_TAG.sub('', str(s))
    s = _CONTROL_CHARS.sub(' ', s)
    return s.strip()


_REPEAT_MODES = ('off', 'one', 'all')
_NOTIF_LEVELS = ('info', 'warning', 'error')
_SUBTITLE_KEYWORDS = ('off', 'on', 'next', 'previous')
_STREAM_KEYWORDS = ('next', 'previous')
_ADDONID_RE = re.compile(r'^[A-Za-z0-9._-]+$')

# Si un atacante con el QR pareado deshabilita el propio addon o algo crítico
# (skin activo, repo oficial, JSON-RPC), Kodi queda inutilizable y la
# recuperación requiere acceso físico a la TV: exactamente lo opuesto al
# propósito del control remoto. La lista whitelist es por prefijo: cualquier
# addon que empieza por uno de estos prefijos no puede deshabilitarse desde
# el panel.
_ADDON_BLOCKLIST_PREFIXES = (
    'plugin.program.loiolink',     # el propio addon (bricking trivial)
    'xbmc.',                       # xbmc.json, xbmc.python, etc.
    'metadata.',                   # scrapers de los que depende la library
    'service.xbmc.',               # core services de Kodi
    'repository.xbmc.',            # repo oficial
)

# Tipo de player → playlistid de Kodi (fijo desde XBMC v9).
_TYPE_TO_PLAYLISTID = {'audio': 0, 'video': 1, 'picture': 2}
_VALID_PLAYLIST_IDS = frozenset(_TYPE_TO_PLAYLISTID.values())

# Kodi maneja dos vocabularios para lo mismo: el del player ('audio') y el de
# la biblioteca ('music'; ver library_cache._KODI_LIBRARY_TO_SCOPE). El
# explorador nativo generaba URLs con 'music', que no es clave del dict de
# arriba, así que las canciones caían al default y acababan en la playlist de
# vídeo. Se sigue aceptando el alias porque esas URLs de plugin pueden estar
# guardadas en los favoritos del usuario.
_KIND_ALIASES = {'music': 'audio'}


def playlist_for_kind(kind):
    """playlistid de un `kind`, tolerando el vocabulario de biblioteca."""
    pid = _TYPE_TO_PLAYLISTID.get(_KIND_ALIASES.get(kind, kind))
    if pid is None:
        log.debug(f'playlist_for_kind: {kind!r} no reconocido; usando vídeo')
        return _TYPE_TO_PLAYLISTID['video']
    return pid


def _validate_playlistid(pid):
    """Convierte y valida un playlistid. Lanza ValueError si no es 0/1/2.

    Sin esto un cliente puede enviar `playlistid=99` y, según la build de
    Kodi, esto produce error JSON-RPC (que el endpoint mapea a 500, debería
    ser 400) o comportamiento undefined."""
    try:
        n = int(pid)
    except (TypeError, ValueError):
        raise ValueError(f'playlistid inválido: {pid!r}')
    if n not in _VALID_PLAYLIST_IDS:
        raise ValueError(f'playlistid fuera de rango (0/1/2): {n}')
    return n


def _validate_position(pos, name='position'):
    """Convierte y valida una posición de cola. Lanza ValueError si negativa.

    Posiciones negativas en `Playlist.Swap` se interpretan en algunas builds
    como índice-desde-el-final y mueven el item equivocado en lugar de fallar."""
    try:
        n = int(pos)
    except (TypeError, ValueError):
        raise ValueError(f'{name} inválida: {pos!r}')
    if n < 0:
        raise ValueError(f'{name} negativa: {n}')
    return n


def active_player_id():
    """Devuelve playerid priorizando video > audio > picture, o None."""
    players = _rpc('Player.GetActivePlayers').get('result', [])
    for preferred in ('video', 'audio', 'picture'):
        for p in players:
            if p.get('type') == preferred:
                return p['playerid']
    return None


def _active_player_type():
    """Devuelve el tipo del player activo ('video'/'audio'/'picture') o None."""
    players = _rpc('Player.GetActivePlayers').get('result', [])
    for preferred in ('video', 'audio', 'picture'):
        for p in players:
            if p.get('type') == preferred:
                return p.get('type')
    return None


# --- Watch prompt: detección de streams reproducibles en el móvil ---
#
# `xbmc.Player().getPlayingFile()` devuelve la URL real que Kodi reproduce
# (resuelta por el addon que toque). Si esa URL es HTTP(S) y reproducible
# nativamente en el navegador, el panel ofrece abrirla en el móvil.
#
# Vía rápida: extensión en `_BROWSER_PLAYABLE_EXTS` (no requiere red).
# Vía lenta: HEAD para leer `Content-Type` y matchear contra
# `_BROWSER_PLAYABLE_MIMES`. Cubre URLs sin extensión (Elementum interno
# tipo http://127.0.0.1:65220/abc, CDNs con hash, IPTV /live/canal).
# El HEAD corre en thread daemon para no bloquear la respuesta del
# status; el primer poll para una URL nueva devuelve False, los
# siguientes leen del cache.

_BROWSER_PLAYABLE_EXTS = (
    '.m3u8', '.mp4', '.m4v', '.webm',
    '.mp3', '.m4a', '.aac', '.opus', '.flac', '.wav', '.ogg', '.ogv',
)

_BROWSER_PLAYABLE_MIMES = frozenset((
    'video/mp4', 'video/webm', 'video/ogg',
    'audio/mpeg', 'audio/mp3', 'audio/mp4', 'audio/aac', 'audio/x-aac',
    'audio/wav', 'audio/wave', 'audio/x-wav',
    'audio/flac', 'audio/x-flac',
    'audio/opus', 'audio/ogg', 'audio/webm',
    'application/vnd.apple.mpegurl', 'application/x-mpegurl',
    'application/mpegurl', 'audio/mpegurl', 'audio/x-mpegurl',
))

_url_mime_cache = {}
_url_mime_pending = set()
_url_mime_lock = threading.Lock()
_URL_MIME_CACHE_MAX = 64
_URL_MIME_HEAD_TIMEOUT_S = 2.0


def _head_check_mime(url):
    """HEAD a `url`; cachea True/False según Content-Type. Background.

    Cachea también los fallos: si HEAD revienta (404, timeout, SSL malo,
    server sin soporte HEAD), queda False y el panel no muestra el prompt
    para esta URL hasta que Kodi se reinicie. Asumido por simplicidad;
    refrescar con TTL añade complejidad para un caso marginal.
    """
    result = False
    try:
        req = urllib.request.Request(url, method='HEAD')
        with urllib.request.urlopen(
                req, timeout=_URL_MIME_HEAD_TIMEOUT_S) as resp:
            ct = (resp.headers.get('Content-Type') or '').split(';', 1)[0]
            result = ct.strip().lower() in _BROWSER_PLAYABLE_MIMES
    except (urllib.error.URLError, OSError, ValueError) as e:
        log.sensitive(f'watch-prompt HEAD falló para {url}: {e}')
    finally:
        with _url_mime_lock:
            if (url not in _url_mime_cache
                    and len(_url_mime_cache) >= _URL_MIME_CACHE_MAX):
                _url_mime_cache.pop(next(iter(_url_mime_cache)))
            _url_mime_cache[url] = result
            _url_mime_pending.discard(url)


def _extract_addon_id(file_url):
    """addon_id de 'plugin://addon.id/...' o None."""
    if not file_url or not file_url.startswith('plugin://'):
        return None
    rest = file_url[len('plugin://'):]
    slash = rest.find('/')
    return rest[:slash] if slash != -1 else rest


def _is_browser_playable_url(url):
    """True si la URL es HTTP(S) y reproducible nativo en navegador."""
    if not url:
        return False
    if not (url.startswith('http://') or url.startswith('https://')):
        return False
    path = url.split('?', 1)[0].split('#', 1)[0].lower()
    if path.endswith(_BROWSER_PLAYABLE_EXTS):
        return True
    with _url_mime_lock:
        if url in _url_mime_cache:
            return _url_mime_cache[url]
        if url in _url_mime_pending:
            return False
        _url_mime_pending.add(url)
    try:
        threading.Thread(
            target=_head_check_mime, args=(url,), daemon=True,
        ).start()
    except RuntimeError:
        # OS sin recursos para spawn de thread: limpiar pending para que
        # el siguiente poll pueda reintentar.
        with _url_mime_lock:
            _url_mime_pending.discard(url)
    return False


def _get_playing_file_safe():
    """URL real del stream activo. None si no hay player o falla."""
    try:
        return xbmc.Player().getPlayingFile() or None
    except RuntimeError:
        return None


def _watch_prompt_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('watch_prompt.enabled')
    except RuntimeError:
        return True


def _detect_watch_prompt(item):
    """dict watch_prompt o None. `item` es el resultado de Player.GetItem."""
    if not _watch_prompt_enabled():
        return None
    resolved = _get_playing_file_safe()
    if not _is_browser_playable_url(resolved):
        return None
    return {
        'kind': 'watch',
        'source': _extract_addon_id(item.get('file') or ''),
        'title': _sanitize_notif_text(item.get('title') or item.get('label') or ''),
        'url': resolved,
    }


def status():
    """Estado completo del player. {'playing': False} si nada en reproducción.

    Incluye los campos extendidos (shuffled/repeat/streams/playlistid/...)
    que la barra now-playing del panel necesita. Si una prop no existe para
    el tipo de player actual, se omite del payload.

    El payload añade `type` ('video'/'audio'/'picture') para que el cliente
    pueda ocultar controles que no apliquen al medio activo (botón de
    subtítulos sonando música, controles de seek viendo una foto, etc.).
    Resuelto en la misma llamada a GetActivePlayers que el playerid para
    evitar RPCs duplicados.
    """
    players = _rpc('Player.GetActivePlayers').get('result', []) or []
    active = None
    for preferred in ('video', 'audio', 'picture'):
        for p in players:
            if p.get('type') == preferred:
                active = p
                break
        if active is not None:
            break

    if active is None:
        app = _rpc('Application.GetProperties',
                   {'properties': ['volume', 'muted']}).get('result', {})
        return {
            'playing': False,
            'type': None,
            'volume': app.get('volume', 100),
            'muted': app.get('muted', False),
        }
    pid = active['playerid']
    ptype = active.get('type')

    item = _rpc('Player.GetItem', {
        'playerid': pid,
        'properties': ['title', 'file', 'thumbnail'],
    }).get('result', {}).get('item', {})

    # Set ampliado de propiedades. Kodi ignora las que no aplican al player
    # (p.ej. audiostreams en player de fotos), devolviendo dict parcial.
    props = _rpc('Player.GetProperties', {
        'playerid': pid,
        'properties': [
            'time', 'totaltime', 'percentage', 'speed',
            'shuffled', 'repeat',
            'playlistid', 'position',
            'audiostreams', 'currentaudiostream',
            'subtitles', 'currentsubtitle', 'subtitleenabled',
        ],
    }).get('result', {})

    app = _rpc('Application.GetProperties',
               {'properties': ['volume', 'muted']}).get('result', {})

    watch_prompt = _detect_watch_prompt(item)

    return {
        'playing': True,
        'playerid': pid,
        'type': ptype,
        'title': _sanitize_notif_text(item.get('title') or item.get('label') or ''),
        'file': item.get('file'),
        'thumbnail': item.get('thumbnail'),
        'watch_prompt': watch_prompt,
        'position_s': _time_to_seconds(props.get('time', {})),
        'duration_s': _time_to_seconds(props.get('totaltime', {})),
        'percentage': props.get('percentage', 0),
        'speed': props.get('speed', 1),
        'paused': props.get('speed', 1) == 0,
        'shuffled': props.get('shuffled', False),
        'repeat': props.get('repeat', 'off'),
        'playlistid': props.get('playlistid'),
        'playlistposition': props.get('position', -1),
        'audiostreams': props.get('audiostreams', []),
        'currentaudiostream': props.get('currentaudiostream'),
        'subtitles': props.get('subtitles', []),
        'currentsubtitle': props.get('currentsubtitle'),
        'subtitleenabled': props.get('subtitleenabled', False),
        'volume': app.get('volume', 100),
        'muted': app.get('muted', False),
    }


def play_pause():
    pid = active_player_id()
    if pid is not None:
        _rpc('Player.PlayPause', {'playerid': pid})


def stop():
    pid = active_player_id()
    if pid is not None:
        _rpc('Player.Stop', {'playerid': pid})


def seek_to_seconds(seconds):
    pid = active_player_id()
    if pid is None:
        return
    seconds = max(0, int(seconds))
    _rpc('Player.Seek', {'playerid': pid, 'value': {'seconds': seconds}})


def set_volume(level):
    level = max(0, min(100, int(level)))
    _rpc('Application.SetVolume', {'volume': level})


def _resume_fallback_seek(start_s):
    """Verifica si Kodi efectivamente respetó options.resume y corrige con
    Seek si no. Algunos plugin:// ignoran options.resume y arrancan desde
    el principio. Esto corre en un thread daemon para NO bloquear 2s la
    request HTTP del cliente."""
    xbmc.sleep(2000)
    pid = active_player_id()
    if pid is None:
        return
    props = _rpc('Player.GetProperties',
                 {'playerid': pid, 'properties': ['time']}).get('result', {})
    current_s = _time_to_seconds(props.get('time', {}))
    if abs(current_s - start_s) > 5:
        seek_to_seconds(start_s)


def play_file(path_or_url, start_s=0, title=None, kind='video'):
    """Lanza reproducción con start position atómico vía options.resume.

    Si start_s > 0, Kodi salta DIRECTAMENTE a esa posición sin mostrar el
    principio del vídeo (lo que pasa si haces Player.Open + Seek por separado).

    Si `title` se pasa, usa xbmc.PlayList (con ListItem rico para metadata)
    + Player.Open JSON-RPC con `playlistid`. Esto garantiza que:
    - El player queda en MODO PLAYLIST (Player.playlistid = N): los items
      añadidos vía Playlist.Add encadenan al terminar el actual.
    - Player.GoTo funciona desde el drawer cola para saltar a otro ítem.
    - Evita -32602 (paths con acentos): el file va en ListItem, no en el RPC.
    - Elimina el spinner del skin (ListItem tiene metadata, no hay scrape).

    Insertar al principio (index=0) en vez de clear() preserva los items
    que el usuario ya tuviera en cola: "Reproducir ahora" no destruye lo
    encolado, solo lo aplaza.

    Sin `title` mantenemos el path legacy (Player.Open con file directo)
    por compatibilidad con `/cast` remoto (URLs http/magnet) y tests.

    El fallback de seek corre en un thread daemon; sin esto, cada /cast
    bloqueaba 2 segundos esperando a que Kodi reportase posición, y el
    cliente quedaba "subiendo..." sin razón visible.
    """
    if title:
        import xbmcgui
        li = xbmcgui.ListItem(label=title)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('video')
        except (AttributeError, RuntimeError):
            li.setInfo('video', {'title': title, 'mediatype': 'video'})
        if start_s > 0:
            li.setProperty('StartOffset', str(int(start_s)))
        playlist_id = playlist_for_kind(kind)
        pl = xbmc.PlayList(playlist_id)
        pl.add(path_or_url, li, index=0)
        params = {'item': {'playlistid': playlist_id, 'position': 0}}
        if start_s > 0:
            params['options'] = {'resume': _seconds_to_time(int(start_s))}
        _rpc('Player.Open', params)
        if start_s > 0:
            threading.Thread(
                target=_resume_fallback_seek, args=(int(start_s),),
                name='loiolink-resume-fallback', daemon=True,
            ).start()
        return

    # Path legacy (sin title): Player.Open JSON-RPC.
    params = {'item': {'file': path_or_url}}
    if start_s > 0:
        params['options'] = {'resume': _seconds_to_time(int(start_s))}
    resp = _rpc('Player.Open', params)

    if start_s > 0 and 'error' not in resp:
        threading.Thread(
            target=_resume_fallback_seek, args=(int(start_s),),
            name='loiolink-resume-fallback', daemon=True,
        ).start()


def play_file_with_retry(path_or_url, start_s=0, retries=1,
                         max_wait_s=2.5, poll_interval_s=0.25):
    """Igual que ``play_file`` pero comprueba que Kodi arranca el player,
    y reintenta si no. Pensado para streams IPTV con CDN poco fiables: la
    primera apertura puede fallar silenciosamente (HTTP 4xx tras
    ``Player.Open`` ya aceptado) y un reintento corto suele resolverlo.

    Polling de ``active_player_id()`` cada ``poll_interval_s`` hasta
    ``max_wait_s``. En caso feliz devuelve en cuanto detecta player
    activo; típico <1s. Si expira el wait y quedan ``retries``, vuelve
    a llamar ``play_file()``. Devuelve dict ``{ok, retried, reason}``.

    Detección de fallo basada en ``active_player_id``: si NO había player
    antes de la llamada, basta con que aparezca uno tras ``play_file``.
    Si SÍ había uno (otro vídeo en marcha), no podemos distinguir el
    nuevo del viejo sin más maquinaria, así que skipeamos el retry para
    no mentir al cliente. Es honesto: el camino común del cast IPTV es
    sin reproducción previa.

    El sleep bloquea el thread del HTTPServer atendiendo el request, pero
    cada request va en su propio thread (``ThreadingHTTPServer``); otras
    conexiones no se ven afectadas.
    """
    # Si ya había un player activo, `active_player_id()` siempre devolverá
    # algo (el viejo) aunque el nuevo `Player.Open` haya fallado: cualquier
    # polling daría falso positivo. Skip retry y devuelve sin esperar.
    if active_player_id() is not None:
        play_file(path_or_url, start_s)
        return {'ok': True, 'retried': 0, 'reason': 'player_present'}

    retried = 0
    while True:
        play_file(path_or_url, start_s)
        elapsed = 0.0
        while elapsed < max_wait_s:
            time.sleep(poll_interval_s)
            elapsed += poll_interval_s
            if active_player_id() is not None:
                return {'ok': True, 'retried': retried}
        if retries <= 0:
            return {'ok': False, 'retried': retried, 'reason': 'playback_failed'}
        retries -= 1
        retried += 1


# --- Player extension (next/prev/mute/shuffle/repeat/streams/notify) ---

class NoActivePlayer(RuntimeError):
    """No hay reproducción activa; la acción no tiene contexto."""


def _require_player():
    pid = active_player_id()
    if pid is None:
        raise NoActivePlayer('no hay reproducción activa')
    return pid


def next_track():
    pid = _require_player()
    _rpc_strict('Player.GoTo', {'playerid': pid, 'to': 'next'})


def previous_track():
    pid = _require_player()
    _rpc_strict('Player.GoTo', {'playerid': pid, 'to': 'previous'})


def set_mute(on):
    _rpc_strict('Application.SetMute', {'mute': bool(on)})


def set_shuffle(on):
    pid = _require_player()
    _rpc_strict('Player.SetShuffle', {'playerid': pid, 'shuffle': bool(on)})


def set_repeat(mode):
    if mode not in _REPEAT_MODES:
        raise ValueError(f'repeat inválido: {mode!r}')
    pid = _require_player()
    _rpc_strict('Player.SetRepeat', {'playerid': pid, 'repeat': mode})


def set_audio_stream(value):
    """Cambia stream de audio. `value` puede ser int (índice) o
    'next'/'previous'. Otros strings lanzan ValueError."""
    if isinstance(value, str):
        if value not in _STREAM_KEYWORDS:
            raise ValueError(f'audio stream inválido: {value!r}')
        stream = value
    else:
        stream = int(value)
        if stream < 0:
            raise ValueError(f'índice de audio negativo: {stream}')
    pid = _require_player()
    _rpc_strict('Player.SetAudioStream', {'playerid': pid, 'stream': stream})


def set_subtitle(value):
    """Cambia subtítulo. `value`: int (índice) o 'off'/'on'/'next'/'previous'."""
    if isinstance(value, str):
        if value not in _SUBTITLE_KEYWORDS:
            raise ValueError(f'subtítulo inválido: {value!r}')
        subtitle = value
    else:
        subtitle = int(value)
        if subtitle < 0:
            raise ValueError(f'índice de subtítulo negativo: {subtitle}')
    pid = _require_player()
    _rpc_strict('Player.SetSubtitle', {'playerid': pid, 'subtitle': subtitle})


def show_notification(title, message, level='info', duration_ms=5000):
    """Lanza GUI.ShowNotification en Kodi (popup en la TV).

    Trunca strings a 256 chars (límite razonable; Kodi corta más arriba).
    `level` define el icono nativo: info/warning/error.
    """
    if level not in _NOTIF_LEVELS:
        raise ValueError(f'level inválido: {level!r}')
    title = _sanitize_notif_text(title)[:256] or 'loiolink'
    message = _sanitize_notif_text(message)[:256]
    duration_ms = max(1000, min(60000, int(duration_ms)))
    _rpc_strict('GUI.ShowNotification', {
        'title': title,
        'message': message,
        'image': level,
        'displaytime': duration_ms,
    })


# --- Playlist (cola de reproducción) ---

_QUEUE_PROPS = ['title', 'duration', 'thumbnail', 'art', 'file', 'artist',
                'album', 'showtitle', 'season', 'episode', 'runtime']
_QUEUE_LIMIT = 500


def _queue_version(items):
    """Hash corto del orden actual de la cola, para detectar mutaciones
    concurrentes entre que el cliente GETea y POSTea un swap/remove.

    Sin esto, dos clientes editando la cola a la vez (o un cambio de track
    automático entre GET y POST) hacen que el `swap` mueva el item
    equivocado: las posiciones del cliente ya no corresponden a las del
    servidor. Incluir `file` y `title` cubre el caso normal sin ser tan
    sensible que cualquier metadata refrescada lo invalide."""
    if not items:
        return '0'
    h = hashlib.md5()
    for it in items:
        h.update((it.get('file') or '').encode('utf-8', 'replace'))
        h.update(b'\x00')
        h.update((it.get('title') or '').encode('utf-8', 'replace'))
        h.update(b'\x01')
    return h.hexdigest()[:12]


def _playlist_size(pid):
    """Cuenta los items de una playlist sin pedir propiedades caras."""
    try:
        result = _rpc_strict('Playlist.GetProperties', {
            'playlistid': pid, 'properties': ['size'],
        })
    except RPCError:
        return 0
    if not isinstance(result, dict):
        return 0
    return int(result.get('size', 0) or 0)


def _resolve_playlistid(playlistid):
    """Si `playlistid` is None, usa el del player activo; si tampoco hay
    player, prefiere la playlist NO vacía (video o audio). Si ambas están
    vacías, default a video=1.

    Sin esto, el panel abierto sin player y con música en cola audio
    mostraba 'Sin elementos' (porque defaulteaba a video vacía);
    confundiendo al usuario que oía la música pero no la veía en la cola."""
    if playlistid is not None:
        return int(playlistid)
    ptype = _active_player_type()
    if ptype:
        return _TYPE_TO_PLAYLISTID[ptype]
    # Sin player: probar video primero (caso más común), si vacía probar audio.
    video_pid = _TYPE_TO_PLAYLISTID['video']
    if _playlist_size(video_pid) > 0:
        return video_pid
    audio_pid = _TYPE_TO_PLAYLISTID['audio']
    if _playlist_size(audio_pid) > 0:
        return audio_pid
    return video_pid


def get_queue(playlistid=None):
    """Devuelve {playlistid, position, items, total, truncated}.

    Trunca a `_QUEUE_LIMIT` items para no congelar el panel con audio
    playlists enormes. `position` es la del item actualmente reproduciéndose
    en esa playlist (o -1 si no es la playlist activa)."""
    pid = _resolve_playlistid(playlistid)
    # Posición actual: solo aplica si esta playlist es la del player activo.
    position = -1
    active_pid = active_player_id()
    if active_pid is not None:
        try:
            props = _rpc_strict('Player.GetProperties', {
                'playerid': active_pid,
                'properties': ['playlistid', 'position'],
            }) or {}
            if props.get('playlistid') == pid:
                position = props.get('position', -1)
        except RPCError:
            pass

    try:
        result = _rpc_strict('Playlist.GetItems', {
            'playlistid': pid,
            'properties': _QUEUE_PROPS,
            'limits': {'start': 0, 'end': _QUEUE_LIMIT},
        }) or {}
    except RPCError:
        return {'playlistid': pid, 'position': position,
                'items': [], 'total': 0, 'truncated': False}

    items = result.get('items', []) or []
    total = (result.get('limits') or {}).get('total', len(items))
    # Para archivos uploadeados (no en la biblioteca de Kodi), Playlist.GetItems
    # devuelve thumbnail vacío y art vacío. Construimos image://video@<file>/
    # (o image://music@... para audio); Kodi genera un frame del vídeo o
    # extrae la carátula al servir esa URL vía su webserver. El proxy
    # /artwork ya rutea image:// al webserver de Kodi como último fallback.
    if pid in (0, 1):
        scheme = 'video' if pid == 1 else 'music'
        injected = 0
        for it in items:
            thumb = it.get('thumbnail') or ''
            art = it.get('art') or {}
            art_url = art.get('poster') or art.get('thumb') or art.get('icon') or ''
            file_ = it.get('file') or ''
            log.sensitive(f'get_queue item file={file_[:80]!r} thumbnail={thumb[:120]!r} art_url={art_url[:120]!r}')
            # Kodi a veces devuelve image://<file>/ sin prefijo video@ para
            # archivos no en biblioteca; esa URL falla 404 porque Kodi intenta
            # leer el .mp4 como si fuera imagen. Forzamos video@/music@ para
            # que Kodi extraiga un frame del vídeo / la carátula del audio.
            # safe='@' mantiene la @ literal (Kodi necesita identificarla
            # como separador de scheme); solo se URL-encodea la parte del path.
            needs_inject = (not thumb and not art_url) or (
                file_ and thumb.startswith('image://') and
                f'{scheme}@' not in thumb and f'{scheme}%40' not in thumb
            )
            if needs_inject and file_:
                encoded_path = urllib.parse.quote(file_, safe='')
                it['thumbnail'] = f'image://{scheme}@{encoded_path}/'
                injected += 1
        if items:
            log.info(f'get_queue pid={pid} items={len(items)} thumbnails_inyectados={injected}')
    return {
        'playlistid': pid,
        'position': position,
        'items': items,
        'total': total,
        'truncated': total > _QUEUE_LIMIT,
        'version': _queue_version(items),
    }


class QueueVersionMismatch(Exception):
    """La cola cambió entre que el cliente la consultó y mandó la mutación."""


def _check_queue_version(pid, expected_version):
    """Vuelve a calcular la version actual y la compara. Lanza
    QueueVersionMismatch si difiere; el handler la mapea a 409.
    Solo aplica si el cliente la pasa: callers internos pueden seguir
    omitiendo el parámetro y se acepta sin comprobación."""
    if expected_version is None:
        return
    try:
        result = _rpc_strict('Playlist.GetItems', {
            'playlistid': pid,
            'properties': ['title', 'file'],
            'limits': {'start': 0, 'end': _QUEUE_LIMIT},
        }) or {}
    except RPCError:
        # Si no podemos comprobar, dejamos pasar; el peor caso es el comportamiento previo.
        return
    current = _queue_version(result.get('items', []) or [])
    if current != expected_version:
        raise QueueVersionMismatch(
            f'cola cambió: esperado {expected_version}, actual {current}')


def swap_in_queue(playlistid, pos1, pos2, expected_version=None):
    """Playlist.Swap es atómico pero SOLO intercambia 2 posiciones.

    Para movimientos arbitrarios, el caller hace varios swap consecutivos
    (la UI con botones ↑/↓ siempre mueve 1 paso, así que basta esto).

    `expected_version` (opcional): si el cliente la pasa, verificamos que
    la cola no ha cambiado entre el GET y este POST. Sin esto, dos clientes
    editando en paralelo mueven items equivocados."""
    pid = _validate_playlistid(playlistid)
    p1 = _validate_position(pos1, 'pos1')
    p2 = _validate_position(pos2, 'pos2')
    if p1 == p2:
        return
    _check_queue_version(pid, expected_version)
    _rpc_strict('Playlist.Swap',
                {'playlistid': pid, 'position1': p1, 'position2': p2})


def remove_from_queue(playlistid, position, expected_version=None):
    """Elimina el item en `position`. Rechaza con ValueError si coincide
    con el item actualmente reproduciéndose (Kodi lo permitiría pero el
    UX es desastroso: el player corta y salta a otro track).

    Si el chequeo "es el item actual" falla por RPCError transitorio NO se
    procede silenciosamente; se propaga, evitando que un fallo de consulta
    elimine el item actual sin protección."""
    pid = _validate_playlistid(playlistid)
    pos = _validate_position(position, 'position')
    _check_queue_version(pid, expected_version)
    # Solo chequea si esta es la playlist activa.
    active_pid = active_player_id()
    if active_pid is not None:
        # Si esto falla, NO procedemos: la protección se desactivaría
        # silenciosamente y removeríamos el item actual. Propagar RPCError
        # al caller (handler lo mapea a 500 con mensaje).
        props = _rpc_strict('Player.GetProperties', {
            'playerid': active_pid,
            'properties': ['playlistid', 'position'],
        }) or {}
        if props.get('playlistid') == pid and props.get('position') == pos:
            raise ValueError('no se puede quitar el item en reproducción')
    _rpc_strict('Playlist.Remove', {'playlistid': pid, 'position': pos})


def clear_queue(playlistid):
    pid = _validate_playlistid(playlistid)
    _rpc_strict('Playlist.Clear', {'playlistid': pid})


def goto_position(position, playlistid=1):
    """Player.GoTo a un índice específico de la playlist activa.

    Sin esto, navegar 30 ítems con next/previous es insufrible. La UI del
    drawer cola lo llama al click en el título de cualquier item ("Play
    from here").

    Si no hay player activo, arranca la playlist desde esa posición vía
    Player.Open (caso: cola con items pero nada reproduciendo aún).

    Cota superior: validamos contra el tamaño actual de la playlist activa.
    Sin esto, un click en el último item justo cuando termina el anterior
    (race entre render y click) acaba en error 500 opaco. Devolvemos 400
    con mensaje útil ("posición fuera de rango")."""
    pos = _validate_position(position, 'position')
    try:
        pid = _require_player()
    except NoActivePlayer:
        pid_pl = _validate_playlistid(playlistid)
        _rpc_strict('Player.Open', {'item': {'playlistid': pid_pl, 'position': pos}})
        return
    # Leer la playlist del player activo para validar la cota superior.
    # Si el RPC falla o devuelve algo no dict, dejamos pasar (peor caso:
    # Kodi rechaza con 500, que es lo que ocurría antes). Capturamos
    # ancho (no solo RPCError) para honrar el comentario de "dejar pasar
    # si algo sale mal", pero NO atrapamos ValueError porque ese sí
    # tiene que propagar al handler como 400 (cota superior).
    try:
        props = _rpc_strict('Player.GetProperties', {
            'playerid': pid,
            'properties': ['playlistid'],
        })
        if isinstance(props, dict):
            playlist_id = props.get('playlistid')
            if playlist_id is not None:
                size = _playlist_size(playlist_id)
                if size > 0 and pos >= size:
                    raise ValueError(
                        f'position {pos} fuera de rango '
                        f'(cola tiene {size} items)')
    except ValueError:
        raise  # cota superior: propagar al handler
    except Exception:
        pass  # cualquier otro fallo del check: dejar pasar al GoTo
    # Player.GoTo puede fallar si el track terminó entre el check y aquí
    # (race natural). Traducir RPCError a NoActivePlayer para que el
    # handler responda 409 consistente con el resto de endpoints player-
    # dependent, en lugar de 500 opaco.
    try:
        _rpc_strict('Player.GoTo', {'playerid': pid, 'to': pos})
    except RPCError as e:
        raise NoActivePlayer(
            f'el player desapareció antes del GoTo: {e}')


def add_to_queue(playlistid, item):
    """Añade un item al final de la playlist. `item` es un dict tipo
    {movieid: N}, {episodeid: N}, {songid: N}, {file: path}, etc.

    Cuando `item` trae `file`, se valida contra la whitelist de schemes
    para no exponer rutas locales (`file://`, paths absolutos) ni schemes
    que pueden ejecutar código (`plugin://` arbitrario)."""
    if not isinstance(item, dict) or not item:
        raise ValueError('item debe ser un dict no vacío')
    # Sin esta whitelist {'directory': 'plugin://...'} bypasea el check de
    # 'file' invocando plugins arbitrarios via Playlist.Add.
    allowed = {'movieid', 'episodeid', 'songid', 'albumid', 'artistid', 'file'}
    extra = set(item.keys()) - allowed
    if extra:
        raise ValueError(
            f'claves no permitidas en item: {sorted(extra)}; '
            f'usa una de {sorted(allowed)}'
        )
    if 'file' in item:
        f = (item.get('file') or '').strip()
        # Mismo set que /cast: solo HTTP(S) y magnet. Sin paths locales, sin
        # plugin:// arbitrario, sin smb://, sin file://.
        if not (f.startswith('http://') or f.startswith('https://')
                or f.startswith('magnet:')):
            raise ValueError(
                'file debe ser http(s):// o magnet:; '
                'usa {movieid|episodeid|songid} para items de biblioteca')
    pid = _validate_playlistid(playlistid)
    _rpc_strict('Playlist.Add', {'playlistid': pid, 'item': item})


def add_local_to_queue(playlistid, path):
    """Añade un archivo local al final de la playlist. Bypassa la
    whitelist de schemes de `add_to_queue` porque el path viene de un
    upload del propio addon (trusted), no de input externo.

    Uso interno desde `post_transfer._add_to_queue`. No exponer en API."""
    if not isinstance(path, str) or not path.strip():
        raise ValueError('path debe ser str no vacío')
    pid = _validate_playlistid(playlistid)
    _rpc_strict('Playlist.Add', {'playlistid': pid, 'item': {'file': path}})


# --- Biblioteca (scan / clean) ---

def scan_video_library(path=None):
    params = {}
    if path:
        params['directory'] = path
    _rpc_strict('VideoLibrary.Scan', params or None)


def scan_audio_library(path=None):
    params = {}
    if path:
        params['directory'] = path
    _rpc_strict('AudioLibrary.Scan', params or None)


def clean_video_library():
    _rpc_strict('VideoLibrary.Clean')


def clean_audio_library():
    _rpc_strict('AudioLibrary.Clean')


# --- Mark watched (Video library) ---

_MARK_KINDS = ('movie', 'episode')


def mark_watched(kind, item_id, watched):
    """Marca una película o episodio como visto (playcount=1) o no visto
    (playcount=0) vía VideoLibrary.SetMovieDetails / SetEpisodeDetails.

    Música no soportada en v1. AudioLibrary.SetSongDetails sí acepta
    playcount, pero el caso de uso "marcar canciones como escuchadas" es
    raro y el panel no lo muestra aún."""
    if kind not in _MARK_KINDS:
        raise ValueError(f'kind inválido: {kind!r}')
    try:
        item_id = int(item_id)
    except (TypeError, ValueError):
        raise ValueError(f'id inválido: {item_id!r}')
    if item_id <= 0:
        raise ValueError(f'id debe ser positivo: {item_id}')
    playcount = 1 if watched else 0
    if kind == 'movie':
        _rpc_strict('VideoLibrary.SetMovieDetails',
                    {'movieid': item_id, 'playcount': playcount})
    else:
        _rpc_strict('VideoLibrary.SetEpisodeDetails',
                    {'episodeid': item_id, 'playcount': playcount})


# --- Addons (opt-in en settings) ---

_ADDON_PROPS = ['name', 'enabled', 'version', 'summary',
                'thumbnail', 'author']


def list_addons(content_type=None):
    """Lista todos los addons (incluye deshabilitados). `content_type`
    filtra por tipo Kodi (p.ej. 'xbmc.python.pluginsource')."""
    params = {'properties': _ADDON_PROPS}
    if content_type:
        params['type'] = content_type
    result = _rpc_strict('Addons.GetAddons', params) or {}
    return result.get('addons', []) or []


def set_addon_enabled(addonid, enabled):
    if not addonid or not _ADDONID_RE.match(addonid):
        raise ValueError(f'addonid inválido: {addonid!r}')
    # Solo aplica blocklist al DESHABILITAR; habilitar es siempre seguro
    # (puede recuperar un addon que el usuario tocó por error en Kodi).
    if not enabled:
        for prefix in _ADDON_BLOCKLIST_PREFIXES:
            if addonid == prefix.rstrip('.') or addonid.startswith(prefix):
                raise ValueError(
                    f'no se puede deshabilitar {addonid!r} desde el panel '
                    f'(prefijo crítico {prefix!r})')
    _rpc_strict('Addons.SetAddonEnabled',
                {'addonid': addonid, 'enabled': bool(enabled)})


_BROWSE_PROPS = ['title', 'thumbnail', 'art', 'duration', 'plot',
                 'mimetype', 'file', 'size']
_BROWSE_MEDIA = ('video', 'music', 'pictures', 'files')


def browse(directory, media='files'):
    """Lista el contenido de una carpeta navegable (plugin://, addons://).

    El caller DEBE haber validado que `directory` es un scheme seguro:
    aceptamos sólo plugin:// y addons://, no rutas locales del filesystem.
    """
    if media not in _BROWSE_MEDIA:
        media = 'files'
    # Sin 'sort': Kodi devuelve los items en el orden con que el plugin los
    # añadió con addDirectoryItem (orden natural, como Kodi nativo los pinta).
    result = _rpc_strict('Files.GetDirectory', {
        'directory': directory,
        'media': media,
        'properties': _BROWSE_PROPS,
    }) or {}
    return result.get('files', []) or []


# --- Mando virtual (Input.*) ---

# Whitelist estricta: Input.ExecuteAction acepta cualquier action de Kodi,
# incluyendo cosas peligrosas (`xbmc.shutdown`, `system.exec`). Solo
# permitimos las acciones documentadas de navegación que un usuario espera
# de un mando físico. Cada clave mapea a un método RPC dedicado (mejor que
# ExecuteAction porque son métodos con su propia semántica y validación).
_INPUT_METHODS = {
    'up': 'Input.Up',
    'down': 'Input.Down',
    'left': 'Input.Left',
    'right': 'Input.Right',
    'select': 'Input.Select',
    'back': 'Input.Back',
    'home': 'Input.Home',
    'contextmenu': 'Input.ContextMenu',
    'info': 'Input.Info',
    'osd': 'Input.ShowOSD',
}

# Excepción: 'showsubtitles' requiere Input.ExecuteAction porque NO hay un
# método Input.* dedicado para togglear los subtítulos. Aplicamos un set
# cerrado de actions equivalentes para no caer en el ataque genérico de
# Input.ExecuteAction (que aceptaría 'xbmc.shutdown' y similares).
_INPUT_EXEC_ACTIONS = {
    'showsubtitles': 'showsubtitles',  # toggle on/off del track actual
}
# Sanity check a import time: si en el futuro alguien añade una clave a
# ambos dicts, input_action() preferiría _INPUT_METHODS silenciosamente y
# se perdería la intención de cambiar el behavior. Detectarlo aquí evita
# debugging futuro.
assert not (set(_INPUT_METHODS) & set(_INPUT_EXEC_ACTIONS)), (
    'Clave duplicada entre _INPUT_METHODS y _INPUT_EXEC_ACTIONS: '
    f'{set(_INPUT_METHODS) & set(_INPUT_EXEC_ACTIONS)}'
)


def input_action(action):
    """Mando virtual: dispara una acción de navegación de Kodi.

    Acciones permitidas: up/down/left/right/select/back/home/contextmenu/
    info/osd/showsubtitles. Otras lanzan ValueError. NUNCA pasamos a Kodi
    un action string sin haberlo validado contra una whitelist cerrada,
    ni siquiera para Input.ExecuteAction.
    """
    if action in _INPUT_METHODS:
        _rpc_strict(_INPUT_METHODS[action])
        return
    if action in _INPUT_EXEC_ACTIONS:
        _rpc_strict('Input.ExecuteAction',
                    {'action': _INPUT_EXEC_ACTIONS[action]})
        return
    raise ValueError(f'input action inválida: {action!r}')


# --- Ajuste de delay de audio/subtítulos (Input.ExecuteAction) ---

# Whitelist explícita de actions de delay. Input.ExecuteAction acepta
# cualquier string de la action-list de Kodi (~500 acciones, algunas
# peligrosas). Exponer solo este subconjunto cerrado.
_DELAY_ACTIONS = {
    ('audio', 'plus'):    'audiodelayplus',
    ('audio', 'minus'):   'audiodelayminus',
    ('subtitle', 'plus'): 'subtitledelayplus',
    ('subtitle', 'minus'): 'subtitledelayminus',
}


def adjust_delay(kind, direction):
    """Ajusta el delay de audio o subtítulos en ±50ms (paso configurable
    en Kodi → Ajustes → Reproductor). No hay JSON-RPC directo para leer
    el valor actual; Kodi muestra el OSD con el offset en la TV al recibir
    la action."""
    key = (kind, direction)
    if key not in _DELAY_ACTIONS:
        raise ValueError(f'delay inválido: {kind!r}/{direction!r}')
    _require_player()
    _rpc_strict('Input.ExecuteAction', {'action': _DELAY_ACTIONS[key]})


# --- Power menu (System.Shutdown/Reboot/Suspend/Hibernate, App.Quit) ---

_POWER_METHODS = {
    'shutdown':  'System.Shutdown',
    'reboot':    'System.Reboot',
    'suspend':   'System.Suspend',
    'hibernate': 'System.Hibernate',
    'quit':      'Application.Quit',  # cierra Kodi sin apagar el sistema
}


def power_action(action):
    """Dispara una acción de power de Kodi.

    El gating por setting opt-in vive en el handler HTTP (server_permanent
    `_power_actions_enabled`). Aquí solo validamos el nombre de action."""
    if action not in _POWER_METHODS:
        raise ValueError(f'power action inválida: {action!r}')
    _rpc_strict(_POWER_METHODS[action])


# --- Favourites de Kodi ---
#
# Modelo de seguridad: el cliente NUNCA envía el `fav` completo en el POST
# de ejecución. Solo envía un `index` que el server valida contra la lista
# real de Kodi (re-leída con cada ejecución). Sin esto, un cliente con
# cookie pareada podría fabricar `{"fav":{"type":"media","path":"smb://..."}}`
# y reproducir cualquier path, bypaseando la whitelist de `add_to_queue`.

def _favourite_fingerprint(fav):
    """Hash corto que identifica un favourite por su contenido visible.

    Sirve para detectar que la lista cambió entre que el cliente la
    renderizó y el momento en que pidió ejecutar uno. Combinamos title
    + type + path + window porque son los campos que el usuario reconoce
    o que afectan a dónde apunta el item."""
    parts = [
        (fav.get('title') or ''),
        (fav.get('type') or ''),
        (fav.get('path') or ''),
        (fav.get('window') or ''),
        (fav.get('windowparameter') or ''),
    ]
    h = hashlib.md5('\x00'.join(parts).encode('utf-8', 'replace'))
    return h.hexdigest()[:12]


def list_favourites_with_fingerprint():
    """Devuelve los favoritos con `_fp` añadido. Lee del XML directo
    (no del cache JSON-RPC de Kodi) para que los cambios hechos por
    nosotros se vean inmediatamente en el panel. El cliente devuelve `_fp`
    en run_favourite_by_index para detectar TOCTOU.

    El fingerprint se calcula ANTES del strip de BBCode: dos favoritos
    con distinta decoración pero mismo path apuntan al mismo recurso,
    y queremos detectar la mutación que cambia la decoración (el cliente
    re-render). Si se calculara post-strip, dos favoritos `[B]X[/B]` y
    `X` chocarían y se confundirían silenciosamente.
    """
    from lib.accessibility import strip_bbcode
    favs = _list_favourites_from_xml()
    for fav in favs:
        fav['_fp'] = _favourite_fingerprint(fav)
        if 'title' in fav:
            fav['title'] = strip_bbcode(fav['title'])
    return favs


class FavouriteMismatch(Exception):
    """El favourite en la posición pedida no coincide con el que el
    cliente estaba viendo. La lista cambió entre el GET y el POST."""


def run_favourite_by_index(index, expected_fp=None):
    """Ejecuta el favourite en la posición `index` del XML.

    Modelo de seguridad: el cliente solo envía índice + fingerprint. El
    server re-lee el XML, verifica que el item en esa posición sigue
    siendo el mismo, y lo ejecuta. Sin esto, el cliente podría enviar un
    fav arbitrario con path `smb://attacker/x` y bypasear la whitelist.

    `expected_fp` (opcional): fingerprint del item que el cliente cree
    estar ejecutando. Sin esto, una race entre el GET (lista renderizada)
    y el POST (click) ejecutaría silenciosamente el item EQUIVOCADO si
    la lista cambió (usuario marcó/desmarcó un favorito o nosotros mismos
    editamos desde el panel entre medias). Con el fingerprint comparamos
    contenido; diferente → 409.

    Lee del XML (no del cache JSON-RPC) por consistencia con el panel y
    con _favs_verify; si no, los fingerprints fresh (XML) no coincidirían
    con los stale (JSON-RPC) tras un edit. Ejecuta vía
    xbmc.executebuiltin, exactamente lo que Kodi UI hace al clicar un
    favorito; cubre ActivateWindow, PlayMedia, RunAddon, RunScript,
    ExecuteBuiltin sin necesidad de un dispatcher por tipo."""
    try:
        idx = int(index)
    except (TypeError, ValueError):
        raise ValueError(f'index inválido: {index!r}')
    if idx < 0:
        raise ValueError(f'index negativo: {idx}')
    with _favs_lock:
        root = _load_favourites_xml()
        elems = root.findall('favourite')
        if idx >= len(elems):
            raise ValueError(
                f'index {idx} fuera de rango ({len(elems)} favoritos)')
        elem = elems[idx]
        raw_action = (elem.text or '').strip()
        if expected_fp is not None:
            target = _favourite_from_xml_elem(elem)
            actual_fp = _favourite_fingerprint(target)
            if actual_fp != expected_fp:
                raise FavouriteMismatch(
                    f'favorito en posición {idx} cambió: '
                    f'esperado {expected_fp}, actual {actual_fp}')
    if not raw_action:
        raise ValueError(f'favourite {idx} sin acción ejecutable')
    xbmc.executebuiltin(raw_action)


# --- Helpers de tiempo ---

def _time_to_seconds(t):
    return (t.get('hours', 0) * 3600
            + t.get('minutes', 0) * 60
            + t.get('seconds', 0))


def _seconds_to_time(s):
    return {
        'hours': s // 3600,
        'minutes': (s % 3600) // 60,
        'seconds': s % 60,
        'milliseconds': 0,
    }


# --- Edición de Favourites ---
_favs_lock = threading.Lock()

_FAV_VFS     = 'special://profile/favourites.xml'
_FAV_VFS_TMP = 'special://profile/favourites.xml.tmp'

_RE_ACTIVATE_WINDOW = re.compile(r'^ActivateWindow\((.+)\)\s*$',
                                 re.IGNORECASE | re.DOTALL)
_RE_PLAY_MEDIA      = re.compile(r'^PlayMedia\((.+)\)\s*$',
                                 re.IGNORECASE | re.DOTALL)
_RE_URL_PATH        = re.compile(r'^[a-z][a-z0-9+.-]*://', re.IGNORECASE)
_RE_RUN_ADDON       = re.compile(r'^RunAddon\(\s*([A-Za-z0-9._-]+)\s*[,)]',
                                 re.IGNORECASE)


def _split_kodi_args(s):
    """Splitea args de un builtin Kodi respetando comillas (la coma
    dentro de "..." no separa). Crítico para PlayMedia con URLs que
    llevan ?p=a,b dentro de comillas."""
    args, current, quote = [], [], None
    for c in s:
        if quote:
            current.append(c)
            if c == quote:
                quote = None
        elif c in '"\'':
            quote = c
            current.append(c)
        elif c == ',':
            args.append(''.join(current).strip())
            current = []
        else:
            current.append(c)
    if current:
        args.append(''.join(current).strip())
    return args


def _parse_quoted_arg(s):
    """Quita comillas externas emparejadas: "x" → x; 'x' → x; x → x."""
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in '"\'':
        return s[1:-1]
    return s


def _favourite_from_xml_elem(elem):
    """Convierte un <favourite> XML en el MISMO dict que produce
    Favourites.GetFavourites (title, type, path, window, windowparameter,
    thumbnail). Necesario para que el fingerprint coincida sea cual sea
    el origen de la lectura."""
    action = (elem.text or '').strip()
    fav = {
        'title': elem.get('name') or '',
        'thumbnail': elem.get('thumb') or '',
        'type': 'unknown',
        'path': '',
        'window': '',
        'windowparameter': '',
    }
    m = _RE_ACTIVATE_WINDOW.match(action)
    if m:
        args = _split_kodi_args(m.group(1))
        if args and args[-1].lower() == 'return':
            args = args[:-1]
        if args:
            fav['type'] = 'window'
            fav['window'] = _parse_quoted_arg(args[0])
            if len(args) >= 2:
                fav['windowparameter'] = _parse_quoted_arg(args[1])
        return fav
    m = _RE_PLAY_MEDIA.match(action)
    if m:
        args = _split_kodi_args(m.group(1))
        if args:
            fav['type'] = 'media'
            fav['path'] = _parse_quoted_arg(args[0])
        return fav
    if _RE_URL_PATH.match(action):
        fav['type'] = 'media'
        fav['path'] = action
    return fav


def _load_favourites_xml():
    import xml.etree.ElementTree as ET
    import xbmcvfs
    # kodi#15378 y Kodi recién instalado: el archivo puede no existir
    # hasta que el usuario marca el primer favorito desde la UI.
    if not xbmcvfs.exists(_FAV_VFS):
        # _write_favourites_xml() borra el fichero final ANTES de renombrar el
        # .tmp (xbmcvfs.rename no sobrescribe en todas las builds). Si el
        # proceso murió en esa ventana, el .tmp tiene los favoritos completos
        # y el final no existe: recuperarlo en vez de devolver una lista vacía
        # que la siguiente escritura convertiría en pérdida definitiva. Mismo
        # recovery que history.py y hls_scheduler.
        if xbmcvfs.exists(_FAV_VFS_TMP) and xbmcvfs.rename(_FAV_VFS_TMP, _FAV_VFS):
            log.warning('[player] recuperado favourites.xml desde el .tmp huérfano')
        else:
            return ET.fromstring('<favourites/>')
    path = xbmcvfs.translatePath(_FAV_VFS)
    with open(path, encoding='utf-8') as f:
        data = f.read()
    return ET.fromstring(data)


def _list_favourites_from_xml():
    """Lee favourites.xml directamente y devuelve la lista parseada.

    Bypassea el cache RAM de Kodi: Favourites.GetFavourites (JSON-RPC)
    devuelve datos stale tras nuestras escrituras directas al XML. Sin
    esto, el panel no vería los cambios hasta que Kodi invalide su
    cache (puede tardar o no ocurrir hasta el siguiente arranque)."""
    root = _load_favourites_xml()
    return [_favourite_from_xml_elem(elem) for elem in root.findall('favourite')]


def _write_favourites_xml(root):
    import xml.etree.ElementTree as ET
    import xbmcvfs
    content = ('<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
               + ET.tostring(root, encoding='unicode'))
    f = xbmcvfs.File(_FAV_VFS_TMP, 'wb')
    try:
        ok = f.write(bytearray(content.encode('utf-8')))
        if ok is False:
            raise OSError('xbmcvfs.write devolvió False')
    finally:
        f.close()
    # Borramos el original antes del rename: xbmcvfs.rename NO sobrescribe
    # en todas las builds (Windows/Android no garantizan la semántica de
    # POSIX rename(2)). Si delete falla devolviendo False, abortamos en
    # vez de continuar con un rename que silenciosamente no haría nada.
    if xbmcvfs.exists(_FAV_VFS):
        if not xbmcvfs.delete(_FAV_VFS):
            xbmcvfs.delete(_FAV_VFS_TMP)
            raise OSError(f'no se pudo borrar {_FAV_VFS} antes del rename')
    if not xbmcvfs.rename(_FAV_VFS_TMP, _FAV_VFS):
        # Fallback: algunas builds fallan rename incluso sin destino.
        # Copy + delete del tmp. Si copy también falla → XML perdido,
        # propagar para que el cliente reciba 500 (no toast verde mintiendo).
        if not xbmcvfs.copy(_FAV_VFS_TMP, _FAV_VFS):
            raise OSError(f'rename y copy fallaron para {_FAV_VFS}')
        xbmcvfs.delete(_FAV_VFS_TMP)


def _favs_verify(index, expected_fp):
    """Verifica índice + fp y devuelve (root, elems, idx, elem) listos
    para editar. Debe llamarse dentro de _favs_lock.

    Lee directamente del XML: el fingerprint debe coincidir con el que
    list_favourites_with_fingerprint() devolvió al panel (también XML)."""
    try:
        idx = int(index)
    except (TypeError, ValueError):
        raise ValueError(f'index inválido: {index!r}')
    if idx < 0:
        raise ValueError(f'index negativo: {idx}')
    root = _load_favourites_xml()
    elems = root.findall('favourite')
    if idx >= len(elems):
        raise ValueError(f'index {idx} fuera de rango ({len(elems)} favoritos)')
    if expected_fp is not None:
        target = _favourite_from_xml_elem(elems[idx])
        actual = _favourite_fingerprint(target)
        if actual != expected_fp:
            raise FavouriteMismatch(
                f'favorito {idx} cambió: esperado {expected_fp}, actual {actual}')
    return root, elems, idx, elems[idx]


def delete_favourite(index, expected_fp=None):
    with _favs_lock:
        root, _, _, elem = _favs_verify(index, expected_fp)
        root.remove(elem)
        _write_favourites_xml(root)


def move_favourite(index, direction, expected_fp=None):
    if direction not in ('up', 'down'):
        raise ValueError(f'direction inválida: {direction!r}')
    with _favs_lock:
        root, elems, idx, elem = _favs_verify(index, expected_fp)
        new_idx = idx - 1 if direction == 'up' else idx + 1
        if new_idx < 0:
            raise ValueError('ya está en la primera posición')
        if new_idx >= len(elems):
            raise ValueError('ya está en la última posición')
        root.remove(elem)
        root.insert(new_idx, elem)
        _write_favourites_xml(root)


def move_favourite_to(index, target_index, expected_fp=None):
    """Mueve un favorito a una posición arbitraria (drag-and-drop).

    Contrato: target_index es la posición final de elem en la lista
    resultante (0..N-1, N = total). Se valida contra len(elems) ya con
    elem dentro; tras remove + insert(target_index), elem queda en esa
    posición exacta (insert con idx == N-1 sobre lista de N-1 hace
    append, así que to=N-1 funciona)."""
    try:
        to_int = int(target_index)
    except (TypeError, ValueError):
        raise ValueError(f'target_index inválido: {target_index!r}')
    with _favs_lock:
        root, elems, idx, elem = _favs_verify(index, expected_fp)
        if idx == to_int:
            return
        if not (0 <= to_int < len(elems)):
            raise ValueError(
                f'target_index {to_int} fuera de rango ({len(elems)} favoritos)')
        root.remove(elem)
        root.insert(to_int, elem)
        _write_favourites_xml(root)


def rename_favourite(index, expected_fp=None, new_title=''):
    # Kodi SÍ interpreta BBCode al pintar el nombre en la TV, así que un
    # `[COLOR red][B]...[/B][/COLOR]` es phishing visual, y aquí además queda
    # persistido en favourites.xml en vez de cinco segundos en un toast. El
    # panel ya muestra el nombre actual en plano (kodiLabelToPlain), o sea que
    # guardarlo en plano es lo coherente.
    new_title = _sanitize_persisted_text(new_title)
    if not new_title:
        raise ValueError('nuevo nombre vacío')
    with _favs_lock:
        root, _, _, elem = _favs_verify(index, expected_fp)
        elem.set('name', new_title)
        _write_favourites_xml(root)


def reload_kodi_favourites():
    """Fuerza a Kodi a re-leer favourites.xml desde disco.

    Kodi cachea favourites en RAM (CFavouritesService) y NO tiene file
    watcher: cualquier escritura externa al XML (las nuestras desde el
    panel) no se refleja en la UI nativa de Kodi hasta que algo dispare
    OnSettingsLoaded. El único camino público para forzarlo es recargar
    el perfil actual.

    Efectos secundarios: LoadProfile recarga settings, sources y addons.
    Cierra diálogos. Si hay reproducción activa se interrumpe. Por eso
    se expone como acción explícita en el panel, no se llama auto."""
    profile = xbmc.getInfoLabel('System.ProfileName') or 'Default'
    xbmc.executebuiltin(f'LoadProfile({profile})')


_THUMB_SCHEMES = ('http://', 'https://', 'special://')


def set_favourite_thumb(index, expected_fp=None, new_thumb=''):
    """Cambia la miniatura de un favorito; vacío la quita.

    El valor viene del cliente, al revés que en `add_addon_to_favourites`,
    donde el thumb es el icono del addon y no hay nada que elegir: aquí el
    panel pide literalmente "Nueva URL de imagen", así que aceptarlo ES la
    función. Lo que se rechaza son las dos formas que no sirven para enseñar
    una imagen y sí para otra cosa: una ruta UNC hace que Kodi en Windows
    negocie NTLM contra el host que diga el cliente, y un `file://`, `smb://`
    o `image://` (que envuelve otra URL) convierte el visor de favoritos en
    un lector del disco de la TV. Un path suelto se sigue admitiendo: no
    llega a ningún sitio y ya había favoritos guardados así.
    """
    new_thumb = str(new_thumb).strip()
    if new_thumb.startswith(('\\\\', '//')):
        raise ValueError(f'thumb UNC no permitido: {new_thumb[:80]!r}')
    if '://' in new_thumb and not new_thumb.lower().startswith(_THUMB_SCHEMES):
        raise ValueError(f'esquema de thumb no permitido: {new_thumb[:80]!r}')
    with _favs_lock:
        root, _, _, elem = _favs_verify(index, expected_fp)
        if new_thumb:
            elem.set('thumb', new_thumb)
        else:
            elem.attrib.pop('thumb', None)
        _write_favourites_xml(root)


def list_favourite_addon_ids():
    """Devuelve los addonids presentes en favourites.xml como RunAddon(...)."""
    root = _load_favourites_xml()
    ids = []
    for elem in root.findall('favourite'):
        m = _RE_RUN_ADDON.match((elem.text or '').strip())
        if m:
            ids.append(m.group(1))
    return ids


def add_addon_to_favourites(addonid, name):
    # Validamos formato antes de interpolar en RunAddon(...): sin esto, un
    # addonid con ')' inyectaría builtins extra ("plugin.x) RunPlugin(evil").
    if not addonid or not _ADDONID_RE.match(addonid):
        raise ValueError(f'addonid inválido: {addonid!r}')
    name = _sanitize_persisted_text(name) or addonid
    # Thumb computado server-side: si lo aceptáramos del cliente, podría ser
    # una URL externa que filtra la IP del Kodi al renderizar favoritos.
    thumb = f'special://home/addons/{addonid}/icon.png'
    action = f'RunAddon({addonid})'
    action_lower = action.lower()
    with _favs_lock:
        import xml.etree.ElementTree as ET
        root = _load_favourites_xml()
        for elem in root.findall('favourite'):
            if (elem.text or '').strip().lower() == action_lower:
                return  # ya estaba, no duplicar
        new_elem = ET.SubElement(root, 'favourite')
        new_elem.set('name', name)
        new_elem.set('thumb', thumb)
        new_elem.text = action
        _write_favourites_xml(root)


def remove_addon_from_favourites(addonid):
    if not addonid or not _ADDONID_RE.match(addonid):
        raise ValueError(f'addonid inválido: {addonid!r}')
    action_lower = f'RunAddon({addonid})'.lower()
    with _favs_lock:
        root = _load_favourites_xml()
        to_remove = [e for e in root.findall('favourite')
                     if (e.text or '').strip().lower() == action_lower]
        if not to_remove:
            return
        for elem in to_remove:
            root.remove(elem)
        _write_favourites_xml(root)
