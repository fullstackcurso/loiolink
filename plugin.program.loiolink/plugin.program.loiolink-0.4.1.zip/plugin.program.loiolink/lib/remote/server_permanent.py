"""Server HTTP permanente para control remoto desde móvil.

Vive en background dentro del xbmc.service. Distinto del server efímero
(server.py) que es single-shot para "Recibir texto".

La lista de abajo es un mapa de orientación de los endpoints principales, NO
el contrato completo (faltan familias como /pair, /upload*, /api/backup/*,
/api/hls/*, /api/library/fb/*, sesiones, power y PWA). El contrato al día vive
en tests/API.md y API.txt.

Endpoints:
- GET  /                       → HTML del panel (player + historial + cast).
- GET  /remote/status?since=   → long-polling de estado (hasta 25s).
- GET  /history                → JSON con todas las entries.
- GET  /stream/<id>            → bytes del archivo del historial (Range).
- GET  /stream-page/<id>?start=N → HTML5 player con sync de posición.
- GET  /stream-transcode/<id>  → ffmpeg on-the-fly (sin Range, secuencial).
- GET  /library/               → HTML del panel Biblioteca (tabs).
- GET  /library/stream?path=         → bytes de un archivo de la biblioteca (Range).
- GET  /library/stream-page?path=    → HTML5 player para path de biblioteca.
- GET  /library/stream-transcode?path= → ffmpeg pipe para path de biblioteca.
- GET  /library/download?path=       → descarga directa de UN archivo.
- GET  /library/download-zip?path=   → ZIP streamed de una carpeta.
- GET  /api/library/status     → counts + webserver + sources.
- GET  /api/library/movies|tvshows|episodes|artists|albums|songs → listados.
- GET  /api/library/movie/<id>|tvshow/<id>/seasons → detalles.
- GET  /api/library/sources?media= → sources de Kodi por tipo.
- GET  /api/library/browse?path=   → contenido de directorio.
- GET  /api/library/playable?path= → ¿playable en browser? (heurística + ffprobe).
- GET  /static/<file>          → CSS/JS/HTML del panel Biblioteca.
- GET  /artwork?u=image://...  → proxy al webserver interno de Kodi.
- POST /remote/play_pause      → toggle.
- POST /remote/stop            → stop.
- POST /remote/seek    {s}     → seek a segundo absoluto.
- POST /remote/volume  {v}     → set volume 0..100.
- POST /remote/sync_position   → sync de posición desde el player web.
- POST /history/play    {id}   → reproduce entry en Kodi.
- POST /history/delete  {id}   → borra entry (sin confirm en Kodi).
- POST /cast {url, start_s=0}  → móvil→Kodi: lanza URL con Player.Open.
- POST /api/library/play {path, start_s} → reproduce path validado en Kodi.
- POST /api/library/enable_webserver     → pide activar webserver de Kodi.

Long-polling con hash sobre estado RELEVANTE (no position_s, que cambia
cada segundo y degeneraría el long-poll en polling 1Hz). position_s se
manda siempre con la respuesta.

Lifecycle:
- start() devuelve (server, port) o (None, 0) si todos los puertos del
  rango están ocupados. Arranca un thread daemon con serve_forever.
- stop(server) cierra limpio.
"""
import hashlib
import html
import http.client
import ipaddress
import json
import math
import os as _os
import re
import secrets
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict

import xbmc
import xbmcaddon
import xbmcgui

from lib import log


# Assets estáticos del panel Biblioteca. Whitelist por nombre (sin
# separadores ni '..'); el caller filtra con _SAFE_STATIC_NAME antes de
# leer del disco.
_SAFE_STATIC_NAME = re.compile(r'^[A-Za-z0-9._-]+$')
_ADDONID_RE = re.compile(r'^[A-Za-z0-9._-]+$')

# Browse remoto: solo schemes virtuales de Kodi (plugin://, addons://). NUNCA
# permitimos file://, smb://, /ruta/local: eso expondría el filesystem entero
# del aparato a quien tenga sesión web. plugin:// es código que Kodi ya tiene
# instalado y autorizado a ejecutar, lo demás es trust boundary.
_BROWSE_SCHEME_RE = re.compile(r'^(plugin|addons)://')
# Caracteres prohibidos: control chars (\x00-\x1f, \x7f), comillas, ángulos
# y backslash. Plugins devuelven títulos UTF-8 con tildes/eñes legítimos, así
# que NO usamos whitelist ASCII (rechazaría 'Película' de un plugin español).
_BROWSE_BAD_CHARS_RE = re.compile(r'[\x00-\x1f\x7f<>"\\]')
_BROWSE_MAX_LEN = 2048


def _is_safe_browse_path(path):
    if not path or len(path) > _BROWSE_MAX_LEN:
        return False
    if not _BROWSE_SCHEME_RE.match(path):
        return False
    if _BROWSE_BAD_CHARS_RE.search(path):
        return False
    return True


def _decode_image_url(u):
    """Decodifica image://<urlencoded>/ → la URL/path interna que envuelve.

    Formato Kodi: el contenido interno va urlencoded y termina en '/'.
    Devuelve None si la entrada no es válida.
    """
    if not u or not u.startswith('image://'):
        return None
    inner = u[len('image://'):]
    if inner.endswith('/'):
        inner = inner[:-1]
    if not inner:
        return None
    try:
        return urllib.parse.unquote(inner)
    except Exception as e:
        log.debug(f'_decode_image_url: unquote falló para {inner!r}: {e}')
        return None


def _is_forbidden_ip(ip_str):
    """True si la IP no debe alcanzarse desde el proxy de artwork:
    loopback, rangos privados, link-local (incluye metadata de cloud,
    169.254.x), reservadas, multicast o no especificadas."""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return True
    # IPv6 con IPv4 embebida (::ffff:127.0.0.1): juzgar la IPv4 real.
    mapped = getattr(ip, 'ipv4_mapped', None)
    if mapped is not None:
        ip = mapped
    return (ip.is_private or ip.is_loopback or ip.is_link_local
            or ip.is_reserved or ip.is_multicast or ip.is_unspecified)


def _artwork_url_allowed(url):
    """True si la URL es http(s) y su host resuelve SOLO a IPs públicas.

    Es la guarda anti-SSRF del proxy de artwork: sin ella, un cliente
    autenticado podría usar /artwork?u= para que Kodi alcance servicios
    de la LAN o de loopback. Queda un TOCTOU residual (DNS rebinding
    entre este getaddrinfo y el resolve interno de urllib); mitigarlo
    exigiría pinning de IP y no compensa para servir thumbnails.
    """
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        return False
    if parts.scheme not in ('http', 'https') or not parts.hostname:
        return False
    try:
        port = parts.port or (443 if parts.scheme == 'https' else 80)
    except ValueError:
        return False
    try:
        infos = socket.getaddrinfo(parts.hostname, port,
                                   proto=socket.IPPROTO_TCP)
    except OSError:
        return False
    return bool(infos) and not any(_is_forbidden_ip(i[4][0]) for i in infos)


class _SsrfSafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Revalida cada redirect contra la guarda SSRF: un CDN público podría
    redirigir a una IP interna y saltarse el check inicial."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _artwork_url_allowed(newurl):
            log.security(f'artwork SSRF bloqueado en redirect: {newurl[:120]!r}')
            raise urllib.error.HTTPError(newurl, 403, 'forbidden redirect',
                                         headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _build_artwork_opener():
    """Opener para fetches salientes de artwork: sin proxy de sistema
    (en Windows urllib lee el proxy del registro de IE/Edge y rompe
    cualquier HTTPS con "Tunnel connection failed"), TLS verificado y
    redirects revalidados contra la guarda SSRF."""
    ctx = ssl.create_default_context()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ctx),
        _SsrfSafeRedirectHandler(),
    )


# Ubicaciones special:// que aceptamos servir como imagen pública. Excluimos
# explícitamente userdata/profile/temp/masterprofile/database/thumbnails:
# pueden contener datos privados del usuario o cachés del que no debemos
# confiar el content-type. Las ubicaciones aceptadas son read-only y públicas:
# iconos, fanart, recursos de addons distribuidos por upstream.
_SAFE_SPECIAL_IMG_PREFIXES = (
    'special://home/addons/',
    'special://xbmc/addons/',
    'special://home/media/',
    'special://xbmc/media/',
)


def _is_safe_special_image(vpath):
    if not vpath or not vpath.startswith('special://'):
        return False
    if '..' in vpath:
        return False
    return any(vpath.startswith(p) for p in _SAFE_SPECIAL_IMG_PREFIXES)
_STATIC_MIME = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.ico': 'image/x-icon',
    # PWA: el manifest debe servirse con este content-type específico para
    # que los navegadores lo reconozcan en `<link rel="manifest">`.
    '.json': 'application/manifest+json',
}


# Mapping de prefijos special:// a rutas físicas, resuelto al cargar el módulo
# (desde el thread principal, donde xbmcvfs sí funciona). Las llamadas a
# xbmcvfs.translatePath() desde los worker threads del ThreadingHTTPServer
# fallaban silenciosamente y dejaban todos los iconos en 404.
def _resolve_special_prefixes():
    try:
        import xbmcvfs
    except ImportError:
        return {}
    mapping = {}
    for vpath in _SAFE_SPECIAL_IMG_PREFIXES:
        try:
            d = xbmcvfs.translatePath(vpath)
        except Exception as e:
            log.debug(f'translatePath falló para {vpath!r}: {e}')
            continue
        if d:
            mapping[vpath] = _os.path.normpath(d)
    return mapping


_SPECIAL_PREFIX_MAP = _resolve_special_prefixes()

# Subconjunto solo addons, usado por _handle_addon_icon y _is_safe_local_image
# (favoritos guardan thumbs como rutas absolutas a archivos de addons).
_ADDONS_DIRS = tuple(
    _SPECIAL_PREFIX_MAP[p]
    for p in ('special://home/addons/', 'special://xbmc/addons/')
    if p in _SPECIAL_PREFIX_MAP
)


def _translate_safe_special(vpath):
    """Traduce un special:// path bajo _SAFE_SPECIAL_IMG_PREFIXES a una ruta
    física usando el cache. Devuelve None si el path no está bajo ningún
    prefijo conocido (el caller debe haberlo filtrado con _is_safe_special_image).
    """
    for prefix, base in _SPECIAL_PREFIX_MAP.items():
        if vpath.startswith(prefix):
            rel = vpath[len(prefix):].replace('/', _os.sep)
            return _os.path.join(base, rel)
    return None


def _is_safe_local_image(path):
    """Valida que `path` apunte a un archivo de imagen bajo el directorio
    de addons de Kodi. Bloquea path traversal vía realpath antes de comparar.
    """
    if not path or not _os.path.isabs(path):
        return False
    ext = _os.path.splitext(path)[1].lower()
    ct = _STATIC_MIME.get(ext)
    if not ct or not ct.startswith('image/'):
        return False
    try:
        real = _os.path.realpath(path)
    except (OSError, ValueError):
        return False
    real_norm = _os.path.normcase(real)
    for base in _ADDONS_DIRS:
        base_norm = _os.path.normcase(_os.path.normpath(base))
        if not base_norm.endswith(_os.sep):
            base_norm += _os.sep
        if real_norm == base_norm[:-1] or real_norm.startswith(base_norm):
            return True
    return False


def _static_path(name):
    """Ruta absoluta a un archivo dentro de lib/remote/web_assets/."""
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
    except RuntimeError:
        return None
    return _os.path.join(addon_path, 'lib', 'remote', 'web_assets', name)


_STATIC_REF_RE = re.compile(r'"(/static/([^"?]+\.(?:css|js)))"')


def _panel_rev():
    """mtime de panel.js (o 0). El JS lo compara contra X-Panel-Rev del
    long-poll para detectar que la pestaña abierta tiene código viejo."""
    p = _static_path('panel.js')
    try:
        return int(_os.path.getmtime(p)) if p else 0
    except OSError:
        return 0


def _bust_static_urls(html_text):
    """Reemplaza "/static/X.css" → "/static/X.css?v=<mtime>" en el HTML.

    Patrón "fingerprinted URLs": cuando el contenido del asset cambia, su
    mtime cambia, la URL cambia y el navegador descarga la nueva versión.
    Los hits cacheados anteriores quedan invalidados sin necesidad de
    bump manual de versión ni Ctrl+F5 del usuario.

    Mantenemos Cache-Control: public, max-age=86400 en _handle_static porque
    cada URL es única por mtime; cachear largo es seguro y ahorra requests.
    """
    def repl(m):
        url = m.group(1)
        name = m.group(2)
        path = _static_path(name)
        try:
            mtime = int(_os.path.getmtime(path)) if path else 0
        except OSError:
            mtime = 0
        return f'"{url}?v={mtime}"' if mtime else f'"{url}"'
    return _STATIC_REF_RE.sub(repl, html_text)


_PORT_DEFAULT = 9095
_PORT_RANGE = 10
_LOG_PREFIX = '[loiolink.remote]'

# Hardening en profundidad. nosniff evita que el navegador reinterprete el
# content-type de lo que servimos; SAMEORIGIN bloquea el clickjacking del
# panel desde otro origen (no DENY: el propio panel abre /instructions/ en
# un iframe same-origin).
#
# Van aquí y no dentro de _send porque las respuestas que streamean fichero
# (/stream, /library/stream, las descargas y el pipe de ffmpeg) no pasan por
# _send y son justo las que sirven contenido que subió otra persona.
# IMPORTANTE: nosniff obliga a que _MIME_BY_EXT tenga un tipo real para todo
# lo que is_browser_playable puede declarar reproducible; si falta, el
# navegador ya no puede adivinarlo y deja de reproducirlo.
SECURITY_HEADERS = (
    ('X-Content-Type-Options', 'nosniff'),
    ('X-Frame-Options', 'SAMEORIGIN'),
    ('Referrer-Policy', 'strict-origin-when-cross-origin'),
)

# Tras bindear, esperar este tiempo y volver a hacer self-check. Cubre el caso
# en que un competidor (típicamente script.module.slyguy) arranca poco después
# de nosotros y bindea 127.0.0.1 con SO_REUSEADDR. En el log real observado
# slyguy llegó +68 ms tras loiolink; 1 s da margen de sobra sin alargar el
# startup más de la cuenta.
_HIJACK_DETECT_DELAY_S = 1.0

# Token único por arranque del service. Sirve para que start() verifique tras
# bindear que las respuestas en el puerto son SUYAS y no de otro proceso que
# comparta el socket (ej: script.module.slyguy escucha en 8095 con
# SO_REUSEADDR; por eso el default de loiolink es 9095, no 8095. En Windows el
# SO entrega los paquetes al socket más específico y el "ganador" de
# 127.0.0.1:<port> puede no ser loiolink si hay colisión).
_INSTANCE_NONCE = secrets.token_urlsafe(16)


class _LimitedReader:
    """Limita lecturas de rfile a exactamente limit bytes.

    El rfile del HTTP handler es un socket keep-alive sin EOF implícito:
    tras consumir el body, un read() adicional bloquearía esperando la
    siguiente request. Esta clase devuelve b'' en cuanto se agotan los
    bytes declarados en Content-Length, señalando EOF al parser multipart.
    """
    def __init__(self, rfile, limit):
        self._rfile = rfile
        self._remaining = limit

    def read(self, n=-1):
        if self._remaining <= 0:
            return b''
        if n < 0 or n > self._remaining:
            n = self._remaining
        data = self._rfile.read(n)
        self._remaining -= len(data)
        return data

# Window property que el modal _QRInfoDialog polea para auto-cerrarse
# cuando llega contenido por el panel (upload, text, etc.) y va a
# aparecer un dialog ('¿Reproducir ahora?') que necesita estar visible.
_MODAL_DISMISS_PROP = 'loiolink.modal.dismiss'
_HOME_WINDOW_ID = 10000


def _signal_modal_dismiss():
    """Marca la dismiss-flag para que el modal del panel se aparte.

    Si el modal no está abierto, el setProperty es inocuo: el plugin
    no lo lee y se limpia al volver a abrir el modal (clearProperty
    en __init__). El service y el plugin son procesos distintos pero
    Window(10000) está sincronizada entre ambos.
    """
    try:
        xbmcgui.Window(_HOME_WINDOW_ID).setProperty(_MODAL_DISMISS_PROP, '1')
    except RuntimeError:
        pass

_STATUS_LONGPOLL_S = 25  # < 30 para evitar corte por CGNAT móvil
_STATUS_POLL_INTERVAL_S = 1

# Posición reportada por el player web del móvil, por entry_id. Memoria,
# no persistente; sirve para retomar al cambiar de dispositivo dentro
# de la misma sesión de Kodi.
_SYNC_POSITIONS = {}
_SYNC_LOCK = threading.Lock()
# Tope: el entry_id no se valida contra history, así que un cliente pareado
# podría hacer crecer el dict indefinidamente con /remote/sync_position y
# entry distinto cada vez. Evicción FIFO como _SCAN_RATE_HITS/library_cache.
_SYNC_POSITIONS_MAX = 512

# Cache de status() para evitar saturar JSON-RPC cuando hay varias
# conexiones long-poll. TTL 1s = comportamiento idéntico al polling
# interno actual, pero compartido entre todas las conexiones.
_STATUS_CACHE = {'ts': 0.0, 'value': None}
_STATUS_CACHE_LOCK = threading.Lock()
_STATUS_CACHE_TTL_S = 1.0


# UA Chrome desktop para el "modo IPTV" del cast: muchos servers IPTV
# (RTVE, etc.) rechazan el UA por defecto de FFmpeg de Kodi con 403.
# Idéntico al `_UA` de hls_recorder y al que usa plugin.video.espatv en
# su setting `iptv_anti_errors` (validado contra rtvelivestream.rtve.es).
_IPTV_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/120.0.0.0 Safari/537.36')


def _iptv_wrap_url(url):
    """Inyecta User-Agent Chrome en la URL usando la sintaxis pipe de
    FFmpeg/Kodi (``URL|User-Agent=...``). Si la URL ya tiene ``|`` (el
    usuario ha pegado sus propios headers), la devuelve tal cual:
    respetar la intención del usuario es más importante que homogeneizar.

    No añade Referer: servers IPTV a menudo validan Referer contra su
    origen real y un Referer inventado puede romper streams que sin él
    funcionan. Si en la práctica algún dominio lo exige, se añade una
    tabla por dominio conocido como segundo paso.

    Función pura (sin side effects) para que sea testeable unit.
    """
    if '|' in url:
        return url
    return url + '|User-Agent=' + urllib.parse.quote(_IPTV_UA)


def _invalidate_status_cache():
    """Marca el cache como expirado. La próxima lectura forzará un RPC.

    Lo registramos como invalidador del módulo `notify` para que el
    monitor (que recibe eventos JSON-RPC push) pueda obligar a recalcular
    el status sin esperar a que el TTL caduque.
    """
    with _STATUS_CACHE_LOCK:
        _STATUS_CACHE['ts'] = 0.0


# Wiring del monitor con el cache local. Esta línea ejecuta una sola vez
# al importar el módulo: deja la invalidación lista incluso si el monitor
# aún no se ha instanciado (tests, arranque en frío del addon, etc.).
from lib.remote import notify as _notify
_notify.register_cache_invalidator(_invalidate_status_cache)


def _get_status_cached():
    """Devuelve player.status() cacheado con TTL. Thread-safe.

    Sin esto, 10 conexiones long-poll × 1 RPC/s = 10 ráfagas a JSON-RPC
    interno cada segundo (3 calls por status), saturando dispositivos
    lentos (Fire TV, Shield viejo).
    """
    from lib.remote import player
    now = time.time()
    with _STATUS_CACHE_LOCK:
        if _STATUS_CACHE['value'] is not None and \
                now - _STATUS_CACHE['ts'] < _STATUS_CACHE_TTL_S:
            return _STATUS_CACHE['value']
    # Llamada FUERA del lock para no bloquear otras conexiones esperando.
    # Posible doble-call si dos conexiones ven cache expirado a la vez,
    # pero el coste es bajo y el lock corto es más importante.
    try:
        value = player.status()
    except Exception as e:
        # JSON-RPC transitorio o Kodi cerrando. No propagar al handler (sería
        # 500 al móvil y el long-poll se rompería). Devolver el último valor
        # cacheado marcado stale; si nunca hubo cache, un objeto mínimo.
        log.warning(f'player.status() falló, devolviendo stale: {e}')
        with _STATUS_CACHE_LOCK:
            prev = _STATUS_CACHE['value']
        if prev is not None:
            stale = dict(prev)
            stale['stale'] = True
            return stale
        return {'state': 'unknown', 'error': True}
    with _STATUS_CACHE_LOCK:
        _STATUS_CACHE['ts'] = time.time()
        _STATUS_CACHE['value'] = value
    return value


def _status_with_hls():
    """Igual que `_get_status_cached` pero añade el snapshot de grabaciones
    HLS activas y programadas. NO entra al cache (cambian más rápido que el
    TTL del status); siempre se leen los dicts globales actualizados.

    Devuelve un dict NUEVO para no contaminar el valor cacheado.
    """
    from lib.transfers import hls_recorder, hls_scheduler
    base = _get_status_cached()
    out = dict(base)
    out['hls_recordings'] = hls_recorder.list_active()
    scheduler = hls_scheduler.get_instance()
    out['hls_scheduled'] = scheduler.list_pending() if scheduler else []
    return out


def _parse_position_s(value):
    """Segundo de reproducción validado, o None si el valor no sirve.

    `inf`/`nan` son floats válidos para Python pero al interpolarlos en la
    página del reproductor quedan como `const start = inf;`, que en JS es un
    ReferenceError y tumba el script entero (sin seek, sin manejo de error,
    sin botón de transcodificación). Entran por `?start=` y por POST
    /remote/sync_position, donde además `json.loads` acepta `Infinity`/`NaN`
    por defecto.

    Devuelve None en vez de un default para que el caller decida: al pintar la
    página se cae a 0, pero al guardar una posición un valor inválido debe
    ignorarse, NO machacar con 0 la posición buena que ya había (el player web
    manda `t: null` cuando `currentTime` es NaN, p. ej. antes de loadedmetadata).
    """
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(f) or f < 0:
        return None
    return f


_FILENAME_INVALID_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


# Cache de /api/capabilities. find_ffmpeg() hace stat de varios paths; con
# este TTL evitamos pagarlo cada vez que el panel abre el modal de grabación.
# 60s es suficiente: el usuario que instala FFmpeg en runtime espera unos
# segundos a refrescar la página igualmente.
# Lock indispensable: ThreadingHTTPServer puede entrar dos requests a la vez
# y el tearing entre _CAPS_CACHE y _CAPS_CACHE_AT da resultados inconsistentes.
_CAPS_CACHE = None
_CAPS_CACHE_AT = 0.0
_CAPS_LOCK = threading.Lock()


# Rate limit ligero para /api/cast/scan: máx N scans por IP en una ventana
# deslizante. Sin esto, un cliente autenticado podría hacer 100 POSTs/s,
# cada uno bajando 512 KB de HTML + HEAD requests. Cliente legítimo nunca
# se acerca; cliente buggy/malicioso queda capado en 429.
_SCAN_RATE_WINDOW_S = 60
_SCAN_RATE_LIMIT = 15
_SCAN_RATE_LOCK = threading.Lock()
_SCAN_RATE_HITS: 'Dict[str, deque]' = {}


def _scan_rate_limit_allow(client_ip: str) -> bool:
    """True si la IP aún cabe en la ventana, False si excedió. Atómico."""
    now = time.time()
    cutoff = now - _SCAN_RATE_WINDOW_S
    with _SCAN_RATE_LOCK:
        hits = _SCAN_RATE_HITS.get(client_ip)
        if hits is None:
            hits = deque()
            _SCAN_RATE_HITS[client_ip] = hits
        # Drop timestamps fuera de la ventana.
        while hits and hits[0] < cutoff:
            hits.popleft()
        if len(hits) >= _SCAN_RATE_LIMIT:
            return False
        hits.append(now)
        # GC defensivo: si el dict crece demasiado (muchas IPs distintas),
        # purgar entradas vacías. Coste amortizado bajo.
        if len(_SCAN_RATE_HITS) > 256:
            _SCAN_RATE_HITS.clear()
            _SCAN_RATE_HITS[client_ip] = hits
    return True


def _sanitize_filename(name, max_len=200):
    """Sanitiza un nombre de archivo para uso cross-platform.

    Quita caracteres reservados de Windows (`<>:"/\\|?*`) y controles ASCII,
    rechaza secuencias `..` (defensa en profundidad contra path traversal
    aunque os.path.join no las resuelva con guiones bajos en medio), colapsa
    whitespace y limita longitud. Devuelve `'recording'` si el resultado
    queda vacío o es solo placeholders sin información útil.
    """
    if not name:
        return 'recording'
    s = _FILENAME_INVALID_RE.sub('_', str(name)).strip()
    # Path traversal defense: `..` (con o sin separador alrededor) jamás
    # debe aparecer en el filename. Reemplazo a `_` antes del whitespace
    # collapse para que `..` quede como `_` (no como ` _ `).
    s = s.replace('..', '_')
    s = re.sub(r'\s+', ' ', s)
    # Limpieza final: puntos/underscores/espacios sueltos al final son ruido.
    # Windows además rechaza nombres que acaban en `.` (`foo.` es inválido);
    # `foo...` tras el replace queda `foo._` y este rstrip lo deja en `foo`.
    s = s.rstrip('._ ')
    if len(s) > max_len:
        s = s[:max_len].rstrip('._ ')
    # Si todo fue reemplazado por '_' (input 100% inválido), no aporta info.
    if not s or set(s) <= {'_', ' '}:
        return 'recording'
    return s


def _get_port_start():
    try:
        val = xbmcaddon.Addon().getSetting('remote_port')
        if val:
            p = int(val)
            if 1024 <= p <= 65535:
                return p
    except (ValueError, RuntimeError):
        pass
    return _PORT_DEFAULT


def _interesting_hash(status):
    """Hash sobre campos cuyo cambio justifica notificar al cliente.

    position_s y speed NO entran (avanzan cada segundo y harían polling 1Hz;
    el cliente interpola position localmente). Se mandan siempre en el
    payload para que el cliente reposicione el slider tras un seek manual.

    Sí entran shuffled/repeat/currentaudiostream/currentsubtitle/subtitle-
    enabled/playlistposition para que cambios en esos toggles disparen
    respuesta inmediata del long-poll.
    """
    # Para grabaciones HLS, solo cambio de set o de state dispara wakeup.
    # Bytes no entran: avanza cada segundo, haría polling 1 Hz innecesario.
    # El cliente lee bytes del campo hls_recordings y muestra progreso.
    hls = status.get('hls_recordings') or []
    hls_sig = tuple(
        (r.get('recording_id'), r.get('state'))
        for r in hls
    )
    # Grabaciones programadas: cambios de set (add/cancel/fire) deben despertar
    # paneles abiertos en otros dispositivos para que la lista se refresque sin
    # esperar al timeout del long-poll (~25 s).
    sched = status.get('hls_scheduled') or []
    sched_sig = tuple(
        (s.get('schedule_id'), s.get('start_time'))
        for s in sched
    )
    interesting = {
        'playing': status.get('playing'),
        'title': status.get('title'),
        'file': status.get('file'),
        'duration_s': status.get('duration_s'),
        'paused': status.get('paused'),
        'volume': status.get('volume'),
        'muted': status.get('muted'),
        'shuffled': status.get('shuffled'),
        'repeat': status.get('repeat'),
        'playlistid': status.get('playlistid'),
        'playlistposition': status.get('playlistposition'),
        'currentaudiostream': (status.get('currentaudiostream') or {}).get('index'),
        'currentsubtitle': (status.get('currentsubtitle') or {}).get('index'),
        'subtitleenabled': status.get('subtitleenabled'),
        'hls_signature': hls_sig,
        'hls_scheduled_signature': sched_sig,
    }
    return hashlib.md5(
        json.dumps(interesting, sort_keys=True).encode(),
    ).hexdigest()[:12]


def _addon_mgmt_enabled():
    """¿El usuario activó la gestión remota de addons en settings?

    Default OFF: gestionar addons desde la LAN puede dejar Kodi inutilizable
    si alguien con el QR deshabilita un addon crítico (skin, repo). Opt-in
    explícito desde Ajustes."""
    try:
        return xbmcaddon.Addon().getSettingBool('remote.allow_addon_management')
    except (RuntimeError, AttributeError):
        return False


def _power_actions_enabled():
    """¿El usuario activó las acciones de apagado/reinicio en settings?

    Default OFF: apagar Kodi sin querer desde un dispositivo pareado es
    trivialmente molesto en setups multi-usuario (alguien recargando el
    panel desde el móvil mientras otro está viendo algo). Opt-in explícito."""
    try:
        return xbmcaddon.Addon().getSettingBool('remote.allow_power_actions')
    except (RuntimeError, AttributeError):
        return False


def _auto_inject_enabled():
    """¿El usuario quiere auto-inyección en teclados virtuales abiertos?

    Default ON: comportamiento conveniente que NO destruye nada (el clipboard
    se sigue rellenando siempre, esta es solo una capa adicional). Opt-out
    para quien prefiera el flujo manual de menú contextual "Pegar"."""
    try:
        return xbmcaddon.Addon().getSettingBool('remote.auto_inject_text')
    except (RuntimeError, AttributeError):
        return True


_share_token_path_lock = threading.Lock()
_share_token_path_cache = [None]


def _get_share_token_path():
    with _share_token_path_lock:
        if _share_token_path_cache[0] is None:
            import xbmcvfs
            _share_token_path_cache[0] = xbmcvfs.translatePath(
                'special://profile/addon_data/plugin.program.loiolink/sources_share_token.json'
            )
        return _share_token_path_cache[0]


def _validate_share_token(token):
    if not token:
        return False
    try:
        with open(_get_share_token_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return False
    stored = data.get('token')
    if not isinstance(stored, str):
        return False
    from lib.remote import sessions
    return (sessions.token_eq(stored, token)
            and time.time() < data.get('expires_at', 0))


class _RemoteServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


_HTML_PAIRING_TEMPLATE = """<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>loiolink: conecta este navegador con tu Kodi</title>
<style>body{{font-family:system-ui,-apple-system,sans-serif;background:#0d1117;
color:#c9d1d9;padding:24px 16px;text-align:center;line-height:1.5;margin:0}}
h1{{color:#58a6ff;margin:0 0 8px;font-size:1.35em}}
.box{{max-width:440px;margin:0 auto;background:#161b22;
border:1px solid #30363d;border-radius:12px;padding:24px}}
.lead{{color:#c9d1d9;margin:0 0 18px;font-size:1em}}
.sub{{color:#8b949e;margin:0 0 8px;font-size:.9em;text-align:left}}
ol{{text-align:left;color:#c9d1d9;padding-left:22px;margin:0 0 18px}}
ol li{{margin-bottom:8px}}
ol li b{{color:#fff}}
.hint{{background:#0d2818;border:1px solid #238636;border-radius:8px;
padding:12px 14px;margin:0 0 18px;color:#c9d1d9;font-size:.95em;text-align:left}}
.hint b{{color:#7ee787}}
input[type=text]{{width:100%;padding:14px;font-size:1.8em;text-align:center;
letter-spacing:.4em;font-weight:600;background:#0d1117;color:#c9d1d9;
border:1px solid #30363d;border-radius:8px;box-sizing:border-box;
font-family:ui-monospace,Menlo,Consolas,monospace}}
input[type=text]:focus{{outline:none;border-color:#58a6ff}}
button{{width:100%;margin-top:14px;padding:12px;font-size:1em;
background:#238636;color:#fff;border:0;border-radius:8px;cursor:pointer;
font-weight:600}}
button:hover{{background:#2ea043}}
.err{{background:#3d1416;border:1px solid #f85149;color:#ffa198;
border-radius:8px;padding:10px;margin-bottom:16px;font-size:.9em}}
.note{{color:#8b949e;font-size:.8em;margin:18px 0 0}}
</style></head><body><div class="box">
<h1>Conecta este navegador</h1>
<p class="lead">Este navegador todavía no tiene permiso para usar el panel.</p>
{error_block}
<p class="hint"><b>Lo más rápido:</b> escanear con la cámara del móvil el código QR que ves en Kodi.</p>
<p class="sub">Si no puedes escanear:</p>
<ol>
<li>En Kodi abre <b>loiolink</b> y entra en <b>"Controlar Kodi y mandar contenido desde el móvil"</b>.</li>
<li>Pulsa <b>OK / Enter</b> en el mando para ver un código de 6 cifras.</li>
<li>Escribe ese código aquí debajo.</li>
</ol>
<form method="POST" action="/pair" autocomplete="off">
<input type="text" name="pin" inputmode="numeric" pattern="[0-9]{{6}}"
       maxlength="6" autofocus required placeholder="000000">
<button type="submit">Conectar</button>
</form>
<p class="note">Una vez conectado, este navegador queda autorizado durante un año.</p>
</div></body></html>"""


def _html_pairing(error_msg=''):
    """Renderiza la pantalla de emparejamiento con un posible mensaje de error.

    error_msg se inserta tal cual: el caller solo debe pasar literales
    propios, nunca input del cliente.
    """
    block = f'<div class="err">{error_msg}</div>' if error_msg else ''
    return _HTML_PAIRING_TEMPLATE.format(error_block=block)


class _RemoteHandler(BaseHTTPRequestHandler):
    # Corta threads zombi si un cliente abre conexión y se queda mudo.
    # 5 min es generoso para uploads grandes en LAN; uno legítimo siempre
    # envía algún byte dentro de ese margen.
    timeout = 300

    def log_message(self, fmt, *args):
        pass

    def _send_security_headers(self):
        """Para las respuestas que no pasan por _send (streaming de
        fichero y descargas): mismas cabeceras, una sola fuente."""
        for name, value in SECURITY_HEADERS:
            self.send_header(name, value)

    def _send(self, code, body=b'', content_type='text/plain; charset=utf-8',
              extra_headers=None):
        try:
            self.send_response(code)
            for _hname, _hvalue in SECURITY_HEADERS:
                self.send_header(_hname, _hvalue)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            # Default seguro: no-store. Si el caller pasa su propio Cache-Control
            # en extra_headers (assets versionados, etc.), respetar esa decisión y
            # no emitir el default; los navegadores cogen el primero y duplicar
            # headers contradictorios neutralizaría la intención del caller.
            caller_cc = extra_headers and any(
                k.lower() == 'cache-control' for k, _ in extra_headers)
            if not caller_cc:
                self.send_header('Cache-Control', 'no-store')
            # Si la auth vino por ?t= y todavía no se persistió en cookie, hacerlo
            # ahora (primer acceso desde el QR).
            pending = getattr(self, '_pending_cookie', None)
            if pending:
                self.send_header('Set-Cookie', pending)
                self._pending_cookie = None
            if extra_headers:
                for k, v in extra_headers:
                    self.send_header(k, v)
            self.end_headers()
            if body:
                self.wfile.write(body)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            # Cliente desconectado (cerró tab, perdió wifi, terminó long-poll
            # por timeout, navegó a otro sitio). Es comportamiento normal en
            # endpoints largos como /remote/status?since= o /remote/keyboard-wait
            # que se resuelven a los 25-30 s. Silenciar evita inundar el log con
            # tracebacks completos por cada disconnect.
            pass

    def _check_auth_or_reject(self):
        """Devuelve True si la petición tiene auth válida o el path es read-only.
        Devuelve False si ya se envió respuesta de rechazo (200 con form para
        la raíz, 401 con form para otros paths).
        """
        from lib.remote import auth
        from urllib.parse import urlparse
        path = urlparse(self.path).path
        if auth.is_read_only_path(path):
            return True
        if auth.is_authorized(self):
            # Si el token vino por ?t=, setear cookie para próximos accesos.
            from urllib.parse import parse_qs
            qs_str = self.path.split('?', 1)[1] if '?' in self.path else ''
            qs = parse_qs(qs_str)
            if auth.QUERY_PARAM in qs and qs[auth.QUERY_PARAM][0]:
                self._pending_cookie = auth.first_seen_cookie_header(
                    qs[auth.QUERY_PARAM][0],
                    secure=auth.is_request_https(self),
                )
            return True
        # No autorizado. Si el navegador entra a la raíz, mostramos el form
        # de emparejamiento (200) en vez de un 401 seco: es el camino
        # esperado para un móvil que no tiene cookie todavía.
        sources = []
        if auth.QUERY_PARAM + '=' in (self.path.split('?', 1)[1] if '?' in self.path else ''):
            sources.append('query')
        cookie_header = self.headers.get('Cookie', '')
        if any(c.strip().startswith(auth.COOKIE_NAME + '=')
               for c in cookie_header.split(';')):
            sources.append('cookie')
        if self.headers.get(auth.HEADER_NAME):
            sources.append('header')
        log.security(
            f'auth fallida en {path} (fuentes recibidas: {sources or "ninguna"})'
        )
        body = _html_pairing().encode('utf-8')
        status = 200 if path in ('/', '') else 401
        self._send(status, body, 'text/html; charset=utf-8')
        return False

    def _send_json(self, obj):
        body = json.dumps(obj).encode('utf-8')
        self._send(200, body, 'application/json')

    def do_HEAD(self):
        if not self._check_auth_or_reject():
            return
        # Para soportar HEAD en /stream/<id> y /library/stream: algunos
        # reproductores HTML5 (y descargadores) mandan HEAD antes del GET
        # con Range para conocer Content-Length y Accept-Ranges.
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path.startswith('/stream/'):
            self._handle_stream(parsed.path[len('/stream/'):])
            return
        if parsed.path == '/library/stream':
            self._handle_library_stream(parsed.query)
            return
        self._send(404, b'not found')

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == '/api/sources-export':
            self._handle_sources_export(parsed.query)
            return
        if not self._check_auth_or_reject():
            return
        if path in ('/', ''):
            self._handle_panel_page()
            return
        if path == '/health':
            self._send_json({
                'status': 'ok',
                'service': 'loiolink',
                'nonce': _INSTANCE_NONCE,
            })
            return
        if path == '/version':
            try:
                ver = xbmcaddon.Addon().getAddonInfo('version')
            except RuntimeError:
                ver = 'unknown'
            self._send_json({'version': ver, 'api': 1})
            return
        # PWA: manifest y service worker viven en la raíz (no en /static/)
        # porque la convención PWA y el `scope: '/'` lo esperan ahí.
        # Sin auth (están en `_READ_ONLY_PATHS`): el manifest se pide ANTES
        # de tener cookie y el SW corre en sandbox del browser.
        if path == '/manifest.json':
            self._handle_pwa_asset('manifest.json',
                                   'application/manifest+json')
            return
        if path == '/sw.js':
            # Service-Worker-Allowed permite scope amplio; sin esto algunos
            # browsers limitan el scope al path del SW.
            self._handle_pwa_asset('sw.js',
                                   'application/javascript; charset=utf-8',
                                   extra_headers=[('Service-Worker-Allowed', '/')])
            return
        if path == '/loiolink-ca.crt':
            self._handle_ca_download()
            return
        if path == '/share':
            self._handle_share_target(parsed.query)
            return
        if path == '/remote/status':
            self._handle_status_longpoll(parsed.query)
            return
        if path == '/history':
            self._handle_history_list()
            return
        if path.startswith('/stream-page/'):
            self._handle_stream_page(path[len('/stream-page/'):], parsed.query)
            return
        if path.startswith('/stream-transcode/'):
            self._handle_stream_transcode(path[len('/stream-transcode/'):])
            return
        if path.startswith('/stream/'):
            self._handle_stream(path[len('/stream/'):])
            return
        if path.startswith('/static/'):
            self._handle_static(path[len('/static/'):])
            return
        if path == '/library/' or path == '/library':
            self._handle_library_page()
            return
        if path == '/instructions/' or path == '/instructions':
            self._handle_instructions_page()
            return
        if path == '/library/stream':
            self._handle_library_stream(parsed.query)
            return
        if path == '/library/stream-page':
            self._handle_library_stream_page(parsed.query)
            return
        if path == '/library/stream-transcode':
            self._handle_library_stream_transcode(parsed.query)
            return
        if path == '/library/download':
            self._handle_library_download(parsed.query)
            return
        if path == '/library/download-zip':
            self._handle_library_download_zip(parsed.query)
            return
        if path == '/api/library/fb/fs_browse':
            self._handle_fs_browse(parsed.query)
            return
        if path == '/api/library/fb/trash/list':
            # Cableado aquí para que la papelera muestre la UI desde Fase 5
            # incluso si está vacía (POST /trash/list sería contradictorio).
            self._handle_trash_list()
            return
        if path == '/artwork':
            self._handle_artwork(parsed.query)
            return
        if path.startswith('/api/library/'):
            self._handle_library_api(path[len('/api/library/'):], parsed.query)
            return
        if path == '/remote/playlist':
            self._handle_get_playlist(parsed.query)
            return
        if path == '/remote/addons':
            self._handle_list_addons(parsed.query)
            return
        if path == '/remote/addons/fav-ids':
            self._handle_addon_fav_ids()
            return
        if path == '/remote/power-status':
            # Endpoint probe para que el panel sepa si mostrar los botones
            # de apagado o el mensaje "activa en Ajustes". No expone nada
            # sensible (es un bool del setting opt-in).
            self._send_json({'enabled': _power_actions_enabled()})
            return
        if path == '/remote/favourites':
            self._handle_list_favourites()
            return
        if path.startswith('/remote/addon-icon/'):
            self._handle_addon_icon(path[len('/remote/addon-icon/'):])
            return
        if path == '/remote/browse':
            self._handle_browse(parsed.query)
            return
        if path == '/remote/keyboard-wait':
            self._handle_keyboard_wait(parsed.query)
            return
        if path == '/remote/sessions':
            self._handle_list_sessions()
            return
        if path.startswith('/api/backup/'):
            self._handle_backup_get(path[len('/api/backup/'):], parsed.query)
            return
        if path == '/api/share/qr':
            self._handle_share_qr(parsed.query)
            return
        if path == '/api/hls/list':
            self._handle_hls_list()
            return
        if path == '/api/hls/probe':
            self._handle_hls_probe(parsed.query)
            return
        if path == '/api/capabilities':
            self._handle_capabilities()
            return
        self._send(404, b'not found')

    def _handle_share_qr(self, query):
        import io
        params = urllib.parse.parse_qs(query)
        url = (params.get('url') or [''])[0]
        if not url:
            self._send(400, b'url required', 'text/plain')
            return
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.scheme not in ('http', 'https') or not parsed_url.netloc:
            self._send(400, b'url invalida', 'text/plain')
            return
        try:
            # segno vive en <addon>/lib/segno. Intentamos importar directamente;
            # si no está en sys.modules todavía, añadimos <addon>/lib una sola vez.
            # A partir de ahí queda cacheado y el path insert no se repite.
            try:
                import segno
            except ImportError:
                import os as _os, sys as _sys
                _lib = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
                if _lib not in _sys.path:
                    _sys.path.insert(0, _lib)
                import segno
            qr = segno.make(url, micro=False, error='M')
            with io.BytesIO() as buf:
                qr.save(buf, kind='png', scale=8, dark='#000000', light='#ffffff', border=2)
                self._send(200, buf.getvalue(), 'image/png')
        except Exception as e:
            log.warning(f'_handle_share_qr {type(e).__name__}: {e}')
            self._send(500, b'error generando QR', 'text/plain')

    def _handle_sources_export(self, query):
        params = urllib.parse.parse_qs(query)
        share = (params.get('share') or [''])[0]
        if not _validate_share_token(share):
            self._send(403, b'Token invalido o expirado', 'text/plain')
            return
        from lib import sources as _sources
        items = _sources.list_files_sources()
        payload = {
            'addon': 'plugin.program.loiolink',
            'version': 1,
            'exported_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'sources': items,
        }
        self._send_json(payload)

    def do_POST(self):
        # /pair va antes de la auth: la propia request es el credencial
        # alternativo (PIN) que canjeamos por cookie. Cualquier otro POST
        # sin auth debe seguir rechazándose.
        path_only = self.path.split('?', 1)[0].rstrip('/')
        if path_only == '/pair':
            self._handle_pair()
            return
        if not self._check_auth_or_reject():
            return
        path = path_only

        # /upload es multipart streaming: el body NO se puede leer aquí como
        # JSON o se consume del socket y multipart_stream ve EOF prematuro.
        # Dispatch antes de tocar rfile.
        if path == '/upload':
            self._handle_upload()
            return

        # /upload/chunk es body binario (el chunk del archivo); también
        # NO se puede pre-parsear como JSON. Headers: X-Upload-Session-Id
        # + Content-Range bytes <start>-<end>/<total>.
        if path == '/upload/chunk':
            self._handle_upload_chunk()
            return

        # Endpoints JSON: tope de 1 MB para evitar agotar RAM con un
        # Content-Length absurdo. Los payloads reales son < 1 KB (URLs,
        # texto corto, IDs de historial).
        try:
            length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            length = 0
        if length > 1024 * 1024:
            self._send(413, b'payload too large')
            return
        try:
            body = json.loads(self.rfile.read(length).decode('utf-8')) if length else {}
        except (ValueError, TypeError, UnicodeDecodeError):
            body = {}
        # JSON válido pero no-dict (`[]`, `42`, `"x"`, `null`): los handlers
        # llaman `body.get(...)` y eso crashea con AttributeError. Coercemos
        # a {} antes del dispatch para que el comportamiento sea idéntico al
        # de un body vacío (todos los handlers ya validan required fields).
        if not isinstance(body, dict):
            body = {}

        if path == '/cast':
            self._handle_cast(body)
            return
        if path == '/api/hls/start':
            self._handle_hls_start(body)
            return
        if path == '/api/hls/stop':
            self._handle_hls_stop(body)
            return
        if path == '/api/hls/schedule':
            self._handle_hls_schedule(body)
            return
        if path == '/api/hls/cancel_scheduled':
            self._handle_hls_cancel_scheduled(body)
            return
        if path == '/text':
            self._handle_text(body)
            return
        if path == '/upload/init':
            self._handle_upload_init(body)
            return
        if path == '/upload/status':
            self._handle_upload_status(body)
            return
        if path == '/upload/finalize':
            self._handle_upload_finalize(body)
            return
        if path == '/upload/cancel':
            self._handle_upload_cancel(body)
            return
        if path.startswith('/history/'):
            self._handle_history_action(path[len('/history/'):], body)
            return
        if path == '/api/library/play':
            self._handle_library_play(body)
            return
        if path == '/api/library/enable_webserver':
            self._handle_library_enable_webserver()
            return
        if path == '/api/library/disable_webserver':
            self._handle_library_disable_webserver()
            return
        if path.startswith('/api/library/fb/'):
            self._handle_fb_api(path[len('/api/library/fb/'):], body)
            return
        if path.startswith('/api/backup/'):
            self._handle_backup_post(path[len('/api/backup/'):], body)
            return
        if not path.startswith('/remote/'):
            self._send(404, b'not found')
            return

        from lib.remote import player
        from lib.remote.rpc import RPCError
        action = path[len('/remote/'):]
        try:
            if action == 'play_pause':
                player.play_pause()
            elif action == 'stop':
                player.stop()
            elif action == 'seek':
                player.seek_to_seconds(body.get('s', 0))
            elif action == 'volume':
                player.set_volume(body.get('v', 50))
            elif action == 'next':
                player.next_track()
            elif action == 'previous':
                player.previous_track()
            elif action == 'mute':
                player.set_mute(bool(body.get('on', False)))
            elif action == 'shuffle':
                player.set_shuffle(bool(body.get('on', False)))
            elif action == 'repeat':
                player.set_repeat(body.get('mode', 'off'))
            elif action == 'audio':
                player.set_audio_stream(body.get('index', 0))
            elif action == 'subtitle':
                player.set_subtitle(body.get('index', 'off'))
            elif action == 'playlist/swap':
                player.swap_in_queue(body['playlistid'],
                                     body['pos1'], body['pos2'],
                                     expected_version=body.get('version'))
            elif action == 'playlist/remove':
                player.remove_from_queue(body['playlistid'], body['position'],
                                         expected_version=body.get('version'))
            elif action == 'playlist/clear':
                player.clear_queue(body['playlistid'])
            elif action == 'playlist/add':
                # Añadir un item a la cola desde la biblioteca. player.add_to_queue
                # ya valida el item (whitelist de schemes si trae `file`).
                player.add_to_queue(body['playlistid'], body.get('item') or {})
            elif action == 'playlist/goto':
                # Play from here: salta a la posición N de la cola actual.
                player.goto_position(body['position'],
                                     playlistid=body.get('playlistid', 1))
            elif action == 'library/mark':
                # Marcar peli/episodio como visto/no visto.
                # body = {kind: 'movie'|'episode', id: N, watched: bool}
                player.mark_watched(body.get('kind', ''),
                                    body.get('id'),
                                    bool(body.get('watched', True)))
            elif action == 'favourites/run':
                # Lanzar un favourite. El cliente envía índice + fp
                # (fingerprint del contenido en el momento del render).
                # El server re-lee la lista real de Kodi, verifica que
                # el item en esa posición sigue siendo el mismo y lo
                # ejecuta. Si el fp difiere → 409 (la lista cambió,
                # cliente debe recargar). Nunca aceptamos un objeto fav
                # arbitrario del cliente.
                player.run_favourite_by_index(body.get('index'),
                                              expected_fp=body.get('fp'))
            elif action == 'favourites/delete':
                player.delete_favourite(body.get('index'),
                                        expected_fp=body.get('fp'))
            elif action == 'favourites/move':
                player.move_favourite(body.get('index'),
                                      body.get('direction', ''),
                                      expected_fp=body.get('fp'))
            elif action == 'favourites/move_to':
                # Al arrastrar y soltar, el cliente envía índice origen + posición
                # destino visual (post-remove). Mismo patrón TOCTOU: server
                # re-lee, valida fp, mueve. 409 si fp difiere; 400 si to
                # fuera de rango.
                player.move_favourite_to(body.get('index'),
                                         body.get('to'),
                                         expected_fp=body.get('fp'))
            elif action == 'favourites/rename':
                player.rename_favourite(body.get('index'),
                                        expected_fp=body.get('fp'),
                                        new_title=body.get('title', ''))
            elif action == 'favourites/thumb':
                player.set_favourite_thumb(body.get('index'),
                                           expected_fp=body.get('fp'),
                                           new_thumb=body.get('thumb', ''))
            elif action == 'favourites/reload_kodi':
                # LoadProfile recarga TODO el perfil: parará reproducción
                # y cerrará diálogos. Cliente lo dispara como acción
                # explícita, nunca automática.
                player.reload_kodi_favourites()
            elif action == 'library/scan':
                if body.get('type') == 'audio':
                    player.scan_audio_library(body.get('path'))
                else:
                    player.scan_video_library(body.get('path'))
            elif action == 'library/clean':
                if body.get('type') == 'audio':
                    player.clean_audio_library()
                else:
                    player.clean_video_library()
            elif action == 'notify':
                player.show_notification(
                    body.get('title', 'loiolink'),
                    body.get('message', ''),
                    body.get('level', 'info'),
                    body.get('duration_ms', 5000),
                )
            elif action == 'play_item':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                raw = body.get('file')
                file_ = raw.strip() if isinstance(raw, str) else ''
                if not _is_safe_browse_path(file_):
                    self._send(400, b'unsafe path')
                    return
                player.play_file(file_)
            elif action == 'addons/toggle':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                player.set_addon_enabled(body.get('addonid', ''),
                                         bool(body.get('enabled', True)))
            elif action == 'addons/fav-add':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                player.add_addon_to_favourites(
                    body.get('addonid', ''),
                    body.get('name', ''),
                )
            elif action == 'addons/fav-remove':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                player.remove_addon_from_favourites(body.get('addonid', ''))
            elif action == 'keyboard-send':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                raw = body.get('text', '')
                if not isinstance(raw, str):
                    self._send(400, b'text must be string')
                    return
                if len(raw) > 4096:
                    self._send(400, b'text too long')
                    return
                # send_now no re-chequea is_keyboard_active. El watcher ya
                # detectó que estaba abierto cuando disparó el modal; un
                # re-chequeo aquí mete un race transitorio que devuelve 409
                # falsamente aunque el teclado siga visible.
                from lib.remote import keyboard_input
                ok = keyboard_input.send_now(
                    raw, done=bool(body.get('done', True)))
                if not ok:
                    # Solo llega aquí si Kodi rechaza el RPC o si el mutex
                    # estaba ocupado (otra inyección en vuelo).
                    self._send(503, b'send rejected by kodi')
                    return
            elif action == 'keyboard-cancel':
                if not _addon_mgmt_enabled():
                    self._send(403, b'addon management disabled in settings')
                    return
                from lib.remote import keyboard_input
                keyboard_input.cancel_keyboard()
            elif action == 'sessions/rename':
                from lib.remote import sessions
                sid = body.get('id', '')
                label = body.get('label', '')
                if not isinstance(sid, str) or not isinstance(label, str):
                    self._send(400, b'invalid params')
                    return
                if len(label) > 1024:
                    # Cap defensivo antes de pasar al modelo (que ya trim+cap a 80).
                    self._send(400, b'label too long')
                    return
                ok = sessions.rename(sid, label)
                if not ok:
                    self._send(400, b'rename failed')
                    return
            elif action == 'sessions/revoke':
                from lib.remote import sessions, auth as _auth
                sid = body.get('id', '')
                if not isinstance(sid, str) or not sid:
                    self._send(400, b'missing or invalid id')
                    return
                # Si el usuario revoca SU PROPIA sesión, además le quitamos
                # la cookie al navegador (limpieza ergonómica).
                self_token = _auth.current_request_token(self)
                target = None
                for s in sessions.load_all():
                    if s.get('id') == sid:
                        target = s
                        break
                if target is None:
                    self._send(404, b'session not found')
                    return
                # La sesión existe, así que un False solo puede venir de que
                # no se pudo escribir: decir "no encontrada" despistaría sobre
                # la causa real (y el dispositivo sigue teniendo acceso).
                if not sessions.revoke(sid):
                    self._send(500, b'no se pudo revocar la sesion')
                    return
                self_revoked = bool(
                    target and self_token
                    and target.get('token') == self_token)
                extra = ([('Set-Cookie', _auth.clear_cookie_header())]
                         if self_revoked else None)
                body = json.dumps(
                    {'ok': True, 'self_revoked': self_revoked}
                ).encode('utf-8')
                self._send(200, body, 'application/json',
                           extra_headers=extra)
                return
            elif action == 'sessions/revoke_others':
                from lib.remote import sessions, auth as _auth
                token = _auth.current_request_token(self)
                if not token:
                    self._send(401, b'no current session')
                    return
                if not sessions.revoke_others(token):
                    # No se pudo persistir: los otros dispositivos siguen
                    # dentro. Un 200 haría que el panel dijera "revocadas".
                    self._send(500, b'no se pudieron revocar las sesiones')
                    return
            elif action == 'sync_position':
                entry_id = body.get('entry')
                pos = _parse_position_s(body.get('t', 0))
                # Un `t` inválido se ignora: machacar la posición guardada con
                # 0 sería peor que no actualizarla.
                if entry_id and pos is not None:
                    with _SYNC_LOCK:
                        # Refrescar posición al final (re-inserta para que el
                        # entry activo no sea el candidato a evicción).
                        _SYNC_POSITIONS.pop(entry_id, None)
                        _SYNC_POSITIONS[entry_id] = pos
                        while len(_SYNC_POSITIONS) > _SYNC_POSITIONS_MAX:
                            _SYNC_POSITIONS.pop(next(iter(_SYNC_POSITIONS)))
            elif action.startswith('input/'):
                # Mando virtual: /remote/input/{up,down,...} sin body.
                # La whitelist vive en player.input_action; cualquier action
                # fuera de la lista canónica devuelve 400.
                player.input_action(action[len('input/'):])
            elif action == 'delay':
                # Ajuste de delay de audio/subtítulos en ±50ms.
                # body = {kind: 'audio'|'subtitle', direction: 'plus'|'minus'}
                player.adjust_delay(body.get('kind', ''),
                                    body.get('direction', ''))
            elif action.startswith('power/'):
                # Apagar/reiniciar/suspender Kodi. Setting opt-in obligatorio:
                # alguien con el QR podría apagar Kodi sin querer.
                if not _power_actions_enabled():
                    self._send(403, b'power actions disabled in settings')
                    return
                _power_action_name = action[len('power/'):]
                # Validar antes de responder para que ValueError llegue como
                # 400, no como toast tras un 200 OK falso.
                if _power_action_name not in player._POWER_METHODS:
                    raise ValueError(f'power action inválida: {_power_action_name!r}')
                # Application.Quit / System.Shutdown / Reboot matan el
                # service del addon → si invocáramos en el thread del
                # handler, el cliente vería "connection reset" en vez de
                # nuestro 200 OK. Responder PRIMERO, ejecutar después en
                # un thread daemon con delay pequeño para asegurar flush.
                #
                # `Connection: close` fuerza al cliente HTTP/1.1 con
                # keep-alive a cerrar el socket inmediatamente; sin esto
                # el handler puede quedar dentro de `handle_one_request`
                # cuando Kodi mata el proceso, perdiendo el thread daemon
                # antes de que ejecute (más visible en Windows).
                _body = json.dumps({'ok': True}).encode('utf-8')
                self._send(200, _body, 'application/json',
                           extra_headers=[('Connection', 'close')])
                import threading as _t

                def _delayed_power(name=_power_action_name):
                    try:
                        xbmc.sleep(300)  # tiempo para que el TCP flush
                        player.power_action(name)
                    except Exception as ex:
                        log.warning(f'power_action {name} en thread: {ex}')

                _t.Thread(target=_delayed_power,
                          name='loiolink-power-deferred',
                          daemon=True).start()
                return
            elif action == 'shutdown':
                # Pone el setting a False; el service lo detecta en su poll
                # (<=1s) y para el HTTP. No tocamos el server desde aquí: el
                # service vive en otro hilo y es quien tiene la referencia
                # al socket. Misma decisión que toggle_remote_server.py.
                try:
                    import xbmcaddon
                    xbmcaddon.Addon().setSettingBool(
                        'remote_server_enabled', False)
                except RuntimeError as e:
                    log.warning(f'shutdown: setSettingBool falló: {e}')
                    self._send(500, b'cannot toggle setting')
                    return
                log.info('shutdown solicitado vía /remote/shutdown')
                self._send_json({'ok': True})
                return
            else:
                self._send(404, b'unknown action')
                return
        except player.NoActivePlayer:
            # Mensaje fijo: no hay nada sensible en este caso.
            self._send(409, b'no active player')
            return
        except player.QueueVersionMismatch:
            # La cola cambió entre GET y POST. Cliente debe recargar y
            # reintentar; pero los datos NO son confidenciales.
            self._send(409, b'queue changed')
            return
        except player.FavouriteMismatch:
            # La lista de favoritos cambió entre GET y POST: el item en
            # esa posición ya no es el que el cliente quería ejecutar.
            # Cliente debe recargar la lista y reintentar.
            self._send(409, b'favourites changed')
            return
        except (ValueError, KeyError, TypeError) as e:
            # Log con detalle al server, body genérico al cliente; si en
            # el futuro un ValueError trae paths o tokens en el mensaje, no
            # se filtran al move externo.
            log.info(f'remote action {action}: input inválido: {e}')
            self._send(400, b'invalid input')
            return
        except RPCError as e:
            log.warning(f'remote action {action}: JSON-RPC error: {e}')
            self._send(500, b'kodi error')
            return
        except Exception as e:
            log.warning(f'remote action {action} falló: {e}')
            self._send(500, b'error')
            return
        self._send_json({'ok': True})

    def _handle_pair(self):
        """POST /pair: canjea un PIN de 6 cifras por cookie persistente.

        El form de _HTML_PAIRING envía aquí `pin=NNNNNN` como
        application/x-www-form-urlencoded. Si el PIN está en `pairing` y
        no ha caducado, devolvemos 303 a `/` con Set-Cookie con el token
        real (la misma cookie que se setea cuando el QR trae `?t=`).
        """
        from lib.remote import auth, pairing
        try:
            length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            length = 0
        # El form real envía `pin=NNNNNN` (~10 bytes). Cap a 1 KB blinda este
        # endpoint no-autenticado: sin cap, un cliente puede anunciar
        # Content-Length: 999999999 y bloquear el thread leyendo o agotando
        # memoria.
        if length > 1024:
            self._send(413, b'pair body too large')
            return
        try:
            raw = self.rfile.read(length).decode('utf-8') if length else ''
        except (ValueError, UnicodeDecodeError):
            raw = ''
        fields = urllib.parse.parse_qs(raw)
        pin = (fields.get('pin', [''])[0] or '').strip()

        if not pairing.validate_and_consume(pin):
            # Con la IP: los demás log.security del servidor sí dan contexto, y
            # `sessions.json` ya guarda `last_seen_ip`, así que no es un dato
            # nuevo. Sin ella, una ráfaga de intentos es indistinguible de un
            # usuario tecleando mal.
            log.security(f'pair fallido desde {self.client_address[0]}')
            body = _html_pairing(
                'Código no válido o caducado. Pide uno nuevo en Kodi.',
            ).encode('utf-8')
            # 401 para que clientes automatizados detecten el rechazo, pero
            # el navegador igualmente pinta la página.
            self._send(401, body, 'text/html; charset=utf-8')
            return

        # Nuevo modelo: cada pareo crea una sesión propia con su token. El
        # label se auto-deriva del User-Agent (editable luego desde el panel).
        from lib.remote import sessions
        ua = (self.headers.get('User-Agent') or '').strip()
        try:
            session = sessions.add(ua=ua)
        except OSError as e:
            # El PIN ya se consumió, pero sin sesión persistida la cookie no
            # valdría de nada: mejor un error claro que un pareo fantasma.
            log.error(f'pair: no se pudo guardar la sesión: {e!r}')
            self._send(500, b'no se pudo guardar la sesion; revisa el log')
            return
        secure = auth.is_request_https(self)
        cookie = auth.first_seen_cookie_header(session['token'], secure=secure)
        self._send(
            303, b'', 'text/plain; charset=utf-8',
            extra_headers=[('Location', '/'), ('Set-Cookie', cookie)],
        )
        log.info(f'pair exitoso, sesión nueva creada: {session["label"]!r}')

    def _handle_text(self, body):
        """POST /text del server permanente. Acepta texto o magnet.

        A diferencia del efímero (server.py), aquí el body ya está parseado
        (do_POST lo hace antes del routing). Y no hay single-shot; múltiples
        envíos en serie.
        """
        text = (body.get('text') or '').strip()
        if not text:
            self._send(400, b'empty')
            return
        if len(text) > 100_000:
            self._send(400, b'text too long')
            return


        from lib.remote import elementum
        if elementum.is_magnet(text):
            from lib.transfers import history
            history.queue_event({'kind': 'magnet_received', 'uri': text})
            log.info(f'magnet recibido vía panel (len={len(text)})')
            _signal_modal_dismiss()
            self._send_json({'ok': True, 'kind': 'magnet'})
            return

        # Texto normal → clipboard interno (que propaga al SO via N1).
        # Comportamiento histórico, intacto: el clipboard se rellena SIEMPRE.
        import clipboard as internal_clip
        internal_clip.set(text)
        log.info(f'texto recibido vía panel (len={len(text)})')
        _signal_modal_dismiss()

        # Capa nueva no destructiva: si hay teclado virtual abierto en Kodi y
        # el setting lo permite, también inyectamos vía Input.SendText. El
        # clipboard ya quedó listo arriba; la inyección es side-effect.
        injected = False
        if _auto_inject_enabled():
            from lib.remote import keyboard_input
            try:
                injected = keyboard_input.try_inject(text, wait_appear_ms=1500)
            except Exception as e:
                log.info(f'inject opcional falló: {e}')
        self._send_json({'ok': True, 'kind': 'text', 'injected': injected})

    def _handle_upload(self):
        """POST /upload del server permanente. Reutiliza multipart_stream."""
        ctype = self.headers.get('Content-Type', '')
        if 'multipart/form-data' not in ctype.lower():
            log.warning(f'POST /upload 400: content-type no multipart ({ctype!r})')
            self._send(400, b'expected multipart/form-data')
            return

        # rfile keep-alive sin EOF: hay que limitar lecturas a Content-Length
        # para que multipart_stream no se cuelgue tras consumir el body.
        try:
            body_length = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            body_length = 0
        if body_length <= 0:
            te = self.headers.get('Transfer-Encoding', '')
            log.warning(
                f'POST /upload 400: missing content-length '
                f'(transfer-encoding={te!r})'
            )
            self._send(400, b'missing content-length')
            return

        from lib.transfers import storage
        from lib.remote import library
        raw_dest = self.headers.get('X-Loio-Dest-Dir') or ''
        custom_dest = raw_dest.strip().rstrip('/\\')
        if custom_dest:
            checks = {
                'isabs': _os.path.isabs(custom_dest),
                'not_url': '://' not in custom_dest[:16],
                'isdir': _os.path.isdir(custom_dest),
            }
            checks['under_source'] = (
                all(checks.values())
                and library.is_path_under_source(custom_dest, strict_local=True)
            )
            if all(checks.values()):
                dest_dir = custom_dest
            else:
                log.warning(
                    f'POST /upload: X-Loio-Dest-Dir {custom_dest!r} '
                    f'rechazado ({checks}); fallback a storage.get_dest_dir'
                )
                try:
                    dest_dir = storage.get_dest_dir()
                except storage.StorageError as e:
                    log.warning(f'POST /upload 507: {e}')
                    self._send(507, b'destino no disponible')
                    return
        else:
            try:
                dest_dir = storage.get_dest_dir()
            except storage.StorageError as e:
                log.warning(f'POST /upload 507: {e}')
                self._send(507, b'destino no disponible')
                return

        # Setting `transfer_max_size_gb` compartido con el server efímero.
        try:
            val = xbmcaddon.Addon().getSetting('transfer_max_size_gb')
            max_bytes = int(float(val) * 1024 * 1024 * 1024) if val else 2 * 1024**3
        except (ValueError, RuntimeError):
            max_bytes = 2 * 1024**3

        limited = _LimitedReader(self.rfile, body_length)

        # Modo de upload elegido por el cliente (toggle del panel). Default
        # 'incremental' por compatibilidad con clientes que no envían header.
        # - 'incremental': reproducir desde los primeros bytes (rápido pero
        #                  puede rebufferear si el bitrate > velocidad subida,
        #                  y algunos containers MP4 con moov al final fallan).
        # - 'wait': esperar al archivo completo, reproducir al terminar (fiable).
        # - 'none': no reproducir nunca; el cliente decide qué hacer al recibir
        #           la respuesta (lo usa el explorador de archivos, que muestra
        #           un prompt manual con entry_id + media_kind).
        upload_mode = (
            self.headers.get('X-Loio-Upload-Mode', 'incremental') or ''
        ).strip().lower()
        if upload_mode not in ('incremental', 'wait', 'none'):
            upload_mode = 'incremental'

        # Pre-leer action_in_panel: si está activo, post_transfer NO se ejecuta
        # tras finalizar el upload (defer_to_panel=True, l. ~1349), así que
        # los guards auto_action/always_use_dialog no aplican aquí; son del
        # flujo viejo cuando post_transfer mandaba.
        try:
            _action_in_panel = xbmcaddon.Addon().getSettingBool(
                'transfer.action_in_panel')
        except RuntimeError:
            _action_in_panel = True

        started_playing = False

        def _on_first_write(filepath):
            nonlocal started_playing
            if upload_mode != 'incremental':
                log.info(f'upload incremental: skip, modo={upload_mode}')
                return
            ct = _guess_content_type(filepath)
            if not (ct.startswith('video/') or ct.startswith('audio/')):
                log.info(f'upload incremental: skip, content-type={ct}')
                return
            # MP4 con moov-at-end (layout por defecto de móviles, OBS y
            # muchas descargas): el moov atom vive al final del file. Si
            # arrancamos play_file con upload a medias, Kodi hace seek a
            # un offset que aún no existe y muestra "Error de reproducción".
            # NO redeclarar `import os as _os` aquí: convertiría `_os` en
            # local a TODA _handle_upload y dispararía UnboundLocalError en
            # la validación del path (línea ~1272) antes de llegar al import.
            _ext = _os.path.splitext(filepath)[1].lower()
            if _ext in ('.mp4', '.m4v', '.mov'):
                from lib.transfers import mp4_probe
                _fs = mp4_probe.is_mp4_faststart(filepath)
                if _fs is not True:
                    log.info(
                        f'upload incremental: skip, MP4 no-faststart (fs={_fs})')
                    return
            # Solo aplicamos guards de auto_action/always_use_dialog si el
            # flujo va a post_transfer (action_in_panel=false). Con el modal
            # del panel no hay colisión: el modal pregunta tras finalizar y
            # nuestro started_playing se propaga como already_playing.
            if not _action_in_panel:
                try:
                    addon = xbmcaddon.Addon()
                    if addon.getSettingBool('transfer.always_use_dialog'):
                        log.info('upload incremental: skip, always_use_dialog')
                        return
                    if addon.getSettingBool('transfer.auto_action'):
                        log.info('upload incremental: skip, auto_action ON')
                        return
                except RuntimeError:
                    pass
            # No interrumpir NADA que el usuario tenga abierto.
            from lib.remote.rpc import call as _jsonrpc
            active = _jsonrpc('Player.GetActivePlayers').get('result', [])
            if active:
                log.info(f'upload incremental: skip, player activo={active}')
                return
            from lib.remote import player
            _title = _os.path.splitext(_os.path.basename(filepath))[0]
            log.sensitive(f'upload incremental: play_file {filepath} (title={_title})')
            player.play_file(filepath, title=_title)
            started_playing = True

        try:
            from lib.transfers import classifier, history, multipart_stream
            # Threshold dinámico para "Reproducir mientras sube" (Bloque 6
            # del plan). Para archivos chicos (< 10 MB), 50% del body es
            # razonable. Para archivos grandes (> 100 MB), esperar 25% o
            # 50 MB para evitar rebuffering con conexiones lentas. El
            # usuario puede ajustar el mínimo en settings.
            try:
                _min_mb = int(xbmcaddon.Addon().getSetting(
                    'upload.incremental_threshold_mb') or '5')
            except (ValueError, RuntimeError):
                _min_mb = 5
            _min_bytes = max(1, _min_mb) * 1024 * 1024
            if body_length > 100 * 1024 * 1024:
                _play_after = min(50 * 1024 * 1024, body_length // 4)
            else:
                _play_after = min(_min_bytes, body_length // 2)
            filepath, name, size, truncated = (
                multipart_stream.stream_multipart_to_disk(
                    limited, ctype, dest_dir, max_bytes,
                    on_first_write=_on_first_write,
                    on_first_write_after=_play_after,
                )
            )
        except (ValueError, OSError) as e:
            log.warning(f'POST /upload 400: {e}')
            self._send(400, b'upload failed')
            return

        # Clasificar primero. Si falla, limpiar el archivo huérfano:
        # catch ancho porque cualquier excepción en classify (corrupción,
        # permisos, parser ZIP rompiéndose) dejaría basura en disco sin
        # entrada en historial.
        try:
            kind, addon_id = classifier.classify(filepath)
        except Exception as e:
            log.warning(f'POST /upload 500 classify falló, limpiando: {e}')
            try:
                _os.remove(filepath)
            except OSError:
                pass
            self._send(500, b'internal error')
            return

        # Modo 'wait': reproducir AHORA que el archivo está completo.
        # Va ANTES de history.add para que la entry se grabe con
        # action_taken='played' directamente: operación atómica que
        # evita el TOCTOU race entre HTTP thread y main thread del
        # service (que también escriben a history.json).
        # Mismos guards que en _on_first_write: solo audio/video, sin
        # player activo (no interrumpimos lo que el usuario tiene abierto).
        if (upload_mode == 'wait' and not started_playing
                and kind in ('video', 'audio')):
            from lib.remote.rpc import call as _jsonrpc
            if not _jsonrpc('Player.GetActivePlayers').get('result', []):
                from lib.remote import player
                _title = _os.path.splitext(_os.path.basename(name))[0]
                player.play_file(filepath, title=_title)
                started_playing = True

        # history.add con action_taken según started_playing, atómico.
        try:
            entry = history.add(
                filepath, name, size, kind, addon_id=addon_id,
                truncated=truncated, source='upload',
                action_taken='played' if started_playing else None,
            )
        except Exception as e:
            log.warning(f'POST /upload 500 history.add falló: {e}')
            try:
                _os.remove(filepath)
            except OSError:
                pass
            self._send(500, b'internal error')
            return

        # Flujo UX simplificado: si el setting transfer.action_in_panel está
        # activo (default) Y el archivo es video/audio, SIEMPRE preguntamos
        # en el panel del móvil, sin importar auto_action, sin importar si
        # ya se está reproduciendo. El usuario subió desde el panel, lo
        # natural es preguntar ahí.
        action_in_panel = True   # default si el setting no se puede leer
        try:
            action_in_panel = xbmcaddon.Addon().getSettingBool(
                'transfer.action_in_panel')
        except RuntimeError:
            pass

        defer_to_panel = action_in_panel and kind in ('video', 'audio')

        if not defer_to_panel:
            # Sin banner panel → flujo clásico (auto_action / dialog / notif)
            # decidido por show_post_transfer_dialog en el main thread.
            history.queue_event({
                'kind': 'post_transfer', 'entry': entry,
                'already_played': started_playing,
            })

        log.sensitive(f'upload via panel: {name} ({size}b, kind={kind}, trunc={truncated})')
        _signal_modal_dismiss()
        payload = {
            'ok': True, 'kind': 'upload',
            'media_kind': kind,
            'name': name, 'size': size, 'truncated': truncated,
            'playing': started_playing,
            'entry_id': entry['id'],
        }
        if defer_to_panel:
            payload['actions_available'] = ['play', 'queue', 'both', 'library', 'decline']
            payload['already_playing'] = started_playing
        self._send_json(payload)

    # --- Chunked upload con resume (Bloque 4 del plan) ---
    #
    # Flujo:
    #   1. POST /upload/init   body: {name, size, mime} → {session_id}
    #   2. POST /upload/chunk  headers: X-Upload-Session-Id, Content-Range
    #                          body: bytes (binario) → {received, complete}
    #   3. POST /upload/status body: {session_id} → {received, total, name}
    #   4. POST /upload/finalize body: {session_id}
    #                          → {ok, entry_id, name, kind, actions_available, ...}
    #   5. POST /upload/cancel body: {session_id} → {ok}
    #
    # El cliente persiste {session_id, name, size} en localStorage. Si
    # cierra el panel a mitad y vuelve, llama /upload/status para
    # reanudar desde received_bytes.

    def _handle_upload_init(self, body):
        from lib.transfers import upload_session
        name = (body.get('name') or '').strip()
        size = body.get('size')
        mime = (body.get('mime') or '').strip()
        if not name:
            self._send(400, b'missing name')
            return
        # Aplicar el mismo límite que el upload legacy.
        try:
            val = xbmcaddon.Addon().getSetting('transfer_max_size_gb')
            max_bytes = int(float(val) * 1024 * 1024 * 1024) if val else 2 * 1024**3
        except (ValueError, RuntimeError):
            max_bytes = 2 * 1024**3
        try:
            size_i = int(size)
        except (TypeError, ValueError):
            self._send(400, b'invalid size')
            return
        if size_i <= 0:
            self._send(400, b'size must be positive')
            return
        if size_i > max_bytes:
            self._send(413, b'file too large')
            return
        try:
            sid = upload_session.create_session(name, size_i, mime)
        except (ValueError, OSError) as e:
            log.warning(f'POST /upload/init failed: {e}')
            self._send(400, b'init failed')
            return
        self._send_json({'session_id': sid, 'received': 0, 'total': size_i})

    def _handle_upload_chunk(self):
        """Body binario; no se parsea como JSON."""
        from lib.transfers import upload_session
        session_id = (self.headers.get('X-Upload-Session-Id') or '').strip()
        crange = (self.headers.get('Content-Range') or '').strip()
        if not session_id or not crange:
            self._send(400, b'missing headers')
            return
        m = re.match(r'bytes (\d+)-(\d+)/(\d+)', crange)
        if not m:
            self._send(400, b'invalid Content-Range')
            return
        start, end, total = int(m.group(1)), int(m.group(2)), int(m.group(3))
        expected_len = end - start + 1
        try:
            content_len = int(self.headers.get('Content-Length', 0) or 0)
        except (TypeError, ValueError):
            content_len = 0
        if content_len != expected_len:
            self._send(400, b'Content-Length mismatch with Content-Range')
            return
        # Tope defensivo por chunk: 50 MB. Cliente debería usar 5-10 MB.
        if expected_len > 50 * 1024 * 1024:
            self._send(413, b'chunk too large (max 50 MB)')
            return

        # Timeout en la lectura del chunk: sin esto, un cliente que abre
        # conexión y deja de enviar (red caída, browser colgado) bloquea
        # el thread hasta el timeout HTTP global (300s): DoS efectivo.
        # 120s sin recibir bytes → abortar el chunk con 408.
        _sock = getattr(self.rfile, '_sock', None)
        if _sock is None:
            _raw = getattr(self.rfile, 'raw', None)
            if _raw is not None:
                _sock = getattr(_raw, '_sock', None)
        _old_timeout = None
        if _sock is not None and hasattr(_sock, 'gettimeout'):
            try:
                _old_timeout = _sock.gettimeout()
                _sock.settimeout(120)
            except OSError:
                _sock = None
        try:
            try:
                data = self.rfile.read(content_len)
            except socket.timeout:
                log.warning('upload/chunk: timeout leyendo chunk')
                self._send(408, b'chunk read timeout')
                return
            except (OSError, ValueError) as e:
                log.warning(f'POST /upload/chunk read failed: {e}')
                self._send(400, b'read failed')
                return
        finally:
            if _sock is not None and _old_timeout is not None:
                try:
                    _sock.settimeout(_old_timeout)
                except OSError:
                    pass
        # rfile.read(n) puede devolver MENOS de n bytes si el cliente cierra la
        # conexión a mitad. Sin esta validación, write_chunk recibe un buffer
        # corto, received_bytes avanza con menos de lo declarado y el archivo
        # final queda corrupto sin ningún error visible.
        if len(data) != content_len:
            log.warning(
                f'upload/chunk: short read ({len(data)}/{content_len})',
            )
            self._send(400, b'short read on chunk body')
            return
        try:
            received = upload_session.write_chunk(session_id, start, data)
        except upload_session.SessionNotFound:
            self._send(404, b'session not found')
            return
        except upload_session.InvalidRange as e:
            log.warning(f'POST /upload/chunk invalid range: {e}')
            self._send(409, b'invalid range')
            return
        except (OSError, ValueError) as e:
            log.warning(f'POST /upload/chunk write failed: {e}')
            self._send(500, b'write failed')
            return
        self._send_json({
            'received': received,
            'total': total,
            'complete': received >= total,
        })

    def _handle_upload_status(self, body):
        from lib.transfers import upload_session
        sid = (body.get('session_id') or '').strip()
        if not sid:
            self._send(400, b'missing session_id')
            return
        try:
            st = upload_session.get_status(sid)
        except upload_session.SessionNotFound:
            self._send(404, b'session not found')
            return
        self._send_json({
            'session_id': sid,
            'received': st['received_bytes'],
            'total': st['total_bytes'],
            'name': st['name'],
            'mime': st.get('mime', ''),
            'complete': st['received_bytes'] >= st['total_bytes'],
        })

    def _handle_upload_finalize(self, body):
        from lib.transfers import upload_session, classifier, history
        sid = (body.get('session_id') or '').strip()
        if not sid:
            self._send(400, b'missing session_id')
            return
        try:
            st = upload_session.get_status(sid)
        except upload_session.SessionNotFound:
            self._send(404, b'session not found')
            return
        if st['received_bytes'] < st['total_bytes']:
            self._send(409, b'upload not complete')
            return

        # Resolver dest_dir igual que el upload legacy.
        from lib.transfers import storage
        try:
            dest_dir = storage.get_dest_dir()
        except storage.StorageError as e:
            log.warning(f'POST /upload/finalize 507: {e}')
            self._send(507, b'destino no disponible')
            return
        try:
            filepath, name, size = upload_session.finalize(sid, dest_dir)
        except upload_session.UploadSessionError as e:
            log.warning(f'POST /upload/finalize failed: {e}')
            self._send(409, str(e).encode('utf-8'))
            return
        except OSError as e:
            log.warning(f'POST /upload/finalize OS error: {e}')
            self._send(500, b'finalize failed')
            return

        # Reusa la misma lógica que _handle_upload tras stream completo:
        # classify → play (si action_in_panel + video) → history.add atómica
        # → encolar post_transfer si NO defer_to_panel.
        try:
            kind, addon_id = classifier.classify(filepath)
        except Exception as e:
            # El fichero ya está ensamblado: son los bytes que el usuario subió
            # íntegros. NO lo borramos por un fallo al clasificar; queda en la
            # carpeta de descargas (visible en el explorador) aunque sin entrada
            # de historial. Borrarlo aquí destruía una subida completa.
            log.warning(f'finalize classify falló; fichero conservado en {filepath!r}: {e}')
            self._send(500, b'classify failed')
            return

        try:
            entry = history.add(
                filepath, name, size, kind, addon_id=addon_id,
                truncated=False, source='upload',
                action_taken=None,
            )
        except Exception as e:
            # Igual: el fichero está guardado y clasificado. Si falla el append
            # al historial (p.ej. disco lleno al escribir history.json), borrar
            # el fichero perdería la subida completa. Se conserva en destino.
            log.warning(f'finalize history.add falló; fichero conservado en {filepath!r}: {e}')
            self._send(500, b'history.add failed')
            return

        action_in_panel = True
        try:
            action_in_panel = xbmcaddon.Addon().getSettingBool(
                'transfer.action_in_panel')
        except RuntimeError:
            pass
        defer_to_panel = action_in_panel and kind in ('video', 'audio')

        if not defer_to_panel:
            history.queue_event({
                'kind': 'post_transfer', 'entry': entry,
                'already_played': False,
            })

        log.sensitive(f'upload finalized: {name} ({size}b, kind={kind})')
        _signal_modal_dismiss()
        payload = {
            'ok': True, 'kind': 'upload',
            'media_kind': kind,
            'name': name, 'size': size, 'truncated': False,
            'playing': False, 'entry_id': entry['id'],
        }
        if defer_to_panel:
            payload['actions_available'] = ['play', 'queue', 'both', 'library', 'decline']
            payload['already_playing'] = False
        self._send_json(payload)

    def _handle_upload_cancel(self, body):
        from lib.transfers import upload_session
        sid = (body.get('session_id') or '').strip()
        if not sid:
            self._send(400, b'missing session_id')
            return
        upload_session.cancel(sid)
        self._send_json({'ok': True})

    def _handle_history_list(self):
        from lib.transfers import history
        entries = history.list_all()
        # Filtrar campos pesados / sensibles (path no se manda al móvil).
        slim = []
        for e in entries:
            slim.append({
                'id': e['id'],
                'name': e['name'],
                'size': e['size'],
                'kind': e['kind'],
                'truncated': e.get('truncated', False),
                'created_at': e['created_at'],
                'action_taken': e.get('action_taken'),
            })
        self._send_json({'entries': slim})

    def _handle_history_action(self, action, body):
        entry_id = body.get('id')
        if not entry_id:
            self._send(400, b'missing id')
            return
        from lib.transfers import history
        entry = history.get(entry_id)
        if entry is None:
            self._send(404, b'entry not found')
            return

        # Validar existencia del archivo antes de encolar el evento. Si se
        # borró fuera del panel, Kodi falla silencioso al ejecutar la acción
        # y el usuario ve "no pasa nada". 410 permite al cliente mostrar un
        # toast claro. Excluimos delete: queremos poder limpiar entries con
        # archivo huérfano.
        if action != 'delete':
            path = entry.get('path')
            if not path or not _os.path.exists(path):
                self._send(410, b'archivo no encontrado en disco')
                return

        # Acciones del modal del panel tras upload (Bloques 2/3 del plan):
        # play/queue/library/both/decline encolan post_transfer con
        # forced_action para que show_post_transfer_dialog ejecute sin
        # diálogo modal en TV.
        if action in ('play', 'queue', 'library', 'both', 'decline', 'elementum'):
            history.queue_event({
                'kind': 'post_transfer', 'entry': entry,
                'forced_action': action,
            })
            _signal_modal_dismiss()
            self._send_json({'ok': True})
            return
        if action == 'install':
            # Sin forced_action: show_post_transfer_dialog ejecuta el flujo
            # completo con diálogo de confirmación en Kodi. Validamos kind
            # para no disparar el diálogo de video/audio/image desde este
            # endpoint (sería sorprendente y confuso para el usuario).
            if entry.get('kind') not in ('apk', 'addon_zip', 'repo_zip'):
                self._send(400, b'entry kind not installable')
                return
            # force_confirm: ignora transfer.auto_action; un click explícito
            # en "Instalar/Abrir" desde el panel siempre debe pedir confirmación
            # en Kodi (defensa contra dispositivos pareados comprometidos).
            history.queue_event({
                'kind': 'post_transfer', 'entry': entry,
                'force_confirm': True,
            })
            _signal_modal_dismiss()
            self._send_json({'ok': True})
            return
        if action == 'delete':
            history.delete(entry_id, remove_file=True)
            self._send_json({'ok': True})
            return
        self._send(404, b'unknown action')

    def _handle_cast(self, body):
        url = body.get('url', '').strip()
        if not url:
            self._send(400, b'missing url')
            return

        # ID acestream desnudo (40 hex sin prefijo): normalizar antes del
        # scheme check. Sin scheme `acestream://`, urllib.parse devolvería
        # scheme vacío y el whitelist lo rechazaría aunque sea válido.
        from lib.remote import elementum, player, acestream as ace
        if ace.is_acestream(url):
            url = ace.normalize(url)

        # Whitelist de esquemas. Sin esto, un atacante en la LAN podría
        # forzar Kodi a abrir `file:///etc/passwd`, `smb://attacker/share/x`,
        # `plugin://plugin.video.X/...` con params hostiles, etc.
        scheme = urllib.parse.urlparse(url).scheme.lower()
        if scheme not in ('http', 'https', 'magnet', 'acestream'):
            log.security(f'cast rechazado: scheme={scheme!r} url={url[:80]!r}')
            self._send(400, b'scheme not allowed')
            return

        start_s = body.get('start_s', 0)
        try:
            start_s = max(0, int(start_s))
        except (ValueError, TypeError):
            start_s = 0
        iptv_mode = bool(body.get('iptv_mode', False))
        # Magnet: Elementum primario, Horus como fallback si Elementum no está.
        if elementum.is_magnet(url):
            if elementum.has_magnet_player():
                try:
                    via = elementum.play_magnet_with_fallback(url)
                except (RuntimeError, ValueError) as e:
                    log.warning(f'cast magnet falló: {e!r}')
                    self._send_json({'ok': False, 'error': 'magnet_play_failed'})
                    return
                _signal_modal_dismiss()
                self._send_json({'ok': True, 'via': via})
                return
            from lib.transfers import history
            history.queue_event({'kind': 'magnet_received', 'uri': url})
            _signal_modal_dismiss()
            self._send_json({'ok': True, 'via': 'queued_for_install'})
            return
        if scheme == 'acestream':
            if not ace.is_acestream(url):
                log.security(f'cast acestream malformado: url={url[:80]!r}')
                self._send(400, b'formato acestream invalido: acestream://<40 chars hex>')
                return
            try:
                via = ace.play(url)
                _signal_modal_dismiss()
                self._send_json({'ok': True, 'via': via})
            except RuntimeError:
                self._send(400, b'acestream requiere Plexus (program.plexus) o Horus (script.module.horus)')
            return

        # Resolver URLs de servicios conocidos (YouTube/Twitch/Vimeo/...) a
        # `plugin://`. La URL `plugin://` es construida por nosotros con
        # los IDs extraídos del match: no procede del cliente y por tanto
        # no relaja la whitelist anterior. Si la URL no es de un servicio
        # cubierto, queda intacta y se envía cruda (camino actual).
        from lib.actions import url_resolver
        target = url
        resolved_via = 'player'
        plugin_url = url_resolver.resolve(url)
        if plugin_url:
            target = plugin_url
            resolved_via = 'plugin_resolver'
            log.info(f'cast: resolver -> {plugin_url[:120]!r}')

        # Si el resolver no matcheó y la URL tampoco es un stream directo,
        # probar a escanear la página por vídeos embebidos antes de pasarla
        # cruda al player (que fallaría sin feedback si es un artículo de
        # blog, una página con iframe de YouTube, etc.). Solo http(s); el
        # scheme ya está validado más arriba.
        from lib.remote import stream_player
        if plugin_url is None and not stream_player.is_stream_url(url):
            # video_scanner orquesta html_scanner regex + yt-dlp si está
            # instalado en el sistema. Cubre sitios con JS dinámico (TikTok,
            # redes sociales) que el regex puro no resuelve, y también
            # detecta magnets/.torrent en HTML para casos de indexers.
            #
            # Escanear es lo único de /cast que hace salir peticiones a una
            # URL elegida por el cliente, así que aquí van las dos guardas.
            # SSRF: sin ella, un dispositivo pareado podía hacer que Kodi
            # leyera su propio webserver en 127.0.0.1 (con su JSON-RPC) y le
            # devolviera lo encontrado. is_internal_url NO bloquea rangos
            # privados: escanear el NAS de casa sigue funcionando.
            from lib import url_utils
            if url_utils.is_internal_url(url):
                log.security(f'cast: scanner bloqueado por SSRF: {url[:120]!r}')
                self._send(400, b'host not allowed')
                return
            # Rate limit: cada scan se baja hasta 512 KB. Estaba puesto en
            # /api/cast/scan, que no lo llamaba nadie, mientras esta ruta
            # -la que sí se usa- iba sin tope.
            if not _scan_rate_limit_allow(self.client_address[0]):
                self._send(429, b'rate limit: max scans/min alcanzado')
                return
            from lib.transfers import video_scanner
            try:
                videos = video_scanner.scan_videos(url, timeout=8)
            except Exception as e:
                log.warning(f'cast: scanner falló: {e!r}')
                videos = []
            if videos:
                _signal_modal_dismiss()
                self._send_json({
                    'ok': True,
                    'via': 'scanner',
                    'videos': videos,
                })
                return

        # Modo IPTV antierrores: inyecta UA Chrome (necesario para RTVE
        # y similares que rechazan el UA por defecto de FFmpeg) y
        # reintenta 1 vez si Kodi no arranca el player. Solo aplica si
        # `target` sigue siendo una URL HTTP cruda; si el resolver la
        # convirtió a `plugin://`, ese plugin gestiona sus headers.
        if iptv_mode and plugin_url is None:
            target = _iptv_wrap_url(target)
            result = player.play_file_with_retry(target, start_s=start_s)
            _signal_modal_dismiss()
            self._send_json({
                'ok': bool(result.get('ok')),
                'via': 'iptv',
                'retried': result.get('retried', 0),
                'reason': result.get('reason'),
            })
            return

        player.play_file(target, start_s=start_s)
        _signal_modal_dismiss()
        self._send_json({'ok': True, 'via': resolved_via})

    # HLS recording

    def _handle_hls_start(self, body):
        """Arranca una grabación HLS al disco.

        Body: {url, quality?, max_duration_mins?, filename?, name?,
               compress?, compress_crf?}.
        - `quality`: bandwidth máximo en bps (0 = ilimitado).
        - `max_duration_mins`: 0 = usa setting (default 180).
        - `filename`: nombre sugerido (sanitizado); si no, derivado de la URL.
        - `name`: etiqueta legible para logs y UI.
        - `compress`: si true, FFmpeg reencode a MP4 (libx264 + AAC).
        - `compress_crf`: 18-35, default 26.

        La validación + creación del recorder vive en
        ``lib/transfers/hls_start.py`` para que el scheduler la reutilice.
        Aquí solo mapeamos el resultado a códigos HTTP.
        """
        from lib.transfers import hls_start

        result = hls_start.start_recording_now(body, origin='api')

        # Mapeo a HTTP status preservando el contrato del endpoint original.
        if result.get('ok'):
            self._send_json(result)
            return
        err = result.get('error')
        if err == hls_start.ERROR_DISABLED:
            self._send(403, b'hls recording disabled in settings')
            return
        if err == hls_start.ERROR_MISSING_URL:
            self._send(400, b'missing url')
            return
        if err == hls_start.ERROR_INVALID_SCHEME:
            self._send(400, b'scheme not allowed')
            return
        # Resto de errores (dest_unavailable, low_disk_space, reserve_failed,
        # too_many_active, start_failed) viajan en JSON con ok:false.
        self._send_json(result)

    def _handle_hls_stop(self, body):
        """Detiene una grabación activa por recording_id.

        Devuelve `history_entry_id` y `name` además del estado, para que el
        cliente pueda ofrecer "Reproducir ahora" tras parar sin tener que
        buscar la entrada en el historial por nombre.
        """
        from lib.transfers import hls_recorder
        rid = (body.get('recording_id') or '').strip()
        if not rid:
            self._send(400, b'missing recording_id')
            return
        r = hls_recorder.get(rid)
        if r is None:
            self._send_json({'ok': False, 'error': 'not_found'})
            return
        r.stop()
        # join() levanta RuntimeError si el thread nunca se startó (caso edge:
        # alguien registra recorder y no lo arranca). Defensivo igual que
        # `stop_all`. is_alive() devuelve False para threads no iniciados.
        if r.is_alive():
            r.join(timeout=5)
        self._send_json({
            'ok': True,
            'state': r.state,
            'bytes': r.downloaded_bytes,
            'duration_s': r.elapsed_s(),
            'history_entry_id': r.history_entry_id,
            'name': r.channel_name,
        })

    def _handle_hls_list(self):
        """Lista las grabaciones HLS activas."""
        from lib.transfers import hls_recorder
        self._send_json({'recordings': hls_recorder.list_active()})

    def _handle_hls_probe(self, query):
        """Probe de un master M3U8 para que el panel pre-grabación pueda
        ofrecer un diálogo de selección de calidad. Solo lee el manifest
        (sin tocar el grabador). Devuelve siempre 200 con dict; los
        errores HTTP/red del upstream van en el campo `error` del JSON,
        no como status code del propio endpoint.
        """
        from lib.transfers import hls_recorder
        params = urllib.parse.parse_qs(query)
        url = (params.get('url') or [''])[0].strip()
        if not url:
            self._send(400, b'missing url')
            return
        # Consistencia con validate_url de hls_start: el formato Kodi
        # `URL|Header=Value` no es soportado por probe_master (urllib
        # lo rechaza con InvalidURL y caemos al except como 'network',
        # feedback opaco). Rechazar arriba con error claro.
        if '|' in url:
            self._send(400, 'URL con headers (|) no soportada'.encode('utf-8'))
            return
        scheme = urllib.parse.urlparse(url).scheme.lower()
        if scheme not in ('http', 'https'):
            self._send(400, b'scheme not allowed')
            return
        self._send_json(hls_recorder.probe_master(url, timeout=8.0))

    def _handle_hls_schedule(self, body):
        """Programa una grabación HLS para una hora futura.

        Body: {url, start_time(epoch_s), filename?, name?, compress?,
        compress_crf?, quality?, max_duration_mins?}. Validaciones idénticas
        a /api/hls/start excepto que la grabación no arranca aún; se guarda
        en el scheduler y se dispara cuando `time.time() >= start_time`.

        Si el toggle global está apagado, devolvemos 403 (no programar
        algo que no podrá arrancar).
        """
        from lib.transfers import hls_scheduler, hls_start
        # Toggle global compartido con /api/hls/start.
        try:
            enabled = xbmcaddon.Addon().getSettingBool('transfer.hls.enabled')
        except (TypeError, RuntimeError):
            enabled = True
        if not enabled:
            self._send(403, b'hls recording disabled in settings')
            return

        scheduler = hls_scheduler.get_instance()
        if scheduler is None:
            self._send_json({'ok': False, 'error': 'scheduler_unavailable'})
            return

        ok, err, sch = scheduler.add(body or {})
        if not ok:
            if err == hls_start.ERROR_MISSING_URL:
                self._send(400, 'falta la URL'.encode('utf-8'))
                return
            if err == hls_start.ERROR_INVALID_SCHEME:
                self._send(400, 'URL inválida'.encode('utf-8'))
                return
            if err == 'invalid_time':
                self._send(400, 'la hora debe estar en el futuro'.encode('utf-8'))
                return
            if err == 'horizon_exceeded':
                self._send(400, 'hora demasiado lejana (máx 30 días)'.encode('utf-8'))
                return
            if err == 'too_many_pending':
                # 429 Too Many Requests, semánticamente correcto para cap
                # de cantidad. El panel.js distingue por status code.
                self._send(429, 'demasiadas grabaciones programadas (máx 100)'.encode('utf-8'))
                return
            if err == 'persist_failed':
                self._send(500, 'no se pudo guardar la programación'.encode('utf-8'))
                return
            # Otros errores defensivos: 200 con ok:false para extensibilidad
            # futura (el panel mostrará el `error` literal en el toast).
            self._send_json({'ok': False, 'error': err})
            return
        self._send_json({
            'ok': True,
            'schedule_id': sch['schedule_id'],
            'start_time': sch['start_time'],
        })

    def _handle_hls_cancel_scheduled(self, body):
        """Cancela una grabación programada por schedule_id."""
        from lib.transfers import hls_scheduler
        sid = (body.get('schedule_id') or '').strip()
        if not sid:
            self._send(400, 'falta schedule_id'.encode('utf-8'))
            return
        scheduler = hls_scheduler.get_instance()
        if scheduler is None:
            self._send_json({'ok': False, 'error': 'scheduler_unavailable'})
            return
        ok = scheduler.cancel(sid)
        if not ok:
            self._send_json({'ok': False, 'error': 'not_found'})
            return
        self._send_json({'ok': True})

    def _handle_capabilities(self):
        """Devuelve las capabilities runtime del addon para el panel.

        El panel usa esto para mostrar/ocultar el checkbox de compresión
        (sin sentido si FFmpeg no está instalado) y futuros toggles.
        Cacheamos 60s a nivel de proceso porque find_ffmpeg() hace stat
        de varios paths y queremos esto barato en cada apertura del modal.
        """
        from lib.remote import transcode as _tc
        global _CAPS_CACHE, _CAPS_CACHE_AT
        now = time.time()
        # Fast-path bajo lock: si el cache es válido, devolverlo sin recalcular.
        with _CAPS_LOCK:
            if _CAPS_CACHE is not None and now - _CAPS_CACHE_AT < 60:
                self._send_json(_CAPS_CACHE)
                return
        # Cache stale o vacío: calculamos fuera del lock (find_ffmpeg hace I/O)
        # y publicamos bajo lock. Una segunda petición concurrente puede llegar
        # aquí también; ambas hacen el find pero solo una mantiene el valor,
        # cosa que se autocorrige al siguiente request (idempotente).
        caps = {
            'ffmpeg': bool(_tc.find_ffmpeg()),
            'ffprobe': bool(_tc.find_ffprobe()),
            'version': 1,
        }
        with _CAPS_LOCK:
            _CAPS_CACHE = caps
            _CAPS_CACHE_AT = now
        self._send_json(caps)

    def _handle_ca_download(self):
        """Devuelve el cert PEM del addon para que el usuario lo importe
        en su sistema operativo (Android, Windows) y el browser confíe
        en él. Sin esta confianza, instalar la PWA en Chrome Android no
        es posible y `share_target` no aparece en el menú de Compartir.

        El cert es público (la clave privada vive en disco junto al
        cert y NUNCA se sirve por HTTP). El endpoint va en
        `_READ_ONLY_PATHS` por una razón concreta: el usuario necesita
        descargarlo ANTES de tener auth (no puede aceptar el HTTPS sin
        importar el cert).
        """
        from lib.remote import tls
        cert_path = tls.get_cert_path()
        if not cert_path:
            self._send(404, b'cert not generated')
            return
        try:
            with open(cert_path, 'rb') as f:
                pem = f.read()
        except OSError as e:
            log.warning(f'no se pudo leer cert: {e}')
            self._send(500, b'cert read error')
            return
        self._send(
            200, pem,
            content_type='application/x-x509-ca-cert',
            extra_headers=[
                ('Content-Disposition',
                 'attachment; filename="loiolink-ca.crt"'),
                ('Cache-Control', 'no-store'),
            ],
        )

    def _handle_share_target(self, query):
        """Entrada de Web Share Target: el usuario eligió loiolink desde
        el menú "Compartir" de otra app. El payload llega como query
        string del manifest (`title`, `text`, `url`).

        Comportamiento:

        - Extrae la URL más probable: `url` > `text` > `title`.
        - Pasa por `mux()` y, si reconocido, por `url_resolver`.
        - Redirige a `/` con `?shared=ok` o `?shared=fail` para feedback.
        - Si no hay auth, el `_check_auth_or_reject` previo ya habrá
          enviado el form de pairing. Aquí ya está autorizado.
        """
        from lib import url_utils
        from lib.actions import url_resolver

        params = urllib.parse.parse_qs(query)
        raw = (
            (params.get('url') or [''])[0]
            or (params.get('text') or [''])[0]
            or (params.get('title') or [''])[0]
        ).strip()

        normalized = url_utils.mux(raw)
        if not normalized:
            log.info(f'share_target: input no reconocido como URL ({len(raw)} chars)')
            self._send(
                303, b'',
                'text/plain; charset=utf-8',
                extra_headers=[('Location', '/?shared=fail')],
            )
            return

        # Si la URL es de un servicio conocido, traducimos a plugin://.
        target = url_resolver.resolve(normalized) or normalized

        # Validar scheme final: si el resolver devolvió None y la URL
        # cruda es magnet/acestream/http(s), seguimos; cualquier otro
        # scheme se rechaza por seguridad (igual que _handle_cast).
        scheme = urllib.parse.urlparse(target).scheme.lower()
        if scheme not in ('http', 'https', 'magnet', 'plugin', 'acestream'):
            log.security(f'share_target: scheme no permitido {scheme!r}')
            self._send(
                303, b'',
                'text/plain; charset=utf-8',
                extra_headers=[('Location', '/?shared=fail')],
            )
            return

        from lib.remote import elementum, player, acestream as ace
        try:
            if scheme == 'magnet':
                if elementum.has_magnet_player():
                    elementum.play_magnet_with_fallback(target)
                else:
                    from lib.transfers import history
                    history.queue_event({'kind': 'magnet_received', 'uri': target})
            elif scheme == 'acestream':
                if ace.is_acestream(target):
                    ace.play(target)
                else:
                    raise RuntimeError('acestream malformado')
            else:
                player.play_file(target)
            # Si había un modal QR abierto (pairing pendiente, recibir
            # texto efímero, etc.) lo cerramos para que el dialog de
            # "Reproduciendo en este Kodi" del player tenga espacio en
            # pantalla. Mismo gesto que _handle_cast.
            _signal_modal_dismiss()
            log.info(f'share_target: dispatched ({scheme}) {target[:120]!r}')
            self._send(
                303, b'',
                'text/plain; charset=utf-8',
                extra_headers=[('Location', '/?shared=ok')],
            )
        except Exception as e:
            log.warning(f'share_target: falló dispatch: {e!r}')
            self._send(
                303, b'',
                'text/plain; charset=utf-8',
                extra_headers=[('Location', '/?shared=fail')],
            )

    def _handle_stream(self, entry_id):
        if not entry_id:
            self._send(404, b'missing entry id')
            return
        from lib.transfers import history
        entry = history.get(entry_id)
        if entry is None:
            self._send(404, b'entry not found')
            return
        path = entry.get('path')
        if not path:
            self._send(404, b'no path')
            return
        # Content-Type por extensión (heurística simple).
        ct = _guess_content_type(path)
        from lib.remote import range_http
        range_http.serve_range(self, path, ct,
                               extra_headers=SECURITY_HEADERS)

    def _handle_stream_page(self, entry_id, query):
        if not entry_id:
            self._send(404, b'missing entry id')
            return
        from lib.transfers import history
        entry = history.get(entry_id)
        if entry is None:
            self._send(404, b'entry not found')
            return

        # Posición inicial: ?start=N o última sincronizada o 0.
        qs = urllib.parse.parse_qs(query)
        t_param = qs.get('start', [None])[0]
        if t_param is None:
            with _SYNC_LOCK:
                start_s = _SYNC_POSITIONS.get(entry_id, 0.0)
        else:
            start_s = _parse_position_s(t_param)
            if start_s is None:
                start_s = 0.0

        # Detectar si el navegador puede reproducirlo.
        # Si no, ofrecer transcoding si ffmpeg está disponible.
        from lib.remote import transcode
        path = entry.get('path', '')
        force = qs.get('force', [None])[0]  # ?force=raw para saltar la detección
        playable, reason = transcode.is_browser_playable(path)
        ffmpeg_available = transcode.find_ffmpeg() is not None
        offer_transcode = (not playable) and ffmpeg_available and force != 'raw'

        html = _build_stream_page(
            title=entry.get('name') or '',
            start_s=start_s,
            stream_url=f'/stream/{entry_id}',
            transcode_url=f'/stream-transcode/{entry_id}',
            sync_key=entry_id,
            playable=playable, reason=reason,
            offer_transcode=offer_transcode,
            ffmpeg_available=ffmpeg_available,
            is_audio=_is_audio_path(entry.get('name') or entry.get('path', '')),
        )
        self._send(200, html.encode('utf-8'), 'text/html; charset=utf-8')

    def _handle_stream_transcode(self, entry_id):
        if not entry_id:
            self._send(404, b'missing entry id')
            return
        from lib.transfers import history
        entry = history.get(entry_id)
        if entry is None or not entry.get('path'):
            self._send(404, b'entry not found')
            return
        self._pipe_ffmpeg(entry['path'])

    def _pipe_ffmpeg(self, path):
        """Pipe ffmpeg → wfile. Sin Range (output secuencial).

        Llamado tanto desde /stream-transcode/<id> (history) como desde
        /library/stream-transcode?path=... (biblioteca). El caller debe
        haber validado el path antes (history privado o is_path_allowed).
        """
        from lib.remote import transcode
        ffmpeg = transcode.find_ffmpeg()
        if not ffmpeg:
            self._send(503, b'ffmpeg not available')
            return
        if not transcode.acquire_slot():
            self._send(503, b'transcoder ocupado')
            return

        import subprocess
        try:
            # MP4 fragmentado para empezar a reproducir sin esperar al moov al final.
            proc = subprocess.Popen(
                [
                    ffmpeg, '-i', transcode.safe_path_arg(path),
                    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23',
                    '-c:a', 'aac', '-b:a', '128k',
                    '-movflags', '+frag_keyframe+empty_moov+default_base_moof',
                    '-f', 'mp4', 'pipe:1',
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                **transcode.no_console_flags(),
            )
            try:
                self.send_response(200)
                self._send_security_headers()
                self.send_header('Content-Type', 'video/mp4')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                # Pipe directo. Sin Content-Length (no se conoce).
                while True:
                    chunk = proc.stdout.read(64 * 1024)
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError,
                            ConnectionAbortedError):
                        break
            finally:
                # Cerrar stdout PRIMERO desbloquea ffmpeg si está intentando
                # escribir al pipe roto. Sin esto, el wait/kill puede colgar y
                # los FDs quedan abiertos hasta GC (leak en sesiones largas).
                try:
                    if proc.stdout is not None:
                        proc.stdout.close()
                except OSError:
                    pass
                try:
                    proc.terminate()
                    proc.wait(timeout=2)
                except (subprocess.TimeoutExpired, OSError):
                    try:
                        proc.kill()
                        proc.wait(timeout=1)
                    except (subprocess.TimeoutExpired, OSError):
                        pass
        finally:
            transcode.release_slot()

    def _handle_status_longpoll(self, query):
        qs = urllib.parse.parse_qs(query)
        since = qs.get('since', [''])[0]

        deadline = time.time() + _STATUS_LONGPOLL_S
        while time.time() < deadline:
            st = _status_with_hls()
            current = _interesting_hash(st)
            if current != since:
                st['hash'] = current
                st['panel_rev'] = _panel_rev()
                self._send_json(st)
                return
            # wait_for_bump despierta antes del timeout si el LoiolinkMonitor
            # recibe un evento Kodi relevante (Player.OnPause, etc.). Sin
            # bump, el comportamiento es idéntico al `time.sleep` anterior:
            # un tick del polling cada _STATUS_POLL_INTERVAL_S segundos.
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            _notify.wait_for_bump(min(_STATUS_POLL_INTERVAL_S, remaining))

        # Timeout sin cambios: devolver el mismo hash para que el cliente
        # vuelva a pedir sin renderizar (evita flickering).
        st = _status_with_hls()
        st['hash'] = since
        st['panel_rev'] = _panel_rev()
        self._send_json(st)

    def _handle_get_playlist(self, query):
        from lib.remote import player
        qs = urllib.parse.parse_qs(query)
        pid_raw = (qs.get('playlistid') or [None])[0]
        try:
            playlistid = int(pid_raw) if pid_raw is not None else None
            data = player.get_queue(playlistid)
        except ValueError as e:
            self._send(400, str(e).encode('utf-8'))
            return
        except Exception as e:
            log.warning(f'get_queue falló: {e}')
            self._send(500, b'error')
            return
        self._send_json(data)

    def _handle_browse(self, query):
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        from lib.remote import player
        from lib.remote.rpc import RPCError
        qs = urllib.parse.parse_qs(query)
        path_ = (qs.get('path') or [''])[0]
        media = (qs.get('media') or ['files'])[0]
        if not _is_safe_browse_path(path_):
            log.security(f'browse rechazado: path inválido {path_[:80]!r}')
            self._send(400, b'unsafe path')
            return
        try:
            items = player.browse(path_, media=media)
        except RPCError as e:
            # Kodi devolvió error (carpeta inexistente, plugin que falla...).
            # 502 porque el fallo viene de upstream, no del request del cliente.
            log.info(f'browse {path_[:80]!r}: rpc {e}')
            self._send(502, str(e).encode('utf-8'))
            return
        self._send_json({'path': path_, 'items': items})

    def _handle_list_sessions(self):
        """GET /remote/sessions → lista de sesiones (sin tokens)."""
        from lib.remote import sessions, auth as _auth
        self_token = _auth.current_request_token(self)
        self._send_json({'sessions': sessions.public_view(self_token)})

    def _handle_keyboard_wait(self, query):
        """Long-poll: devuelve {active, heading} cuando un teclado virtual se
        abre en Kodi, o {active: false} si pasa el timeout sin detección.

        El frontend usa esto para enseñar un modal de prompt al usuario.
        timeout máximo 30s (igual que el long-poll de status).
        """
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        from lib.remote import keyboard_input
        qs = urllib.parse.parse_qs(query)
        try:
            timeout = int((qs.get('timeout') or ['25'])[0])
        except (TypeError, ValueError):
            timeout = 25
        timeout = max(1, min(30, timeout))
        deadline = time.time() + timeout
        while time.time() < deadline:
            if keyboard_input.is_keyboard_active():
                self._send_json({
                    'active': True,
                    'heading': keyboard_input.keyboard_heading(),
                })
                return
            time.sleep(0.2)
        self._send_json({'active': False})

    def _handle_addon_icon(self, addonid):
        """Sirve el icono de un addon directamente del filesystem.

        No depende del webserver interno de Kodi; funciona aunque esté
        deshabilitado. Los iconos son imágenes públicas instaladas por el
        addon; no hay riesgo de exponer datos privados.

        Usamos `_ADDONS_DIRS` cacheado en lugar de xbmcvfs.translatePath() por
        request: las llamadas a xbmcvfs desde worker threads fallaban silenciosas.
        """
        if not addonid or not _ADDONID_RE.match(addonid):
            self._send(404, b'not found')
            return
        # Algunos addons (plugin.video.ted.talks) guardan el icono en resources/
        # en lugar de la raíz del addon, así que probamos ambas ubicaciones.
        candidates_rel = (
            'icon.png', 'icon.jpg',
            _os.path.join('resources', 'icon.png'),
            _os.path.join('resources', 'icon.jpg'),
        )
        for base in _ADDONS_DIRS:
            for rel in candidates_rel:
                path = _os.path.join(base, addonid, rel)
                if not _os.path.isfile(path):
                    continue
                ct = _STATIC_MIME.get(_os.path.splitext(path)[1].lower(),
                                      'image/png')
                try:
                    with open(path, 'rb') as f:
                        body = f.read()
                except OSError:
                    continue
                self._send(200, body, ct,
                           extra_headers=[('Cache-Control', 'public, max-age=3600')])
                return
        self._send(404, b'not found')

    def _handle_list_addons(self, query):
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        from lib.remote import player
        qs = urllib.parse.parse_qs(query)
        content_type = (qs.get('type') or [None])[0]
        try:
            data = player.list_addons(content_type)
        except Exception as e:
            log.warning(f'list_addons falló: {e}')
            self._send(500, b'error')
            return
        self._send_json({'addons': data})

    def _handle_addon_fav_ids(self):
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        from lib.remote import player
        try:
            ids = player.list_favourite_addon_ids()
        except Exception as e:
            log.warning(f'list_favourite_addon_ids falló: {e}')
            self._send(500, b'error')
            return
        self._send_json({'addonids': ids})

    def _handle_list_favourites(self):
        # Sin opt-in: los favoritos son lectura del estado del propio Kodi,
        # ya marcados por el usuario; cualquiera con el QR vería lo que
        # ese usuario ha guardado, lo cual es coherente con lo que ya ve
        # de biblioteca y reproducción.
        #
        # Cada item viene con `_fp` (fingerprint del contenido). El cliente
        # lo devuelve al ejecutar para detectar si la lista cambió entre
        # el GET y el POST (race silenciosa = ejecutar el equivocado).
        from lib.remote import player
        try:
            data = player.list_favourites_with_fingerprint()
        except Exception as e:
            log.warning(f'list_favourites falló: {e}')
            self._send(500, b'error')
            return
        self._send_json({'favourites': data})

    def _handle_pwa_asset(self, name, content_type, extra_headers=None):
        """Sirve un asset de PWA (manifest.json, sw.js) en la raíz.

        A diferencia de _handle_static, no necesita whitelist por regex
        porque solo se llama con nombres fijos hardcoded en las rutas
        del do_GET; no hay path injection posible.

        Para sw.js: sustituye `__BUILD__` por una versión dinámica derivada
        del mtime del propio sw.js. Esto fuerza al browser a invalidar el
        cache de assets viejo cuando se actualiza el addon (sin esto los
        usuarios con SW instalado seguirían recibiendo panel.js de hace
        meses)."""
        path = _static_path(name)
        if not path or not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            with open(path, 'rb') as f:
                body = f.read()
        except OSError:
            self._send(500, b'read error')
            return
        # Bust de versión para sw.js: cada cambio en el archivo (mtime)
        # produce un nombre de cache distinto → el SW viejo no toca los
        # assets nuevos y purga el cache anterior en `activate`.
        #
        # Si alguien quitara la cadena `__BUILD__` por error al editar
        # sw.js, el cache nunca se invalidaría y los usuarios con PWA
        # instalada se quedarían con assets viejos para siempre. Detectar
        # y loguear (no fallar; el SW seguiría funcionando, solo sin
        # invalidación de versión).
        if name == 'sw.js':
            if b'__BUILD__' in body:
                try:
                    build = str(int(_os.path.getmtime(path)))
                except OSError:
                    build = '0'
                body = body.replace(b'__BUILD__', build.encode('ascii'))
            else:
                log.warning(
                    'sw.js no contiene la cadena __BUILD__: el cache del '
                    'SW nunca se invalidará al actualizar el addon. '
                    'Restaurar la línea `const CACHE = ...__BUILD__...` '
                    'en sw.js.')
        headers = list(extra_headers or [])
        headers.append(('Cache-Control', 'public, max-age=3600'))
        self._send(200, body, content_type, extra_headers=headers)

    # --- Biblioteca / Plex-like ---

    def _handle_static(self, name):
        # Whitelist por nombre: solo letras, números, punto, guion, guion bajo.
        # Sin separadores ni '..', así descartamos cualquier traversal.
        # El check explícito de '..' es defensa en profundidad: la regex
        # no permite separadores así que no hay traversal real, pero el
        # nombre '..' a secas no debe ser válido para evitar ruido.
        if not name or '..' in name or not _SAFE_STATIC_NAME.match(name):
            self._send(404, b'not found')
            return
        path = _static_path(name)
        if not path or not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            with open(path, 'rb') as f:
                body = f.read()
        except OSError:
            self._send(500, b'read error')
            return
        ct = _STATIC_MIME.get(_os.path.splitext(name)[1].lower(),
                              'application/octet-stream')
        self._send(200, body, ct,
                   extra_headers=[('Cache-Control', 'public, max-age=86400')])

    def _handle_panel_page(self):
        path = _static_path('panel.html')
        if not path or not _os.path.isfile(path):
            self._send(500, b'panel.html missing')
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                html_text = f.read()
        except OSError:
            self._send(500, b'read error')
            return
        # rev = mtime de panel.js. La inyectamos como <meta panel-rev> para
        # que el JS de una pestaña abierta detecte cambios en background y
        # avise al usuario de recargar (si no, los cambios al panel no se
        # ven hasta el siguiente F5; confusion mode tras cada deploy).
        rev = _panel_rev()
        html_text = html_text.replace(
            '<head>',
            f'<head>\n<meta name="panel-rev" content="{rev}">',
            1,
        )
        body = _bust_static_urls(html_text).encode('utf-8')
        # no-store: la página del panel nunca se guarda en cache. Cada visita
        # trae el HTML fresco desde el server, que a su vez referencia los
        # assets versionados (panel.css?v=<mtime>); esos sí cachean 24h.
        self._send(200, body, 'text/html; charset=utf-8',
                   extra_headers=[('Cache-Control', 'no-store')])
        # El móvil cargó el panel autenticado: si el QR modal está abierto,
        # ya no hace falta enseñarlo. Va DESPUES del _send 200 (no en los
        # early-returns con 500) y solo se alcanza si la escritura no
        # lanzó, asi que no marcamos como conectado en errores de I/O.
        _signal_modal_dismiss()

    def _handle_library_page(self):
        path = _static_path('library.html')
        if not path or not _os.path.isfile(path):
            self._send(500, b'library.html missing')
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                html_text = f.read()
        except OSError:
            self._send(500, b'read error')
            return
        body = _bust_static_urls(html_text).encode('utf-8')
        self._send(200, body, 'text/html; charset=utf-8',
                   extra_headers=[('Cache-Control', 'no-store')])

    def _handle_instructions_page(self):
        try:
            addon_path = xbmcaddon.Addon().getAddonInfo('path')
        except RuntimeError:
            self._send(500, b'addon path unavailable')
            return
        path = _os.path.join(addon_path, 'index.html')
        if not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                html_text = f.read()
        except OSError:
            self._send(500, b'read error')
            return
        body = html_text.encode('utf-8')
        self._send(200, body, 'text/html; charset=utf-8',
                   extra_headers=[('Cache-Control', 'no-cache')])

    def _handle_library_api(self, subpath, query):
        from lib.remote import kodi_webserver, library
        qs = urllib.parse.parse_qs(query)

        try:
            if subpath == 'status':
                sources = {}
                for media in ('video', 'music', 'pictures', 'files'):
                    sources[media] = library.get_sources(media)
                self._send_json({
                    'webserver_enabled': kodi_webserver.is_enabled(),
                    'kodi_port': kodi_webserver.get_port(),
                    'counts': library.counts(),
                    'sources': sources,
                })
                return

            if subpath == 'movies':
                q = qs.get('q', [''])[0]
                self._send_json({'movies': library.list_movies(
                    limit=_parse_limit(qs), offset=_parse_offset(qs), q=q)})
                return

            if subpath.startswith('movie/'):
                movieid = subpath[len('movie/'):]
                self._send_json(library.get_movie(movieid))
                return

            if subpath == 'tvshows':
                q = qs.get('q', [''])[0]
                self._send_json({'tvshows': library.list_tvshows(
                    limit=_parse_limit(qs), offset=_parse_offset(qs), q=q)})
                return

            if subpath.startswith('tvshow/') and subpath.endswith('/seasons'):
                tvshowid = subpath[len('tvshow/'):-len('/seasons')]
                self._send_json({'seasons': library.list_seasons(tvshowid)})
                return

            if subpath == 'episodes':
                tvshowid = qs.get('tvshowid', [''])[0]
                if not tvshowid:
                    self._send(400, b'missing tvshowid')
                    return
                season = qs.get('season', [None])[0]
                self._send_json({'episodes': library.list_episodes(
                    tvshowid, season=season if season is not None else None)})
                return

            if subpath == 'artists':
                q = qs.get('q', [''])[0]
                self._send_json({'artists': library.list_artists(
                    limit=_parse_limit(qs), offset=_parse_offset(qs), q=q)})
                return

            if subpath == 'albums':
                artistid = qs.get('artistid', [None])[0]
                self._send_json({'albums': library.list_albums(
                    artistid=artistid if artistid is not None else None,
                    limit=_parse_limit(qs), offset=_parse_offset(qs))})
                return

            if subpath == 'songs':
                albumid = qs.get('albumid', [None])[0]
                if albumid is None:
                    self._send(400, b'missing albumid')
                    return
                self._send_json({'songs': library.list_songs(
                    albumid=albumid,
                    limit=_parse_limit(qs), offset=_parse_offset(qs))})
                return

            if subpath == 'sources':
                media = qs.get('media', ['video'])[0]
                self._send_json({'sources': library.get_sources(media)})
                return

            if subpath == 'browse':
                p = qs.get('path', [''])[0]
                if not p:
                    self._send(400, b'missing path')
                    return
                if not library.is_path_under_source(p):
                    self._send(403, b'path not allowed')
                    return
                self._send_json({'files': library.browse(p)})
                return

            if subpath == 'playable':
                # Pre-chequeo del media player web: ¿el navegador puede
                # reproducir este archivo directamente, o necesita transcode?
                # Requiere path local (is_path_allowed media_only ya lo exige
                # vía _is_local_path interno). Para paths de red el frontend
                # ya ha caído al modal "▶ Kodi" antes de llegar aquí.
                from lib.remote import transcode
                p = qs.get('path', [''])[0]
                if not p:
                    self._send(400, b'missing path')
                    return
                if not library.is_path_allowed(p, media_only=True):
                    self._send(403, b'path not allowed')
                    return
                playable, reason = transcode.is_browser_playable(p)
                self._send_json({
                    'playable': playable,
                    'reason': reason,
                    'has_ffmpeg': transcode.find_ffmpeg() is not None,
                    'is_audio': _is_audio_path(p),
                })
                return

            self._send(404, b'unknown api endpoint')
        except (ValueError, TypeError) as e:
            log.warning(f'library api {subpath} error: {e}')
            self._send(400, b'bad request')
        except Exception as e:
            log.warning(f'library api {subpath} excepción: {e}')
            self._send(500, b'error')

    def _handle_library_play(self, body):
        # play acepta SMB/NFS/local: Kodi resuelve internamente. Validación
        # por prefix de source (sin realpath, no aplica a paths de red).
        from lib.remote import library, player
        path = (body or {}).get('path', '').strip()
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_under_source(path):
            self._send(403, b'path not allowed')
            return
        try:
            start_s = max(0, int((body or {}).get('start_s', 0) or 0))
        except (ValueError, TypeError):
            start_s = 0
        player.play_file(path, start_s=start_s)
        self._send_json({'ok': True})

    def _handle_library_disable_webserver(self):
        from lib.remote import kodi_webserver
        if not kodi_webserver.is_enabled():
            self._send_json({'ok': True, 'already': True})
            return
        ok = kodi_webserver.disable()
        self._send_json({'ok': ok})

    def _handle_library_enable_webserver(self):
        from lib.remote import kodi_webserver
        if kodi_webserver.is_enabled():
            self._send_json({'ok': True, 'already': True})
            return
        ok = kodi_webserver.request_enable_via_dialog()
        if ok:
            self._send_json({'ok': True})
        else:
            self._send_json({'ok': False, 'reason': 'declined'})

    def _handle_fb_api(self, op, body):
        from lib.remote import library
        body = body or {}
        log.sensitive(f'[loiolink.fb] op={op!r} body={str(body)[:200]}')
        try:
            if op == 'delete':
                path = body.get('path', '')
                permanent = bool(body.get('permanent', False))
                force = bool(body.get('force', False))
                if not path:
                    self._fb_err('Falta la ruta.', 400); return
                if not library.is_path_under_source(path, strict_local=True):
                    self._fb_err('Ruta no permitida.', 403); return
                if not library.path_exists(path):
                    self._fb_err('El elemento ya no existe.'); return

                # Papelera SOLO para paths locales. Sources de red (smb://,
                # nfs://, etc.) van directas a borrado físico (el frontend
                # debe haber mostrado un confirm "permanente"). Si la
                # papelera está deshabilitada en settings o el caller pidió
                # permanent=true, también va al borrado directo.
                # NOTA: import explícito DENTRO del branch; otro elif más
                # abajo hace `import xbmcaddon` local, lo que convierte
                # xbmcaddon en variable local a toda la función y produce
                # UnboundLocalError si lo usásemos vía el import del top.
                from lib.remote import trash
                import xbmcaddon as _xbmca
                addon = _xbmca.Addon()

                # Archivos críticos de Kodi (Addons33.db, guisettings.xml…)
                # dentro de special://home requieren confirmación explícita.
                # El frontend reenvía con force=true tras avisar al usuario.
                if not force and trash.is_critical_path(path):
                    basename = path.rstrip('/\\').rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
                    self._send_json({
                        'ok': False,
                        'requires_confirm': True,
                        'reason': 'critical_file',
                        'basename': basename,
                    })
                    return

                use_trash = (addon.getSettingBool('file_browser.trash.enabled')
                             and not permanent
                             and library._is_local_path(path.rstrip('/\\')))

                if use_trash:
                    tid = trash.move_to_trash(path)
                    if tid:
                        try:
                            max_items = int(addon.getSetting(
                                'file_browser.trash.max_items') or 10)
                        except (ValueError, TypeError):
                            max_items = 10
                        trash.enforce_limit(max_items)
                        self._send_json({'ok': True, 'in_trash': True,
                                         'trash_id': tid})
                        return
                    # Move falló (archivo en uso Windows, disco lleno, etc.).
                    # Fallback al borrado directo abajo con log de aviso.
                    log.warning('[trash] move falló; fallback a borrado directo')

                ok = library.fb_delete(path)
                if ok:
                    self._send_json({'ok': True, 'in_trash': False})
                else:
                    self._fb_err('No se pudo eliminar.')
                return

            elif op == 'rename':
                path = body.get('path', '')
                new_name = (body.get('new_name') or '').strip()
                if not path:
                    self._fb_err('Falta la ruta.', 400); return
                if not _is_valid_filename(new_name):
                    self._fb_err('Nombre no válido para esta plataforma.'); return
                if not library.is_path_under_source(path, strict_local=True):
                    self._fb_err('Ruta no permitida.', 403); return
                stripped = path.rstrip('/\\')
                sep = '/' if '/' in stripped else '\\'
                parent = stripped.rsplit(sep, 1)[0] + sep
                dst = parent + new_name
                if library.path_exists(dst):
                    self._fb_err('Ya existe un elemento con ese nombre.'); return
                ok = library.fb_rename(path, dst)
                self._fb_ok() if ok else self._fb_err('No se pudo renombrar.')

            elif op in ('copy', 'move'):
                src = body.get('src', '')
                dst = body.get('dst', '')
                if not src or not dst:
                    self._fb_err('Faltan origen o destino.', 400); return
                if not library.is_path_under_source(src, strict_local=True):
                    self._fb_err('Origen fuera de fuentes.', 403); return
                if not library.is_path_under_source(dst, strict_local=True):
                    self._fb_err('Destino fuera de fuentes.', 403); return
                if library.path_exists(dst):
                    self._fb_err('Ya existe un elemento con ese nombre en el destino.'); return
                is_dir = src.endswith('/') or src.endswith('\\')
                if is_dir and library.is_within(src, dst):
                    self._fb_err(
                        'No se puede ' + ('copiar' if op == 'copy' else 'mover') +
                        ' una carpeta dentro de sí misma.'
                    ); return
                if op == 'copy':
                    ok = library.fb_copy(src, dst)
                    self._fb_ok() if ok else self._fb_err('No se pudo copiar.')
                else:
                    ok = library.fb_move(src, dst)
                    self._fb_ok() if ok else self._fb_err(
                        'No se pudo mover. Si es entre unidades distintas, prueba copiar y luego eliminar.'
                    )

            elif op == 'mkdir':
                parent = body.get('parent', '')
                name = (body.get('name') or '').strip()
                if not parent:
                    self._fb_err('Falta la ruta del padre.', 400); return
                if not _is_valid_filename(name):
                    self._fb_err('Nombre no válido para esta plataforma.'); return
                if not library.is_path_under_source(parent, strict_local=True):
                    self._fb_err('Ruta no permitida.', 403); return
                sep = '/' if '/' in parent else '\\'
                new_path = parent.rstrip('/\\') + sep + name + sep
                if library.path_exists(new_path):
                    self._fb_err('Ya existe un archivo o carpeta con ese nombre.'); return
                ok = library.fb_mkdir(new_path)
                self._fb_ok() if ok else self._fb_err('No se pudo crear la carpeta.')

            elif op == 'set_upload_dest':
                path = body.get('path', '')
                if not path:
                    self._fb_err('Falta la ruta.', 400); return
                if not library.is_path_under_source(path, strict_local=True):
                    self._fb_err('Ruta no permitida.', 403); return
                import xbmcaddon
                xbmcaddon.Addon().setSetting('transfer.dest_folder', path)
                self._fb_ok()

            elif op == 'add_source':
                name = (body.get('name') or '').strip()
                path = (body.get('path') or '').strip()
                if not name:
                    self._fb_err('Falta el nombre de la fuente.', 400); return
                if not path:
                    self._fb_err('Falta la ruta de la fuente.', 400); return
                from lib import sources
                existing = sources.list_files_sources()
                if any(s['name'] == name for s in existing):
                    self._fb_err('Ya existe una fuente con ese nombre.'); return
                if any(s['path'].rstrip('/\\') == path.rstrip('/\\') for s in existing):
                    self._fb_err('Ya existe una fuente apuntando a esa ruta.'); return
                sources.add_source(name, path)
                library._invalidate_sources_cache()
                self._fb_ok()

            elif op == 'rename_source':
                old_name = (body.get('old_name') or '').strip()
                new_name = (body.get('new_name') or '').strip()
                if not old_name or not new_name:
                    self._fb_err('Faltan nombres.', 400); return
                from lib import sources, source_state
                existing = sources.list_files_sources()
                if any(s['name'] == new_name and s['name'] != old_name for s in existing):
                    self._fb_err('Ya existe una fuente con ese nombre.'); return
                src_path = next(
                    (s['path'] for s in existing if s['name'] == old_name),
                    None,
                )
                ok = sources.rename_source(old_name, new_name)
                if ok and src_path:
                    source_state.upsert(src_path, name=new_name)
                library._invalidate_sources_cache()
                self._fb_ok() if ok else self._fb_err('Fuente no encontrada.')

            elif op == 'delete_source':
                name = (body.get('name') or '').strip()
                if not name:
                    self._fb_err('Falta el nombre.', 400); return
                from lib import sources, source_state
                src_path = next(
                    (s['path'] for s in sources.list_files_sources() if s['name'] == name),
                    None,
                )
                ok = sources.remove_source(name)
                if ok and src_path:
                    source_state.remove(src_path)
                library._invalidate_sources_cache()
                self._fb_ok() if ok else self._fb_err('Fuente no encontrada.')

            elif op == 'test_source_url':
                # Valida una URL pegada en el panel y devuelve preview del contenido.
                # Si es repo Kodi (addons.xml válido) → lista de addons.
                # Si no, fallback a xbmcvfs.listdir (directory listing, smb, nfs, ftp).
                url = (body.get('url') or '').strip()
                if not url:
                    self._fb_err('Falta la URL.', 400); return
                if not _is_paste_src_scheme(url):
                    self._fb_err('URL no válida. Debe empezar por http(s), smb, nfs o ftp.')
                    return
                if _paste_src_host_blocked(url):
                    self._fb_err('No se permiten URLs locales (localhost/127.0.0.1).', 403)
                    return
                log.sensitive(f'[paste_src] test_source_url url={url!r}')
                from lib import url_utils, repos, sources
                # Cargar UNA vez el mapa de instalados para enriquecer todos
                # los items. Si JSON-RPC falla, queda {} y los items se
                # muestran como "no instalado" sin romper nada.
                installed_map = _paste_src_installed_map()
                log.info(f'[paste_src] installed_map size={len(installed_map)}')
                items = []
                kind = None
                xml_err = None
                if url.startswith(('http://', 'https://')):
                    reachable, info = url_utils.test_http_reachable(url, timeout=6)
                    if not reachable:
                        self._fb_err(f'No responde: {info}'); return
                    text, xml_err = _paste_src_fetch_addons_xml(url)
                    if text and repos.looks_like_addons_xml(text):
                        kind = 'repo'
                        addons_map = repos.parse_addons_xml(text)
                        datadir = url if url.endswith('/') else url + '/'
                        for aid, ver in sorted(addons_map.items()):
                            inst = installed_map.get(aid)
                            items.append({
                                'type': 'addon',
                                'name': aid,
                                'addon_id': aid,
                                'version': ver,
                                # Patrón Kodi estándar del zip dentro de un repo
                                # (mismo que installer.py:_install_addon_zip_directly).
                                'zip_url': f'{datadir}{aid}/{aid}-{ver}.zip',
                                'installed': bool(inst),
                                'installed_version': inst.get('version') if inst else None,
                                'installed_enabled': inst.get('enabled') if inst else None,
                            })
                if kind is None:
                    listed, list_err = _paste_src_list_vfs(url, installed_map=installed_map)
                    if listed is None:
                        detail = list_err or 'sin detalle'
                        if xml_err:
                            detail = f'addons.xml: {xml_err}; listdir: {detail}'
                        self._fb_err(f'No se pudo previsualizar la URL ({detail}).')
                        return
                    kind = 'generic'
                    items = listed
                existing = sources.list_files_sources()
                normalized = url.rstrip('/\\')
                already_added = any(
                    s['path'].rstrip('/\\') == normalized for s in existing
                )
                log.info(f'[paste_src] kind={kind} items={len(items)} already={already_added}')
                self._send_json({
                    'ok': True,
                    'kind': kind,
                    'url': url,
                    'items': items,
                    'name_suggestion': url_utils.suggest_source_name(url),
                    'already_added': already_added,
                })

            elif op == 'list_source_path':
                # Navega a una subcarpeta de una fuente ya previsualizada.
                # Solo esquemas remotos permitidos; nunca paths locales.
                path = (body.get('path') or '').strip()
                if not path:
                    self._fb_err('Falta la ruta.', 400); return
                if not _is_paste_src_scheme(path):
                    self._fb_err('Ruta no permitida.', 403); return
                if _paste_src_host_blocked(path):
                    self._fb_err('No se permiten URLs locales.', 403); return
                log.sensitive(f'[paste_src] list_source_path path={path!r}')
                installed_map = _paste_src_installed_map()
                listed, list_err = _paste_src_list_vfs(path, installed_map=installed_map)
                if listed is None:
                    self._fb_err(f'No se pudo listar el contenido ({list_err or "sin detalle"}).')
                    return
                self._send_json({'ok': True, 'items': listed, 'path': path})

            elif op == 'install_zip_from_url':
                # Descarga un ZIP remoto y lo instala como repo o addon.
                # El addon_id se detecta leyendo el addon.xml dentro del ZIP.
                url = (body.get('url') or '').strip()
                kind = (body.get('kind') or '').strip()
                if not url:
                    self._fb_err('Falta la URL del ZIP.', 400); return
                if kind not in ('repo', 'addon'):
                    self._fb_err('kind debe ser "repo" o "addon".', 400); return
                if not _is_paste_src_scheme(url):
                    self._fb_err('URL no permitida.', 403); return
                if _paste_src_host_blocked(url):
                    self._fb_err('No se permiten URLs locales.', 403); return
                # Validar extensión sobre el path (ignorar query string/fragment
                # que algunos hostings añaden tipo CDN tokens).
                import urllib.parse as _up
                _zpath = (_up.urlparse(url).path or '').lower().rstrip('/')
                if not _zpath.endswith('.zip'):
                    self._fb_err('La URL no apunta a un .zip.', 400); return
                log.sensitive(f'[paste_src] install_zip_from_url kind={kind} url={url!r}')
                ok, msg, installed_id = _paste_src_install_zip(url, kind)
                if ok:
                    log.info(f'[paste_src] install OK id={installed_id!r}')
                    self._send_json({'ok': True, 'installed_id': installed_id})
                else:
                    log.warning(f'[paste_src] install FAIL: {msg}')
                    self._fb_err(msg)

            elif op == 'trash/restore':
                from lib.remote import trash
                tid = (body.get('id') or '').strip()
                if not tid:
                    self._fb_err('Falta id.', 400); return
                ok, msg = trash.restore(tid)
                if ok:
                    self._send_json({'ok': True, 'restored_to': msg})
                else:
                    self._send_json({'ok': False, 'error': msg})

            elif op == 'trash/purge':
                from lib.remote import trash
                tid = (body.get('id') or '').strip()
                if not tid:
                    self._fb_err('Falta id.', 400); return
                ok = trash.purge(tid)
                if ok:
                    self._fb_ok()
                else:
                    self._fb_err('No se pudo eliminar (item no encontrado o en uso).')

            elif op == 'trash/purge_all':
                from lib.remote import trash
                n = trash.purge_all()
                self._send_json({'ok': True, 'count': n})

            elif op == 'trash/config':
                # Setea max_items y aplica enforce inmediato. Clamp 1-100
                # (defensa: nunca permitir 0 que purgaría todo).
                # Mismo motivo de alias _xbmca que en op 'delete': otro elif
                # hace `import xbmcaddon` local y rompe el binding global.
                from lib.remote import trash
                import xbmcaddon as _xbmca
                try:
                    n = int(body.get('max_items', 10))
                except (ValueError, TypeError):
                    self._fb_err('max_items inválido.', 400); return
                n = max(1, min(100, n))
                _xbmca.Addon().setSetting(
                    'file_browser.trash.max_items', str(n))
                trash.enforce_limit(n)
                self._fb_ok()

            else:
                self._fb_err('Operación desconocida.', 404)

        except (ValueError, TypeError) as e:
            log.warning(f'fb api {op} bad request: {e}')
            self._fb_err('Petición inválida.', 400)
        except Exception as e:
            log.warning(f'fb api {op} excepción: {e}')
            self._fb_err('Error interno.', 500)

    def _fb_ok(self):
        self._send_json({'ok': True})

    def _fb_err(self, msg, status=200):
        log.warning(f'[loiolink.fb] error: {msg!r}')
        self._send_json({'ok': False, 'error': msg})

    def _handle_library_stream(self, query):
        from lib.remote import library, range_http
        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_allowed(path, media_only=True):
            self._send(403, b'path not allowed')
            return
        ct = _guess_content_type(path)
        range_http.serve_range(self, path, ct,
                               extra_headers=SECURITY_HEADERS)

    def _handle_library_stream_page(self, query):
        from lib.remote import library, transcode
        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_allowed(path, media_only=True):
            self._send(403, b'path not allowed')
            return
        start_s = _parse_position_s(qs.get('start', ['0'])[0] or 0)
        if start_s is None:
            start_s = 0.0
        force = qs.get('force', [''])[0]
        playable, reason = transcode.is_browser_playable(path)
        ffmpeg_available = transcode.find_ffmpeg() is not None
        offer_transcode = (not playable) and ffmpeg_available and force != 'raw'
        title = _os.path.basename(path)
        quoted = urllib.parse.quote(path, safe='')
        html = _build_stream_page(
            title=title,
            start_s=start_s,
            stream_url=f'/library/stream?path={quoted}',
            transcode_url=f'/library/stream-transcode?path={quoted}',
            sync_key=None,
            playable=playable, reason=reason,
            offer_transcode=offer_transcode,
            ffmpeg_available=ffmpeg_available,
            is_audio=_is_audio_path(path),
        )
        self._send(200, html.encode('utf-8'), 'text/html; charset=utf-8')

    def _handle_library_stream_transcode(self, query):
        from lib.remote import library
        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_allowed(path, media_only=True):
            self._send(403, b'path not allowed')
            return
        self._pipe_ffmpeg(path)

    def _handle_library_download(self, query):
        """GET /library/download?path=...: descarga directa de UN archivo.

        A diferencia de /library/stream:
        - Acepta CUALQUIER extensión bajo una source (no solo media).
        - Acepta paths de red (SMB/NFS/etc.) usando xbmcvfs.File.
        - Content-Disposition: attachment para forzar descarga (no preview).
        - Sin Range: el navegador descarga de una pasada o aborta. Patrón
          EOF-driven (sin Content-Length cuando size desconocido) + Connection:
          close, igual que _pipe_ffmpeg; BaseHTTPRequestHandler default es
          HTTP/1.0 (Transfer-Encoding: chunked no es válido).
        """
        from lib.remote import library
        import xbmcvfs
        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_under_source(path, strict_local=True):
            log.security(f'download fuera de sources: {path[:120]!r}')
            self._send(403, b'path not allowed')
            return
        if path.endswith('/') or path.endswith('\\'):
            self._send(400, b'use /library/download-zip for directories')
            return
        if not library.path_exists(path):
            self._send(404, b'not found')
            return
        # Defensa adicional: un cliente puede pedir un directorio sin slash
        # final. Detección por tipo: paths locales con os.path.isdir; paths
        # de red asumimos archivo (el cliente debió poner /). NO usamos
        # library.path_exists(path+'/') porque su wrapper hace rstrip
        # interno y devuelve True para archivos.
        clean_no_sep = path.rstrip('/\\')
        if library._is_local_path(clean_no_sep) and _os.path.isdir(clean_no_sep):
            self._send(400, b'use /library/download-zip for directories')
            return

        # Nombre para Content-Disposition. urllib.parse.quote escapa CR/LF y
        # caracteres de control → defensa anti-header-injection.
        name = path.rstrip('/\\').rsplit('/', 1)[-1].rsplit('\\', 1)[-1] or 'archivo'
        quoted = urllib.parse.quote(name, safe='')

        # Tamaño si disponible (local rápido; red puede no responder).
        # Solo enviamos Content-Length si la stat tiene éxito y es >= 0;
        # size = 0 es legítimo (archivo vacío) y se envía Content-Length: 0.
        size = -1
        try:
            st = xbmcvfs.Stat(path)
            s = st.st_size()
            if s is not None and s >= 0:
                size = s
        except (AttributeError, RuntimeError, OSError):
            size = -1

        # xbmcvfs.File() ANTES de enviar headers: si lanza (archivo desapareció
        # entre path_exists y aquí, permiso denegado, share remoto caído), aún
        # podemos devolver 500/404 al cliente. Si abriésemos después de los
        # headers, el cliente esperaría body sine die.
        try:
            f = xbmcvfs.File(path)
        except (OSError, RuntimeError) as e:
            log.warning(f'download: no se pudo abrir {name!r}: {e}')
            self._send(500, b'cannot open file')
            return

        try:
            try:
                self.send_response(200)
                self._send_security_headers()
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition',
                                 f"attachment; filename*=UTF-8''{quoted}")
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                if size >= 0:
                    self.send_header('Content-Length', str(size))
                self.end_headers()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

            while True:
                # readBytes está disponible en Kodi 19+ (Python 3.8+) y devuelve
                # bytearray. Cubre tanto local como SMB/NFS/HTTP via xbmcvfs.
                try:
                    chunk = f.readBytes(256 * 1024)
                except (OSError, RuntimeError) as e:
                    log.warning(f'download: read falló en {name!r}: {e}')
                    return  # headers ya enviados, no podemos 500
                if not chunk:
                    break
                try:
                    self.wfile.write(bytes(chunk))
                except (BrokenPipeError, ConnectionResetError,
                        ConnectionAbortedError):
                    log.sensitive(f'download: cliente cerró {name!r}')
                    return
        finally:
            try:
                f.close()
            except OSError:
                pass

    def _handle_library_download_zip(self, query):
        """GET /library/download-zip?path=...: ZIP streamed on-the-fly.

        Stream EOF-driven (sin Content-Length, sin chunked). zipfile soporta
        wfile sin seek desde Python 3.5 (data descriptors automáticos). Usa
        _BufferedWfile para no fragmentar wfile en writes diminutos del
        zipfile. Compresión STORED para extensiones ya comprimidas.

        Defensas:
        - Nombres con / o \\ rechazados (zip slip defense).
        - force_zip64 cuando tamaño desconocido o >= 2 GiB.
        - flag_bits |= 0x800 para señalar UTF-8 filenames.
        - Archivos individuales fallidos se saltan con log; el ZIP continúa.
        - Anti-loop: set de paths ya visitados (symlinks circulares en VFS
          que sigan links; algunos plugins de Kodi lo hacen).
        - Cap de profundidad (1000) y nº de archivos (200_000) para
          evitar OOM / handler bloqueado por estructuras patológicas.
        """
        from lib.remote import library
        import xbmcvfs
        import zipfile
        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        if not path:
            self._send(400, b'missing path')
            return
        if not library.is_path_under_source(path, strict_local=True):
            log.security(f'download-zip fuera de sources: {path[:120]!r}')
            self._send(403, b'path not allowed')
            return
        if not library.path_exists(path):
            self._send(404, b'not found')
            return
        # Validar que es DIRECTORIO. Sin esto, un cliente con un path de
        # archivo generaría un ZIP vacío (xbmcvfs.listdir(file) falla en
        # el BFS y todo se salta). Misma estrategia que en download:
        # local → os.path.isdir; red → confiamos en convención de slash final.
        clean_no_sep = path.rstrip('/\\')
        ends_with_sep = path.endswith('/') or path.endswith('\\')
        if library._is_local_path(clean_no_sep):
            is_dir = _os.path.isdir(clean_no_sep)
        else:
            is_dir = ends_with_sep
        if not is_dir:
            self._send(400, b'not a directory; use /library/download instead')
            return

        root = path.rstrip('/\\').replace('\\', '/') + '/'
        base_name = root.rstrip('/').rsplit('/', 1)[-1] or 'archivo'
        quoted = urllib.parse.quote(f'{base_name}.zip', safe='')

        try:
            self.send_response(200)
            self._send_security_headers()
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition',
                             f"attachment; filename*=UTF-8''{quoted}")
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return

        # Caps duros contra estructuras patológicas / DoS accidental.
        max_depth = 1000
        max_entries = 200_000
        bw = _BufferedWfile(self.wfile)
        skipped = 0
        entries_added = 0
        visited = set()
        try:
            # allowZip64 default True desde Python 3.4; explícito por claridad.
            with zipfile.ZipFile(bw, 'w', allowZip64=True) as zf:
                # BFS sobre el subárbol con xbmcvfs.listdir (soporta SMB/NFS).
                # depth=0 es el root. Cap a max_depth previene recursión
                # excesiva si un VFS exótico sigue symlinks circulares.
                queue = [(root, '', 0)]
                while queue:
                    if bw.broken:
                        break
                    if entries_added >= max_entries:
                        log.warning(
                            f'zip: cap {max_entries} entradas alcanzado en '
                            f'{base_name!r}; truncando')
                        break
                    cur_path, cur_arc, depth = queue.pop(0)
                    # Canonicalizamos el path con normpath para
                    # detectar el mismo dir visitado por rutas distintas.
                    canon = cur_path.replace('\\', '/').rstrip('/')
                    if canon in visited:
                        log.security(
                            f'zip: subdir ya visitado, posible loop: {canon!r}')
                        continue
                    visited.add(canon)
                    try:
                        folders, files = xbmcvfs.listdir(cur_path)
                    except OSError as e:
                        log.warning(f'zip listdir falló en {cur_path!r}: {e}')
                        skipped += 1
                        continue
                    for fname in files:
                        if bw.broken or entries_added >= max_entries:
                            break
                        if not fname or fname in ('.', '..'):
                            continue
                        # Defensa zip slip: nombre no debe escapar.
                        if '/' in fname or '\\' in fname:
                            log.security(
                                f'zip: nombre con separador rechazado: {fname!r}')
                            skipped += 1
                            continue
                        full = cur_path + fname
                        arc = (cur_arc + fname) if cur_arc else fname
                        if _zip_add_file(zf, full, arc,
                                         _zip_compression_for(arc)):
                            entries_added += 1
                        else:
                            skipped += 1
                    if depth + 1 > max_depth:
                        log.warning(
                            f'zip: cap max_depth={max_depth} alcanzado en '
                            f'{cur_path!r}; subcarpetas ignoradas')
                        continue
                    for dname in folders:
                        if bw.broken:
                            break
                        if not dname or dname in ('.', '..'):
                            continue
                        if '/' in dname or '\\' in dname:
                            log.security(
                                f'zip: subdir con separador rechazado: {dname!r}')
                            skipped += 1
                            continue
                        queue.append((cur_path + dname + '/',
                                      (cur_arc + dname + '/') if cur_arc
                                      else (dname + '/'),
                                      depth + 1))
            # __exit__ del zipfile escribe el central directory. Si el
            # cliente ya cerró, el write puede lanzar BrokenPipeError; lo
            # capturamos abajo. El ZIP queda incompleto pero no rompemos
            # el thread del handler.
            if skipped or entries_added:
                log.sensitive(
                    f'zip: {base_name} terminado, {entries_added} entries, '
                    f'{skipped} saltadas')
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            log.sensitive(f'zip: cliente desconectado durante {base_name!r}')
        except (OSError, zipfile.BadZipFile, RuntimeError) as e:
            # Headers ya enviados; no podemos mandar 5xx. Cerramos limpio.
            log.warning(f'zip: error generando {base_name!r}: {e}')
        finally:
            # bw.close() flushea el último buffer pendiente al socket. SI el
            # ZipFile __exit__ tuvo éxito pero la conexión murió justo
            # después, sin esto el central directory final se perdería.
            try:
                bw.close()
            except (BrokenPipeError, ConnectionResetError,
                    ConnectionAbortedError, OSError):
                pass

    def _handle_fs_browse(self, query):
        """GET /api/library/fb/fs_browse?path=...: explora el filesystem
        visible a Kodi para 'Añadir fuente examinando' (F3).

        SEGURIDAD: opt-in vía setting file_browser.allow_fs_browse (default
        false). Cuando está activado, cualquier holder del token puede
        ENUMERAR (no leer) todos los archivos visibles al proceso Kodi.

        - path vacío o '/' → raíces (drives en Windows, '/' en Unix).
        - path concreto → contenido de la carpeta vía os.scandir.
        - Bloquea '..', paths relativos y control chars.
        - Solo lista; nunca sirve contenido de archivos.
        - Log [loiolink.SEC] por cada llamada con IP del cliente.
        """
        import os
        import string
        from lib.remote import library
        # Setting siempre chequeado (no cachear: si el usuario lo desactiva,
        # surte efecto en la siguiente llamada).
        if not xbmcaddon.Addon().getSettingBool('file_browser.allow_fs_browse'):
            self._send_json({'ok': False,
                             'error': 'Activa "Permitir examinar el filesystem" '
                                      'en Ajustes del addon → Avanzado.'})
            return

        qs = urllib.parse.parse_qs(query)
        path = qs.get('path', [''])[0]
        client_ip = self.client_address[0] if self.client_address else '?'
        log.sensitive(f'[fs_browse] path={path[:200]!r} from {client_ip}')

        # Raíz: enumerar drives Windows o devolver '/' en Unix.
        # NO comprobamos os.path.exists por letra (puede colgar 30 s en
        # lectores de CD vacíos o USB removibles). El cliente al clicar
        # un drive no disponible verá un error normal del scandir.
        if not path or path in ('/', '\\'):
            if os.name == 'nt':
                entries = [
                    {'file': f'{L}:\\', 'name': f'{L}:\\', 'is_dir': True,
                     'size': None, 'lastmodified': None}
                    for L in string.ascii_uppercase
                ]
            else:
                entries = [{'file': '/', 'name': '/', 'is_dir': True,
                            'size': None, 'lastmodified': None}]
            self._send_json({'ok': True, 'entries': entries, 'parent': None})
            return

        # Defensas path concreto.
        if library._has_dotdot_component(path):
            log.security(f'[fs_browse] .. rechazado: {path[:120]!r}')
            self._send_json({'ok': False, 'error': 'Ruta inválida (contiene "..").'})
            return
        if any(ord(c) < 32 for c in path):
            self._send_json({'ok': False, 'error': 'Ruta con caracteres inválidos.'})
            return
        # Windows: "X:" SIN slash final es CWD-relative del proceso (lista
        # el directorio actual de Kodi, no la raíz del drive). Normalizar
        # a "X:\", la intención obvia es "raíz del drive". ANTES del
        # isabs check, porque 'C:' devuelve False en os.path.isabs.
        if os.name == 'nt' and len(path) == 2 and path[1] == ':':
            path = path + '\\'
        if not os.path.isabs(path):
            self._send_json({'ok': False, 'error': 'Se requiere ruta absoluta.'})
            return

        entries = []
        truncated = False
        try:
            with os.scandir(path) as it:
                for e in it:
                    if len(entries) >= 5000:
                        truncated = True
                        break
                    try:
                        is_dir = e.is_dir(follow_symlinks=False)
                        st = e.stat(follow_symlinks=False)
                        # Trailing sep en dir: ayuda al cliente a saber que
                        # es navegable y normaliza el match en operaciones
                        # posteriores.
                        suffix = ('\\' if is_dir and os.name == 'nt'
                                  else ('/' if is_dir else ''))
                        entries.append({
                            'file': e.path + suffix,
                            'name': e.name,
                            'is_dir': is_dir,
                            'size': st.st_size if not is_dir else None,
                            'lastmodified': int(st.st_mtime),
                        })
                    except OSError:
                        # Symlink roto, permiso en stat individual, etc.
                        continue
        except PermissionError:
            self._send_json({'ok': False, 'error': 'Permiso denegado en la carpeta.'})
            return
        except FileNotFoundError:
            self._send_json({'ok': False, 'error': 'La carpeta no existe.'})
            return
        except NotADirectoryError:
            self._send_json({'ok': False, 'error': 'No es una carpeta.'})
            return
        except OSError as e:
            # Drive no listo (CD/USB), red, filesystem corrupto.
            self._send_json({'ok': False,
                             'error': f'No se pudo leer la carpeta (errno={e.errno}).'})
            return

        # Carpetas primero, alfabético dentro de cada grupo.
        entries.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
        parent = os.path.dirname(path.rstrip('/\\')) or None
        # En Windows, parent de "C:\" es "C:" (raro). Si parent quedó como
        # drive letter sin sep, normalizamos a None (volver a las raíces).
        if parent and os.name == 'nt' and len(parent) == 2 and parent[1] == ':':
            parent = ''  # vacío → raíces
        self._send_json({'ok': True, 'entries': entries,
                         'parent': parent, 'truncated': truncated})

    def _handle_trash_list(self):
        """GET /api/library/fb/trash/list: lista de items en la papelera +
        config actual (max_items, enabled). cleanup_orphans en el primer call
        de cada sesión barre items inconsistentes (manifest corrupto, payload
        huérfano)."""
        from lib.remote import trash
        addon = xbmcaddon.Addon()
        enabled = addon.getSettingBool('file_browser.trash.enabled')
        try:
            max_items = int(addon.getSetting('file_browser.trash.max_items') or 10)
        except (ValueError, TypeError):
            max_items = 10
        # Barrido perezoso de items inconsistentes (cheap si todo OK).
        trash.cleanup_orphans()
        items = trash.list_trash()
        self._send_json({'ok': True, 'items': items,
                         'max_items': max(1, min(100, max_items)),
                         'enabled': enabled})

    def _handle_artwork(self, query):
        qs = urllib.parse.parse_qs(query)
        u = qs.get('u', [''])[0]
        if not u:
            self._send(400, b'invalid url')
            return

        # Strip de opciones tipo "url|user-agent=...&session_type=art" que
        # algunos addons (SlyGuy) usan en favoritos. No aplica a image://, que
        # no usa | como separador.
        if not u.startswith('image://') and '|' in u:
            u = u.split('|', 1)[0].strip()

        # Proxy local SlyGuy: http://127.0.0.1:<puerto>/https://cdn.example.com/img.jpg
        # SlyGuy puede no estar escuchando; extraemos la URL interna y la fetcamos directo.
        if u.startswith('http://127.0.0.1:'):
            slash = u.find('/', len('http://127.0.0.1:'))
            if slash != -1:
                inner = u[slash + 1:]
                if inner.startswith(('http://', 'https://')):
                    u = inner

        # 1) Formato image:// (Kodi envuelve HTTP(S) o special:// aquí).
        if u.startswith('image://'):
            inner = _decode_image_url(u)

            if inner and inner.startswith(('http://', 'https://')):
                self._artwork_proxy_http(inner)
                return

            if inner and inner.startswith('special://'):
                self._artwork_serve_special(inner)
                return

            # Ruta local absoluta codificada en image:// (browse items de plugins
            # que usan setArt con rutas Windows). Servir directamente del disco.
            if inner and _os.path.isabs(inner) and _is_safe_local_image(inner):
                self._artwork_serve_local(inner)
                return

            # Fallback al webserver de Kodi (artwork interno de la biblioteca:
            # cachés generados por Kodi que solo el webserver sabe servir).
            from lib.remote import kodi_webserver
            if not kodi_webserver.is_enabled():
                log.info(f'artwork: webserver_off, no se puede servir {u[:120]!r}')
                self._send(503, b'kodi webserver disabled',
                           extra_headers=[('X-Loio-Reason', 'webserver_off')])
                return
            target = kodi_webserver.image_url(u)
            if not target:
                self._send(400, b'invalid url')
                return
            try:
                import urllib.request as _urlreq
                req = _urlreq.Request(target)
                user, pwd = kodi_webserver.get_credentials()
                if user:
                    import base64
                    tok = base64.b64encode(f'{user}:{pwd or ""}'.encode()).decode()
                    req.add_header('Authorization', f'Basic {tok}')
                with _urlreq.urlopen(req, timeout=10) as resp:
                    body = resp.read()
                    ct = resp.headers.get('Content-Type', 'image/jpeg')
            except Exception as e:
                log.warning(f'artwork proxy falló: {e}')
                self._send(502, b'upstream error')
                return
            self._send(200, body, ct,
                       extra_headers=[('Cache-Control', 'public, max-age=3600')])
            return

        # 2) URL HTTP(S) directa: favoritos.xml puede guardar thumbs como URL
        # sin envolverlas en image:// (CDN, mirrors, proxies locales de addons).
        if u.startswith(('http://', 'https://')):
            self._artwork_proxy_http(u)
            return

        # 3) Ruta local absoluta: favoritos.xml también almacena thumbs como
        # "C:\...\addons\X\icon.png" sin envolver. Validamos contra
        # _ADDONS_DIRS para impedir leer archivos arbitrarios del sistema.
        if _os.path.isabs(u) and _is_safe_local_image(u):
            self._artwork_serve_local(u)
            return

        log.security(f'artwork rechazado: scheme inválido u={u[:80]!r}')
        self._send(400, b'invalid url')

    def _artwork_proxy_http(self, url):
        """Proxy directo de URL HTTP(S) (típico: posters de TMDB/IMDB que un
        plugin referencia). Limitamos tamaño, tipo y destino para evitar
        abuso: solo hosts públicos (guarda SSRF) y TLS verificado."""
        if not _artwork_url_allowed(url):
            log.security(f'artwork SSRF bloqueado: {url[:120]!r}')
            self._send(403, b'forbidden target')
            return
        _opener = _build_artwork_opener()
        try:
            with _opener.open(url, timeout=3) as resp:
                ct = resp.headers.get('Content-Type', 'image/jpeg')
                if not ct.startswith('image/'):
                    log.security(f'artwork http: content-type no-imagen {ct!r}')
                    self._send(502, b'not an image')
                    return
                # Cap a 8 MB: thumbnails legítimos son < 2 MB.
                body = resp.read(8 * 1024 * 1024 + 1)
                if len(body) > 8 * 1024 * 1024:
                    self._send(502, b'image too large')
                    return
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as e:
            log.sensitive(f'artwork http {url[:80]!r}: {e}')
            self._send(502, b'upstream error')
            return
        self._send(200, body, ct,
                   extra_headers=[('Cache-Control', 'public, max-age=3600')])

    def _artwork_serve_special(self, vpath):
        """Sirve un recurso bajo special:// del filesystem (icons/fanart de
        addons). Solo dejamos ubicaciones públicas read-only; nunca
        special://userdata, profile, masterprofile, temp, etc., donde puede
        haber datos privados.
        """
        if not _is_safe_special_image(vpath):
            log.security(f'artwork special rechazado: {vpath[:80]!r}')
            self._send(403, b'forbidden')
            return
        path = _translate_safe_special(vpath)
        if not path or not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        # Solo extensiones de imagen reconocidas: `special://home/addons/X/`
        # contiene también source code, configs y otros archivos sensibles que
        # NO debemos exponer aunque la carpeta padre sea "pública".
        ext = _os.path.splitext(path)[1].lower()
        ct = _STATIC_MIME.get(ext)
        if not ct or not ct.startswith('image/'):
            self._send(403, b'not an image')
            return
        try:
            with open(path, 'rb') as f:
                body = f.read()
        except OSError as e:
            log.sensitive(f'artwork special read {path!r}: {e}')
            self._send(404, b'not found')
            return
        self._send(200, body, ct,
                   extra_headers=[('Cache-Control', 'public, max-age=3600')])

    def _artwork_serve_local(self, path):
        """Sirve un archivo de imagen local. El caller DEBE haber validado
        con _is_safe_local_image() antes de llamar.
        """
        ct = _STATIC_MIME.get(_os.path.splitext(path)[1].lower())
        try:
            with open(path, 'rb') as f:
                body = f.read()
        except OSError as e:
            log.sensitive(f'artwork local read {path!r}: {e}')
            self._send(404, b'not found')
            return
        self._send(200, body, ct,
                   extra_headers=[('Cache-Control', 'public, max-age=3600')])

    # --- Backup / restauración ---
    #
    # Sub-paths bajo /api/backup/. Gestión remota gated por la misma
    # setting que el resto: 'remote.allow_addon_management'. Sin ese
    # consent explícito, devolvemos 403 y el frontend oculta la sección.

    def _handle_backup_get(self, subpath, query):
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        if subpath == 'manifest':
            self._handle_backup_manifest_json()
            return
        if subpath == 'manifest.txt':
            self._handle_backup_manifest_txt()
            return
        if subpath == 'list':
            self._handle_backup_list()
            return
        if subpath.startswith('download/'):
            self._handle_backup_download(subpath[len('download/'):])
            return
        if subpath == 'favourites':
            self._handle_backup_favourites_download()
            return
        if subpath == 'favourites/backups':
            self._handle_backup_favourites_backups_list()
            return
        if subpath.startswith('favourites/backup/'):
            self._handle_backup_favourites_backup_content(
                subpath[len('favourites/backup/'):])
            return
        if subpath.startswith('peek/'):
            self._handle_backup_peek(subpath[len('peek/'):])
            return
        if subpath.startswith('dry_run/'):
            self._handle_backup_dry_run(subpath[len('dry_run/'):])
            return
        if subpath.startswith('job/'):
            self._handle_backup_job_status(subpath[len('job/'):])
            return
        self._send(404, b'not found')

    def _handle_backup_post(self, subpath, body):
        if not _addon_mgmt_enabled():
            self._send(403, b'addon management disabled in settings')
            return
        if subpath == 'create':
            self._handle_backup_create(body)
            return
        if subpath == 'delete':
            self._handle_backup_delete(body)
            return
        if subpath == 'restore':
            self._handle_backup_restore(body)
            return
        if subpath == 'install_xml':
            self._handle_backup_install_xml(body)
            return
        if subpath == 'export':
            self._handle_backup_export(body)
            return
        if subpath == 'sanitize':
            self._handle_backup_sanitize(body)
            return
        if subpath == 'import':
            self._handle_backup_import(body)
            return
        if subpath == 'favourites/import':
            self._handle_backup_favourites_import(body)
            return
        if subpath == 'migrate':
            self._handle_backup_migrate(body)
            return
        if subpath.startswith('job/') and subpath.endswith('/cancel'):
            jid = subpath[len('job/'):-len('/cancel')]
            self._handle_backup_job_cancel(jid)
            return
        self._send(404, b'not found')

    def _handle_backup_manifest_json(self):
        from lib import backup
        try:
            manifest = backup.build_manifest()
        except Exception as e:
            log.warning(f'backup manifest build failed: {e!r}')
            self._send(500, b'manifest build failed')
            return
        body = json.dumps(manifest, ensure_ascii=False).encode('utf-8')
        self._send(200, body, 'application/json')

    def _handle_backup_manifest_txt(self):
        from lib import backup
        try:
            manifest = backup.build_manifest()
            text = backup.export_txt(manifest)
        except Exception as e:
            log.warning(f'backup manifest txt failed: {e!r}')
            self._send(500, b'manifest build failed')
            return
        body = text.encode('utf-8')
        stamp = time.strftime('%Y%m%d_%H%M%S')
        filename = f'kodi_addons_{stamp}.txt'
        self._send(200, body, 'text/plain; charset=utf-8',
                   extra_headers=[
                       ('Content-Disposition',
                        f'attachment; filename="{filename}"'),
                   ])

    def _handle_backup_list(self):
        from lib import backup
        try:
            snapshots = backup.list_snapshots()
        except Exception as e:
            log.warning(f'backup list failed: {e!r}')
            self._send(500, b'list failed')
            return
        self._send_json({'snapshots': snapshots})

    def _handle_backup_migrate(self, body):
        """Migra todos los snapshots entre dos storages."""
        from lib import backup, backup_jobs
        from_name = body.get('from') or 'default'
        to_name = body.get('to') or 'custom'
        delete_source = bool(body.get('delete_source', False))
        if from_name not in ('default', 'custom') \
                or to_name not in ('default', 'custom'):
            self._send(400, b'invalid storage names')
            return
        if from_name == to_name:
            self._send(400, b'from y to no pueden ser iguales')
            return

        def _runner(progress_cb=None, cancel_check=None):
            return backup.migrate_snapshots(
                from_name, to_name,
                delete_source=delete_source,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )

        jid = backup_jobs.start_job('backup_migrate', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_export(self, body):
        """Exporta un snapshot a una ruta arbitraria."""
        from lib import backup, backup_jobs
        filename = body.get('filename', '')
        dest_path = body.get('dest_path', '')
        overwrite = bool(body.get('overwrite', False))
        if not isinstance(filename, str) or not isinstance(dest_path, str):
            self._send(400, b'invalid filename or dest_path')
            return
        if not filename or not dest_path:
            self._send(400, b'missing filename or dest_path')
            return

        def _runner(progress_cb=None, cancel_check=None):
            return backup.export_snapshot(
                filename, dest_path, overwrite=overwrite,
                progress_cb=progress_cb, cancel_check=cancel_check,
            )

        jid = backup_jobs.start_job('backup_export', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_sanitize(self, body):
        """Genera un ZIP compartible sanitizado.

        Elimina passwords.xml, tokens en addon_data y PII del manifest del
        backup original. Crea un nuevo snapshot que se puede enviar a
        otros usuarios sin filtrar credenciales propias.
        """
        from lib import backup, backup_jobs
        filename = body.get('filename', '')
        if not isinstance(filename, str) or not filename:
            self._send(400, b'invalid filename')
            return

        def _runner(progress_cb=None, cancel_check=None):
            return backup.sanitize_backup_for_sharing(
                filename,
                progress_cb=progress_cb, cancel_check=cancel_check,
            )

        jid = backup_jobs.start_job('backup_sanitize', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_import(self, body):
        """Importa un ZIP externo a SNAPSHOTS_DIR.

        Acepta dos fuentes:
          - source_path: ruta directa al ZIP en el sistema de archivos
          - entry_id: id de transfers (ZIP subido vía /upload/*)
        """
        from lib import backup, backup_jobs
        label = body.get('label')
        if label is not None and not isinstance(label, str):
            label = None
        validate = bool(body.get('validate', True))

        source_path = body.get('source_path', '')
        entry_id = body.get('entry_id', '')
        if not isinstance(source_path, str) or not isinstance(entry_id, str):
            self._send(400, b'invalid source')
            return
        if entry_id:
            from lib.transfers import history
            entry = history.get(entry_id)
            if not entry:
                self._send(404, b'entry not found')
                return
            source_path = entry.get('path') or ''
        if not source_path or not _os.path.isfile(source_path):
            self._send(404, b'source file not found')
            return

        def _runner(progress_cb=None, cancel_check=None):
            return backup.import_snapshot(
                source_path, label=label, validate=validate,
                progress_cb=progress_cb, cancel_check=cancel_check,
            )

        jid = backup_jobs.start_job('backup_import', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_dry_run(self, filename):
        """Informe pre-restore sin tocar disco."""
        from lib import backup
        try:
            path = backup.snapshot_path(filename)
        except backup.BackupError:
            self._send(400, b'invalid filename')
            return
        if not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            report = backup.dry_run_restore(path)
        except Exception as e:
            log.warning(f'backup dry_run failed: {e!r}')
            self._send(500, b'dry_run failed')
            return
        self._send_json(report)

    def _handle_backup_peek(self, filename):
        """Devuelve resumen del backup (versión Kodi, totales) sin restaurar.

        El frontend lo usa para avisar del mismatch de versión Kodi antes de
        iniciar el restore (job asíncrono, no se podría cancelar ya empezado
        sin perder progreso).
        """
        from lib import backup
        try:
            path = backup.snapshot_path(filename)
        except backup.BackupError:
            self._send(400, b'invalid filename')
            return
        if not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            manifest = backup.load_manifest_from_zip(path)
        except backup.BackupError as e:
            self._send(400, str(e).encode('utf-8'))
            return
        info = backup.check_kodi_version_compat(manifest)
        # Si el manifest está cifrado, el stub solo trae metadata pública
        # (addons_count, created). El frontend prompt para password antes
        # del restore.
        is_encrypted = bool(manifest.get('encrypted'))
        self._send_json({
            'filename': filename,
            'kodi_version_check': info,
            'addons_count': len(manifest.get('addons') or [])
                            or manifest.get('addons_count', 0),
            'repos_count': len(manifest.get('repos') or []),
            'created': manifest.get('created'),
            'label': manifest.get('label'),
            'loiolink_version': manifest.get('loiolink_version'),
            'encrypted': is_encrypted,
        })

    def _handle_backup_download(self, filename):
        from lib import backup
        try:
            path = backup.snapshot_path(filename)
        except backup.BackupError:
            self._send(400, b'invalid filename')
            return
        if not _os.path.isfile(path):
            self._send(404, b'not found')
            return
        try:
            size = _os.path.getsize(path)
        except OSError:
            self._send(500, b'stat failed')
            return
        # Streaming chunked. ZIPs grandes (>200 MB) sin esto agotarían RAM.
        try:
            self.send_response(200)
            self._send_security_headers()
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Length', str(size))
            self.send_header(
                'Content-Disposition',
                f'attachment; filename="{filename}"')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            with open(path, 'rb') as fh:
                while True:
                    chunk = fh.read(64 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def _handle_backup_favourites_download(self):
        from lib import backup
        path = backup._FAVOURITES_PATH
        if not _os.path.isfile(path):
            self._send(404, b'favourites.xml no existe')
            return
        try:
            with open(path, 'rb') as fh:
                body = fh.read()
        except OSError:
            self._send(500, b'read failed')
            return
        stamp = time.strftime('%Y%m%d_%H%M%S')
        self._send(200, body, 'application/xml; charset=utf-8',
                   extra_headers=[
                       ('Content-Disposition',
                        f'attachment; filename="favourites_{stamp}.xml"'),
                   ])

    def _handle_backup_favourites_backups_list(self):
        from lib import backup
        items = backup.list_favourites_backups()
        self._send_json({'items': items})

    def _handle_backup_favourites_backup_content(self, filename):
        from lib import backup
        try:
            path = backup._validate_favourites_backup_name(filename)
        except backup.BackupError as e:
            self._send(404, str(e).encode('utf-8'))
            return
        try:
            with open(path, 'rb') as fh:
                body = fh.read()
        except OSError:
            self._send(500, b'read failed')
            return
        self._send(200, body, 'application/xml; charset=utf-8')

    def _handle_backup_favourites_import(self, body):
        from lib import backup
        xml_text = body.get('xml')
        mode = body.get('mode')
        if not isinstance(xml_text, str) or not isinstance(mode, str):
            self._send(400, b'xml y mode deben ser string')
            return
        if mode not in ('add', 'overwrite'):
            self._send(400, b"mode debe ser 'add' u 'overwrite'")
            return
        if len(xml_text) > 4 * 1024 * 1024:
            self._send(413, b'xml demasiado grande')
            return
        try:
            result = backup.import_favourites(xml_text, mode)
        except backup.BackupError as e:
            self._send(400, str(e).encode('utf-8'))
            return
        except Exception as e:
            log.warning(f'backup favourites import failed: {e!r}')
            self._send(500, b'import failed')
            return
        self._send_json(result)

    def _handle_backup_job_status(self, job_id):
        from lib import backup_jobs
        if not job_id or '/' in job_id:
            self._send(400, b'invalid job id')
            return
        job = backup_jobs.get_job(job_id)
        if job is None:
            self._send(404, b'job not found')
            return
        self._send_json(job)

    def _handle_backup_job_cancel(self, job_id):
        from lib import backup_jobs
        if not job_id or '/' in job_id:
            self._send(400, b'invalid job id')
            return
        ok = backup_jobs.cancel_job(job_id)
        if not ok:
            self._send(404, b'job not found or already finished')
            return
        self._send_json({'ok': True})

    def _handle_backup_create(self, body):
        from lib import backup, backup_jobs
        mode = (body.get('mode') or 'full').lower()
        if mode not in ('full', 'custom'):
            self._send(400, b'invalid mode')
            return
        # Si el body no especifica una opción, usar el default del addon
        # (settings.xml). El body solo lleva lo que el user toca en el modal.

        def _setting_bool(key, fallback):
            try:
                if body.get(key) is None:
                    return xbmcaddon.Addon().getSettingBool(key)
                return bool(body.get(key))
            except (RuntimeError, AttributeError):
                return fallback

        if 'exclude_system' in body:
            exclude_system = bool(body['exclude_system'])
        else:
            exclude_system = _setting_bool(
                'backup.exclude_system_default', True)
        if 'exclude_skins' in body:
            exclude_skins = bool(body['exclude_skins'])
        else:
            exclude_skins = _setting_bool(
                'backup.exclude_skins_default', True)
        include_sources = bool(body.get('include_sources', True))
        include_favourites = bool(body.get('include_favourites', True))
        if 'include_addon_data' in body:
            include_addon_data = body['include_addon_data']
            if not isinstance(include_addon_data, (bool, dict)):
                include_addon_data = True
        else:
            include_addon_data = _setting_bool(
                'backup.include_addon_data_default', True)
        label = body.get('label')
        if label is not None and not isinstance(label, str):
            label = None
        # kodi_categories dict opcional {name: bool}. Validamos tipos para
        # no pasarle basura al backend.
        raw_categories = body.get('kodi_categories')
        kodi_categories = None
        if isinstance(raw_categories, dict):
            kodi_categories = {}
            for k, v in raw_categories.items():
                if isinstance(k, str) and isinstance(v, bool):
                    kodi_categories[k] = v
        if mode == 'full':
            # Enumera todo lo backupeable presente en addons/
            try:
                installed = _os.listdir(backup._ADDONS_DIR)
            except OSError:
                installed = []
            addon_ids = []
            repo_ids = []
            for name in installed:
                if not backup._valid_addon_id(name):
                    continue
                if name.startswith('repository.'):
                    if name.startswith('repository.xbmc.'):
                        continue
                    repo_ids.append(name)
                else:
                    if backup.is_backupable(name,
                                            exclude_system=exclude_system,
                                            exclude_skins=exclude_skins):
                        addon_ids.append(name)
        else:
            raw_addons = body.get('addons') or []
            raw_repos = body.get('repos') or []
            if not isinstance(raw_addons, list) or not isinstance(raw_repos, list):
                self._send(400, b'addons/repos must be arrays')
                return
            addon_ids = [a for a in raw_addons if isinstance(a, str)]
            repo_ids = [r for r in raw_repos if isinstance(r, str)]

        # Rotación: keep configurable; default 5
        try:
            keep = int(xbmcaddon.Addon().getSetting('backup.snapshots.keep') or 5)
        except (ValueError, RuntimeError):
            keep = 5

        # Password de cifrado. Prioridad: (1) body.password,
        # (2) setting `backup.encryption.password` si encryption.enabled.
        encrypt_password = body.get('encrypt_password') or None
        if not encrypt_password:
            try:
                enc_enabled = xbmcaddon.Addon().getSettingBool(
                    'backup.encryption.enabled')
            except (RuntimeError, AttributeError):
                enc_enabled = False
            if enc_enabled:
                try:
                    stored = xbmcaddon.Addon().getSetting(
                        'backup.encryption.password') or ''
                except RuntimeError:
                    stored = ''
                if stored:
                    encrypt_password = stored
        # Validar tipo
        if encrypt_password is not None:
            if not isinstance(encrypt_password, str) or not encrypt_password.strip():
                encrypt_password = None

        def _runner(progress_cb=None, cancel_check=None):
            filename = backup.create_backup(
                addon_ids=addon_ids,
                repo_ids=repo_ids,
                include_addon_data=include_addon_data,
                include_sources=include_sources,
                include_favourites=include_favourites,
                label=label,
                exclude_system=exclude_system,
                exclude_skins=exclude_skins,
                kodi_categories=kodi_categories,
                encrypt_password=encrypt_password,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )
            backup.rotate_snapshots(keep)
            full = _os.path.join(backup.SNAPSHOTS_DIR, filename)
            size = _os.path.getsize(full) if _os.path.isfile(full) else 0
            return {'filename': filename, 'size': size,
                    'encrypted': bool(encrypt_password)}

        jid = backup_jobs.start_job('backup_create', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_delete(self, body):
        from lib import backup
        filename = body.get('filename', '')
        if not isinstance(filename, str):
            self._send(400, b'invalid filename')
            return
        try:
            ok = backup.delete_snapshot(filename)
        except backup.BackupBusyError:
            self._send(409, b'backup busy, retry shortly')
            return
        except backup.BackupError:
            self._send(400, b'invalid filename')
            return
        if not ok:
            self._send(404, b'not found')
            return
        self._send_json({'ok': True})

    def _handle_backup_restore(self, body):
        from lib import backup, backup_jobs
        mode = (body.get('mode') or 'files').lower()
        if mode not in ('files', 'repos'):
            self._send(400, b'invalid mode')
            return
        source = (body.get('source') or 'snapshot').lower()
        if source not in ('snapshot', 'transfer'):
            self._send(400, b'invalid source')
            return

        # Resolver ruta del ZIP según fuente
        if source == 'snapshot':
            filename = body.get('filename', '')
            if not isinstance(filename, str):
                self._send(400, b'invalid filename')
                return
            try:
                zip_path = backup.snapshot_path(filename)
            except backup.BackupError:
                self._send(400, b'invalid filename')
                return
        else:
            # Restaurar desde un entry de transferencia (uploaded ZIP)
            entry_id = body.get('entry_id')
            if not isinstance(entry_id, str) or not entry_id:
                self._send(400, b'invalid entry_id')
                return
            from lib.transfers import history
            entry = history.get(entry_id)
            if not entry:
                self._send(404, b'entry not found')
                return
            zip_path = entry.get('path')
            if not zip_path or not _os.path.isfile(zip_path):
                self._send(404, b'file not found')
                return

        if not _os.path.isfile(zip_path):
            self._send(404, b'zip not found')
            return

        raw_ids = body.get('addons')
        addon_ids = None
        if isinstance(raw_ids, list):
            addon_ids = [a for a in raw_ids if isinstance(a, str)]
        include_sources_mode = body.get('include_sources_mode') or 'merge'
        if include_sources_mode not in ('merge', 'overwrite', 'skip'):
            include_sources_mode = 'merge'
        include_favourites = bool(body.get('include_favourites', False))
        # Restore selectivo de categorías Kodi. Acepta 'all', null/missing
        # (default None = nada), o lista de nombres.
        raw_cats = body.get('restore_categories')
        if raw_cats == 'all':
            restore_categories = 'all'
        elif isinstance(raw_cats, list):
            restore_categories = [c for c in raw_cats if isinstance(c, str)]
            if not restore_categories:
                restore_categories = None
        else:
            restore_categories = None

        # Password opcional para backups cifrados.
        password = body.get('password') or None
        if password is not None and not isinstance(password, str):
            password = None

        if mode == 'files':
            def _runner(progress_cb=None, cancel_check=None):
                return backup.restore_from_zip(
                    zip_path,
                    addon_ids=addon_ids,
                    include_sources_mode=include_sources_mode,
                    include_favourites=include_favourites,
                    restore_categories=restore_categories,
                    password=password,
                    progress_cb=progress_cb,
                    cancel_check=cancel_check,
                )
        else:
            # Modo "repos": leer manifest del ZIP y reinstalar desde repo.
            try:
                manifest = backup.load_manifest_from_zip(
                    zip_path, password=password,
                )
            except backup.ManifestError as e:
                # Si requiere password, indicarlo explícitamente al frontend
                msg = str(e)
                if 'password' in msg.lower():
                    body = json.dumps(
                        {'error': msg, 'requires_password': True}
                    ).encode('utf-8')
                    self._send(401, body, 'application/json')
                    return
                self._send(400, str(e).encode('utf-8'))
                return
            if manifest.get('encrypted'):
                # Stub devuelto sin password real → no se puede restaurar
                body = json.dumps({
                    'error': 'backup cifrado; password requerido',
                    'requires_password': True,
                }).encode('utf-8')
                self._send(401, body, 'application/json')
                return

            def _runner(progress_cb=None, cancel_check=None):
                return backup.restore_from_manifest(
                    manifest,
                    addon_ids=addon_ids,
                    progress_cb=progress_cb,
                    cancel_check=cancel_check,
                )

        jid = backup_jobs.start_job('backup_restore', _runner)
        self._send_json({'job_id': jid})

    def _handle_backup_install_xml(self, body):
        from lib import backup, backup_jobs
        entry_id = body.get('entry_id')
        if not isinstance(entry_id, str) or not entry_id:
            self._send(400, b'invalid entry_id')
            return
        from lib.transfers import history
        entry = history.get(entry_id)
        if not entry:
            self._send(404, b'entry not found')
            return
        xml_path = entry.get('path')
        if not xml_path or not _os.path.isfile(xml_path):
            self._send(404, b'file not found')
            return

        def _runner(progress_cb=None, cancel_check=None):
            return backup.install_from_xml(
                xml_path,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )

        jid = backup_jobs.start_job('backup_install_xml', _runner)
        self._send_json({'job_id': jid})


def _identify_competitor(body, content_type, parsed_json):
    """Heurística para identificar qué servicio responde en nuestro puerto.

    Mira el body (truncado a 2 KB), el Content-Type y el JSON parseado (si lo
    es) buscando marcadores conocidos. Devuelve un string corto para meter en
    el log del usuario, no para parsing automatizado.

    parsed_json puede ser None o cualquier tipo JSON (dict, list, str, number).
    Solo intentamos `.get()` si es dict; un competidor puede devolver
    `"texto plano"` o `[1, 2]` como JSON válido y eso no es un AttributeError.

    content_type debe ser string (vacío si no había header). El caller en
    _self_check lo garantiza con `(headers.get(...) or '').lower()`.
    """
    body_lc = (body or b'').lower()
    if b'slyguy' in body_lc:
        return 'slyguy'
    if isinstance(parsed_json, dict) and parsed_json.get('service'):
        return f"service={parsed_json['service']!r}"
    if content_type.startswith('video/') or 'mpegurl' in content_type:
        return 'proxy de streaming (HLS/MP4)'
    if content_type.startswith('application/octet-stream'):
        return 'binario (probable proxy de streaming)'
    if content_type.startswith('application/dash'):
        return 'proxy DASH'
    if content_type.startswith('text/html'):
        return 'servidor HTTP genérico'
    # Body sanitizado a ASCII printable: bytes raros romperían el log de Kodi.
    # 80 chars bastan para ver el banner del interceptor (NordVPN Threat
    # Protection, AV con web shield, portal cautivo, etc.) y diagnosticar.
    snippet = bytes(b for b in body_lc[:80] if 32 <= b < 127).decode('ascii', 'replace')
    ct_part = f' ct={content_type!r}' if content_type else ''
    return f'no identificado{ct_part} body[:80]={snippet!r}'


def _self_check(port, is_https):
    """Confirma que las respuestas en `port` vienen de ESTE proceso (loiolink).

    Hace GET a 127.0.0.1:<port>/health y verifica que el JSON devuelve nuestro
    `_INSTANCE_NONCE`. Si otro proceso comparte el puerto vía SO_REUSEADDR
    (caso típico: script.module.slyguy con su proxy en 127.0.0.1:8095), el SO
    entrega los paquetes locales al socket más específico y la respuesta no
    será nuestra. Tres intentos con 50ms entre ellos para absorber errores
    de red transientes (IncompleteRead, ConnectionReset al cerrar conexiones
    keep-alive, etc.); el caller en `start()` ya garantiza accept-ready con
    `threading.Event`, así que el retraso de `serve_forever` no es un factor.

    Verificación contra 127.0.0.1 (no get_local_ip()): es exactamente la
    interfaz que los proxies locales suelen "robar"; la LAN no la usan.

    Returns:
        (True, None) si la respuesta es nuestra.
        (False, hint) si el puerto está secuestrado; `hint` describe al
        competidor (ej. 'slyguy', 'proxy de streaming').
        (None, mensaje) si nada responde tras 3 reintentos: caso
        indeterminado (filtro de loopback intra-process).
    """
    scheme = 'https' if is_https else 'http'
    url = f'{scheme}://127.0.0.1:{port}/health'
    ctx = ssl._create_unverified_context() if is_https else None
    # Bypass del proxy de sistema: NordVPN, ProtonVPN, antivirus con web shield
    # y proxies corporativos inyectan ajustes en WinInet que urllib hereda.
    # Aplicarlos a una consulta loopback al propio proceso no tiene sentido y
    # rompe el self-check (el proxy responde con 404 → falso "hijack").
    handlers = [urllib.request.ProxyHandler({})]
    if ctx is not None:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    opener = urllib.request.build_opener(*handlers)
    last_err = None
    for _ in range(3):
        try:
            with opener.open(url, timeout=2) as r:
                body = r.read(2048)
                ct = (r.headers.get('Content-Type') or '').lower()
                try:
                    data = json.loads(body.decode('utf-8'))
                except (ValueError, UnicodeDecodeError):
                    data = None
                # isinstance(data, dict): el competidor podría devolver
                # `"texto"` o `[1,2]` como JSON válido; `.get` crashearía.
                if (isinstance(data, dict)
                        and data.get('service') == 'loiolink'
                        and data.get('nonce') == _INSTANCE_NONCE):
                    return True, None
                # Respuesta válida pero no es la nuestra → puerto secuestrado.
                return False, _identify_competitor(body, ct, data)
        except urllib.error.HTTPError as e:
            # Algo respondió pero con error no-2xx: es un servidor, no nosotros.
            try:
                body = e.read(2048)
            except OSError:
                body = b''
            ct = (e.headers.get('Content-Type') or '').lower() if e.headers else ''
            return False, _identify_competitor(body, ct, None)
        except (urllib.error.URLError, OSError, ValueError, UnicodeDecodeError,
                http.client.HTTPException) as e:
            # HTTPException cubre IncompleteRead, BadStatusLine y otros
            # errores low-level que urllib NO envuelve siempre en URLError;
            # típicos cuando el competidor cierra la conexión durante el read.
            # Guardamos el último error para que el `return None` final tenga
            # contexto: ConnectionRefused = thread muerto, timed out = filtro
            # WFP, SSLError = handshake roto, ProxyError = ProxyHandler({}) no aplicó.
            last_err = f'{type(e).__name__}: {e}'[:200]
            time.sleep(0.05)
    # Tras 3 intentos sin respuesta: caso indeterminado. NO confirmamos hijack
    # ni "nuestro". Visto en entornos donde algún driver WFP (NordVPN, otros
    # VPN/AV con filtro de red) intercepta el loopback intra-process: el bind
    # y los clientes externos funcionan, pero urlopen desde el mismo proceso
    # al 127.0.0.1 propio timeoutea. El caller decide qué hacer.
    return None, f'sin respuesta del propio servidor (last_err={last_err})'


def start():
    """Bindea el primer puerto libre y verificado del rango. Devuelve
    (server, port) o (None, 0) si ninguno responde con nuestro nonce.

    Si el setting `remote_https_enabled` está activo, intenta envolver el
    socket con TLS (cert autofirmado generado/cacheado por lib.remote.tls).
    Si openssl no está disponible o la generación falla, cae a HTTP plano
    con warning; el panel sigue funcionando.

    Self-check post-bind detecta colisiones donde otro servicio (slyguy,
    proxies locales) comparte el socket: bind y serve_forever arrancan pero
    las respuestas en 127.0.0.1:<port> las sirve el otro. En ese caso
    apagamos limpio y probamos el siguiente puerto del rango.
    """
    from lib.remote import tls
    start_port = _get_port_start()

    # Diagnóstico del entorno de red al arrancar (y en cada reintento cada
    # _BIND_BACKOFF_S si fallamos). Aunque _self_check usa ProxyHandler({}),
    # saber qué heredaría urllib por defecto explica comportamientos raros
    # si la defensa fallase o aparece un nuevo proxy entre reintentos.
    try:
        env_proxies = urllib.request.getproxies()
    except Exception as e:
        env_proxies = {'__error__': f'{type(e).__name__}: {e}'}
    log.sensitive(
        f'start() port_range={start_port}..'
        f'{start_port + _PORT_RANGE} sys_proxies={env_proxies}',
    )

    ssl_context = None
    if tls.is_https_enabled():
        ip = get_local_ip()
        cert, key = tls.get_or_generate_cert(ip) if ip else (None, None)
        if cert and key:
            ssl_context = tls.build_ssl_context(cert, key)
        if ssl_context is None:
            xbmc.log(
                f'{_LOG_PREFIX} HTTPS pedido pero no disponible; fallback a HTTP',
                xbmc.LOGWARNING,
            )

    # Tracking de bodies devueltos por self-check `False`. Si los N puertos
    # del rango devuelven el MISMO body, no son N competidores distintos
    # sino UN interceptor universal de loopback (driver WFP, AV, proxy
    # transparente). En ese caso el bind sigue siendo útil para clientes
    # externos en LAN; fallback al final del bucle.
    hijack_hints = []
    first_bound_srv = None
    first_bound_port = 0
    first_bound_thread = None

    for port in range(start_port, start_port + _PORT_RANGE + 1):
        try:
            srv = _RemoteServer(('', port), _RemoteHandler)
        except OSError:
            continue
        if ssl_context is not None:
            srv.socket = ssl_context.wrap_socket(srv.socket, server_side=True)
        # Scheme REAL con el que se bindeó, no el que pide el setting: si
        # HTTPS estaba activado pero openssl no estaba disponible (Android,
        # Fire TV) el fallback a HTTP de arriba es silencioso, y quien
        # construye el QR necesita saberlo o el móvil intenta TLS contra un
        # socket en claro. Mismo patrón que el `_scheme` del servidor de
        # texto, que service.py ya publica en una Window property.
        srv._scheme = 'https' if ssl_context is not None else 'http'

        # Event para sincronizar accept-ready y detectar muerte temprana del
        # thread. Sin esto: _self_check corre a ciegas; si serve_forever
        # explota pre-accept (handshake TLS roto, OOM, etc.), start() devuelve
        # un server zombie y nadie se entera.
        accepting = threading.Event()
        def _runner(s=srv, ev=accepting, p=port):
            ev.set()
            try:
                s.serve_forever()
            except Exception as exc:
                xbmc.log(
                    f'{_LOG_PREFIX} serve_forever murió en :{p}: '
                    f'{type(exc).__name__}: {exc}',
                    xbmc.LOGERROR,
                )
        t = threading.Thread(
            target=_runner, name='loiolink-remote-http', daemon=True,
        )
        t.start()
        is_https = ssl_context is not None

        if not accepting.wait(2.0):
            xbmc.log(
                f'{_LOG_PREFIX} thread no señalizó accept-ready en :{port} '
                '(probable crash pre-accept); probando siguiente',
                xbmc.LOGWARNING,
            )
            try:
                srv.shutdown()
                srv.server_close()
            except OSError:
                pass
            continue

        # Doble self-check: el primero pilla competidores que YA estaban; el
        # segundo (tras ~1 s) pilla competidores que arrancan después y bindean
        # 127.0.0.1 con SO_REUSEADDR; caso real observado: slyguy +68 ms.
        # _self_check devuelve True (nuestro), False (otro servicio respondió)
        # o None (sin respuesta; entorno con filtro de loopback intra-process).
        reason = None
        ok, hint = _self_check(port, is_https)
        if ok is False:
            hijack_hints.append((port, hint))
            # Truncado: el hint puede llevar un `service` field controlado
            # por el competidor (hasta 2 KB del body parseado). 200 chars
            # bastan para identificación sin contaminar el log.
            reason = f'colisiona con otro servicio ({hint[:200]})'
        elif ok is None:
            # Indeterminado. Visto en entornos con WFP/algún AV que intercepta
            # el loopback intra-process: bind() funciona y los clientes
            # externos (móvil por LAN) ven el servidor, pero el urlopen del
            # propio Kodi al 127.0.0.1 timeoutea. Aceptamos el bind: si hubiera
            # hijack real, el competidor respondería con contenido distinto y
            # caería en `ok is False`.
            xbmc.log(
                f'{_LOG_PREFIX} self-check indeterminado en :{port} ({hint}); '
                'aceptando bind (los clientes externos sí podrán conectar)',
                xbmc.LOGWARNING,
            )
        else:
            time.sleep(_HIJACK_DETECT_DELAY_S)
            ok2, hint2 = _self_check(port, is_https)
            if ok2 is False:
                reason = f'secuestrado tras bind por {hint2[:200]} (competidor arrancó después)'
            elif ok2 is None:
                # Primer check pasó, segundo no responde. Raro pero no fatal:
                # los clientes externos probablemente siguen funcionando.
                xbmc.log(
                    f'{_LOG_PREFIX} segundo self-check indeterminado en :{port} '
                    f'({hint2}); manteniendo bind',
                    xbmc.LOGWARNING,
                )

        # Verificación de vida del thread tras los self-checks. El Event setea
        # ANTES de serve_forever, así que no detecta crashes ocurridos
        # inmediatamente después (excepción lanzada al entrar al loop). Si el
        # thread murió, el self-check habría dado ConnectionRefused → ok is None
        # → "aceptaríamos" un server zombie. Cubre crash post-set, durante
        # primer check, durante el sleep entre checks, durante segundo check.
        if not t.is_alive():
            xbmc.log(
                f'{_LOG_PREFIX} thread del server murió en :{port} '
                '(serve_forever lanzó excepción tras arrancar); '
                'probando siguiente',
                xbmc.LOGWARNING,
            )
            try:
                srv.shutdown()
                srv.server_close()
            except OSError:
                pass
            continue

        if reason is None:
            proto = 'HTTPS' if is_https else 'HTTP'
            xbmc.log(
                f'{_LOG_PREFIX} server permanente {proto} en puerto {port}',
                xbmc.LOGINFO,
            )
            # Si ya teníamos un first_bound guardado de iteraciones anteriores
            # (caso: 1+ puertos `False` antes de uno OK), cerrarlo limpio.
            if first_bound_srv is not None and first_bound_srv is not srv:
                try:
                    first_bound_srv.shutdown()
                    first_bound_srv.server_close()
                except OSError:
                    pass
            return srv, port

        # Guardamos el primer bind viable por si activamos el fallback de
        # "interceptor universal" al final del bucle. No cerramos srv aquí.
        # Guardamos también el thread para chequear is_alive() al final.
        if first_bound_srv is None:
            first_bound_srv = srv
            first_bound_port = port
            first_bound_thread = t
        else:
            try:
                srv.shutdown()
                srv.server_close()
            except OSError:
                pass

        xbmc.log(
            f'{_LOG_PREFIX} puerto {port} {reason}; probando siguiente',
            xbmc.LOGWARNING,
        )

    # Fallback "interceptor universal": si >=3 puertos dieron False con bodies
    # equivalentes (mismo prefijo de 60 chars), no son N competidores distintos
    # sino UN filtro/proxy interceptando todo loopback. El bind del primer
    # puerto sigue siendo útil para clientes externos en LAN (el self-check
    # loopback intra-process es lo único roto).
    if (first_bound_srv is not None
            and first_bound_thread is not None
            and first_bound_thread.is_alive()
            and len(hijack_hints) >= 3):
        prefixes = {h[:60] for _, h in hijack_hints}
        if len(prefixes) == 1:
            xbmc.log(
                f'{_LOG_PREFIX} TODOS los puertos del rango respondieron con el '
                f'MISMO body ({len(hijack_hints)} puertos, hint={hijack_hints[0][1][:300]}). '
                'Asumiendo interceptor universal de loopback (driver WFP, AV o '
                f'proxy transparente). Aceptando bind en :{first_bound_port}; '
                'los clientes externos en LAN podrán conectar.',
                xbmc.LOGWARNING,
            )
            return first_bound_srv, first_bound_port

    if first_bound_srv is not None:
        try:
            first_bound_srv.shutdown()
            first_bound_srv.server_close()
        except OSError:
            pass
    return None, 0


def stop(server):
    if server is None:
        return
    try:
        server.shutdown()
        server.server_close()
    except OSError as e:
        xbmc.log(f'{_LOG_PREFIX} error en shutdown: {e}', xbmc.LOGDEBUG)


_AUDIO_EXTS = frozenset({'.mp3', '.flac', '.aac', '.m4a', '.ogg', '.opus', '.wav'})

# Cap del paginado de endpoints API. Kodi clampea internamente pero
# devolver 5000 ítems ya es un response pesado (1-2 MB con art URLs).
_API_LIMIT_MAX = 5000
_API_LIMIT_DEFAULT = 500


def _is_audio_path(path_or_name):
    return _os.path.splitext(path_or_name or '')[1].lower() in _AUDIO_EXTS


def _parse_limit(qs):
    try:
        v = int(qs.get('limit', [str(_API_LIMIT_DEFAULT)])[0] or _API_LIMIT_DEFAULT)
    except (ValueError, TypeError):
        v = _API_LIMIT_DEFAULT
    return max(1, min(_API_LIMIT_MAX, v))


def _parse_offset(qs):
    try:
        v = int(qs.get('offset', ['0'])[0] or 0)
    except (ValueError, TypeError):
        v = 0
    return max(0, v)


# Caracteres prohibidos en cualquier filesystem soportado por Kodi.
# `/` y `\` son separadores en algún SO; NUL termina strings en C/POSIX.
_UNIVERSAL_INVALID_CHARS = set('/\\\x00')
# Adicionales bloqueados solo en Windows (NTFS/FAT); válidos en ext4/HFS+.
_WINDOWS_INVALID_CHARS = set(':*?"<>|')
# Nombres reservados Windows: CON, PRN, AUX, NUL, COM1-9, LPT1-9 (con o sin
# extensión). Crear con estos nombres falla o se redirige a un device.
_WIN_RESERVED_NAMES = frozenset({
    'con', 'prn', 'aux', 'nul',
    'com1', 'com2', 'com3', 'com4', 'com5', 'com6', 'com7', 'com8', 'com9',
    'lpt1', 'lpt2', 'lpt3', 'lpt4', 'lpt5', 'lpt6', 'lpt7', 'lpt8', 'lpt9',
})
# Límite por componente del path. Universal (NTFS, ext4, F2FS, APFS, HFS+).
_MAX_FILENAME_LEN = 255
_IS_WINDOWS = _os.name == 'nt'


def _is_valid_filename(name):
    """¿name es un nombre de archivo/carpeta seguro en la plataforma actual?

    Validación universal: vacío, whitespace, '/' '\\' NUL, '.' '..', >255 chars.
    En Windows además: comodines/comillas/pipe, trailing dot/space, reservados
    (CON, PRN, AUX, NUL, COM1-9, LPT1-9).
    """
    if not name or not name.strip():
        return False
    stripped = name.strip()
    if stripped in ('.', '..'):
        return False
    if len(name) > _MAX_FILENAME_LEN:
        return False
    if any(c in _UNIVERSAL_INVALID_CHARS for c in name):
        return False
    if _IS_WINDOWS:
        if any(c in _WINDOWS_INVALID_CHARS for c in name):
            return False
        if name[-1] in ('.', ' '):
            return False
        if name.split('.', 1)[0].lower() in _WIN_RESERVED_NAMES:
            return False
    return True


_MIME_BY_EXT = {
    '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime',
    '.mkv': 'video/x-matroska', '.webm': 'video/webm',
    '.3gp': 'video/3gpp', '.3g2': 'video/3gpp2', '.mj2': 'video/mj2',
    '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.aac': 'audio/aac',
    '.ogg': 'audio/ogg', '.opus': 'audio/opus', '.flac': 'audio/flac',
    '.wav': 'audio/wav',
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif',
    '.bmp': 'image/bmp', '.svg': 'image/svg+xml',
}


def _guess_content_type(path):
    ext = _os.path.splitext(path)[1].lower()
    return _MIME_BY_EXT.get(ext, 'application/octet-stream')


# --- Helpers de "Probar URL de fuente Kodi" (panel web) ---
_PASTE_SRC_SCHEMES = ('http://', 'https://', 'smb://', 'nfs://', 'ftp://')


def _is_paste_src_scheme(url):
    return isinstance(url, str) and url.lower().startswith(_PASTE_SRC_SCHEMES)


def _paste_src_ip_blocked(ip_str):
    """IP que paste_src no debe alcanzar: loopback (el propio Kodi en
    127.0.0.1:8080), link-local (metadata de cloud 169.254.169.254),
    reservadas/multicast/no-especificadas. NO bloquea rangos privados: un repo
    servido desde la LAN del usuario (NAS, servidor casero) es caso legítimo."""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    mapped = getattr(ip, 'ipv4_mapped', None)
    if mapped is not None:
        ip = mapped
    return (ip.is_loopback or ip.is_link_local or ip.is_reserved
            or ip.is_multicast or ip.is_unspecified)


def _paste_src_host_blocked(url):
    """True si el host de `url` resuelve a una IP que no debe alcanzarse.

    Sustituye al viejo check por-string (solo 4 literales): resuelve DNS, así
    que bloquea tanto una IP literal de loopback (127.0.0.2, ::1) como un
    hostname que apunte ahí (rebinding parcial) o a link-local. Si el host no
    resuelve, no bloquea aquí: la descarga fallará con su propio error.
    """
    try:
        host = urllib.parse.urlsplit(url).hostname or ''
    except ValueError:
        return True
    if not host:
        return True
    try:
        infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    except OSError:
        return False
    return any(_paste_src_ip_blocked(i[4][0]) for i in infos)


class _PasteSrcRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Revalida cada redirect contra la guarda SSRF de paste_src: un host
    público podría responder con un 302 a una IP interna y saltarse el check
    inicial (el opener por defecto sigue el redirect sin revalidar)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if _paste_src_host_blocked(newurl):
            log.security(f'[paste_src] SSRF bloqueado en redirect: {newurl[:120]!r}')
            raise urllib.error.HTTPError(newurl, 403, 'forbidden redirect',
                                         headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _build_paste_src_opener():
    """Opener para las descargas de paste_src: sin proxy de sistema, TLS
    verificado y redirects revalidados contra la guarda SSRF."""
    ctx = ssl.create_default_context()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ctx),
        _PasteSrcRedirectHandler(),
    )


def _paste_src_parse_zip_name(filename):
    """Devuelve (addon_id, version) o (None, None) si el nombre no encaja
    en el patrón `id-version.zip`. Sirve para enriquecer items de directory
    listings con info de instalación sin abrir el zip.
    """
    if not filename or not filename.lower().endswith('.zip'):
        return (None, None)
    base = filename[:-4]  # strip .zip
    # Buscar el último '-' seguido de un grupo "numérico con puntos".
    import re as _re
    m = _re.match(r'^(?P<id>.+)-(?P<ver>\d+(?:\.\d+)*)$', base)
    if not m:
        return (None, None)
    return (m.group('id'), m.group('ver'))


def _paste_src_installed_map():
    """Devuelve {addon_id: {'version': str, 'enabled': bool}} con TODOS los addons.

    Hace 2 llamadas JSON-RPC Addons.GetAddons (enabled=True y enabled=False)
    y las combina. Más fiable que pasar enabled='all' (no es valor estándar
    en Kodi 19+, donde el campo es boolean estricto).

    Si una llamada falla, devuelve lo que tenga. Si ambas fallan, devuelve
    {} y los items se muestran como "no instalado" sin romper el flujo.
    """
    import json as _json
    import xbmc as _xbmc

    def _query(enabled_flag):
        payload = {
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.GetAddons',
            'params': {'enabled': bool(enabled_flag), 'properties': ['version']},
        }
        try:
            raw = _xbmc.executeJSONRPC(_json.dumps(payload))
            data = _json.loads(raw)
        except (ValueError, RuntimeError, OSError) as e:
            log.warning(f'[paste_src] installed_map enabled={enabled_flag} falló: {e}')
            return []
        if 'error' in data:
            log.warning(f'[paste_src] installed_map enabled={enabled_flag} error: {data["error"]}')
            return []
        return (data.get('result') or {}).get('addons', []) or []

    out = {}
    for entry in _query(True):
        aid = entry.get('addonid')
        ver = entry.get('version') or ''
        if aid:
            out[aid] = {'version': ver, 'enabled': True}
    for entry in _query(False):
        aid = entry.get('addonid')
        ver = entry.get('version') or ''
        if aid and aid not in out:  # no machacar uno enabled con su clon disabled
            out[aid] = {'version': ver, 'enabled': False}
    return out


def _paste_src_version_tuple(v):
    """Convierte '1.10.2' en (1, 10, 2) para comparar. Igual que repos._version_tuple
    pero local para no importar lib.repos solo por esto."""
    import re as _re
    parts = []
    for part in _re.split(r'[.-]', v or ''):
        m = _re.match(r'^(\d+)', part)
        if m:
            parts.append(int(m.group(1)))
        else:
            break
    return tuple(parts)


def _paste_src_fetch_addons_xml(base_url):
    """Descarga addons.xml del base_url. Devuelve (texto, error_str|None).

    Mismo patrón que lib/actions/sources_repos_menu._fetch_addons_xml,
    duplicado aquí para evitar import circular entre el handler HTTP y
    los menús Kodi.
    """
    import socket
    import urllib.error
    import urllib.request
    url = base_url if base_url.endswith('/') else base_url + '/'
    url += 'addons.xml'
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
    })
    # Tope: 50 MB. Un addons.xml de repo grande ronda los pocos MB; cualquier
    # cosa mayor es servidor mal configurado o intento de DoS.
    max_bytes = 50 * 1024 * 1024
    try:
        with _build_paste_src_opener().open(req, timeout=10) as r:
            data = r.read(max_bytes + 1)
            if len(data) > max_bytes:
                return (None, f'addons.xml > {max_bytes // (1024*1024)} MB')
            return (data.decode('utf-8', errors='replace'), None)
    except socket.timeout:
        return (None, 'timeout')
    except (urllib.error.URLError, OSError, ValueError) as e:
        return (None, str(e))


def _paste_src_list_vfs(path, installed_map=None):
    """Lista carpetas/archivos vía xbmcvfs.listdir. Devuelve (items, error).

    items=None y error="texto" cuando listdir lanza. items=[] y error=None
    cuando responde pero está vacío (puede ser una URL que existe pero no
    expone listing). Items detecta .zip por extensión.

    installed_map: dict opcional `{addon_id: {version, enabled}}` para
    enriquecer items zip cuyo nombre encaje en `id-version.zip` con info
    de instalación. Si es None, no se enriquece (legacy / barato).
    """
    import xbmcvfs
    norm = path if path.endswith('/') else path + '/'
    try:
        listed = xbmcvfs.listdir(norm)
    except (OSError, RuntimeError, ValueError) as e:
        log.warning(f'[paste_src] listdir falló para {norm!r}: {e}')
        return (None, str(e) or 'listdir lanzó')
    if not listed or not isinstance(listed, (tuple, list)) or len(listed) != 2:
        # xbmcvfs puede devolver False en algunas builds si la URL no se
        # puede abrir. Tratar como fallo blando.
        return (None, 'respuesta vacía o inesperada de listdir')
    folders, files = listed
    items = []
    for f in sorted(folders or []):
        if not f:
            continue
        items.append({'type': 'folder', 'name': f, 'path': norm + f + '/'})
    for f in sorted(files or []):
        if not f:
            continue
        is_zip = f.lower().endswith('.zip')
        item = {'type': 'zip' if is_zip else 'file', 'name': f, 'path': norm + f}
        if is_zip and installed_map is not None:
            aid, ver = _paste_src_parse_zip_name(f)
            if aid:
                inst = installed_map.get(aid)
                item['addon_id'] = aid
                item['version'] = ver
                item['installed'] = bool(inst)
                item['installed_version'] = inst.get('version') if inst else None
                item['installed_enabled'] = inst.get('enabled') if inst else None
        items.append(item)
    return (items, None)


def _paste_src_detect_addon_id(zip_path):
    """Lee el zip y devuelve el id del addon a partir de su addon.xml interno.

    Asume estructura estándar Kodi: el zip contiene UN directorio top-level
    cuyo nombre coincide con el id, y dentro un addon.xml con `id="..."`.
    Devuelve None si no encuentra un addon.xml top-level.
    """
    import xml.etree.ElementTree as ET
    import zipfile
    try:
        with zipfile.ZipFile(zip_path) as z:
            for name in z.namelist():
                parts = name.split('/')
                if len(parts) == 2 and parts[1] == 'addon.xml':
                    text = z.read(name).decode('utf-8', errors='replace')
                    root = ET.fromstring(text)
                    aid = root.get('id')
                    if aid:
                        return aid
    except (zipfile.BadZipFile, OSError, ET.ParseError, KeyError) as e:
        log.warning(f'[paste_src] no se pudo leer addon.xml de {zip_path!r}: {e}')
    return None


def _paste_src_install_zip(zip_url, kind):
    """Descarga zip_url a un temp único y delega en installer.install_zip.

    Devuelve (ok, msg, installed_id). msg lleva la causa cuando ok=False.
    El temp file usa tempfile.mkstemp para evitar colisión entre dos
    instalaciones que se ejecuten concurrentemente (el mutex global del
    installer las serializa, pero el descargado del zip puede solaparse).
    """
    import socket
    import tempfile
    import urllib.error
    import urllib.request
    import xbmcvfs
    from lib import installer

    temp_dir = xbmcvfs.translatePath('special://temp/')
    fd, tmp = tempfile.mkstemp(prefix='paste_src_', suffix='.zip', dir=temp_dir)
    try:
        req = urllib.request.Request(zip_url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
        })
        oversized = False
        try:
            # Orden de los context managers: primero fdopen para que tome
            # ownership del fd; si urlopen lanza durante __enter__, el __exit__
            # de fdopen se ejecuta y cierra el fd correctamente.
            with _os.fdopen(fd, 'wb') as f, _build_paste_src_opener().open(req, timeout=60) as r:
                max_bytes = 200 * 1024 * 1024  # tope defensivo: 200 MB
                # Si Content-Length viene y excede, abortar sin descargar.
                cl = r.headers.get('Content-Length')
                if cl and cl.isdigit() and int(cl) > max_bytes:
                    return (False, f'ZIP demasiado grande según servidor ({int(cl)//(1024*1024)} MB).', None)
                written = 0
                while True:
                    chunk = r.read(64 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    written += len(chunk)
                    if written > max_bytes:
                        oversized = True
                        break
        except socket.timeout:
            return (False, 'Timeout descargando el ZIP (>60s).', None)
        except (urllib.error.URLError, OSError, ValueError) as e:
            return (False, f'No se pudo descargar el ZIP: {e}', None)
        if oversized:
            return (False, 'ZIP demasiado grande (>200 MB).', None)

        addon_id = _paste_src_detect_addon_id(tmp)
        if not addon_id:
            return (False, 'El ZIP no contiene un addon.xml válido.', None)
        if kind == 'repo' and not addon_id.startswith('repository.'):
            log.warning(f'[paste_src] kind=repo pero id no empieza por repository.: {addon_id}')
        try:
            ok = installer.install_zip(tmp, addon_id, kind=kind)
        except installer.InstallBusyError:
            return (False, 'Ya hay otra instalación en curso.', None)
        except installer.InstallError as e:
            return (False, f'Instalación rechazada: {e}', None)
        if ok:
            return (True, '', addon_id)
        return (False, f'No se pudo activar {addon_id} tras la instalación.', addon_id)
    finally:
        try:
            _os.unlink(tmp)
        except OSError:
            pass


# --- Helpers de descarga ZIP (F2.B) ---
# Extensiones ya comprimidas: dentro del ZIP se almacenan SIN compresión
# adicional (ZIP_STORED). Comprimir un .mp4 o .jpg con DEFLATE consume CPU
# sin reducir tamaño apreciable, y en sources de red puede ser el cuello
# de botella del addon.
_ZIP_STORED_EXTS = frozenset({
    '.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.flv', '.wmv',
    '.ts', '.m2ts', '.mpg', '.mpeg', '.3gp',
    '.mp3', '.flac', '.aac', '.m4a', '.ogg', '.opus',
    '.jpg', '.jpeg', '.png', '.gif', '.webp',
    '.zip', '.7z', '.rar', '.gz', '.bz2', '.xz', '.zst',
    '.pdf', '.docx', '.xlsx', '.pptx', '.epub',
})


def _zip_compression_for(name):
    import zipfile
    ext = _os.path.splitext(name)[1].lower()
    return zipfile.ZIP_STORED if ext in _ZIP_STORED_EXTS else zipfile.ZIP_DEFLATED


def _zip_add_file(zf, vfs_path, arcname, compression):
    """Añade UN archivo al ZipFile. Devuelve True si OK, False si se saltó.

    force_zip64=True cuando size desconocido o >= 2 GiB: necesario para
    archivos > 4 GB en stream sin seek (zipfile usa data descriptors).
    flag_bits |= 0x800 marca el filename como UTF-8 explícitamente.
    """
    import xbmcvfs
    import zipfile
    size = -1
    try:
        size = xbmcvfs.Stat(vfs_path).st_size()
    except (AttributeError, RuntimeError, OSError):
        size = -1
    force_zip64 = (size < 0) or (size >= (1 << 31))

    info = zipfile.ZipInfo(filename=arcname)
    info.compress_type = compression
    info.flag_bits |= 0x800  # UTF-8 filename

    # xbmcvfs.File() ANTES del bucle: si lanza (archivo desapareció
    # entre listdir y aquí, o read-protected), skip limpio sin haber
    # iniciado el ZipInfo entry; el ZIP queda válido sin la entrada.
    try:
        f = xbmcvfs.File(vfs_path)
    except (OSError, RuntimeError) as e:
        log.warning(f'zip: no se pudo abrir {arcname!r}: {e}')
        return False
    try:
        with zf.open(info, 'w', force_zip64=force_zip64) as zfp:
            while True:
                chunk = f.readBytes(64 * 1024)
                if not chunk:
                    break
                zfp.write(bytes(chunk))
        return True
    except (OSError, RuntimeError) as e:
        log.warning(f'zip: skip {arcname!r}: {e}')
        return False
    finally:
        try:
            f.close()
        except OSError:
            pass


class _BufferedWfile:
    """Wrapper sobre handler.wfile que acumula writes hasta 64 KB antes de
    volcar al socket. zipfile.ZipFile escribe en muchísimos writes pequeños
    (headers, descriptors, chunks) y mandar cada uno como packet TCP
    desperdicia ancho de banda. El buffer también detecta cliente caído:
    cuando wfile.write lanza BrokenPipe, marca broken=True y los siguientes
    writes son no-op, permitiendo al productor (BFS del ZIP) terminar
    limpiamente sin propagar la excepción a cada llamada.
    """

    def __init__(self, wfile):
        self.wfile = wfile
        self.buf = bytearray()
        self.broken = False

    def write(self, data):
        if not data:
            return 0
        if self.broken:
            return len(data)
        self.buf += data
        if len(self.buf) >= 65536:
            self._flush()
        return len(data)

    def flush(self):
        self._flush()

    def _flush(self):
        if not self.buf or self.broken:
            return
        try:
            self.wfile.write(bytes(self.buf))
        except (BrokenPipeError, ConnectionResetError,
                ConnectionAbortedError, OSError):
            self.broken = True
        self.buf = bytearray()

    def close(self):
        self._flush()


def _build_stream_page(*, title, start_s, stream_url, transcode_url,
                       sync_key=None, playable=True, reason='',
                       offer_transcode=False, ffmpeg_available=False,
                       is_audio=False):
    """HTML player para reproducir un archivo en el navegador del móvil.

    Llamado desde /stream-page/<entry_id> (sync_key = entry_id) y desde
    /library/stream-page?path=... (sync_key = None, no se reporta posición).

    Si is_audio=True, usa <audio> en vez de <video>; evita pantalla negra
    al reproducir mp3/flac/etc.

    Si playable=False, muestra warning con motivo. Si offer_transcode=True
    (ffmpeg disponible + archivo no es browser-playable), añade botón que
    cambia src a transcode_url. Si ffmpeg no está, solo mensaje.

    `loadedmetadata` es el evento correcto para currentTime: antes de él
    el browser no conoce la duration y el seek se ignora.
    """
    safe_title = html.escape(title or '')
    show_player = playable or offer_transcode
    warning_html = ''
    if not playable:
        warning_html = (
            f'<div class="warn show">No se reproducirá directamente: '
            f'{html.escape(reason)}'
            f'<button class="warn-close" onclick="this.closest(\'.warn\').remove()" title="Cerrar">&times;</button>'
            f'</div>'
        )
        if offer_transcode:
            warning_html += (
                '<div class="warn show">'
                '<button onclick="useTranscode()">Reproducir transcodificado (CPU del PC)</button>'
                '<button class="warn-close" onclick="this.closest(\'.warn\').remove()" title="Cerrar">&times;</button>'
                '</div>'
            )
        elif not ffmpeg_available:
            warning_html += (
                '<div class="warn show">ffmpeg no está disponible en el sistema. '
                'Instala ffmpeg para activar la opción de transcodificación.'
                '<button class="warn-close" onclick="this.closest(\'.warn\').remove()" title="Cerrar">&times;</button>'
                '</div>'
            )
    sync_block = ''
    if sync_key:
        sync_block = f"""
  // Reporta posición cada 2s (no más rápido; saturaría el server LAN).
  let lastReport = 0;
  v.addEventListener('timeupdate', () => {{
    const now = Date.now();
    if (now - lastReport < 2000) return;
    lastReport = now;
    fetch('/remote/sync_position', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{entry: {sync_key!r}, t: v.currentTime, paused: v.paused}}),
    }}).catch(() => {{}});
  }});"""
    if show_player:
        if is_audio:
            player_html = (
                f'<div class="audio-wrap">'
                f'<div class="audio-title">{safe_title}</div>'
                f'<audio id="v" src="{stream_url}" controls autoplay></audio>'
                f'</div>'
            )
        else:
            player_html = (
                f'<video id="v" src="{stream_url}" controls autoplay playsinline></video>'
            )
    else:
        player_html = ''
    return f"""<!DOCTYPE html>
<html lang="es"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>loiolink: {safe_title}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{height:100%;background:#000;color:#eee;font-family:system-ui,-apple-system,sans-serif}}
video{{width:100vw;height:100vh;display:block;background:#000}}
.audio-wrap{{height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;gap:32px}}
.audio-title{{font-size:1.2em;font-weight:600;text-align:center;word-break:break-word;max-width:560px}}
audio{{width:100%;max-width:560px}}
.err{{position:fixed;top:0;left:0;right:0;padding:14px;background:#f85149;text-align:center;font-size:.95em;display:none}}
.err.show{{display:block}}
.warn{{position:relative;padding:12px 36px 12px 14px;background:#5a4717;color:#fff;font-size:.92em;text-align:center;display:none}}
.warn.show{{display:block}}
.warn button{{background:#fff;color:#161b22;border:0;padding:8px 14px;border-radius:6px;font-weight:600;cursor:pointer;font-size:.9em}}
.warn-close{{position:absolute;top:50%;right:10px;transform:translateY(-50%);background:none;border:none;color:#fff;font-size:1.2em;line-height:1;cursor:pointer;padding:2px 6px;opacity:.8}}
.warn-close:hover{{opacity:1}}
</style></head><body>
{warning_html}
<div class="err" id="err"></div>
{player_html}
<script>
const v = document.getElementById('v');
const err = document.getElementById('err');
const start = {start_s};

function useTranscode(){{
  // Cambiar src a la versión transcodificada. Sin Range (output secuencial).
  if(v){{
    v.src = {transcode_url!r};
    v.play().catch(() => {{}});
  }}
}}

if(v){{
  v.addEventListener('loadedmetadata', () => {{
    if (start > 0 && start < v.duration) v.currentTime = start;
  }});

  v.addEventListener('error', () => {{
    err.textContent = 'No se pudo reproducir el archivo. El navegador puede no soportar el códec.';
    err.classList.add('show');
  }});
{sync_block}
}}
</script>
</body></html>"""


def get_local_ip():
    """Reusa la lógica de server.py para detectar IP LAN."""
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != '127.0.0.1' and not ip.startswith('0.'):
            return ip
    except RuntimeError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            if ip and ip != '127.0.0.1':
                return ip
        finally:
            s.close()
    except OSError:
        pass
    return None
