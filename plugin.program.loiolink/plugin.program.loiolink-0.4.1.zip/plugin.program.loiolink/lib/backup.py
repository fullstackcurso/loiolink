"""Sistema de backup y restauración de addons, repos y configuración Kodi.

Capacidades:
1. Construye un manifiesto JSON con todos los addons instalados, el repo que
   provee cada uno y la versión más nueva conocida en ese repo.
2. Exporta el manifiesto a TXT legible.
3. Crea un ZIP de backup con archivos físicos seleccionables (carpetas de
   addons + addon_data + sources.xml + favourites.xml + manifest).
4. Restaura desde ZIP (extracción anti path-traversal) o desde manifest
   (reinstala addons desde sus repos por URL).
5. Instala lotes de addons desde un XML simple.

Reglas no negociables:
- NUNCA incluye `plugin.program.loiolink` en el backup ni lo restaura desde
  un ZIP: se autosobrescribiría a mitad de ejecución y dejaría Kodi sin el
  addon que orquesta el trabajo.
- Por defecto excluye prefijos del sistema Kodi (xbmc., metadata.,
  service.xbmc., repository.xbmc.) y skins.
- Valida cada ZIP/XML antes de tocar el filesystem: reutiliza el extractor
  blindado de `lib.installer._extract_zip_safely` para extracción a addons/.
- URLs en el XML de batch install: solo `http://` y `https://`.
- IDs de addon: regex idéntico al usado en `lib.remote.player`.

Storage:
- ZIPs en `special://profile/addon_data/plugin.program.loiolink/backups/snapshots/`
- Rotación configurable (setting `backup.snapshots.keep`, default 5)
"""
import json
import os
import re
import shutil
import threading
import time
import uuid
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from lib import installer, log, repos


# Constantes
SELF_ADDON_ID = 'plugin.program.loiolink'

SYSTEM_PREFIXES = (
    'xbmc.', 'metadata.', 'service.xbmc.', 'repository.xbmc.',
)
SKIN_PREFIXES = ('skin.',)

ADDON_ID_RE = re.compile(r'^[A-Za-z0-9._-]+$')

_ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
_PROFILE_DIR = xbmcvfs.translatePath('special://profile/')
_ADDON_DATA_DIR = xbmcvfs.translatePath('special://profile/addon_data/')
_SOURCES_PATH = xbmcvfs.translatePath('special://profile/sources.xml')
_FAVOURITES_PATH = xbmcvfs.translatePath('special://profile/favourites.xml')

SNAPSHOTS_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/backups/snapshots/'
)

# Snapshots automáticos pre-restore. Aislados de los del usuario para no
# contaminar "Mis backups". Rotación FIFO independiente.
AUTO_PRE_RESTORE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/backups/auto_pre_restore/'
)

MANIFEST_VERSION = 2
SUPPORTED_MANIFEST_VERSIONS = (1, 2)
MAX_RESTORE_ZIP_MB = 51200  # 50 GB; coherente con MAX_EXTRACTED_TOTAL_BYTES
MAX_MANIFEST_BYTES = 5 * 1024 * 1024  # 5 MB: parsers JSON no se atragantan
# Por encima de este umbral, el hash SHA256 se SKIPEA y se marca como
# 'sha256:skipped_size' en el manifest. Razón: doble I/O en DBs grandes
# (zf.write lee el archivo, hash lo lee otra vez). El CRC32 del ZIP +
# integridad SQLite cubren validación en restore.
LARGE_FILE_HASH_SKIP_BYTES = 100 * 1024 * 1024  # 100 MB

# Mapeo del setting `backup.compression_level` (índice 0-3) a (method, level).
# Cuando method == ZIP_STORED, el kwarg `compresslevel` se OMITE en el
# constructor de ZipFile (semánticamente es ruido pasarle nivel a STORED).
# El default (índice 2 = DEFLATED level=3) reproduce el comportamiento
# previo a la introducción del setting.
_COMPRESSION_MAP = (
    (zipfile.ZIP_STORED, None),     # 0: Sin comprimir
    (zipfile.ZIP_DEFLATED, 1),      # 1: Rápido
    (zipfile.ZIP_DEFLATED, 3),      # 2: Normal (default histórico)
    (zipfile.ZIP_DEFLATED, 9),      # 3: Máximo
)
_DEFAULT_COMPRESSION_INDEX = 2

# Patrones de archivos/directorios "basura" para backup. Lista hardcoded:
# si alguien necesita personalizar, se hace en una iteración futura. Estos
# patrones no tienen falsos positivos plausibles en una instalación Kodi.
_GARBAGE_DIR_NAMES = frozenset({
    '__pycache__', '.git', '.svn', '.hg', '.idea', '.vscode', 'node_modules',
})
_GARBAGE_FILE_SUFFIXES = (
    '.pyc', '.pyo', '.tmp', '.bak', '.swp', '.swo', '.orig',
)
_GARBAGE_FILE_EXACT_LOWER = frozenset({
    '.ds_store', 'thumbs.db', 'desktop.ini',
})

# Filename de snapshot: solo letras, números, guiones bajos, puntos y
# guiones. Validamos antes de tocar disco para que la API no acepte paths.
_SAFE_SNAPSHOT_RE = re.compile(r'^kodi_backup_[A-Za-z0-9._-]+\.zip$')


# Categorías de backup de Kodi
#
# Tabla data-driven: añadir una categoría es una entrada nueva aquí,
# nada más. El resto del código itera la tabla. Cada categoría tiene:
#   - subdir_userdata: path relativo dentro de userdata (NO se respalda
#       userdata/ entero, solo subdirs específicos para no recursar a
#       Database/Thumbnails que tienen sus propios flags).
#   - arc_prefix: nombre dentro del ZIP (categories/<cat>/...) para
#       diferenciarlos de addons/ y addon_data/.
#   - default: bool default cuando el usuario no especifica.
#   - sqlite_consistent: si True, usar API .backup() para .db internos.
#   - size_warning_mb: si el dir local supera este tamaño, avisar al
#       usuario antes de empezar (None = sin aviso).
#
# Categorías "virtuales" (no son un dir): guisettings y watched_state
# se respaldan via JSON-RPC y van como JSON dentro del ZIP.

KODI_CATEGORIES_SPEC = (
    # name, subdir, arc, default, sqlite_consistent, size_warning_mb
    ('databases', 'Database', 'categories/databases', False, True, 100),
    ('thumbnails', 'Thumbnails', 'categories/thumbnails', False, False, 100),
    ('playlists', 'playlists', 'categories/playlists', True, False, None),
    ('keymaps', 'keymaps', 'categories/keymaps', True, False, None),
    ('profiles', 'profiles', 'categories/profiles', False, False, None),
    ('game_saves', 'Savestates', 'categories/game_saves', False, False, None),
    ('peripheral_data', 'peripheral_data', 'categories/peripheral_data',
     True, False, None),
    ('library', 'library', 'categories/library', True, False, None),
)

# Categorías "virtuales" sin subdir, se rellenan via JSON-RPC
# (guisettings y watched_state).
KODI_VIRTUAL_CATEGORIES = ('guisettings', 'watched_state')

# `config_root` es un caso especial: respaldar archivos DIRECTOS de
# userdata/ (advancedsettings.xml, sources.xml, favourites.xml,
# passwords.xml, RssFeeds.xml, mediasources.xml, etc.) SIN recursar a
# subdirs (esos tienen flags propios). Se maneja con un helper aparte.
KODI_CONFIG_ROOT_NAME = 'config_root'
KODI_CONFIG_ROOT_ARC = 'categories/config_root'
KODI_CONFIG_ROOT_DEFAULT = True


def category_default_selection():
    """Devuelve dict {category_name: bool} con los defaults para nuevos
    backups. Útil para inicializar la UI y para llamadas sin selección
    explícita.
    """
    d = {KODI_CONFIG_ROOT_NAME: KODI_CONFIG_ROOT_DEFAULT}
    for name, _sub, _arc, default, _sql, _warn in KODI_CATEGORIES_SPEC:
        d[name] = default
    for vname in KODI_VIRTUAL_CATEGORIES:
        d[vname] = True  # guisettings y watched_state default ON
    return d


def _category_estimate_size(name):
    """Estima el tamaño en bytes de una categoría físico-on-disk.
    Devuelve 0 si la categoría es virtual o no existe el dir.
    """
    for cat_name, subdir, _arc, _default, _sql, _warn in KODI_CATEGORIES_SPEC:
        if cat_name != name:
            continue
        path = os.path.join(_PROFILE_DIR, subdir)
        if not os.path.isdir(path):
            return 0
        total = 0
        try:
            for root, _dirs, files in os.walk(path):
                for fn in files:
                    try:
                        total += os.path.getsize(os.path.join(root, fn))
                    except OSError:
                        pass
        except OSError:
            return 0
        return total
    return 0


def get_category_size_warnings(selected):
    """Para cada categoría seleccionada con `size_warning_mb` no None,
    comprueba si el tamaño on-disk supera el umbral. Devuelve lista de
    `{name, size_mb, warning_mb}` para pintar avisos en la UI.
    """
    out = []
    sel = selected or {}
    for name, _sub, _arc, _default, _sql, warn_mb in KODI_CATEGORIES_SPEC:
        if warn_mb is None or not sel.get(name):
            continue
        size = _category_estimate_size(name)
        size_mb = size // (1024 * 1024)
        if size_mb >= warn_mb:
            out.append({
                'name': name,
                'size_mb': size_mb,
                'warning_mb': warn_mb,
            })
    return out


# Excepciones
class BackupError(Exception):
    """Error semántico durante backup/restore."""


class BackupBusyError(BackupError):
    """Otra operación de backup/restore en curso."""


class ManifestError(BackupError):
    """Manifest ausente, corrupto o incompatible."""


# Compatibilidad de versiones
def _parse_kodi_major(version_str):
    """Extrae el número major de un string tipo 'System.BuildVersion'.

    BuildVersion suele ser '21.0 (21.0.0) Git:...' o similar. Devuelve int
    o None si no se puede parsear.
    """
    if not version_str:
        return None
    s = str(version_str).strip()
    digits = []
    for ch in s:
        if ch.isdigit():
            digits.append(ch)
        else:
            break
    if not digits:
        return None
    try:
        return int(''.join(digits))
    except ValueError:
        return None


def check_kodi_version_compat(manifest):
    """Compara la versión de Kodi del manifest con la actual.

    Devuelve dict con backup, current, major_mismatch. Útil para que el
    caller decida si avisar al usuario antes de un restore.
    """
    backup_v = manifest.get('kodi_version') or ''
    current_v = xbmc.getInfoLabel('System.BuildVersion') or ''
    backup_major = _parse_kodi_major(backup_v)
    current_major = _parse_kodi_major(current_v)
    major_mismatch = (
        backup_major is not None
        and current_major is not None
        and backup_major != current_major
    )
    return {
        'backup': backup_v,
        'current': current_v,
        'backup_major': backup_major,
        'current_major': current_major,
        'major_mismatch': major_mismatch,
    }


# Mutex de backup
_BACKUP_MUTEX_PROP = 'loiolink.backup.busy'
_BACKUP_MUTEX_STALE_S = 600  # 10 min: un backup grande puede tardar
_BACKUP_TOKEN = None
# Serializa el CAS intra-proceso. Server permanente (HTTP) llama restore_*
# en threads paralelos; sin lock, dos handlers pueden pasar el post-set check.
_BACKUP_INTRA_LOCK = threading.Lock()


def acquire_backup_mutex(*, owner='backup_op', coord_timeout_s=5):
    """Reclama el mutex global de backup, coordinándose con el resto.

    ORDEN DE ADQUISICIÓN GLOBAL (estricto, MISMO orden en TODA la base
    de código para evitar deadlocks):
      1. Coordinador `addon_ops_mutex` (sup. ops sobre addons/ y addon_data/).
      2. Mutex específico `loiolink.backup.busy` (esta función).

    NUNCA adquirir al revés. Si en el futuro otro módulo añade locks
    debe respetar el orden: addon_ops_mutex SIEMPRE primero.

    Si paso 1 falla: devuelve False sin tocar paso 2.
    Si paso 2 falla: libera paso 1 y devuelve False.

    El coordinator hoy lo adquiere solo `backup`; installer/transfers se
    pueden migrar en el futuro y este ya estará preparado.

    coord_timeout_s: clamped a [1, 30] para evitar valores absurdos.
    """
    # Clamp del timeout para garantizar comportamiento sano ante valores
    # no sensatos (e.g. 0 o muy grandes).
    global _BACKUP_TOKEN
    if coord_timeout_s is None or coord_timeout_s < 1:
        coord_timeout_s = 1
    if coord_timeout_s > 30:
        coord_timeout_s = 30
    from lib import addon_ops_mutex
    if not addon_ops_mutex.acquire(owner, timeout_s=coord_timeout_s):
        return False

    win = xbmcgui.Window(10000)
    with _BACKUP_INTRA_LOCK:
        raw = win.getProperty(_BACKUP_MUTEX_PROP) or ''
        if raw:
            ts_part = raw.split(':', 1)[0]
            try:
                held = int(ts_part)
            except (TypeError, ValueError):
                held = 0
            if time.time() - held < _BACKUP_MUTEX_STALE_S:
                addon_ops_mutex.release()
                return False
            log.warning(f'[backup] mutex stale ({int(time.time() - held)}s), reclamando')
        token = f'{int(time.time())}:{uuid.uuid4().hex}'
        win.setProperty(_BACKUP_MUTEX_PROP, token)
        # Spin-loop CAS-like: 3 lecturas con sleep micro entre ellas. Cierra
        # la ventana cross-process donde A.set→A.get pasa y luego B.set
        # sobrescribe y B.get también pasa (ambos creen tener el lock).
        for attempt in range(3):
            if win.getProperty(_BACKUP_MUTEX_PROP) == token:
                _BACKUP_TOKEN = token
                return True
            if attempt < 2:
                try:
                    import xbmc
                    xbmc.sleep(1)
                except (ImportError, Exception):  # noqa: BLE001
                    time.sleep(0.001)
        # No ganamos la race: liberar el coordinator para no dejarlo
        # ocupado tras nuestro False.
        addon_ops_mutex.release()
        return False


_HEARTBEAT_EVERY_S = 30
_last_heartbeat = 0.0


def heartbeat_backup_mutex():
    """Renueva los dos mutex mientras la operación sigue viva.

    Sin esto, `_BACKUP_MUTEX_STALE_S` (10 min) no distinguía "el proceso que
    lo tenía murió" de "sigue trabajando": un backup con Database y
    Thumbnails de una biblioteca grande, o sobre SMB, pasa de diez minutos
    sin despeinarse. A partir de ahí otra operación consideraba el mutex
    caducado y podía correr EN PARALELO con el backup en curso.

    Se llama desde los bucles largos (una escritura de Window property cada
    `_HEARTBEAT_EVERY_S` segundos como mucho, no una por archivo).
    """
    global _last_heartbeat, _BACKUP_TOKEN
    now = time.time()
    if now - _last_heartbeat < _HEARTBEAT_EVERY_S:
        return
    _last_heartbeat = now

    from lib import addon_ops_mutex
    addon_ops_mutex.touch()

    with _BACKUP_INTRA_LOCK:
        if not _BACKUP_TOKEN:
            return
        win = xbmcgui.Window(10000)
        if win.getProperty(_BACKUP_MUTEX_PROP) != _BACKUP_TOKEN:
            return  # ya no es nuestro; no pisamos el token del nuevo dueño
        _, uid = _BACKUP_TOKEN.split(':', 1)
        token = f'{int(now)}:{uid}'
        win.setProperty(_BACKUP_MUTEX_PROP, token)
        _BACKUP_TOKEN = token


def release_backup_mutex():
    # Orden de release: inverso al acquire. Específico primero, coordinator
    # después. Así otro caller en cola puede adquirir el coordinator sin que
    # nuestro específico siga "ocupado" un instante.
    # CAS al borrar: si superamos el stale y otro proceso reclamó el lock,
    # nuestro release no debe destruir su token activo.
    global _BACKUP_TOKEN
    from lib import addon_ops_mutex
    win = xbmcgui.Window(10000)
    with _BACKUP_INTRA_LOCK:
        if _BACKUP_TOKEN and win.getProperty(_BACKUP_MUTEX_PROP) == _BACKUP_TOKEN:
            win.clearProperty(_BACKUP_MUTEX_PROP)
        elif _BACKUP_TOKEN:
            log.warning('[backup] release con token expirado; no tocamos prop')
        _BACKUP_TOKEN = None
    addon_ops_mutex.release()


# Helpers de filtros y validación
def is_backupable(addon_id, *, exclude_system=True, exclude_skins=True):
    """True si el addon puede entrar en el backup. Self NUNCA pasa."""
    if not addon_id or addon_id == SELF_ADDON_ID:
        return False
    if not ADDON_ID_RE.match(addon_id):
        return False
    if exclude_system and addon_id.startswith(SYSTEM_PREFIXES):
        return False
    if exclude_skins and addon_id.startswith(SKIN_PREFIXES):
        return False
    return True


def _valid_addon_id(addon_id):
    """Valida ID sin filtrar por prefijos del sistema. Bloquea SELF siempre."""
    if not addon_id or addon_id == SELF_ADDON_ID:
        return False
    return bool(ADDON_ID_RE.match(addon_id))


def _http_only_url(url):
    if not isinstance(url, str):
        return False
    return url.startswith('http://') or url.startswith('https://')


def _safe_snapshot_filename(filename):
    """True si `filename` es un nombre válido (sin path, prefix correcto)."""
    if not filename or '/' in filename or '\\' in filename:
        return False
    if filename in ('.', '..'):
        return False
    return bool(_SAFE_SNAPSHOT_RE.match(filename))


# Manifest builder
def _jsonrpc_get_addons(enabled):
    """Llama Addons.GetAddons. Devuelve la lista (vacía si error/timeout)."""
    from lib import jsonrpc_safe
    result = jsonrpc_safe.call(
        'Addons.GetAddons',
        {
            'enabled': enabled,
            'properties': ['name', 'version', 'author', 'enabled',
                           'summary', 'description'],
        },
        timeout_s=20.0,  # GetAddons puede tardar en sistemas con muchos addons
        default={'addons': []},
        log_label='build_manifest:GetAddons',
    )
    return (result or {}).get('addons', []) or []


def _jsonrpc_get_addons_all():
    """Una sola llamada GetAddons con `enabled='all'`.

    Kodi 18+ soporta `enabled='all'` que devuelve enabled + disabled en
    una sola call. Reduce el coste de `build_manifest` a la mitad
    (antes 2 llamadas con timeout 20s c/u = hasta 40s; ahora 20s max).

    Fallback: si la respuesta viene vacía o con error, intentamos las
    2 llamadas separadas (Kodi <18 o configuración custom).
    """
    from lib import jsonrpc_safe
    result = jsonrpc_safe.call(
        'Addons.GetAddons',
        {
            'enabled': 'all',
            'properties': ['name', 'version', 'author', 'enabled',
                           'summary', 'description'],
        },
        timeout_s=20.0,
        default=None,
        log_label='build_manifest:GetAddons(all)',
    )
    if result is not None:
        return (result or {}).get('addons', []) or []
    # Fallback: doble call con dedup
    log.info('[backup] GetAddons(all) falló, fallback a 2 llamadas')
    enabled = _jsonrpc_get_addons(True)
    disabled = _jsonrpc_get_addons(False)
    seen = set()
    combined = []
    for a in enabled + disabled:
        aid = a.get('addonid') if isinstance(a, dict) else None
        if aid and aid not in seen:
            seen.add(aid)
            combined.append(a)
    return combined


def _parse_local_addon_xml(addon_id):
    """Lee `addons/<id>/addon.xml` y devuelve (version, requires).

    requires es lista de dicts {id, version}. version se devuelve aunque ya
    venga en JSON-RPC para tener un fallback consistente.
    """
    path = os.path.join(_ADDONS_DIR, addon_id, 'addon.xml')
    if not os.path.isfile(path):
        return (None, [])
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            tree = ET.parse(fh)
    except (OSError, ET.ParseError):
        return (None, [])
    root = tree.getroot()
    if root.tag != 'addon':
        return (None, [])
    version = root.get('version')
    requires = []
    req_block = root.find('requires')
    if req_block is not None:
        for imp in req_block.findall('import'):
            rid = imp.get('addon')
            if rid:
                requires.append({'id': rid, 'version': imp.get('version')})
    return (version, requires)


def _has_addon_data(addon_id):
    return os.path.isdir(os.path.join(_ADDON_DATA_DIR, addon_id))


def _list_repo_index(repo_id):
    """(datadir, {addon_id: version}, error). datadir y mapa pueden ser None."""
    datadir = repos.get_datadir(repo_id)
    if not datadir:
        return (None, None, 'datadir no encontrado')
    try:
        text = repos.fetch_remote_index(datadir)
    except Exception as e:  # red caída, DNS, SSL...
        return (datadir, None, f'no responde: {e}')
    parsed = repos.parse_addons_xml(text)
    if not parsed:
        return (datadir, None, 'addons.xml vacío o inválido')
    return (datadir, parsed, None)


def _repo_zip_url(datadir, repo_id, version):
    """Construye URL del ZIP del repo dentro de su datadir.

    Patrón Kodi estándar: `<datadir>/<repo_id>/<repo_id>-<version>.zip`.
    No siempre coincide (algunos repos usan rutas distintas); marcamos como
    pista, no como verdad absoluta. El restore lo intenta y, si falla,
    informa al usuario.
    """
    if not datadir or not version:
        return None
    base = datadir if datadir.endswith('/') else datadir + '/'
    return f'{base}{repo_id}/{repo_id}-{version}.zip'


def build_manifest(*, exclude_system=True, exclude_skins=True,
                   exclude_garbage=None,
                   compression_level=None,
                   progress_cb=None):
    """Construye el manifiesto leyendo addons instalados y escaneando repos.

    exclude_garbage / compression_level: si None, se lee del setting
    correspondiente (con fallback al default si no está disponible). Los
    callers que crean backup pasan el valor explícito ya resuelto en
    `_do_create_backup`; los callers que solo exportan/listan (`build_manifest`
    directo desde panel web o menú) pasan None para reflejar la configuración
    actual del usuario en el JSON exportado.

    progress_cb(done, total, msg): callable opcional, se llama por cada repo
    consultado y por cada paso macro.
    """
    exclude_garbage = _resolve_exclude_garbage(exclude_garbage)
    compression_level = _resolve_compression_index(compression_level)
    if progress_cb:
        progress_cb(0, 0, 'Listando addons instalados...')

    raw_addons = _jsonrpc_get_addons_all()
    seen = set()
    all_addons = []
    for entry in raw_addons:
        if not isinstance(entry, dict):
            continue
        aid = entry.get('addonid')
        if not aid or aid in seen:
            continue
        seen.add(aid)
        all_addons.append(entry)

    repo_ids = repos.list_installed_repos()
    repo_indexes = {}
    total_steps = max(len(repo_ids), 1)
    for i, repo_id in enumerate(repo_ids):
        if progress_cb:
            progress_cb(i, total_steps, f'Consultando {repo_id}...')
        datadir, index, err = _list_repo_index(repo_id)
        repo_indexes[repo_id] = {
            'datadir': datadir,
            'index': index or {},
            'error': err,
        }

    if progress_cb:
        progress_cb(total_steps, total_steps, 'Componiendo manifest...')

    addons_manifest = []
    for entry in all_addons:
        aid = entry.get('addonid')
        if aid == SELF_ADDON_ID:
            continue  # nunca incluir self
        if not is_backupable(aid, exclude_system=exclude_system,
                             exclude_skins=exclude_skins):
            continue

        local_version, requires = _parse_local_addon_xml(aid)
        version = entry.get('version') or local_version or '0.0.0'

        provided_by = []
        newest_repo = None
        newest_version = None
        for repo_id, repo_data in repo_indexes.items():
            remote_version = repo_data['index'].get(aid)
            if not remote_version:
                continue
            provided_by.append({
                'repo_id': repo_id,
                'repo_version': remote_version,
                'is_newest': False,
            })
            if newest_version is None or repos.is_newer(remote_version,
                                                       newest_version):
                newest_version = remote_version
                newest_repo = repo_id
        if newest_repo:
            for p in provided_by:
                p['is_newest'] = (p['repo_id'] == newest_repo
                                  and p['repo_version'] == newest_version)

        addons_manifest.append({
            'id': aid,
            'name': entry.get('name') or aid,
            'version': version,
            'enabled': bool(entry.get('enabled', True)),
            'author': entry.get('author') or '',
            'requires': requires,
            'provided_by': provided_by,
            'has_addon_data': _has_addon_data(aid),
        })

    repos_manifest = []
    for repo_id in repo_ids:
        if repo_id == SELF_ADDON_ID:
            continue
        repo_data = repo_indexes.get(repo_id, {})
        repo_local_version, _ = _parse_local_addon_xml(repo_id)
        datadir = repo_data.get('datadir')
        repos_manifest.append({
            'id': repo_id,
            'version': repo_local_version or '',
            'datadir': datadir,
            'addon_xml_url': (datadir + 'addons.xml') if datadir else None,
            'zip_url_hint': _repo_zip_url(datadir, repo_id,
                                          repo_local_version),
            'index_error': repo_data.get('error'),
        })

    # sources.xml (lista plana)
    sources_manifest = []
    try:
        from lib import sources as _sources
        for s in _sources.list_files_sources():
            sources_manifest.append({
                'name': s.get('name', ''),
                'path': s.get('path', ''),
            })
    except Exception as e:
        log.warning(f'[backup] no se pudo leer sources.xml: {e!r}')

    try:
        loio_version = xbmcaddon.Addon().getAddonInfo('version')
    except RuntimeError:
        loio_version = 'unknown'
    kodi_version = xbmc.getInfoLabel('System.BuildVersion') or 'unknown'

    return {
        'manifest_version': MANIFEST_VERSION,
        'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'created_unix': int(time.time()),
        'kodi_version': kodi_version,
        'loiolink_version': loio_version,
        'filters': {
            'exclude_system': exclude_system,
            'exclude_skins': exclude_skins,
            'exclude_garbage': exclude_garbage,
            'compression_level': compression_level,
        },
        'repos': repos_manifest,
        'addons': addons_manifest,
        'sources': sources_manifest,
        # Campos v2 que se rellenan en fases posteriores. Los dejamos
        # presentes (vacíos) para que el manifest sea homogéneo y los
        # consumidores no tengan que distinguir "campo ausente" vs "vacío".
        'file_hashes': {},
        'hash_algo': None,
        'environment': build_environment_block(),
        'categories': {},
        'watched_state': None,
        'guisettings_dump': None,
    }


# Export TXT
def export_txt(manifest, *, saved_to_path=None):
    """Convierte un manifest a texto legible. Devuelve str.

    UTF-8 sin BOM. Idioma español. Sin emdash. Útil tanto para guardar a
    fichero como para mostrar en un textviewer Kodi.

    Si `saved_to_path` se pasa, se incluye en la cabecera una línea
    `Lista guardada en: <path>` para que el usuario sepa dónde está el .txt.
    """
    lines = []
    created = manifest.get('created', '')
    kodi_v = manifest.get('kodi_version', '?')
    loio_v = manifest.get('loiolink_version', '?')
    lines.append(f'=== KODI BACKUP: {created} ===')
    lines.append(f'Kodi: {kodi_v}     loiolink: {loio_v}')
    if saved_to_path:
        lines.append(f'Lista guardada en: {saved_to_path}')
    label = manifest.get('label')
    if label:
        lines.append(f'Etiqueta: {label}')
    lines.append('')

    repo_list = manifest.get('repos', [])
    lines.append(f'REPOSITORIOS INSTALADOS ({len(repo_list)})')
    lines.append('-' * 40)
    for i, repo in enumerate(repo_list, 1):
        rid = repo.get('id', '?')
        rver = repo.get('version', '?')
        lines.append(f'[{i}] {rid}  v{rver}')
        if repo.get('addon_xml_url'):
            lines.append(f'    URL addons.xml: {repo["addon_xml_url"]}')
        if repo.get('zip_url_hint'):
            lines.append(f'    URL ZIP:        {repo["zip_url_hint"]}')
        if repo.get('index_error'):
            lines.append(f'    Aviso: {repo["index_error"]}')
        lines.append('')

    addon_list = manifest.get('addons', [])
    lines.append(f'ADDONS INSTALADOS ({len(addon_list)})')
    lines.append('-' * 40)
    for i, addon in enumerate(addon_list, 1):
        state = 'activo' if addon.get('enabled', True) else 'deshabilitado'
        aid = addon.get('id', '?')
        aver = addon.get('version', '?')
        lines.append(f'[{i}] {aid}  v{aver}  [{state}]')
        if addon.get('name') and addon['name'] != addon.get('id'):
            lines.append(f'    Nombre: {addon["name"]}')
        if addon.get('author'):
            lines.append(f'    Autor: {addon["author"]}')
        provided = addon.get('provided_by', []) or []
        newest = next((p for p in provided if p.get('is_newest')), None)
        if newest:
            lines.append(f'    Repo más nuevo: {newest["repo_id"]} (v{newest["repo_version"]})')
        elif provided:
            first = provided[0]
            lines.append(f'    Repo: {first["repo_id"]} (v{first["repo_version"]})')
        else:
            lines.append('    Sin repo conocido. Solo backup de archivos.')
        has_data = 'sí' if addon.get('has_addon_data') else 'no'
        lines.append(f'    Datos de usuario incluidos: {has_data}')
        requires = addon.get('requires') or []
        if requires:
            reqs = []
            for r in requires:
                if r.get('version'):
                    reqs.append(f'{r["id"]}>={r["version"]}')
                else:
                    reqs.append(r['id'])
            joined = ', '.join(reqs)
            lines.append(f'    Requiere: {joined}')
        lines.append('')

    sources_list = manifest.get('sources', [])
    if sources_list:
        lines.append(f'FUENTES (sources.xml) ({len(sources_list)})')
        lines.append('-' * 40)
        for i, src in enumerate(sources_list, 1):
            sname = src.get('name', '?')
            lines.append(f'[{i}] {sname}')
            lines.append(f'    {src.get("path", "")}')
            lines.append('')

    return '\n'.join(lines)


# _parse_batch_xml rechaza ficheros mayores que esto por seguridad
# (billion-laughs). Si export_xml produce un XML mayor, no será reimportable.
MAX_BATCH_XML_BYTES = 1024 * 1024


def export_xml(manifest, *, addon_ids=None, repo_ids=None):
    """Genera un XML <kodi-addons> reinstalable con install_from_xml.

    addon_ids/repo_ids: None = todos los del manifest; o lista de IDs a incluir.

    Devuelve (xml_text, info):
        xml_text: str UTF-8 con declaración, listo para guardar a .xml.
        info: dict con:
            'skipped_repos': list[str] de repo IDs descartados por no tener
                zip_url_hint http(s). El importador necesita URL de ZIP;
                addon_xml_url no sirve.
            'orphan_addon_repos': list[str] de repo IDs referenciados por
                algún addon incluido pero NO presentes en <repositories>.
                Si se importa en un Kodi sin esos repos pre-instalados, los
                addons fallarán. La UI puede ofrecer auto-incluirlos.
            'size_bytes': int, tamaño UTF-8 del XML serializado.
            'exceeds_parser_limit': bool, True si excede MAX_BATCH_XML_BYTES
                (el parser lo rechazará en otro Kodi).

    Para cada addon usa provided_by[is_newest].repo_id como atributo `repo`;
    si no hay repo conocido, se omite el atributo (el parser lo trata como
    None y deja que install_addon_from_repo elija el repo disponible).
    """
    from xml.dom import minidom

    addons_all = manifest.get('addons') or []
    repos_all = manifest.get('repos') or []

    if addon_ids is not None:
        wanted_addons = set(addon_ids)
        addons_sel = [a for a in addons_all if a.get('id') in wanted_addons]
    else:
        addons_sel = list(addons_all)

    if repo_ids is not None:
        wanted_repos = set(repo_ids)
        repos_sel = [r for r in repos_all if r.get('id') in wanted_repos]
    else:
        repos_sel = list(repos_all)

    root = ET.Element('kodi-addons')
    generated = manifest.get('created')
    if generated:
        root.set('generated', generated)

    repos_block = ET.SubElement(root, 'repositories')
    skipped_repos = []
    included_repo_ids = set()
    for r in repos_sel:
        rid = r.get('id') or ''
        url = r.get('zip_url_hint') or ''
        if not _valid_addon_id(rid):
            continue
        if not _http_only_url(url):
            skipped_repos.append(rid)
            continue
        ET.SubElement(repos_block, 'repo', {'id': rid, 'url': url})
        included_repo_ids.add(rid)

    addons_block = ET.SubElement(root, 'addons')
    referenced_repos = set()
    for a in addons_sel:
        aid = a.get('id') or ''
        if aid == SELF_ADDON_ID:
            continue
        if not _valid_addon_id(aid):
            continue
        attrs = {'id': aid}
        provided = a.get('provided_by') or []
        newest = next((p for p in provided if p.get('is_newest')), None)
        if newest is None and provided:
            newest = provided[0]
        if newest:
            rid = newest.get('repo_id') or ''
            if _valid_addon_id(rid):
                attrs['repo'] = rid
                referenced_repos.add(rid)
        ET.SubElement(addons_block, 'addon', attrs)

    raw = ET.tostring(root, encoding='utf-8')
    pretty = minidom.parseString(raw).toprettyxml(indent='  ', encoding='utf-8')
    xml_text = pretty.decode('utf-8')
    size_bytes = len(xml_text.encode('utf-8'))
    info = {
        'skipped_repos': skipped_repos,
        'orphan_addon_repos': sorted(referenced_repos - included_repo_ids),
        'size_bytes': size_bytes,
        'exceeds_parser_limit': size_bytes > MAX_BATCH_XML_BYTES,
    }
    return xml_text, info


# Creación de ZIP de backup
# Cache del check de paths críticos: se ejecuta una vez por proceso.
# Si falla, todas las operaciones de backup abortan con error claro
# (no rompe el import del módulo porque eso bloquearía el addon entero).
_PATHS_VALIDATED = None  # None=no comprobado todavía, str=mensaje de error, True=OK


def _validate_paths_or_raise():
    """Verifica al primer uso que SNAPSHOTS_DIR no apunta dentro de
    addons/ ni a sí mismo via symlink/junction roto.

    Caso peligroso: si alguien (manualmente, scripts, o un addon malicioso
    instalado) hizo `userdata/addon_data/plugin.program.loiolink/backups/
    snapshots/ -> addons/` (symlink), los ZIPs irían dentro de addons/ y
    se interpretarían como addons en el siguiente arranque de Kodi.
    """
    global _PATHS_VALIDATED
    if _PATHS_VALIDATED is True:
        return
    if isinstance(_PATHS_VALIDATED, str):
        raise BackupError(_PATHS_VALIDATED)
    try:
        # Crear el directorio para poder hacer realpath fiable.
        os.makedirs(SNAPSHOTS_DIR, exist_ok=True)
    except OSError as e:
        msg = f'No se puede crear SNAPSHOTS_DIR: {e}'
        _PATHS_VALIDATED = msg
        log.error(f'[backup] {msg}')
        raise BackupError(msg)
    snap_real = os.path.realpath(SNAPSHOTS_DIR)
    addons_real = os.path.realpath(_ADDONS_DIR)
    if snap_real == addons_real or snap_real.startswith(addons_real + os.sep):
        msg = ('SNAPSHOTS_DIR resuelve dentro de addons/. Configuración '
               'corrupta o symlink malicioso. Backup deshabilitado.')
        _PATHS_VALIDATED = msg
        log.security(f'[backup] {msg} (snap={snap_real!r} addons={addons_real!r})')
        raise BackupError(msg)
    _PATHS_VALIDATED = True


def _ensure_snapshots_dir():
    _validate_paths_or_raise()
    os.makedirs(SNAPSHOTS_DIR, exist_ok=True)
    _cleanup_orphan_tmp()
    return SNAPSHOTS_DIR


def _cleanup_orphan_tmp(max_age_s=86400):
    """Elimina archivos .tmp más antiguos que `max_age_s` en SNAPSHOTS_DIR.

    Cubre el caso de Kodi/Python muriendo entre el zipfile.close() y el
    os.replace() final: el .tmp queda huérfano. Por defecto 24h para no
    pisar un .tmp legítimo de un backup en curso.
    """
    if not os.path.isdir(SNAPSHOTS_DIR):
        return
    cutoff = time.time() - max_age_s
    try:
        for name in os.listdir(SNAPSHOTS_DIR):
            if not name.endswith('.tmp'):
                continue
            full = os.path.join(SNAPSHOTS_DIR, name)
            try:
                st = os.stat(full)
            except OSError:
                continue
            if st.st_mtime < cutoff:
                try:
                    os.unlink(full)
                    log.info(f'[backup] limpiado .tmp huérfano: {name}')
                except OSError:
                    pass
    except OSError:
        pass


def _safe_label(label):
    """Sanitiza un label para usarlo en el filename."""
    if not label:
        return ''
    cleaned = re.sub(r'[^A-Za-z0-9_-]+', '_', label).strip('_')
    return cleaned[:40]


def _build_filename(label=None):
    stamp = time.strftime('%Y-%m-%d_%H%M%S')
    safe = _safe_label(label)
    base = f'kodi_backup_{stamp}'
    if safe:
        base += f'_{safe}'
    return f'{base}.zip'


def _safe_arcname(parts):
    """Une partes con `/` y verifica que no haya `..` ni paths absolutos."""
    name = '/'.join(p.strip('/') for p in parts if p)
    if name.startswith('/') or '..' in name.split('/'):
        raise BackupError(f'arcname inválido: {name!r}')
    return name


# Tabla de códigos técnicos a frases accionables en español. Si el código
# de error viaja al user (notification, toast, dialog), el caller debe usar
# `friendly_error_message(reason)` para traducirlo. Si no hay match,
# devuelve el code original (graceful fallback).
_FRIENDLY_ERROR_MESSAGES = {
    # Manifest
    'manifest_invalid': ('El archivo de manifiesto está dañado. El backup '
                          'no se puede usar; prueba con otro o reimporta.'),
    'manifest_not_found': 'Este ZIP no es un backup válido (sin manifiesto).',
    'manifest_too_large': ('El manifiesto es demasiado grande, sospechoso. '
                            'Se rechaza por seguridad.'),
    'zip_disappeared': ('El archivo de backup desapareció durante la operación. '
                         'Verifica que no se haya borrado y reintenta.'),
    # Cifrado
    'encrypted_no_password': ('Este backup está cifrado: introduce el password '
                                'para continuar.'),
    'password_incorrect': ('Password incorrecto. Si lo escribiste bien, el '
                            'backup puede estar dañado.'),
    # Integridad
    'integrity_failure': ('El backup no pasa la verificación de integridad '
                            '(posible corrupción del archivo).'),
    'hash_mismatch': ('Algún archivo del backup fue modificado o se corrompió. '
                       'Vuelve a importarlo o usa otro backup.'),
    'decompression_bomb': ('El backup intenta descomprimirse a un tamaño '
                            'sospechoso. Se rechaza por seguridad.'),
    # SQLite
    'sqlite_corrupt': ('Una base de datos del backup está corrupta y no se '
                        'restaura. El resto del backup sí se ha aplicado.'),
    'db_version_mismatch': ('La base de datos del backup es de otra versión '
                              'de Kodi. Tras restaurar, re-escanea tu biblioteca.'),
    'textures_policy_skip': ('Cache de miniaturas omitido (Kodi lo reconstruirá '
                              'al arrancar). Comportamiento normal.'),
    # Cross-version
    'python_version_mismatch': ('Este addon necesita otra versión de Python; '
                                  'no funcionará en tu Kodi actual.'),
    'kodi_version_mismatch': ('Backup hecho en otra versión major de Kodi; '
                                'algunos addons pueden no cargar.'),
    # Mutex/operations
    'mutex_busy': ('Hay otra operación en curso. Espera a que termine y '
                    'reintenta.'),
    'backup_busy': ('Otra operación de backup está activa. Espera y reintenta.'),
    # Espacio/storage
    'disk_full': 'No hay suficiente espacio en disco para esta operación.',
    'destination_not_writable': ('No se puede escribir en el destino. '
                                   'Verifica permisos o conexión.'),
    # Generic
    'addon_in_use': ('El addon está siendo usado por Kodi; ciérralo o reinicia '
                      'Kodi antes de restaurar.'),
    'symlink_rejected': ('El backup contiene un symlink sospechoso; rechazado '
                          'por seguridad.'),
    'path_too_long': ('Una ruta del backup es demasiado larga para tu sistema. '
                       'Más común en Windows con paths >260 caracteres.'),
    'symlink': ('El backup contiene un enlace simbólico; se omite por seguridad.'),
    'path_escape': ('Una ruta del backup intenta salir del directorio destino; '
                     'se rechaza por seguridad.'),
    'sqlite_companion_omitted': ('Archivo WAL/SHM de base de datos omitido: '
                                   'el snapshot consistente ya los incluye.'),
    'non_regular': ('Un archivo del backup no es un archivo regular '
                     '(es dispositivo, pipe, etc.); se rechaza por seguridad.'),
    'traversal': ('Una entrada del ZIP intenta acceder fuera del destino; '
                   'se rechaza por seguridad.'),
    'traversal_dir': ('Un directorio del ZIP intenta acceder fuera del destino; '
                       'se rechaza por seguridad.'),
    'xml_malformed': ('Un archivo XML del backup está malformado y no se aplicará.'),
    'symlink_materialized': ('Un symlink fue materializado durante extracción y '
                              'se rechaza por seguridad.'),
    'ya_existe_destino': ('El archivo ya existe en el destino; usa "sobrescribir" '
                           'si quieres reemplazarlo.'),
    'borrado_durante_migracion': ('El archivo fue borrado durante la migración; '
                                    'sin cambios.'),
    'aparecio_durante_migracion': ('Un archivo apareció en el destino mientras '
                                     'migrabas; se omite para no sobreescribir.'),
    'dep_sistema_no_instalada': ('Una dependencia del sistema Kodi no está '
                                   'instalada; el addon no se puede activar.'),
    'dep_no_resuelta': ('Una dependencia del addon no se pudo encontrar; '
                         'el addon queda parcial.'),
    'no_presente_en_zip': ('El addon no está incluido en este backup.'),
    'zip_no_existe': ('El archivo del backup no se encuentra (puede haber sido '
                       'borrado).'),
    'manifest_error': ('El manifest del backup tiene un problema; revisa el ZIP.'),
}


def friendly_error_message(reason, *, fallback=None):
    """Traduce código técnico a frase accionable en español.

    Si no hay traducción, devuelve `fallback` o el código original.
    Útil para mensajes que viajan al user (toasts, notif, dialog).
    Los logs internos pueden seguir usando códigos técnicos.

    Ejemplo:
        for entry in result['failed']:
            user_msg = friendly_error_message(entry.get('reason', ''))
            show_toast(user_msg)
    """
    if not reason:
        return fallback or ''
    # Match exacto primero
    if reason in _FRIENDLY_ERROR_MESSAGES:
        return _FRIENDLY_ERROR_MESSAGES[reason]
    # Match por prefijo (códigos como 'python_version_mismatch: <detalle>')
    base = reason.split(':', 1)[0].strip()
    if base in _FRIENDLY_ERROR_MESSAGES:
        return _FRIENDLY_ERROR_MESSAGES[base]
    return fallback if fallback is not None else reason


# Sanitización de paths para logs/errores. No filtrar paths completos
# del SO que revelan estructura de directorios del usuario: tabla simple
# de sustituciones. El orden importa (el más específico primero:
# _ADDON_DATA_DIR antes que _PROFILE_DIR).
_LOG_PATH_REPLACEMENTS_INITIALIZED = False
_LOG_PATH_REPLACEMENTS = []


def _ensure_path_replacements():
    global _LOG_PATH_REPLACEMENTS_INITIALIZED, _LOG_PATH_REPLACEMENTS
    if _LOG_PATH_REPLACEMENTS_INITIALIZED:
        return
    _LOG_PATH_REPLACEMENTS = [
        (_ADDON_DATA_DIR, '<addon_data>/'),
        (_PROFILE_DIR, '<userdata>/'),
        (_ADDONS_DIR, '<addons>/'),
        (SNAPSHOTS_DIR, '<snapshots>/'),
    ]
    # Filtrar entries con paths vacíos (xbmcvfs.translatePath podría
    # devolver '' en tests sin mock_kodi configurado).
    _LOG_PATH_REPLACEMENTS = [(r, repl) for r, repl in _LOG_PATH_REPLACEMENTS if r]
    _LOG_PATH_REPLACEMENTS_INITIALIZED = True


def _sanitize_path_for_log(s, *, max_len=200):
    """Reemplaza paths conocidos del SO con placeholders.

    Útil cuando un error contiene un path absoluto que no aporta al usuario
    (y que revela estructura de directorios). El log.security original
    mantiene el path completo (canal interno); este helper es para mensajes
    que viajan al frontend o aparecen en notif.
    """
    if not s:
        return ''
    _ensure_path_replacements()
    out = str(s)
    for raw, repl in _LOG_PATH_REPLACEMENTS:
        if raw:
            out = out.replace(raw, repl)
    if len(out) > max_len:
        out = out[:max_len - 3] + '...'
    return out


# Límite de longitud de path en Windows. NTFS soporta paths más largos
# con prefijo `\\?\` pero zipfile + os.walk no lo manejan uniformemente
# y muchos clientes ZIP (incluido el del Explorer) revientan. Margen: 230
# para dejar espacio al SNAPSHOTS_DIR cuando se extraiga.
_WINDOWS_MAX_ARC_LEN = 230


_DEVICE_ID_PATH = os.path.join(
    _ADDON_DATA_DIR, 'plugin.program.loiolink', 'backups', '.device_id',
)


def get_device_id():
    """Devuelve un UUID4 random persistente como identificador del dispositivo.

    En lugar de hash de hostname (predecible y filtra PII), un random
    fijo permite detectar "este backup viene de otro Kodi" sin revelar
    info del sistema.

    Generado en el primer uso y persistido en addon_data. Si el archivo
    se pierde se regenera (el nuevo device_id se considera "otro device").
    """
    import uuid
    try:
        if os.path.isfile(_DEVICE_ID_PATH):
            with open(_DEVICE_ID_PATH, 'r', encoding='utf-8') as fh:
                existing = fh.read().strip()
            if existing and len(existing) >= 16:
                return existing
    except OSError:
        pass
    # Generar nuevo
    new_id = uuid.uuid4().hex
    try:
        os.makedirs(os.path.dirname(_DEVICE_ID_PATH), exist_ok=True)
        with open(_DEVICE_ID_PATH, 'w', encoding='utf-8') as fh:
            fh.write(new_id)
    except OSError as e:
        log.warning(f'[backup] no se pudo persistir device_id: {e!r}')
    return new_id


def detect_case_sensitive_fs(base_dir=None):
    """Detecta case sensitivity del filesystem.

    Crea 'LoIoCaseTest' y comprueba si 'loioacasetest' (todo minúsculas)
    es accesible. Si lo es: FS case-insensitive (Windows/macOS HFS+).
    Si no: case-sensitive (Linux ext4, Android, etc.).
    """
    if base_dir is None:
        base_dir = _ADDON_DATA_DIR
    test_path = os.path.join(base_dir, 'LoIoCaseTest_loiolink')
    test_path_lower = os.path.join(base_dir, 'loiocasetest_loiolink')
    try:
        os.makedirs(base_dir, exist_ok=True)
        with open(test_path, 'w', encoding='utf-8') as fh:
            fh.write('test')
        try:
            return not os.path.isfile(test_path_lower)
        finally:
            try:
                os.unlink(test_path)
            except OSError:
                pass
    except OSError:
        return True  # default seguro


def build_environment_block():
    """Bloque `environment` para el manifest.

    Información sin PII para detectar cross-platform restores. NO usamos
    hash de hostname (predecible); usamos device_id random persistido.
    """
    import platform
    import sys as _sys
    # Detectar plataforma Kodi
    plat = 'unknown'
    for cond, name in (
        ('System.Platform.Android', 'android'),
        ('System.Platform.Linux', 'linux'),
        ('System.Platform.OSX', 'osx'),
        ('System.Platform.IOS', 'ios'),
        ('System.Platform.Windows', 'windows'),
        ('System.Platform.UWP', 'uwp'),
    ):
        try:
            if xbmc.getCondVisibility(cond):
                plat = name
                break
        except Exception:  # noqa: BLE001
            pass
    return {
        'kodi_version': xbmc.getInfoLabel('System.BuildVersion') or 'unknown',
        'kodi_major': _parse_kodi_major(
            xbmc.getInfoLabel('System.BuildVersion') or ''
        ),
        'os_name': platform.system(),
        'os_release': (platform.release() or '')[:80],
        'arch': platform.machine(),
        'python_version': _sys.version.split()[0],
        'language': xbmc.getInfoLabel('System.Language') or '',
        'device_id': get_device_id(),
        'addon_data_path': _ADDON_DATA_DIR,
        'case_sensitive_fs': detect_case_sensitive_fs(),
        'platform_kodi': plat,
    }


def check_environment_mismatch(backup_env, current_env=None):
    """Compara environment del manifest con el actual. Devuelve lista de
    warnings (vacía si OK). Cada warning es `{kind, backup, current, severity}`.
    """
    if not backup_env:
        return []
    if current_env is None:
        current_env = build_environment_block()
    out = []
    if (backup_env.get('os_name')
            and backup_env['os_name'] != current_env['os_name']):
        out.append({
            'kind': 'os_name',
            'backup': backup_env.get('os_name'),
            'current': current_env['os_name'],
            'severity': 'warning',
            'message': (
                f'Backup hecho en {backup_env["os_name"]}, restaurando '
                f'en {current_env["os_name"]}: paths absolutos pueden no '
                'funcionar'
            ),
        })
    if (backup_env.get('arch')
            and current_env.get('arch')
            and backup_env['arch'] != current_env['arch']):
        out.append({
            'kind': 'arch',
            'backup': backup_env.get('arch'),
            'current': current_env['arch'],
            'severity': 'warning',
            'message': (
                f'Backup arch={backup_env["arch"]}, sistema actual='
                f'{current_env["arch"]}: addons con binarios nativos '
                '(.so/.dll) pueden no cargar'
            ),
        })
    if (backup_env.get('device_id')
            and current_env.get('device_id')
            and backup_env['device_id'] != current_env['device_id']):
        # Si OS y arch coinciden, probablemente es el mismo device físico
        # tras un wipe de addon_data. Demote a info; solo info si OS y
        # arch coinciden.
        os_match = (backup_env.get('os_name') == current_env.get('os_name'))
        arch_match = (backup_env.get('arch') == current_env.get('arch'))
        severity = 'info' if (os_match and arch_match) else 'warning'
        msg = (
            'Backup viene de otro dispositivo.'
            if not (os_match and arch_match)
            else 'El device_id ha cambiado pero OS/arch coinciden '
                 '(posiblemente reset de addon_data en este mismo equipo).'
        )
        out.append({
            'kind': 'device_id',
            'backup': backup_env.get('device_id', '')[:8],
            'current': current_env.get('device_id', '')[:8],
            'severity': severity,
            'message': msg,
        })
    return out


def _rotate_dir_by_count(directory, keep, *, name_filter=None):
    """Mantiene los `keep` ZIPs más recientes en `directory`. FIFO por mtime."""
    if not os.path.isdir(directory) or keep < 1:
        return 0
    try:
        names = os.listdir(directory)
    except OSError:
        return 0
    files = []
    for n in names:
        if not n.lower().endswith('.zip'):
            continue
        if name_filter and not name_filter(n):
            continue
        p = os.path.join(directory, n)
        try:
            mt = os.path.getmtime(p)
        except OSError:
            continue
        files.append((mt, p))
    files.sort(reverse=True)
    removed = 0
    for _mt, p in files[keep:]:
        try:
            os.unlink(p)
            removed += 1
        except OSError:
            pass
    return removed


def _make_pre_restore_snapshot(*, addon_ids, addon_data_ids,
                                kodi_categories, cancel_check=None):
    """Snapshot rápido del estado actual antes de un restore.

    Solo respalda lo que el restore va a tocar (sin manifest grande, sin
    hashes, sin rotación de snapshots del usuario). El propósito es
    permitir reversión si el restore deja el sistema en mal estado.

    Sin mutex (estamos dentro de uno). Si falla, devuelve None y se logea
    pero el restore continúa (snapshot pre-restore es "best effort").

    Devuelve path absoluto del ZIP o None.
    """
    try:
        os.makedirs(AUTO_PRE_RESTORE_DIR, exist_ok=True)
    except OSError as e:
        log.warning(f'[backup] auto_pre_restore: no mkdir: {e!r}')
        return None
    # Resolver settings de compresión/basura una vez para que el snapshot
    # respete la configuración del usuario (consistente con backup normal).
    comp_idx = _resolve_compression_index()
    exclude_garbage = _resolve_exclude_garbage()
    stamp = time.strftime('%Y-%m-%d_%H%M%S')
    fname = f'kodi_backup_{stamp}_pre_restore.zip'
    final_path = os.path.join(AUTO_PRE_RESTORE_DIR, fname)
    tmp_path = final_path + '.tmp'
    try:
        with _zipfile_open_write(tmp_path, compression_index=comp_idx) as zf:
            # Mini-manifest minimal para que el ZIP sea "loadable" si el
            # user lo importa como backup normal en el futuro.
            mini_manifest = {
                'manifest_version': MANIFEST_VERSION,
                'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
                'created_unix': int(time.time()),
                'kodi_version': (
                    xbmc.getInfoLabel('System.BuildVersion') or 'unknown'
                ),
                'loiolink_version': 'auto_pre_restore',
                'filters': {
                    'exclude_system': True,
                    'exclude_skins': True,
                    'exclude_garbage': exclude_garbage,
                    'compression_level': comp_idx,
                },
                'addons': [], 'repos': [], 'sources': [],
                'file_hashes': {},
                'hash_algo': None,
                'environment': {},
                'categories': dict(kodi_categories or {}),
                'watched_state': None,
                'guisettings_dump': None,
                'auto_pre_restore': True,
                'label': 'pre_restore_auto',
            }
            zf.writestr('manifest.json',
                        json.dumps(mini_manifest, indent=2,
                                    ensure_ascii=False).encode('utf-8'))

            # Solo respaldamos addons que el restore va a sobrescribir.
            for aid in addon_ids or []:
                if cancel_check and cancel_check():
                    raise InterruptedError('cancelado')
                src = os.path.join(_ADDONS_DIR, aid)
                if os.path.isdir(src):
                    _add_dir_to_zip(
                        zf, src, _safe_arcname(['addons', aid]),
                        cancel_check=cancel_check,
                        exclude_garbage=exclude_garbage,
                    )
            for aid in addon_data_ids or []:
                if cancel_check and cancel_check():
                    raise InterruptedError('cancelado')
                src = os.path.join(_ADDON_DATA_DIR, aid)
                if os.path.isdir(src):
                    _add_dir_to_zip(
                        zf, src, _safe_arcname(['addon_data', aid]),
                        cancel_check=cancel_check,
                        exclude_garbage=exclude_garbage,
                    )
            if kodi_categories:
                _add_kodi_categories_to_zip(
                    zf, kodi_categories,
                    cancel_check=cancel_check,
                    exclude_garbage=exclude_garbage,
                )
        os.replace(tmp_path, final_path)
        # Rotación: solo afecta a auto_pre_restore/, no a snapshots/.
        try:
            keep = int(
                xbmcaddon.Addon().getSetting(
                    'backup.auto_pre_restore.keep') or 3
            )
        except (ValueError, RuntimeError):
            keep = 3
        _rotate_dir_by_count(AUTO_PRE_RESTORE_DIR, keep)
        log.info(f'[backup] auto_pre_restore creado: {fname}')
        return final_path
    except Exception as e:
        log.warning(f'[backup] auto_pre_restore falló: {e!r}')
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        return None


def _hash_file_sha256(path):
    """SHA256 streaming de un archivo. Devuelve hex (64 chars) o None si error.

    Streaming en bloques de 64KB para no cargar archivos grandes a RAM.
    """
    import hashlib
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as fh:
            while True:
                chunk = fh.read(65536)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()
    except OSError as e:
        log.warning(
            f'[backup] hash falló para {_sanitize_path_for_log(path)}: '
            f'{_sanitize_path_for_log(repr(e))[:120]}'
        )
        return None


def _hash_bytes_sha256(data):
    """SHA256 de un bloque de bytes (para verificación tras extracción)."""
    import hashlib
    return hashlib.sha256(data).hexdigest()


def _backup_sqlite_consistent(src_path):
    """Snapshot consistente de una DB SQLite con la API `.backup()`.

    Necesario porque las DBs Kodi (Music/Video/Textures/EPG) están abiertas
    en modo WAL y un `os.copy` raw del `.db` pierde transacciones que
    están en `.db-wal` no checkpointed.

    Devuelve path a un tempfile con la copia consistente. El caller debe
    `os.unlink` después de copiar al ZIP. Si SQLite falla (DB no SQLite,
    locks irrecuperables, etc.), levanta sqlite3.DatabaseError.

    Antes del backup hace `PRAGMA wal_checkpoint(TRUNCATE)` para forzar
    que todos los cambios del WAL queden en el .db principal antes de
    snapshotear, eliminando dependencia del `.db-wal` y `.db-shm`.
    """
    import sqlite3
    import tempfile
    import xbmcvfs
    temp_dir = xbmcvfs.translatePath('special://temp/')
    # Kodi crea special://temp/ al arrancar, pero no dependemos de ello:
    # si falta, mkstemp lanzaría FileNotFoundError y abortaría el backup
    # entero por una precondición implícita.
    os.makedirs(temp_dir, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(
        suffix='.db', prefix='loiolink_sqlite_backup_', dir=temp_dir,
    )
    os.close(fd)
    # Tomar ownership del tempfile. Si CUALQUIER excepción ocurre entre
    # el mkstemp y el return, debemos limpiarlo nosotros (el caller
    # espera recibir un path válido o una excepción; nunca un tempfile
    # huérfano).
    try:
        src = sqlite3.connect(src_path, timeout=10.0)
        try:
            # Asegurar checkpoint del WAL para que la copia incluya cambios
            # recientes. Si la DB no es WAL este pragma es no-op.
            try:
                src.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            except sqlite3.OperationalError:
                # DB locked u otro pragma fail: continuamos con .backup()
                # que tolera estado en flux (es online backup API).
                pass
            dst = sqlite3.connect(tmp_path)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        return tmp_path
    except BaseException:
        # Cualquier fallo (sqlite3.DatabaseError, OSError, KeyboardInterrupt):
        # limpiamos el tempfile y propagamos la excepción.
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# Tabla de versiones de DB Kodi por major version.
# Cada release de Kodi suele incrementar el sufijo numérico de MyVideos.
# Datos verificados de la wiki: kodi.wiki/view/Databases/MyVideos
_KODI_DB_VERSIONS = {
    # major: {'MyVideos': N, 'MyMusic': N, 'Textures': N, 'Epg': N}
    #
    # Valores verificados contra xbmc/xbmc en GitHub (mayo 2026):
    # - MyVideos: VideoDatabaseMigration.cpp (GetSchemaVersion)
    # - MyMusic: MusicDatabase.cpp (return 84 en master)
    # - Textures: TextureDatabase.h (return 14)
    # - Epg: pvr/epg/EpgDatabase.h (return 21)
    #
    # MyMusic, Textures y Epg han cambiado MUY POCO entre versiones major
    # de Kodi (los esquemas son mucho más estables que MyVideos). Por eso
    # usamos el mismo número en todas las versiones soportadas.
    19: {'MyVideos': 119, 'MyMusic': 82, 'Textures': 13, 'Epg': 10},   # Matrix
    20: {'MyVideos': 121, 'MyMusic': 84, 'Textures': 14, 'Epg': 21},   # Nexus
    21: {'MyVideos': 131, 'MyMusic': 84, 'Textures': 14, 'Epg': 21},   # Omega
    22: {'MyVideos': 145, 'MyMusic': 84, 'Textures': 14, 'Epg': 21},   # Piers (Alpha 3, master 2026)
}

# Mapping Kodi major a Python major. Cambió en Kodi 19 (último release con
# Python 2 fue Kodi 18 Leia; Kodi 19 Matrix introdujo Python 3). Un addon
# que requiere `xbmc.python >= 3.0` NO carga en Kodi 18 aunque se instale;
# un addon que requiere `xbmc.python 2.x` no debería instalarse en Kodi 19+.
_KODI_PYTHON_MAJOR = {
    18: 2,    # Leia
    19: 3,    # Matrix
    20: 3,    # Nexus
    21: 3,    # Omega
    22: 3,    # Piers
}

# Regex para extraer prefix + número del filename de DB.
_DB_FILENAME_RE = re.compile(r'^(MyVideos|MyMusic|Textures|Epg|ADSPDB)(\d+)\.db$',
                              re.IGNORECASE)


def check_addon_python_compat(addon_dict, current_kodi_major):
    """¿Es este addon compatible con la versión Python de Kodi?

    Lee `addon['requires']` (lista de dicts {id, version}) y busca la
    dependencia `xbmc.python`. Si el major de la versión requerida no
    coincide con el major Python de la Kodi target, devuelve incompatibilidad.

    Devuelve `(compatible: bool, warning: str | None)`. Si no hay info
    suficiente (manifest v1 sin requires, Kodi major desconocido), devuelve
    (True, None): permisivo por defecto, mejor advertir solo cuando hay
    certeza.

    Casos detectados (silenciosos sin esta función):
    - Backup Kodi 19+ (Py 3) restaurado en Kodi 18 (Py 2): addon no carga
    - Backup Kodi 18 (Py 2) restaurado en Kodi 19+ (Py 3): addon no carga
    """
    if not addon_dict or not isinstance(addon_dict, dict):
        return True, None
    requires = addon_dict.get('requires') or []
    if not requires or current_kodi_major is None:
        return True, None
    target_python_major = _KODI_PYTHON_MAJOR.get(current_kodi_major)
    if target_python_major is None:
        # Kodi major fuera de nuestra tabla; ser permisivo (asumir Py3)
        return True, None
    for req in requires:
        if not isinstance(req, dict):
            continue
        if req.get('id') != 'xbmc.python':
            continue
        req_version = req.get('version') or ''
        if not req_version:
            continue
        # Extraer major: "3.0.0" → 3, "2.25.0" → 2
        try:
            req_major = int(str(req_version).split('.', 1)[0])
        except (ValueError, IndexError):
            continue
        if req_major != target_python_major:
            aid = addon_dict.get('id', '?')
            return False, (
                f'{aid} requiere Python {req_major} pero Kodi {current_kodi_major} '
                f'usa Python {target_python_major}; el addon no cargará tras restaurar'
            )
        return True, None
    return True, None


def check_db_version_compat(db_filename, current_kodi_major):
    """¿Es esta DB compatible con la Kodi actual?

    Devuelve `(compatible: bool, warning: str | None)`. Para DBs con
    versión que NO conocemos en la tabla, devuelve (True, None) (no
    sabemos, asumimos compatible).
    """
    m = _DB_FILENAME_RE.match(os.path.basename(db_filename))
    if not m:
        # No es una DB con versión en el nombre (companions, addon DBs custom).
        return True, None
    prefix = m.group(1)
    try:
        backup_ver = int(m.group(2))
    except ValueError:
        return True, None
    if current_kodi_major is None:
        return True, None
    if current_kodi_major not in _KODI_DB_VERSIONS:
        # Major desconocido (Kodi futuro): asumir compatible para no rechazar
        # restores cuando sale una versión nueva antes de actualizar la tabla.
        log.info(
            f'[backup] check_db_version_compat: Kodi major {current_kodi_major} '
            f'no esta en _KODI_DB_VERSIONS; asumiendo compatible '
            f'({prefix}{backup_ver}.db). Actualizar tabla si Kodi cambio el schema.'
        )
        return True, None
    expected = _KODI_DB_VERSIONS[current_kodi_major].get(prefix)
    if expected is None:
        # Prefijo no listado para esta major (companion, addon DB custom).
        return True, None
    if backup_ver == expected:
        return True, None
    return False, (
        f'{prefix}{backup_ver}.db es de otra versión de Kodi (esperado '
        f'{prefix}{expected}.db en Kodi {current_kodi_major}). Kodi '
        'no podrá leer esta DB; tras restaurar reescanea la biblioteca.'
    )


def _is_sqlite_companion(filename):
    """True si el archivo es companion WAL/SHM de una DB.

    Cuando hacemos snapshot consistente del .db, estos companions quedan
    obsoletos (ya están consolidados en el .db). NO se respaldan para
    evitar inconsistencia (un .db consolidated + un .db-wal viejo daría
    DB corrupta al restaurar).
    """
    lower = filename.lower()
    return (lower.endswith('.db-wal') or lower.endswith('.db-shm')
            or lower.endswith('.db-journal'))


def _should_skip_garbage(name, *, is_dir):
    """True si `name` (basename) coincide con un patrón de basura.

    Case-insensitive en todas las comparaciones. Para directorios,
    devuelve True si el nombre exacto está en `_GARBAGE_DIR_NAMES` (sin
    extensión). Para archivos, comprueba nombre exacto, extensión, y la
    convención `*~` (editor backups).
    """
    if not name:
        return False
    lower = name.lower()
    if is_dir:
        return lower in _GARBAGE_DIR_NAMES
    if lower in _GARBAGE_FILE_EXACT_LOWER:
        return True
    if lower.endswith(_GARBAGE_FILE_SUFFIXES):
        return True
    if name.endswith('~'):
        return True
    return False


def _resolve_compression_index(index=None):
    """Resuelve el índice de compresión válido (entero 0..len(MAP)-1).

    Si `index` es None, lee `backup.compression_level`. Si el setting está
    vacío, corrupto, fuera de rango o `xbmcaddon` no está disponible
    (tests), cae al default. Centraliza el saneo para que callers no
    repitan el clamp y para no propagar valores ilegales al ZipFile.
    """
    if index is None:
        try:
            index = xbmcaddon.Addon().getSettingInt('backup.compression_level')
        except (RuntimeError, ValueError, AttributeError):
            index = _DEFAULT_COMPRESSION_INDEX
    if (not isinstance(index, int) or index < 0
            or index >= len(_COMPRESSION_MAP)):
        index = _DEFAULT_COMPRESSION_INDEX
    return index


def _resolve_exclude_garbage(value=None):
    """Resuelve el flag de exclude_garbage con fallback robusto."""
    if value is None:
        try:
            value = xbmcaddon.Addon().getSettingBool('backup.exclude_garbage')
        except (RuntimeError, AttributeError):
            value = True
    return bool(value)


def _resolve_compression(index=None):
    """Devuelve (method, level_or_None) según `backup.compression_level`."""
    return _COMPRESSION_MAP[_resolve_compression_index(index)]


def _zipfile_open_write(path, *, compression_index=None):
    """ZipFile abierto en modo write con la compresión configurada.

    Centraliza la omisión del kwarg `compresslevel` cuando el método es
    ZIP_STORED: pasar `compresslevel=None` no crashea pero es ruido.
    """
    method, level = _resolve_compression(compression_index)
    if level is None:
        return zipfile.ZipFile(path, 'w', method, allowZip64=True)
    return zipfile.ZipFile(path, 'w', method, compresslevel=level,
                           allowZip64=True)


def _add_dir_to_zip(zf, src_dir, arc_prefix, cancel_check=None,
                    skipped_log=None, sqlite_consistent=False,
                    hash_log=None, exclude_garbage=False):
    """Añade recursivamente un directorio al ZIP bajo arc_prefix/.

    Devuelve el número de archivos añadidos. Los archivos no copiados
    (locks Windows, paths demasiado largos, symlinks, traversal) se
    logean. Si `skipped_log` es una list, se le hace append con
    `{path, reason}` para reporte al caller.

    sqlite_consistent: si True, los `.db` se snapshotean con la API
    `sqlite3.backup()` (consistente con Kodi corriendo). Los companions
    `.db-wal/.db-shm/.db-journal` se omiten (van implícitos en el snapshot).

    hash_log: dict opcional `{arcname: hex_hash}` que se rellena con
    SHA256 de cada archivo escrito al ZIP. Si None, no se calculan hashes.

    exclude_garbage: si True, filtra directorios y archivos basura (ver
    `_should_skip_garbage`) durante el `os.walk`. Los directorios basura
    se podan in-place para que `os.walk` no descienda; esto es importante
    porque `__pycache__/` típico contiene decenas de `.pyc` y la poda
    ahorra el walk completo del subtree.
    """
    if not os.path.isdir(src_dir):
        return 0
    count = 0
    src_real = os.path.realpath(src_dir)
    is_windows = (os.name == 'nt')
    for root, dirs, files in os.walk(src_dir):
        if cancel_check and cancel_check():
            raise InterruptedError('Backup cancelado')
        # Estabilidad del ZIP (orden determinista)
        dirs.sort()
        files.sort()
        if exclude_garbage:
            keep_dirs, skip_dirs = [], []
            for d in dirs:
                (skip_dirs if _should_skip_garbage(d, is_dir=True)
                 else keep_dirs).append(d)
            if skipped_log is not None and skip_dirs:
                for d in skip_dirs:
                    rel = os.path.relpath(
                        os.path.join(root, d), src_dir,
                    ).replace(os.sep, '/')
                    skipped_log.append({
                        'path': _sanitize_path_for_log(
                            _safe_arcname([arc_prefix, rel])),
                        'reason': 'garbage',
                    })
            dirs[:] = keep_dirs  # in-place: os.walk no descenderá
            keep_files = []
            for f in files:
                if _should_skip_garbage(f, is_dir=False):
                    if skipped_log is not None:
                        rel = os.path.relpath(
                            os.path.join(root, f), src_dir,
                        ).replace(os.sep, '/')
                        skipped_log.append({
                            'path': _sanitize_path_for_log(
                                _safe_arcname([arc_prefix, rel])),
                            'reason': 'garbage',
                        })
                else:
                    keep_files.append(f)
            files = keep_files
        for fname in files:
            # Cancel check por archivo (no solo por directorio): un addon con
            # miles de archivos en una misma carpeta tardaría minutos en
            # responder al cancelar si solo se chequea al inicio del os.walk.
            if cancel_check and cancel_check():
                raise InterruptedError('Backup cancelado')
            full = os.path.join(root, fname)
            # Reject symlinks; nuestros backups solo copian regular files.
            if os.path.islink(full):
                log.security(
                    f'[backup] symlink ignorado: {full}'
                )
                if skipped_log is not None:
                    skipped_log.append({
                        'path': _sanitize_path_for_log(full),
                        'reason': 'symlink',
                    })
                continue
            # Defensa anti-escape: el path real debe seguir dentro de src.
            real = os.path.realpath(full)
            if not (real == src_real or real.startswith(src_real + os.sep)):
                log.security(f'[backup] path fuera de src ignorado: {full}')
                if skipped_log is not None:
                    skipped_log.append({
                        'path': _sanitize_path_for_log(full),
                        'reason': 'path_escape',
                    })
                continue
            rel = os.path.relpath(full, src_dir).replace(os.sep, '/')
            arc = _safe_arcname([arc_prefix, rel])
            # Longitud máxima del path en Windows: NTFS sin `\\?\` prefix
            # limita a 260 chars; si alguien extrae el ZIP en Windows
            # revienta. Dejamos margen para el destino de extracción.
            if is_windows and len(arc) > _WINDOWS_MAX_ARC_LEN:
                log.warning(
                    f'[backup] path demasiado largo, omitido: {arc[:80]}...'
                )
                if skipped_log is not None:
                    skipped_log.append({
                        'path': _sanitize_path_for_log(arc),
                        'reason': 'path_too_long',
                    })
                continue
            # SQLite consistency: si la categoría lo pide y es un .db,
            # snapshotear con sqlite3.backup() API. Los companions WAL/SHM
            # se omiten porque el snapshot ya incluye sus datos consolidados
            # (sin esto, copy raw del .db pierde transacciones que viven en
            # el .db-wal mientras Kodi corre).
            if sqlite_consistent:
                if _is_sqlite_companion(fname):
                    if skipped_log is not None:
                        skipped_log.append({
                            'path': _sanitize_path_for_log(arc),
                            'reason': 'sqlite_companion_omitted',
                        })
                    continue
                if fname.lower().endswith('.db'):
                    tmp_path = None
                    try:
                        tmp_path = _backup_sqlite_consistent(full)
                        zf.write(tmp_path, arc)
                        count += 1
                        # Skip hash si DB grande (>100MB): hashear una DB
                        # de 2GB tras `zf.write` significa leer la DB
                        # entera de nuevo (4GB I/O total). Para archivos
                        # grandes confiamos en CRC32 del ZIP + integridad
                        # SQLite (que se valida al restaurar).
                        if hash_log is not None:
                            try:
                                tmp_size = os.path.getsize(tmp_path)
                            except OSError:
                                tmp_size = 0
                            if tmp_size > LARGE_FILE_HASH_SKIP_BYTES:
                                hash_log[arc] = 'sha256:skipped_size'
                            else:
                                h = _hash_file_sha256(tmp_path)
                                if h:
                                    hash_log[arc] = h
                    except Exception as e:  # sqlite3.DatabaseError u otros
                        log.warning(
                            f'[backup] sqlite snapshot falló para '
                            f'{_sanitize_path_for_log(arc)}: {e!r}. '
                            'Cayendo a copy raw.'
                        )
                        # Fallback: copy raw. Mejor un .db raw (posible
                        # inconsistencia) que perder el archivo entero.
                        try:
                            zf.write(full, arc)
                            count += 1
                            if hash_log is not None:
                                h = _hash_file_sha256(full)
                                if h:
                                    hash_log[arc] = h
                        except (OSError, PermissionError) as e2:
                            log.warning(
                                f'[backup] sqlite fallback falló: {e2!r}'
                            )
                            if skipped_log is not None:
                                skipped_log.append({
                                    'path': _sanitize_path_for_log(arc),
                                    'reason': _sanitize_path_for_log(str(e2))[:80],
                                })
                    finally:
                        if tmp_path:
                            try:
                                os.unlink(tmp_path)
                            except OSError:
                                pass
                    continue
            # try/except alrededor de zf.write. En Windows, Kodi puede
            # tener el archivo bloqueado (lock obligatorio de NTFS para
            # procesos con handle abierto). Si revienta, logear y
            # continuar con el resto (no abortar el backup).
            try:
                zf.write(full, arc)
                count += 1
                if hash_log is not None:
                    h = _hash_file_sha256(full)
                    if h:
                        hash_log[arc] = h
            except (OSError, PermissionError) as e:
                log.warning(
                    f'[backup] no se pudo añadir {_sanitize_path_for_log(arc)}: '
                    f'{e!r}'
                )
                if skipped_log is not None:
                    skipped_log.append({
                        'path': _sanitize_path_for_log(arc),
                        'reason': _sanitize_path_for_log(str(e))[:80],
                    })
    return count


# Archivos directos en userdata/ a respaldar como config_root.
# `os.listdir(_PROFILE_DIR)` daría también subdirs (Database, Thumbnails)
# que NO queremos aquí (van por su categoría propia). Lista explícita de
# archivos típicos + lo que esté DIRECTAMENTE en la raíz como archivo.
_CONFIG_ROOT_FILES_HINT = (
    'advancedsettings.xml',
    'guisettings.xml',
    'passwords.xml',
    'RssFeeds.xml',
    'mediasources.xml',
    'sources.xml',
    'favourites.xml',
    'profiles.xml',
    'kodi.log',  # se excluirá por nombre, ver _should_skip_config_file
)

_CONFIG_ROOT_SKIP_FILES = ('kodi.log', 'kodi.old.log', 'spmc.log',
                           'spmc.old.log', 'xbmc.log', 'xbmc.old.log')


def _add_config_root_to_zip(zf, arc_prefix, *, cancel_check=None,
                            skipped_log=None, hash_log=None,
                            exclude_garbage=False):
    """Añade archivos DIRECTOS de userdata/ (no recursivo) al ZIP.

    No incluye subdirectorios (van por categorías propias) ni archivos
    de log (kodi.log etc, ruido sin valor de backup). Si `exclude_garbage`
    es True, también filtra basura por nombre (Thumbs.db, .DS_Store, etc.).
    """
    if not os.path.isdir(_PROFILE_DIR):
        return 0
    count = 0
    try:
        entries = sorted(os.listdir(_PROFILE_DIR))
    except OSError as e:
        log.warning(f'[backup] no se pudo listar userdata: {e!r}')
        return 0
    for name in entries:
        if cancel_check and cancel_check():
            raise InterruptedError('Backup cancelado')
        full = os.path.join(_PROFILE_DIR, name)
        if not os.path.isfile(full):
            continue
        if name in _CONFIG_ROOT_SKIP_FILES or name.lower().endswith('.log'):
            continue
        if exclude_garbage and _should_skip_garbage(name, is_dir=False):
            if skipped_log is not None:
                arc = _safe_arcname([arc_prefix, name])
                skipped_log.append({
                    'path': _sanitize_path_for_log(arc),
                    'reason': 'garbage',
                })
            continue
        if os.path.islink(full):
            log.security(f'[backup] symlink en userdata ignorado: {full}')
            continue
        arc = _safe_arcname([arc_prefix, name])
        try:
            zf.write(full, arc)
            count += 1
            if hash_log is not None:
                h = _hash_file_sha256(full)
                if h:
                    hash_log[arc] = h
        except (OSError, PermissionError) as e:
            log.warning(
                f'[backup] no se pudo añadir {_sanitize_path_for_log(arc)}: {e!r}'
            )
            if skipped_log is not None:
                skipped_log.append({
                    'path': _sanitize_path_for_log(arc),
                    'reason': _sanitize_path_for_log(str(e))[:80],
                })
    return count


def _add_kodi_categories_to_zip(zf, selected, *, cancel_check=None,
                                 skipped_log=None, progress_cb=None,
                                 hash_log=None, exclude_garbage=False):
    """Añade al ZIP las categorías marcadas en `selected` (dict).

    `selected` es `{category_name: bool}`. Las categorías virtuales
    (guisettings, watched_state) se ignoran aquí; los maneja el caller
    porque vienen de JSON-RPC, no de archivos.

    Devuelve dict `{name: files_added}` para incluir en el manifest.
    """
    if not selected:
        return {}
    out = {}
    # Iterar la spec para orden determinista (no el dict del usuario)
    for name, subdir, arc, _default, sqlite_cons, _warn in KODI_CATEGORIES_SPEC:
        if not selected.get(name):
            continue
        src = os.path.join(_PROFILE_DIR, subdir)
        if not os.path.isdir(src):
            out[name] = 0
            continue
        if progress_cb:
            progress_cb(0, 0, f'Añadiendo {name}...')
        count = _add_dir_to_zip(
            zf, src, arc,
            cancel_check=cancel_check,
            skipped_log=skipped_log,
            sqlite_consistent=sqlite_cons,
            hash_log=hash_log,
            exclude_garbage=exclude_garbage,
        )
        out[name] = count
    # config_root es especial (no recursivo, manejo aparte)
    if selected.get(KODI_CONFIG_ROOT_NAME):
        if progress_cb:
            progress_cb(0, 0, 'Añadiendo configuración raíz...')
        out[KODI_CONFIG_ROOT_NAME] = _add_config_root_to_zip(
            zf, KODI_CONFIG_ROOT_ARC,
            cancel_check=cancel_check,
            skipped_log=skipped_log,
            hash_log=hash_log,
            exclude_garbage=exclude_garbage,
        )
    return out


def create_backup(*, addon_ids, repo_ids,
                  include_addon_data, include_sources, include_favourites,
                  label=None, exclude_system=True, exclude_skins=True,
                  kodi_categories=None,
                  encrypt_password=None,
                  compression_level=None, exclude_garbage=None,
                  progress_cb=None, cancel_check=None):
    """Crea un ZIP en SNAPSHOTS_DIR. Devuelve el filename.

    addon_ids: lista de IDs cuyos archivos físicos quedan dentro del ZIP.
    repo_ids: idem para repos. SELF_ADDON_ID se filtra siempre.
    include_addon_data: True/False global, o dict {id: bool} por addon.
    kodi_categories: dict {category_name: bool} con categorías Kodi
        adicionales. None = ninguna nueva (comportamiento legacy). Usa
        `category_default_selection()` para defaults sanos.
    encrypt_password: si se pasa string no vacío, el manifest se cifra con
        AES-256-CBC + PBKDF2. El ZIP queda sin cifrar pero sin manifest no
        se puede restaurar. None/vacío = sin cifrado. Si pierdes el
        password, no podrás restaurar el backup.
    compression_level: índice 0-3 (Sin comprimir/Rápido/Normal/Máximo). Si
        None, se lee del setting `backup.compression_level`.
    exclude_garbage: bool. Si None, se lee del setting
        `backup.exclude_garbage`. Filtra `__pycache__`, `*.pyc`,
        `Thumbs.db`, `.DS_Store` y similares al iterar el filesystem.
    progress_cb(done, total, msg).
    cancel_check(): callable que devuelve True si hay que abortar.

    El manifest incluido refleja TODO el sistema actual aunque la lista de
    `addon_ids` sea parcial. Eso permite que el manifest siga siendo útil
    para "restaurar desde repo" aunque los archivos no estén en el ZIP.
    """
    if not acquire_backup_mutex(owner='backup_create'):
        raise BackupBusyError('Ya hay una operación de backup en curso')
    try:
        return _do_create_backup(
            addon_ids=addon_ids, repo_ids=repo_ids,
            include_addon_data=include_addon_data,
            include_sources=include_sources,
            include_favourites=include_favourites,
            label=label, exclude_system=exclude_system,
            exclude_skins=exclude_skins,
            kodi_categories=kodi_categories,
            encrypt_password=encrypt_password,
            compression_level=compression_level,
            exclude_garbage=exclude_garbage,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    finally:
        release_backup_mutex()


def _replace_with_retry(src, dst, *, max_retries=3, base_delay_s=0.1):
    """`os.replace` con reintento exponencial.

    SMB/NTFS pueden fallar transitoriamente si el destino está siendo
    accedido por otro proceso (Windows Defender escaneando, indexador,
    antivirus, otro Kodi). Reintentamos con backoff antes de propagar.
    """
    last_err = None
    for attempt in range(max_retries):
        try:
            os.replace(src, dst)
            return
        except FileNotFoundError:
            # Si src desapareció, es un error real (no reintento)
            raise
        except OSError as e:
            last_err = e
            if attempt < max_retries - 1:
                time.sleep(base_delay_s * (2 ** attempt))
    raise BackupError(
        f'no se pudo mover archivo final tras {max_retries} intentos: '
        f'{_sanitize_path_for_log(str(last_err))[:80]}'
    )


def _atomic_write_bytes(path, data):
    """Escribe `data` en `path` sin dejarlo truncado si algo falla a mitad.

    Mismo patrón que `_write_favourites_xml` y `lib.sources`: tmp (con pid y
    thread en el nombre para que dos escrituras concurrentes no se pisen el
    intermedio) + `_replace_with_retry`. Importa sobre todo en el restore: si
    un kill, un corte de luz o un disco lleno pilla a medias la escritura de
    favourites.xml o sources.xml, el usuario los pierde enteros.

    En binario a propósito: el contenido viene tal cual del ZIP y así se
    preserva. En modo texto, un XML con CRLF acabaría con '\\r\\r\\n' en
    Windows (Python traduce el '\\n' que ya iba precedido de '\\r').
    """
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'wb') as fh:
            fh.write(data)
        _replace_with_retry(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _atomic_extract_entry(zf, info, dest_path):
    """Extrae un entry del ZIP a `dest_path` sin dejarlo truncado a medias.

    Hermano de `_atomic_write_bytes` para la ruta de categorías, donde el
    destino puede ser una DB de varios GB: escribe en streaming a un tmp y
    hace el replace, en vez de cargar el fichero entero en memoria.

    Efecto lateral bueno: `os.replace` SUSTITUYE el destino, mientras que el
    `open(destino, 'wb')` de antes escribía A TRAVÉS de él si el destino era
    un symlink. El tipo de entry ya se valida en el caller, así que aquí no
    hace falta ningún chequeo extra: lo que escribimos es un fichero regular
    recién creado.
    """
    parent = os.path.dirname(dest_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = f'{dest_path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with zf.open(info, 'r') as src, open(tmp, 'wb') as dst:
            shutil.copyfileobj(src, dst, length=64 * 1024)
        _replace_with_retry(tmp, dest_path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _do_create_backup(*, addon_ids, repo_ids,
                      include_addon_data, include_sources, include_favourites,
                      label, exclude_system, exclude_skins,
                      kodi_categories,
                      encrypt_password=None,
                      compression_level=None, exclude_garbage=None,
                      progress_cb, cancel_check):
    compression_level = _resolve_compression_index(compression_level)
    exclude_garbage = _resolve_exclude_garbage(exclude_garbage)
    _ensure_snapshots_dir()
    filename = _build_filename(label)
    # Si hay custom path escribible, lo usamos como destino;
    # en otro caso, default SNAPSHOTS_DIR.
    from lib import backup_storage
    storages = backup_storage.get_active_storages(SNAPSHOTS_DIR)
    write_storage = next((s for s in storages if s.writable()), None)
    if write_storage is None:
        write_storage = backup_storage.LocalStorage(SNAPSHOTS_DIR)
    final_path = write_storage.path_for(filename)
    tmp_path = final_path + '.tmp'

    def _cb(pct, msg):
        if progress_cb:
            progress_cb(pct, 100, msg)

    # Los helpers de empaquetado llaman a `cancel_check` una vez por archivo,
    # así que es el sitio natural para mantener vivo el mutex sin añadir un
    # hilo ni un timer. `heartbeat_backup_mutex` se estrangula por dentro.
    def _tick():
        heartbeat_backup_mutex()
        return bool(cancel_check and cancel_check())

    def _check_cancel():
        if _tick():
            raise InterruptedError('Backup cancelado')

    _cb(2, 'Generando manifiesto...')
    manifest = build_manifest(
        exclude_system=exclude_system,
        exclude_skins=exclude_skins,
        exclude_garbage=exclude_garbage,
        compression_level=compression_level,
    )
    if label:
        manifest['label'] = label
    _check_cancel()

    # Filtrar listas: SELF, IDs inválidos, y según política de exclusión.
    safe_addon_ids = [
        a for a in (addon_ids or [])
        if is_backupable(a, exclude_system=exclude_system,
                         exclude_skins=exclude_skins)
        and os.path.isdir(os.path.join(_ADDONS_DIR, a))
    ]
    safe_repo_ids = [
        r for r in (repo_ids or [])
        if _valid_addon_id(r) and r.startswith('repository.')
        and not r.startswith('repository.xbmc.')
        and os.path.isdir(os.path.join(_ADDONS_DIR, r))
    ]

    # Marcar en el manifest qué addons llevan archivos físicos
    addon_files_set = set(safe_addon_ids)
    repo_files_set = set(safe_repo_ids)
    for entry in manifest['addons']:
        entry['files_included'] = entry['id'] in addon_files_set
    for entry in manifest['repos']:
        entry['files_included'] = entry['id'] in repo_files_set

    # Normalizar selección de categorías Kodi: si el caller no pasó nada
    # respetamos el comportamiento legacy (solo sources/favourites/addon_data
    # según sus flags propios; ninguna categoría nueva).
    selected_categories = dict(kodi_categories) if kodi_categories else {}
    # Mantener compatibilidad: sources y favourites pueden venir o como
    # bool independiente (legacy) o como categoría. Si el flag legacy es
    # True, garantizamos su presencia para que el restore sepa que estaban.
    selected_categories['sources'] = bool(include_sources)
    selected_categories['favourites'] = bool(include_favourites)

    # Snapshot de qué se intentó respaldar (se incluye en manifest).
    manifest['categories'] = dict(selected_categories)

    skipped_files = []
    # SHA256 de cada archivo añadido. Setting para desactivar en CPUs
    # débiles (RPi 1). Default ON.
    try:
        import xbmcaddon
        compute_hashes = xbmcaddon.Addon().getSettingBool('backup.compute_hashes')
    except (RuntimeError, AttributeError):
        compute_hashes = True
    file_hashes = {} if compute_hashes else None

    try:
        with _zipfile_open_write(tmp_path,
                                 compression_index=compression_level) as zf:
            _check_cancel()

            if include_sources and os.path.isfile(_SOURCES_PATH):
                _cb(8, 'Añadiendo sources.xml...')
                zf.write(_SOURCES_PATH, 'sources.xml')

            if include_favourites and os.path.isfile(_FAVOURITES_PATH):
                _cb(10, 'Añadiendo favourites.xml...')
                zf.write(_FAVOURITES_PATH, 'favourites.xml')

            total_items = len(safe_addon_ids) + len(safe_repo_ids)
            if total_items == 0:
                _cb(45, 'Sin addons/repos físicos a respaldar')
            else:
                base_pct = 12
                for i, rid in enumerate(safe_repo_ids):
                    _check_cancel()
                    pct = base_pct + int((i / total_items) * 35)
                    _cb(pct, f'Empaquetando repo {rid}...')
                    src = os.path.join(_ADDONS_DIR, rid)
                    _add_dir_to_zip(
                        zf, src, _safe_arcname(['addons', rid]),
                        cancel_check=_tick,
                        skipped_log=skipped_files,
                        hash_log=file_hashes,
                        exclude_garbage=exclude_garbage,
                    )

                for j, aid in enumerate(safe_addon_ids):
                    _check_cancel()
                    pct = base_pct + int(
                        ((len(safe_repo_ids) + j) / total_items) * 35
                    )
                    _cb(pct, f'Empaquetando addon {aid}...')
                    src = os.path.join(_ADDONS_DIR, aid)
                    _add_dir_to_zip(
                        zf, src, _safe_arcname(['addons', aid]),
                        cancel_check=_tick,
                        skipped_log=skipped_files,
                        hash_log=file_hashes,
                        exclude_garbage=exclude_garbage,
                    )

                    include_this = include_addon_data
                    if isinstance(include_addon_data, dict):
                        include_this = include_addon_data.get(aid, True)
                    if include_this and _has_addon_data(aid):
                        data_src = os.path.join(_ADDON_DATA_DIR, aid)
                        _add_dir_to_zip(
                            zf, data_src,
                            _safe_arcname(['addon_data', aid]),
                            cancel_check=_tick,
                            skipped_log=skipped_files,
                            hash_log=file_hashes,
                            exclude_garbage=exclude_garbage,
                        )

            # Categorías Kodi adicionales (databases, guisettings, etc.).
            if selected_categories:
                _cb(50, 'Añadiendo categorías de Kodi...')
                cat_counts = _add_kodi_categories_to_zip(
                    zf, selected_categories,
                    cancel_check=_tick,
                    skipped_log=skipped_files,
                    hash_log=file_hashes,
                    exclude_garbage=exclude_garbage,
                )
                manifest['categories_files_added'] = cat_counts

            # Categorías virtuales: dumps via JSON-RPC. Van como JSON
            # dentro del ZIP, no como archivos físicos.
            if selected_categories.get('guisettings'):
                _check_cancel()
                _cb(80, 'Dump de ajustes Kodi...')
                gui_dump = dump_gui_settings()
                if gui_dump:
                    manifest['guisettings_dump'] = gui_dump
                    zf.writestr(
                        'guisettings_dump.json',
                        json.dumps(gui_dump, indent=2,
                                   ensure_ascii=False).encode('utf-8'),
                    )

            # Dump de watched state (playcount, lastplayed, resume).
            if selected_categories.get('watched_state'):
                _check_cancel()
                _cb(85, 'Dump de estado de visionado...')
                try:
                    from lib import backup_watched
                    ws_dump = backup_watched.dump_watched_state()
                except Exception as e:  # noqa: BLE001
                    log.warning(f'[backup] watched_state dump falló: {e!r}')
                    ws_dump = None
                if ws_dump and ws_dump.get('totals'):
                    # Errores por sección quedan registrados en el manifest
                    # (ws_dump['errors']) y se logean aquí para que el usuario
                    # los vea en kodi.log con el contexto del backup.
                    if ws_dump.get('errors'):
                        log.warning(
                            f'[backup] watched_state parcial: '
                            f'{ws_dump["errors"]}',
                        )
                    manifest['watched_state'] = ws_dump
                    zf.writestr(
                        'watched_state.json',
                        json.dumps(ws_dump, ensure_ascii=False).encode('utf-8'),
                    )

            if skipped_files:
                manifest['skipped_files'] = skipped_files[:200]  # cap

            if file_hashes:
                manifest['file_hashes'] = file_hashes
                manifest['hash_algo'] = 'sha256'

            _cb(92, 'Escribiendo manifest...')
            # Manifest al FINAL para que pueda reflejar resultados reales
            # (categories_files_added, skipped_files). zipfile permite leer
            # entries en cualquier orden gracias al central directory.
            manifest_bytes = json.dumps(
                manifest, indent=2, ensure_ascii=False,
            ).encode('utf-8')
            # Si encrypt_password, cifrar manifest y guardar como
            # `manifest.json.enc`. No escribimos manifest.txt en este caso
            # (sería filtrar info que el password debería proteger).
            if encrypt_password:
                from lib import backup_crypto
                blob = backup_crypto.encrypt_manifest_bytes(
                    manifest_bytes, encrypt_password,
                )
                zf.writestr('manifest.json.enc', blob)
                # Marcador minúsculo para que load_manifest detecte cifrado
                # sin necesitar password antes (UX: poder mostrar metadata
                # mínima en el listing de snapshots).
                stub = json.dumps({
                    'manifest_version': MANIFEST_VERSION,
                    'encrypted': True,
                    'created': manifest.get('created'),
                    'created_unix': manifest.get('created_unix'),
                    'kodi_version': manifest.get('kodi_version'),
                    'label': manifest.get('label'),
                    'addons_count': len(manifest.get('addons', [])),
                }).encode('utf-8')
                zf.writestr('manifest.json', stub)
            else:
                zf.writestr('manifest.json', manifest_bytes)
                zf.writestr('manifest.txt',
                            export_txt(manifest).encode('utf-8'))

            _cb(95, 'Cerrando archivo...')

        # Re-verificar tmp_path tras el cierre del context manager: si otro
        # proceso lo borra antes del replace, el FileNotFoundError sería
        # confuso. Defender/indexer son los culpables habituales en Windows.
        if not os.path.isfile(tmp_path):
            raise BackupError(
                'ZIP cerrado pero tempfile desapareció antes del replace; '
                'posible interferencia externa'
            )
        # Retry con backoff para SMB lento: os.replace puede fallar
        # transitoriamente si el destino está siendo accedido por otro
        # proceso (Windows Defender, indexador, etc.).
        _replace_with_retry(tmp_path, final_path)
        _cb(100, 'Completado')
        log.info(f'[backup] creado {filename} ({os.path.getsize(final_path)} bytes)')
        return filename
    except Exception:
        # Limpieza si falla
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def backup_favourites_only(dest_path=None):
    """Copia favourites.xml a SNAPSHOTS_DIR (o dest_path)."""
    if not os.path.isfile(_FAVOURITES_PATH):
        raise BackupError('favourites.xml no existe en este perfil')
    if dest_path is None:
        _ensure_snapshots_dir()
        stamp = time.strftime('%Y-%m-%d_%H%M%S')
        dest_path = os.path.join(SNAPSHOTS_DIR, f'favourites_{stamp}.xml')
    shutil.copy2(_FAVOURITES_PATH, dest_path)
    log.info('[backup] favourites guardado')
    log.sensitive(f'[backup] favourites dest: {dest_path}')
    return dest_path


_FAV_BACKUP_NAME_RE = re.compile(
    r'^favourites_\d{4}-\d{2}-\d{2}_\d{6}\.xml$',
)


def list_favourites_backups():
    """Lista archivos favourites_YYYY-MM-DD_HHMMSS.xml en SNAPSHOTS_DIR.

    Filtra con el mismo regex que _validate_favourites_backup_name para que
    todo lo que aparece en el listado sea también restaurable o borrable.
    """
    if not os.path.isdir(SNAPSHOTS_DIR):
        return []
    try:
        entries = os.listdir(SNAPSHOTS_DIR)
    except OSError as e:
        log.warning(f'[backup] no se pudo listar SNAPSHOTS_DIR: {e!r}')
        return []
    out = []
    for name in entries:
        if not _FAV_BACKUP_NAME_RE.match(name):
            continue
        path = os.path.join(SNAPSHOTS_DIR, name)
        try:
            out.append({
                'filename': name,
                'path': path,
                'created': int(os.path.getmtime(path)),
                'size': os.path.getsize(path),
            })
        except OSError:
            pass
    out.sort(key=lambda e: e['created'], reverse=True)
    return out


def _validate_favourites_backup_name(filename):
    """Valida y devuelve la ruta absoluta al backup en SNAPSHOTS_DIR.

    El regex bloquea path traversal (no admite / \\ ni ..) y deja la ruta
    siempre dentro de SNAPSHOTS_DIR. Loguea por canal de seguridad si llega
    un nombre raro.
    """
    if not isinstance(filename, str) or not _FAV_BACKUP_NAME_RE.match(filename):
        log.security(
            f'[backup] favourites backup filename sospechoso: {filename!r}',
        )
        raise BackupError(f'filename inválido: {filename!r}')
    path = os.path.join(SNAPSHOTS_DIR, filename)
    if not os.path.isfile(path):
        raise BackupError(f'no existe: {filename}')
    return path


def favourites_exists():
    """True si el perfil activo tiene favourites.xml."""
    return os.path.isfile(_FAVOURITES_PATH)


def restore_favourites_backup(filename, mode='overwrite'):
    """Restaura un favourites_*.xml de SNAPSHOTS_DIR sobre el perfil.

    mode='overwrite' borra los favoritos actuales y deja solo los del backup.
    mode='add' mantiene los actuales y añade los del backup al final,
    descartando entradas cuyo comando Kodi (texto del nodo) ya esté presente.

    Pasa por import_favourites para reutilizar el filtrado de tags/atributos
    y la deduplicación por comando. Devuelve {'imported', 'skipped', 'mode'}.
    """
    if mode not in ('overwrite', 'add'):
        raise BackupError(f'mode debe ser "overwrite" o "add", no {mode!r}')
    path = _validate_favourites_backup_name(filename)
    # utf-8-sig por el BOM que Notepad en Windows añade al guardar XML.
    # ET.fromstring con BOM da ParseError; el mensaje no aclara la causa.
    try:
        with open(path, 'r', encoding='utf-8-sig') as fh:
            xml_text = fh.read()
    except OSError as e:
        raise BackupError(f'no se pudo leer {filename}: {e}')
    # Convertimos OSError de escritura (disco lleno, permisos) en BackupError
    # para que la UI la trate igual que el resto de fallos de backup.
    try:
        res = import_favourites(xml_text, mode)
    except OSError as e:
        raise BackupError(f'no se pudo escribir favourites.xml: {e}')
    log.info(f'[backup] favourites restaurado ({mode}) desde {filename}')
    return res


def delete_favourites_backup(filename):
    """Borra un backup de favoritos del SNAPSHOTS_DIR."""
    path = _validate_favourites_backup_name(filename)
    try:
        os.remove(path)
    except OSError as e:
        raise BackupError(f'no se pudo eliminar {filename}: {e}')
    log.info(f'[backup] favourites backup eliminado: {filename}')


_FAV_ALLOWED_ATTRS = frozenset({'name', 'thumb'})
_FAV_IMPORT_MAX_BYTES = 4 * 1024 * 1024


def import_favourites(xml_text, mode):
    """Importa un favourites.xml externo en el perfil Kodi activo.

    mode='overwrite' reemplaza el archivo entero. mode='add' mezcla con el
    actual descartando entradas cuyo destino (texto del nodo) ya exista.
    Solo se aceptan hijos <favourite> con atributos {name, thumb}; cualquier
    otro tag o atributo se descarta y se loguea por trust boundary.
    Devuelve {'imported': N, 'skipped': M, 'mode': mode}.
    """
    if not isinstance(xml_text, str) or not xml_text.strip():
        raise BackupError('XML vacío')
    if len(xml_text.encode('utf-8')) > _FAV_IMPORT_MAX_BYTES:
        raise BackupError('XML demasiado grande')
    try:
        incoming = ET.fromstring(xml_text)
    except ET.ParseError as e:
        raise BackupError(f'XML malformado: {e}')
    if incoming.tag != 'favourites':
        raise BackupError('No es un favourites.xml de Kodi (raíz != <favourites>)')

    clean_incoming = []
    for child in list(incoming):
        if child.tag != 'favourite':
            log.security(f'[backup] import_favourites: tag descartado {child.tag!r}')
            continue
        dest = (child.text or '').strip()
        if not dest:
            continue
        for k in list(child.attrib.keys()):
            if k not in _FAV_ALLOWED_ATTRS:
                log.security(
                    f'[backup] import_favourites: atributo descartado {k!r}'
                )
                del child.attrib[k]
        clean_incoming.append(child)

    if mode == 'overwrite':
        root_out = ET.Element('favourites')
        for c in clean_incoming:
            root_out.append(c)
        _write_favourites_xml(root_out)
        log.info(f'[backup] favourites sobreescritos ({len(clean_incoming)})')
        return {'imported': len(clean_incoming), 'skipped': 0, 'mode': 'overwrite'}

    if mode != 'add':
        raise BackupError("mode debe ser 'overwrite' o 'add'")

    if os.path.isfile(_FAVOURITES_PATH):
        try:
            existing = ET.parse(_FAVOURITES_PATH).getroot()
            if existing.tag != 'favourites':
                existing = ET.Element('favourites')
        except ET.ParseError:
            existing = ET.Element('favourites')
    else:
        existing = ET.Element('favourites')
    existing_dests = {
        (f.text or '').strip()
        for f in existing if f.tag == 'favourite'
    }

    added = 0
    for c in clean_incoming:
        dest = (c.text or '').strip()
        if dest in existing_dests:
            continue
        existing.append(c)
        existing_dests.add(dest)
        added += 1

    _write_favourites_xml(existing)
    log.info(
        f'[backup] favourites importados (add): {added} añadidos, '
        f'{len(clean_incoming) - added} duplicados'
    )
    return {
        'imported': added,
        'skipped': len(clean_incoming) - added,
        'mode': 'add',
    }


def _write_favourites_xml(root):
    """Escribe favourites.xml con la cabecera estándar de Kodi.

    Usa tmp + _replace_with_retry para que una interrupción a mitad (kill,
    disco lleno) no deje el archivo truncado y para tolerar bloqueos
    transitorios de Defender/indexador en Windows. El tmp lleva pid+thread
    en el nombre para que dos llamadas concurrentes (HTTP multihilo) no se
    pisen el fichero intermedio.
    """
    os.makedirs(os.path.dirname(_FAVOURITES_PATH), exist_ok=True)
    body = ET.tostring(root, encoding='unicode')
    tmp = f'{_FAVOURITES_PATH}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as fh:
            fh.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
            fh.write(body)
        _replace_with_retry(tmp, _FAVOURITES_PATH)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


# Listado y rotación de snapshots
def list_snapshots():
    """Devuelve [{filename, size, created, label?, origin}] de TODOS los
    storages activos (default local + custom path si configurado).
    """
    from lib import backup_storage
    out = []
    for storage in backup_storage.get_active_storages(SNAPSHOTS_DIR):
        out.extend(storage.list())
    # Orden global: más reciente primero (cada storage ya viene sorted).
    out.sort(key=lambda e: e.get('created', 0), reverse=True)
    return out


def list_pre_restore_snapshots():
    """Snapshots automáticos creados justo ANTES de cada restore.

    Viven en un directorio aparte para no ensuciar "Mis backups", y hasta
    ahora eso los hacía inalcanzables: `list_snapshots()` solo mira
    SNAPSHOTS_DIR, así que el "rollback de emergencia" que promete el
    setting `backup.auto_pre_restore.enabled` se creaba, se rotaba y no
    había forma de restaurarlo desde el addon.
    """
    from lib import backup_storage
    return backup_storage.LocalStorage(AUTO_PRE_RESTORE_DIR).list()


def pre_restore_snapshot_path(filename):
    if not _safe_snapshot_filename(filename):
        raise BackupError(f'nombre de snapshot inválido: {filename!r}')
    return os.path.join(AUTO_PRE_RESTORE_DIR, filename)


def delete_snapshot(filename):
    """Borra un snapshot del storage donde resida. Devuelve True si lo borró.

    Adquiere el mutex de backup: restore_from_zip re-abre el ZIP varias veces
    para extraer addons, sources, favourites y categorías. Sin lock, un DELETE
    HTTP del panel podría borrar el ZIP entre re-aperturas y dejar estado
    parcial (addons restaurados, sources sin restaurar). El delete es rápido,
    así que el lock dura microsegundos.
    """
    if not _safe_snapshot_filename(filename):
        log.security(f'[backup] delete con filename sospechoso: {filename!r}')
        raise BackupError('filename inválido')
    if not acquire_backup_mutex(owner='backup_delete', coord_timeout_s=2):
        log.warning(f'[backup] delete_snapshot {filename}: mutex ocupado')
        raise BackupBusyError(
            'otra operación de backup/restore en curso, reintenta en unos segundos',
        )
    try:
        from lib import backup_storage
        storage, _path = backup_storage.find_storage_by_filename(
            filename, default_root=SNAPSHOTS_DIR,
        )
        if storage is None:
            return False
        if storage.delete(filename):
            log.info(f'[backup] eliminado {filename} (origin={storage.origin})')
            return True
        return False
    finally:
        release_backup_mutex()


# Patrones de archivos sensibles que no deberían viajar al compartir un
# backup. Match por nombre (no inspección de contenido).
_SENSITIVE_FILE_PATTERNS = (
    # Archivos directos
    'passwords.xml',
    # Patterns en addon_data (cualquier subdir)
    # Convención: lowercase substring match. Más permisivo que regex pero
    # menos falsos negativos para users no-tech.
)

_SENSITIVE_NAME_SUBSTRINGS = (
    'token', 'oauth', 'credential', 'password', 'api_key',
    'apikey', 'secret', 'auth.json', 'cookies', 'session',
    'access_token', 'refresh_token',
)


# Redacción por CONTENIDO. Filtrar por nombre de fichero no basta: los
# secretos de un Kodi real no viven en ficheros llamados "password", viven
# DENTRO de los settings.xml de cada addon (API key del debrid, OAuth de
# Trakt) y del guisettings.xml de Kodi. El filtro por nombre dejaba salir
# todo eso en los backups "sanitizados para compartir".

# Capa 1: el nombre del setting delata el secreto.
_SECRET_KEY_PARTS = (
    'password', 'passwd', 'pwd', 'passkey', 'token', 'secret',
    'apikey', 'api_key', 'credential', 'oauth', 'cookie', 'session',
    'login', 'username', 'private_key', 'privatekey', 'auth',
    # Addons en castellano (alfa, balandro y derivados).
    'clave', 'usuario', 'contrasena', 'contraseña',
)

# Capa 2: el VALOR tiene pinta de secreto aunque la clave no lo diga. Cubre
# al addon que llama a su token `rd_t` o `pk`. Cadena larga sin espacios,
# con letras y dígitos: una API key, un token o un hash. Los User-Agent y
# las rutas quedan fuera (llevan espacios, paréntesis o ':').
_SECRET_VALUE_RE = re.compile(r'^[A-Za-z0-9+/=_-]{20,}$')


def _looks_like_secret(setting_id, value):
    if not value:
        return False
    # Un secreto nunca vale `true`. Sin esto se redactaban los interruptores
    # que solo MENCIONAN el tema (`erase_cookies`, `alldebrid_authorized`,
    # `services.useairplaypassword`), dejando al que recibe el backup sin
    # sus preferencias y sin ganar nada.
    if value.lower() in ('true', 'false'):
        return False
    lowered = (setting_id or '').lower()
    if any(part in lowered for part in _SECRET_KEY_PARTS):
        return True
    if not _SECRET_VALUE_RE.match(value):
        return False
    # Solo dígitos (timestamps, ids) o solo letras (enums, nombres de skin)
    # no son secretos; una clave real mezcla.
    return any(c.isdigit() for c in value) and any(c.isalpha() for c in value)


def _redact_settings_xml(raw_bytes):
    """Quita del XML los `<setting>` cuyo id o valor parezcan un secreto.

    Se ELIMINA el elemento en vez de vaciarlo: un `<setting>` de tipo bool o
    int con el texto en blanco puede reventar al addon que lo lea, mientras
    que si falta usa su default.

    Devuelve `(bytes, [ids_redactados])`, o `(None, [])` si el XML no parsea
    (en cuyo caso el caller debe descartar el fichero: mejor perder un
    settings.xml que compartirlo sin revisar).
    """
    try:
        root = ET.fromstring(raw_bytes)
    except ET.ParseError:
        return None, []

    parents = {child: parent for parent in root.iter() for child in parent}
    redacted = []
    for el in list(root.iter('setting')):
        sid = el.get('id') or ''
        # Formato moderno: el valor es el texto. Kodi 18 y anteriores lo
        # ponían en el atributo `value`.
        value = (el.text or el.get('value') or '').strip()
        if not value:
            continue
        if _looks_like_secret(sid, value):
            parent = parents.get(el)
            if parent is not None:
                parent.remove(el)
                redacted.append(sid)
    if not redacted:
        return raw_bytes, []
    return ET.tostring(root, encoding='utf-8'), redacted


def _redact_settings_dict(dump):
    """Igual que `_redact_settings_xml` pero para el dump JSON de guisettings."""
    if not isinstance(dump, dict):
        return dump, []
    out, redacted = {}, []
    for key, value in dump.items():
        if _looks_like_secret(key, value if isinstance(value, str) else ''):
            redacted.append(key)
            continue
        out[key] = value
    return out, redacted


def _is_settings_xml(arcname):
    """¿Es un fichero de AJUSTES DEL USUARIO cuyo contenido hay que redactar?

    Solo `addon_data/**/settings.xml` (los valores que ha guardado el usuario)
    y el `guisettings.xml` de Kodi.

    NO los `addons/**/resources/settings.xml`: esos son la DEFINICIÓN de los
    ajustes que trae el addon (pública, viene del repo, sin secretos). Quitar
    un `<setting>` de ahí le borraría al addon una opción de su pantalla de
    configuración en el Kodi de quien recibe el backup.
    """
    name = arcname.replace('\\', '/').lower()
    basename = name.rsplit('/', 1)[-1]
    if basename == 'guisettings.xml':
        return True
    return basename == 'settings.xml' and name.startswith('addon_data/')


def _is_sensitive_filename(arcname):
    """¿Este archivo del ZIP es sensible (credenciales/tokens/passwords)?

    Heurística por nombre: descarta el fichero ENTERO. Para los ficheros de
    ajustes, que son legítimos pero llevan secretos dentro, se redacta el
    contenido en vez de descartarlos (ver `_redact_settings_xml`).
    """
    if not arcname:
        return False
    name_lower = arcname.lower()
    basename = name_lower.rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
    # 1. Archivos directos sensibles (passwords.xml, etc.)
    for pat in _SENSITIVE_FILE_PATTERNS:
        if name_lower.endswith('/' + pat) or basename == pat:
            return True
    # 2. Substrings sensibles en el nombre (token, credential, etc.)
    for substr in _SENSITIVE_NAME_SUBSTRINGS:
        if substr in basename:
            return True
    return False


def _sanitize_manifest_for_sharing(manifest):
    """Quita del manifest la PII y los secretos antes de compartir.

    - environment.addon_data_path (revela username del SO)
    - environment.device_id (random pero podría correlacionarse)
    - environment.hostname_hash (legacy, ya no lo usamos pero por si acaso)
    - guisettings_dump: es un `Settings.GetSettings(level='expert')`, o sea
      TODOS los ajustes de Kodi, contraseña del webserver incluida. Viajaba
      entero dentro del manifest del backup compartido.
    """
    if not isinstance(manifest, dict):
        return manifest
    out = dict(manifest)
    env = dict(out.get('environment') or {})
    for pii_field in ('addon_data_path', 'device_id', 'hostname_hash'):
        env.pop(pii_field, None)
    out['environment'] = env
    if out.get('guisettings_dump'):
        out['guisettings_dump'], _ = _redact_settings_dict(
            out['guisettings_dump'])
    # Marker para que el destinatario sepa que es un backup compartido
    out['shared_sanitized'] = True
    out['shared_sanitized_at'] = int(time.time())
    return out


def sanitize_backup_for_sharing(source_filename, *, output_label='shared',
                                  progress_cb=None, cancel_check=None):
    """Genera un ZIP compartible sanitizado.

    Elimina credenciales, tokens y PII del backup original. Crea un ZIP
    nuevo en SNAPSHOTS_DIR con sufijo `_shared` que se puede enviar a
    otros usuarios sin filtrar secretos.

    Tres niveles, porque el nombre del fichero no basta:
      - Ficheros enteros que son un secreto (`passwords.xml`): se descartan.
      - Ficheros legítimos con secretos dentro (`settings.xml` de cada addon,
        `guisettings.xml`, el dump de ajustes de Kodi): se redacta el
        contenido setting a setting.
      - URLs con credenciales inline en `sources.xml`/`mediasources.xml`.

    Devuelve dict con resumen:
    {ok, filename, size, removed_entries: [arc_names descartados],
     redacted_settings: [{entry, ids}], pii_fields_removed: [...]}
    """
    out = {
        'ok': False, 'filename': None, 'size': 0,
        'removed_entries': [], 'pii_fields_removed': [],
        'redacted_settings': [],  # [{entry, ids}] ajustes borrados por secreto
        'error': None,
    }
    if not _safe_snapshot_filename(source_filename):
        out['error'] = friendly_error_message('manifest_not_found')
        return out
    from lib import backup_storage
    storage, src_path = backup_storage.find_storage_by_filename(
        source_filename, default_root=SNAPSHOTS_DIR,
    )
    if not src_path or not os.path.isfile(src_path):
        out['error'] = 'snapshot no encontrado'
        return out

    _ensure_snapshots_dir()
    # Nombre destino: kodi_backup_YYYY-MM-DD_HHMMSS_shared.zip
    target_filename = _build_filename(label=output_label)
    target_path = os.path.join(SNAPSHOTS_DIR, target_filename)
    tmp_path = target_path + '.tmp'

    def _cb(pct, msg):
        if progress_cb:
            progress_cb(pct, 100, msg)

    try:
        _cb(2, 'Leyendo backup original...')
        with zipfile.ZipFile(src_path, 'r') as src_zf:
            entries = src_zf.infolist()
            total = max(len(entries), 1)
            with _zipfile_open_write(tmp_path) as dst_zf:
                for i, info in enumerate(entries):
                    if cancel_check and cancel_check():
                        raise InterruptedError('Sanitización cancelada')
                    pct = 5 + int((i / total) * 85)
                    arc = info.filename.replace('\\', '/')
                    # Filtrar sensibles
                    if _is_sensitive_filename(arc):
                        out['removed_entries'].append(arc)
                        log.security(
                            f'[backup] sanitize: removed sensitive entry '
                            f'{_sanitize_path_for_log(arc)}'
                        )
                        continue
                    # Caso especial: manifest.json → sanitizar contenido
                    if arc == 'manifest.json':
                        try:
                            raw = src_zf.read(info)
                            manifest = json.loads(raw.decode('utf-8'))
                            original_env = manifest.get('environment') or {}
                            sanitized = _sanitize_manifest_for_sharing(manifest)
                            # Track qué campos PII se removieron
                            for f in ('addon_data_path', 'device_id',
                                       'hostname_hash'):
                                if f in original_env:
                                    out['pii_fields_removed'].append(f)
                            new_raw = json.dumps(
                                sanitized, indent=2, ensure_ascii=False,
                            ).encode('utf-8')
                            dst_zf.writestr('manifest.json', new_raw)
                            continue
                        except (ValueError, UnicodeDecodeError, KeyError):
                            # Manifest corrupto: copia raw y continúa
                            pass
                    # Caso: sources.xml / mediasources.xml → filtrar URLs con
                    # credenciales inline (smb://user:pass@nas/...).
                    base = arc.rsplit('/', 1)[-1].lower()
                    if base in ('sources.xml', 'mediasources.xml'):
                        try:
                            raw = src_zf.read(info)
                            sanitized_xml = _sanitize_sources_xml(raw)
                            if sanitized_xml != raw:
                                out['removed_entries'].append(
                                    arc + ' (credenciales inline removidas)'
                                )
                            dst_zf.writestr(arc, sanitized_xml)
                            continue
                        except OSError:
                            pass

                    # Caso: settings.xml de un addon o guisettings.xml de
                    # Kodi. Son legítimos, pero dentro viven las API keys.
                    if _is_settings_xml(arc):
                        try:
                            raw = src_zf.read(info)
                        except (OSError, zipfile.BadZipFile) as e:
                            log.warning(
                                f'[backup] sanitize: error leyendo {arc}: {e!r}')
                            continue
                        redacted_xml, ids = _redact_settings_xml(raw)
                        if redacted_xml is None:
                            # No parsea: descartarlo entero antes que
                            # compartirlo sin poder revisarlo.
                            out['removed_entries'].append(
                                arc + ' (XML ilegible, descartado)')
                            log.security(
                                f'[backup] sanitize: {_sanitize_path_for_log(arc)} '
                                'no parsea; descartado')
                            continue
                        if ids:
                            out['redacted_settings'].append({
                                'entry': arc, 'ids': ids,
                            })
                            log.security(
                                f'[backup] sanitize: {len(ids)} ajustes '
                                f'redactados en {_sanitize_path_for_log(arc)}')
                        dst_zf.writestr(arc, redacted_xml)
                        continue

                    # Caso: dump de ajustes de Kodi (Settings.GetSettings a
                    # nivel experto: lo lleva TODO).
                    if arc == 'guisettings_dump.json':
                        try:
                            dump = json.loads(
                                src_zf.read(info).decode('utf-8'))
                        except (ValueError, UnicodeDecodeError,
                                zipfile.BadZipFile, OSError):
                            out['removed_entries'].append(
                                arc + ' (JSON ilegible, descartado)')
                            continue
                        clean, ids = _redact_settings_dict(dump)
                        if ids:
                            out['redacted_settings'].append({
                                'entry': arc, 'ids': ids,
                            })
                        dst_zf.writestr(arc, json.dumps(
                            clean, ensure_ascii=False).encode('utf-8'))
                        continue

                    # Caso general: copiar entry tal cual
                    try:
                        data = src_zf.read(info)
                        dst_zf.writestr(arc, data)
                    except (OSError, zipfile.BadZipFile) as e:
                        log.warning(
                            f'[backup] sanitize: error leyendo {arc}: {e!r}'
                        )
                    if i % 20 == 0:
                        _cb(pct, f'Sanitizando ({i + 1}/{total})...')
        _cb(95, 'Cerrando archivo...')
        _replace_with_retry(tmp_path, target_path)
        out['ok'] = True
        out['filename'] = target_filename
        out['size'] = os.path.getsize(target_path)
        _cb(100, 'Completado')
        log.info(
            f'[backup] backup sanitizado para compartir: {target_filename}, '
            f'{len(out["removed_entries"])} entries removidas'
        )
    except InterruptedError:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        out['error'] = 'cancelado'
    except Exception as e:
        log.error(f'[backup] sanitize falló: {e!r}')
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        out['error'] = _sanitize_path_for_log(str(e))[:120]
    return out


# Regex para detectar URLs con credentials inline en sources.xml:
# scheme://user:pass@host/path
_INLINE_CRED_RE = re.compile(
    r'([a-z][a-z0-9+\-.]*://)[^/\s<>"]+:[^/\s<>"]+@',
    re.IGNORECASE,
)


def _sanitize_sources_xml(raw_bytes):
    """Reemplaza credenciales inline en URLs de sources.xml.

    Convierte `smb://user:pass@server/share` → `smb://***@server/share`.
    Preserva el host (necesario para que la fuente siga teniendo sentido)
    pero elimina user:pass que viajan en texto plano.
    """
    try:
        text = raw_bytes.decode('utf-8', errors='replace')
    except AttributeError:
        return raw_bytes
    sanitized = _INLINE_CRED_RE.sub(r'\1***@', text)
    return sanitized.encode('utf-8')


def export_snapshot(filename, dest_path, *, overwrite=False,
                    progress_cb=None, cancel_check=None):
    """Copia un snapshot existente a una ruta arbitraria.

    `dest_path`:
      - Path local accesible (validado vía xbmcvfs)
      - smb://server/share/...
      - Cualquier path Kodi VFS

    Si es un directorio existente: copia con el filename original.
    Si es un path completo .zip: usa ese nombre exacto.

    Validaciones de seguridad:
      - Dest NO puede estar dentro de SNAPSHOTS_DIR (duplicación)
      - Dest NO puede estar en _ADDONS_DIR ni _PROFILE_DIR/addon_data/SELF
      - Si overwrite=False y dest existe: error

    Devuelve dict {ok, dest_path, size, error}.
    """
    out = {'ok': False, 'dest_path': None, 'size': 0, 'error': None}
    if not _safe_snapshot_filename(filename):
        out['error'] = 'filename inválido'
        return out

    # Rechazar paths relativos: el CWD del proceso Kodi no es el del
    # usuario (típicamente `/` o el dir de Kodi), produce resolución
    # inesperada. xbmcvfs paths (smb://...) sí son válidos.
    is_kodi_vfs = '://' in dest_path
    if not is_kodi_vfs and not os.path.isabs(dest_path):
        out['error'] = ('path destino debe ser absoluto (e.g. '
                        '/storage/usb/mis-backups/) o un path VFS Kodi '
                        '(smb://...)')
        return out

    from lib import backup_storage
    storage, src_path = backup_storage.find_storage_by_filename(
        filename, default_root=SNAPSHOTS_DIR,
    )
    if not src_path or not os.path.isfile(src_path):
        out['error'] = 'snapshot no encontrado'
        return out

    # Rechazar symlinks en el path destino (defensa TOCTOU). Si el destino
    # o su parent es symlink, abortamos: un attacker puede haber preparado
    # el dir para redirigir el copy.
    if not is_kodi_vfs:
        check_paths = [dest_path]
        parent = os.path.dirname(dest_path.rstrip('/').rstrip('\\'))
        if parent and parent != dest_path:
            check_paths.append(parent)
        for p in check_paths:
            try:
                if os.path.islink(p):
                    log.security(f'[backup] export rechazado: symlink en {p!r}')
                    out['error'] = 'el path destino no puede ser/contener symlinks'
                    return out
            except OSError:
                pass

    # Resolver destino: si dest_path es dir, append filename
    real_dest = dest_path
    if (os.path.isdir(dest_path)
            or (xbmcvfs.exists(dest_path)
                and not dest_path.lower().endswith('.zip'))):
        real_dest = os.path.join(dest_path, filename)

    # Anti-duplicación: rechazar destinos peligrosos
    real_dest_resolved = os.path.realpath(real_dest)
    if real_dest_resolved.startswith(
            os.path.realpath(SNAPSHOTS_DIR) + os.sep):
        out['error'] = ('destino dentro de SNAPSHOTS_DIR: el snapshot ya '
                        'aparecerá en "Mis backups" sin necesidad de exportar')
        return out
    if real_dest_resolved.startswith(os.path.realpath(_ADDONS_DIR) + os.sep):
        log.security(f'[backup] export rechazado a addons/: {real_dest!r}')
        out['error'] = 'no se puede exportar dentro de addons/'
        return out
    self_data = os.path.join(_ADDON_DATA_DIR, SELF_ADDON_ID)
    if real_dest_resolved.startswith(os.path.realpath(self_data) + os.sep):
        out['error'] = ('no se puede exportar dentro del addon_data de '
                        'loiolink (caería en bucle)')
        return out

    # Existencia y overwrite
    if xbmcvfs.exists(real_dest) and not overwrite:
        out['error'] = 'destination_exists'
        return out

    # Asegurar dir contenedor
    try:
        parent = os.path.dirname(real_dest)
        if parent and not xbmcvfs.exists(parent):
            if not xbmcvfs.mkdir(parent):
                out['error'] = f'no se puede crear destino: {parent}'
                return out
    except Exception as e:  # noqa: BLE001
        out['error'] = f'preparación destino falló: {e}'
        return out

    # Copia con xbmcvfs (soporta paths Kodi VFS); fallback a shutil
    try:
        ok = xbmcvfs.copy(src_path, real_dest)
        if not ok:
            shutil.copy2(src_path, real_dest)
    except Exception as e:  # noqa: BLE001
        out['error'] = f'copia falló: {_sanitize_path_for_log(str(e))[:120]}'
        return out

    try:
        out['size'] = os.path.getsize(real_dest)
    except OSError:
        out['size'] = 0
    out['dest_path'] = real_dest
    out['ok'] = True
    log.info(f'[backup] exportado {filename}')
    log.sensitive(f'[backup] export dest: {real_dest}')
    return out


def import_snapshot(source_path, *, label=None, validate=True,
                     overwrite=False,
                     progress_cb=None, cancel_check=None):
    """Copia un ZIP arbitrario a SNAPSHOTS_DIR.

    Si `validate=True`: comprueba que sea un backup loiolink válido (con
    manifest.json parseable) antes de copiar. Rechaza ZIPs no-backup.

    Si el filename original no cumple el regex, lo renombra a
    `kodi_backup_<timestamp>_<label?>.zip`.

    Devuelve dict {ok, filename, size, manifest_summary, error}.
    """
    out = {
        'ok': False, 'filename': None, 'size': 0,
        'manifest_summary': None, 'error': None,
    }
    if not source_path or not os.path.isfile(source_path):
        out['error'] = 'archivo origen no existe'
        return out

    # os.path.isfile() devuelve True también para symlinks; el contenido
    # apuntado puede no ser un ZIP real (path traversal, lectura de
    # archivos sensibles).
    if os.path.islink(source_path):
        log.security(f'[backup] import rechazado: source es symlink {source_path!r}')
        out['error'] = 'archivo origen es un symlink; no permitido'
        return out

    if validate:
        try:
            m = load_manifest_from_zip(source_path)
            out['manifest_summary'] = {
                'created': m.get('created'),
                'kodi_version': m.get('kodi_version'),
                'loiolink_version': m.get('loiolink_version'),
                'addons_count': len(m.get('addons') or []),
            }
        except ManifestError as e:
            out['error'] = f'no es un backup loiolink válido: {e}'
            return out

    # Determinar filename destino. Si el original cumple el regex, usarlo;
    # si no, generar uno nuevo.
    orig_name = os.path.basename(source_path)
    if _safe_snapshot_filename(orig_name) and not label:
        target_name = orig_name
    else:
        target_name = _build_filename(label)

    _ensure_snapshots_dir()
    target_path = os.path.join(SNAPSHOTS_DIR, target_name)
    if os.path.isfile(target_path) and not overwrite:
        out['error'] = 'ya existe un snapshot con ese nombre'
        return out

    try:
        shutil.copy2(source_path, target_path)
    except OSError as e:
        out['error'] = f'copia falló: {_sanitize_path_for_log(str(e))[:120]}'
        return out

    try:
        out['size'] = os.path.getsize(target_path)
    except OSError:
        out['size'] = 0
    out['filename'] = target_name
    out['ok'] = True
    log.info(f'[backup] importado -> {target_name}')
    log.sensitive(f'[backup] import source: {source_path}')
    return out


def migrate_snapshots(from_storage_name, to_storage_name, *,
                       delete_source=False,
                       progress_cb=None, cancel_check=None):
    """Mueve todos los snapshots de un storage a otro.

    `from_storage_name`/`to_storage_name`: 'default' (LocalStorage) o
    'custom' (CustomPathStorage). Si delete_source=True, tras copia
    exitosa se borra el origen.

    Devuelve dict {migrated: int, failed: list, source_remaining: int}.
    """
    from lib import backup_storage
    storages = backup_storage.get_active_storages(SNAPSHOTS_DIR)
    src = next((s for s in storages if s.origin == from_storage_name), None)
    dst = next((s for s in storages if s.origin == to_storage_name), None)
    if src is None:
        return {'migrated': 0, 'failed': [], 'error': 'origen no encontrado'}
    if dst is None or not dst.writable():
        return {'migrated': 0, 'failed': [], 'error': 'destino no escribible'}

    snaps = src.list()
    migrated = 0
    failed = []
    skipped = []  # Items borrados entre src.list() y la copia (TOCTOU)
    for i, entry in enumerate(snaps):
        if cancel_check and cancel_check():
            break
        if progress_cb:
            progress_cb(i, len(snaps),
                        f'Migrando {entry["filename"]}...')
        try:
            src_path = src.path_for(entry['filename'])
            # Re-check de existencia: si fue borrado entre src.list() y
            # ahora, reportar como skipped, no failed.
            if not os.path.isfile(src_path):
                skipped.append({
                    'filename': entry['filename'],
                    'reason': 'borrado_durante_migracion',
                })
                continue
            dst_path = dst.path_for(entry['filename'])
            if os.path.isfile(dst_path):
                failed.append({
                    'filename': entry['filename'],
                    'reason': 'ya_existe_destino',
                })
                continue
            # TOCTOU defense: entre el check de dst_path y el copy, otro
            # proceso podría escribir dst_path causando sobrescritura.
            # Copy a tmp, re-check, replace atómico.
            tmp_dst = dst_path + '.tmp_' + uuid.uuid4().hex
            try:
                shutil.copy2(src_path, tmp_dst)
                # Re-check final ANTES del replace
                if os.path.isfile(dst_path):
                    try:
                        os.unlink(tmp_dst)
                    except OSError:
                        pass
                    failed.append({
                        'filename': entry['filename'],
                        'reason': 'aparecio_durante_migracion',
                    })
                    continue
                os.replace(tmp_dst, dst_path)
            except Exception:
                # Limpiar tmp si copy o replace falló
                try:
                    os.unlink(tmp_dst)
                except OSError:
                    pass
                raise
            if delete_source:
                src.delete(entry['filename'])
            migrated += 1
        except (OSError, ValueError) as e:
            failed.append({
                'filename': entry['filename'],
                'reason': _sanitize_path_for_log(str(e))[:80],
            })
    return {
        'migrated': migrated,
        'failed': failed,
        'skipped': skipped,
        'source_remaining': len(src.list()),
    }


def rotate_snapshots(keep):
    """Mantiene los `keep` más recientes en el storage por defecto.
    Los snapshots en custom path no se rotan automáticamente; el usuario
    los gestiona.
    """
    try:
        keep = int(keep)
    except (TypeError, ValueError):
        keep = 5
    if keep < 1:
        keep = 1
    from lib import backup_storage
    local = backup_storage.LocalStorage(SNAPSHOTS_DIR)
    snaps = local.list()
    removed = 0
    for entry in snaps[keep:]:
        if local.delete(entry['filename']):
            removed += 1
    if removed:
        log.info(f'[backup] rotación: eliminados {removed} snapshots antiguos')
    return removed


def snapshot_path(filename):
    """Path absoluto al ZIP. Busca en TODOS los storages activos.
    Lanza BackupError si filename no es válido o no se encuentra en ninguno.
    """
    if not _safe_snapshot_filename(filename):
        log.security(f'[backup] download con filename sospechoso: {filename!r}')
        raise BackupError('filename inválido')
    from lib import backup_storage
    storage, path = backup_storage.find_storage_by_filename(
        filename, default_root=SNAPSHOTS_DIR,
    )
    if storage is not None and path is not None:
        return path
    # Fallback: el path por defecto (puede que el archivo aún no exista
    # pero el caller quiere preparar el destino para escribir).
    return os.path.join(SNAPSHOTS_DIR, filename)


# Restore: carga de manifiesto
def load_manifest_from_zip(zip_path, *, password=None):
    """Lee manifest.json del ZIP. ManifestError si falta o es inválido.

    Acepta manifests v1 (legacy) y v2 (actual). Los v1 se promocionan con
    defaults vacíos para los campos nuevos, así el restore funciona uniforme.

    Defensa TOCTOU: entre `isfile()` y `ZipFile(...)` el archivo puede
    desaparecer (otro thread borra el snapshot); capturamos OSError y lo
    traducimos a ManifestError.

    Si el ZIP contiene `manifest.json.enc`, requiere `password`. Sin él
    devuelve un stub mínimo con metadata pública (created, addons_count)
    marcado `encrypted=True`. Con password incorrecto: ManifestError.
    """
    if not os.path.isfile(zip_path):
        raise ManifestError('archivo no encontrado')
    try:
        size = os.path.getsize(zip_path)
    except OSError as e:
        raise ManifestError(f'archivo desapareció: {e}')
    if size > MAX_RESTORE_ZIP_MB * 1024 * 1024:
        raise ManifestError(f'ZIP excede {MAX_RESTORE_ZIP_MB} MB')
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            # Detectar manifest cifrado antes del normal.
            try:
                enc_info = zf.getinfo('manifest.json.enc')
            except KeyError:
                enc_info = None
            try:
                info = zf.getinfo('manifest.json')
            except KeyError:
                info = None
            if info is None and enc_info is None:
                raise ManifestError('manifest.json no está en el ZIP')
            # Si hay enc pero no password: devolver stub si existe
            if enc_info is not None and password is None:
                if info is None:
                    raise ManifestError(
                        'manifest cifrado y sin stub; password requerido'
                    )
                raw = zf.read(info)
                # Parsear stub
                try:
                    stub = json.loads(raw.decode('utf-8'))
                    if isinstance(stub, dict) and stub.get('encrypted'):
                        stub.setdefault('manifest_version', MANIFEST_VERSION)
                        return stub
                except (ValueError, UnicodeDecodeError):
                    pass
                # Si no era stub, continuar con flujo normal del manifest sin cifrar
            # Manifest cifrado CON password: descifrar
            if enc_info is not None and password is not None:
                if enc_info.file_size > MAX_MANIFEST_BYTES + 1024:  # margen
                    raise ManifestError(
                        f'manifest cifrado demasiado grande '
                        f'({enc_info.file_size} bytes); rechazado'
                    )
                blob = zf.read(enc_info)
                from lib import backup_crypto
                try:
                    manifest = backup_crypto.decrypt_manifest_json(
                        blob, password,
                    )
                except backup_crypto.BadPasswordError:
                    # Código mapeado en _FRIENDLY_ERROR_MESSAGES; el caller
                    # llama friendly_error_message() antes de mostrar al user.
                    raise ManifestError('password_incorrect')
                except backup_crypto.CryptoError as e:
                    raise ManifestError(f'integrity_failure: {e}')
                if not isinstance(manifest, dict):
                    raise ManifestError(
                        'manifest descifrado no es un objeto JSON'
                    )
                # Saltar el resto del flujo no-cifrado; ir directo a validación
                version = manifest.get('manifest_version')
                if version not in SUPPORTED_MANIFEST_VERSIONS:
                    log.warning(
                        f'[backup] manifest_version={version!r} desconocido'
                    )
                return manifest
            # Manifest sin cifrar (info no es None)
            if info.file_size > MAX_MANIFEST_BYTES:
                raise ManifestError(
                    f'manifest.json sospechosamente grande '
                    f'({info.file_size} bytes); rechazado'
                )
            raw = zf.read(info)
    except zipfile.BadZipFile:
        raise ManifestError('ZIP corrupto')
    except OSError as e:
        # Archivo borrado o ilegible entre isfile() y open
        raise ManifestError(f'archivo desapareció o no se puede leer: {e}')
    try:
        manifest = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError) as e:
        raise ManifestError(f'manifest.json no parseable: {e}')
    if not isinstance(manifest, dict):
        raise ManifestError('manifest.json no es un objeto JSON')
    version = manifest.get('manifest_version')
    if version not in SUPPORTED_MANIFEST_VERSIONS:
        log.warning(
            f'[backup] manifest_version={version!r} desconocido; '
            f'intentando tratar como v{MANIFEST_VERSION}'
        )
    elif version == 1:
        # Promocionar manifest v1 con defaults v2: campos nuevos vacíos
        # para que el resto del código no tenga que comprobar "is None"
        # por todas partes. Mantiene backward compat.
        manifest.setdefault('file_hashes', {})
        manifest.setdefault('hash_algo', None)
        manifest.setdefault('environment', {})
        manifest.setdefault('categories', None)
        manifest.setdefault('watched_state', None)
        manifest.setdefault('guisettings_dump', None)
    # Defensa transversal para v1 y v2 antiguos: filters puede no traer
    # los campos `exclude_garbage`/`compression_level` (añadidos después
    # de v2 sin bumping). Rellenamos defaults sanos para que consumers
    # futuros no necesiten `.get` defensivos.
    filters = manifest.setdefault('filters', {})
    if isinstance(filters, dict):
        filters.setdefault('exclude_garbage', True)
        filters.setdefault('compression_level', _DEFAULT_COMPRESSION_INDEX)
    return manifest


# Restore: desde ZIP (archivos físicos)
# Límites de seguridad anti decompression bomb. Un ZIP malicioso de 10MB
# podría descomprimirse a 1TB; Python `zipfile` no tiene límite built-in.
# Configurables via settings en futuro, hoy hardcoded con valores generosos.
MAX_EXTRACTED_TOTAL_BYTES = 50 * 1024 * 1024 * 1024  # 50 GB total
MAX_EXTRACTED_ENTRY_BYTES = 5 * 1024 * 1024 * 1024   # 5 GB por entry
# testzip() lee todo el ZIP para validar CRC; en ZIPs grandes sobre SMB
# cuelga Kodi por minutos. Por encima de este umbral lo saltamos y
# confiamos en SHA256 del manifest para integridad post-extract.
SKIP_TESTZIP_ABOVE_BYTES = 200 * 1024 * 1024  # 200 MB


def _check_zip_integrity(zip_path):
    """Verifica el ZIP antes de extraer.

    1. zipfile.testzip: CRC32 de todas las entries (validación pre-extracción).
       Para ZIPs > SKIP_TESTZIP_ABOVE_BYTES se salta; el SHA256 del manifest
       cubre integridad.
    2. Suma de file_size por entry: rechaza si excede límites de
       descompresión (defensa decompression bomb).

    Devuelve dict `{ok, reason, total_uncompressed, num_entries,
    testzip_skipped}`. Nunca levanta excepción: el caller decide leyendo `ok`.
    """
    result = {
        'ok': False, 'reason': None,
        'total_uncompressed': 0,
        'num_entries': 0,
        'testzip_skipped': False,
    }
    try:
        zip_file_size = os.path.getsize(zip_path)
        skip_testzip = zip_file_size > SKIP_TESTZIP_ABOVE_BYTES
        with zipfile.ZipFile(zip_path, 'r') as zf:
            # R17: suma rápida sin abrir entries
            total = 0
            num = 0
            for info in zf.infolist():
                num += 1
                size = info.file_size
                if size < 0:
                    result['reason'] = (
                        f'entry {info.filename!r} reporta tamaño negativo'
                    )
                    return result
                if size > MAX_EXTRACTED_ENTRY_BYTES:
                    log.security(
                        f'[backup] decompression bomb: entry '
                        f'{info.filename!r} > {MAX_EXTRACTED_ENTRY_BYTES} bytes'
                    )
                    result['reason'] = (
                        f'entry sospechosamente grande '
                        f'({size // (1024**3)} GB > '
                        f'{MAX_EXTRACTED_ENTRY_BYTES // (1024**3)} GB permitidos)'
                    )
                    return result
                total += size
                if total > MAX_EXTRACTED_TOTAL_BYTES:
                    log.security(
                        f'[backup] decompression bomb: total > '
                        f'{MAX_EXTRACTED_TOTAL_BYTES} bytes'
                    )
                    result['reason'] = (
                        f'descompresión total excede límite '
                        f'({MAX_EXTRACTED_TOTAL_BYTES // (1024**3)} GB)'
                    )
                    return result
            result['total_uncompressed'] = total
            result['num_entries'] = num
            if skip_testzip:
                result['testzip_skipped'] = True
                log.info(
                    f'[backup] testzip skipped (ZIP {zip_file_size // (1024**2)} MB '
                    f'> {SKIP_TESTZIP_ABOVE_BYTES // (1024**2)} MB); '
                    'la integridad se valida con SHA256 al extraer'
                )
            else:
                corrupt = zf.testzip()
                if corrupt is not None:
                    log.warning(
                        f'[backup] testzip falla: primer entry corrupto: '
                        f'{corrupt!r}'
                    )
                    result['reason'] = f'entry corrupto (CRC32): {corrupt}'
                    return result
    except zipfile.BadZipFile as e:
        result['reason'] = f'ZIP malformado: {e}'
        return result
    except OSError as e:
        result['reason'] = f'no se pudo abrir el ZIP: {e}'
        return result
    result['ok'] = True
    return result


def validate_advancedsettings_in_zip(zip_path):
    """Verifica si el ZIP contiene `advancedsettings.xml` y valida su XML.

    Un advancedsettings.xml malformado puede dejar Kodi sin arrancar (y
    requiere reiniciar para aplicarse), así que validamos sintaxis antes
    de copiarlo.

    Devuelve dict:
      {
        'present': bool,
        'valid': bool,   # False si está y el XML está roto
        'reason': str | None,  # explicación si no válido
        'entry_name': str | None,  # nombre del entry dentro del ZIP
        'content': bytes | None,   # contenido si válido (para escritura
                                   # diferida en restore atómico)
      }
    """
    out = {
        'present': False, 'valid': False, 'reason': None,
        'entry_name': None, 'content': None,
    }
    candidate_names = (
        'categories/config_root/advancedsettings.xml',
        'config_root/advancedsettings.xml',
        'advancedsettings.xml',
    )
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            info = None
            for name in candidate_names:
                try:
                    info = zf.getinfo(name)
                    out['entry_name'] = name
                    break
                except KeyError:
                    continue
            if info is None:
                return out  # not present
            out['present'] = True
            if info.file_size > 1 * 1024 * 1024:  # 1 MB
                out['reason'] = 'advancedsettings.xml > 1MB, rechazado'
                log.security(f'[backup] {out["reason"]}')
                return out
            raw = zf.read(info)
    except (zipfile.BadZipFile, OSError) as e:
        out['reason'] = f'lectura ZIP falló: {e}'
        return out
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        log.security(f'[backup] advancedsettings.xml malformado en {zip_path}: {e}')
        out['reason'] = f'XML malformado: {e}'
        return out
    if root.tag != 'advancedsettings':
        out['reason'] = f"raíz esperada <advancedsettings>, encontrado <{root.tag}>"
        return out
    out['valid'] = True
    out['content'] = raw
    return out


# Estado de resume tras restart
_RESUME_STATE_PATH = os.path.join(
    _ADDON_DATA_DIR, 'plugin.program.loiolink', 'backups', 'resume_state.json',
)


def save_resume_state(state):
    """Persiste `state` en addon_data para que el service detecte tras restart."""
    try:
        os.makedirs(os.path.dirname(_RESUME_STATE_PATH), exist_ok=True)
        tmp = _RESUME_STATE_PATH + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(state, fh, indent=2, ensure_ascii=False)
        os.replace(tmp, _RESUME_STATE_PATH)
        log.info('[backup] resume_state guardado')
    except OSError as e:
        log.warning(f'[backup] no se pudo guardar resume_state: {e!r}')


def check_resume_pending():
    """Lee resume_state.json si existe y es válido. Devuelve dict o None.

    Validaciones:
      - Archivo existe
      - JSON parseable, dict
      - created_at <7 días
      - zip_path apunta a un archivo accesible
    Si falla cualquiera, limpia y devuelve None.
    """
    if not os.path.isfile(_RESUME_STATE_PATH):
        return None
    try:
        with open(_RESUME_STATE_PATH, 'r', encoding='utf-8') as fh:
            state = json.load(fh)
    except (OSError, ValueError) as e:
        log.warning(f'[backup] resume_state inválido: {e!r}, limpiando')
        clear_resume_pending()
        return None
    if not isinstance(state, dict):
        clear_resume_pending()
        return None
    created_at = state.get('created_at')
    if not isinstance(created_at, (int, float)):
        clear_resume_pending()
        return None
    if time.time() - created_at > 7 * 86400:
        log.info('[backup] resume_state caducado, limpiando')
        clear_resume_pending()
        return None
    zip_path = state.get('zip_path')
    if not zip_path or not os.path.isfile(zip_path):
        log.info('[backup] resume_state apunta a ZIP inexistente, limpiando')
        clear_resume_pending()
        return None
    return state


def clear_resume_pending():
    try:
        if os.path.isfile(_RESUME_STATE_PATH):
            os.unlink(_RESUME_STATE_PATH)
    except OSError as e:
        log.warning(f'[backup] no se pudo limpiar resume_state: {e!r}')


def resume_restore(state, *, progress_cb=None, cancel_check=None):
    """Continúa un restore interrumpido tras restart de Kodi.

    Lee `state` (output de check_resume_pending). Lanza un restore con
    el subset que queda y la misma configuración (mode files/repos,
    sources_mode, etc.). Limpia el resume_state al terminar (éxito o no);
    el usuario puede reintentar manualmente si falla.

    Adquiere el mutex aquí y pasa `_already_locked=True` a la llamada
    interna para cerrar la race window entre check_resume_pending y la
    adquisición real (otro restore podría colarse en medio).
    """
    zip_path = state.get('zip_path')
    if not zip_path or not os.path.isfile(zip_path):
        log.warning('[backup] resume: zip_path inválido, limpiando')
        clear_resume_pending()
        return {'ok': False, 'reason': 'zip_no_existe'}
    remaining = state.get('remaining_addon_ids') or []
    mode = state.get('mode') or 'files'
    log.info(f'[backup] resume: continuando restore de {len(remaining)} addons '
             f'desde {os.path.basename(zip_path)}')
    # A1: adquirir mutex ANTES del trabajo. Si está ocupado (otro restore
    # corriendo), dejamos el resume_state para próximo arranque y
    # devolvemos sin destruirlo.
    if not acquire_backup_mutex(owner='backup_resume', coord_timeout_s=2):
        log.info('[backup] resume: mutex ocupado por otra operación; '
                 'dejaremos el resume_state para próximo arranque')
        return {'ok': False, 'reason': 'mutex_busy'}
    try:
        # Re-verificar ZIP tras adquirir mutex (TOCTOU window) y capturar
        # ManifestError. Sin esto, un ZIP borrado entre check_resume_pending
        # y el acquire propaga al thread daemon de service.py sin handler.
        if not os.path.isfile(zip_path):
            log.warning('[backup] resume: ZIP desapareció tras mutex acquire')
            clear_resume_pending()
            return {'ok': False, 'reason': 'zip_disappeared'}
        try:
            if mode == 'repos':
                manifest = load_manifest_from_zip(zip_path)
                result = _do_restore_from_manifest(
                    manifest,
                    addon_ids=remaining or None,
                    progress_cb=progress_cb,
                    cancel_check=cancel_check,
                )
            else:
                result = _do_restore_from_zip(
                    zip_path,
                    addon_ids=remaining or None,
                    include_sources_mode=state.get('include_sources_mode', 'merge'),
                    include_favourites=bool(state.get('include_favourites')),
                    restore_categories=state.get('restore_categories'),
                    progress_cb=progress_cb,
                    cancel_check=cancel_check,
                )
        except ManifestError as e:
            log.warning(f'[backup] resume: manifest inválido en ZIP: {e}')
            clear_resume_pending()
            return {'ok': False, 'reason': f'manifest_invalid: {e}'}
        except BackupError as e:
            log.warning(f'[backup] resume: BackupError: {e}')
            clear_resume_pending()
            return {'ok': False, 'reason': f'backup_error: {e}'}
        result['resumed_from'] = os.path.basename(zip_path)
        clear_resume_pending()
        return result
    finally:
        release_backup_mutex()


def dump_gui_settings():
    """Snapshot completo de ajustes Kodi via JSON-RPC.

    Usa `Settings.GetSettings(level='expert')` y devuelve dict
    `{setting_id: value}` excluyendo settings de tipo 'action' (botones,
    no tienen valor que respaldar). Si JSON-RPC falla/timeout, devuelve {}.
    """
    from lib import jsonrpc_safe
    result = jsonrpc_safe.call(
        'Settings.GetSettings',
        {'level': 'expert'},
        timeout_s=20.0,
        default=None,
        log_label='dump_gui_settings',
    )
    if not result or not isinstance(result, dict):
        return {}
    out = {}
    for s in result.get('settings', []) or []:
        if not isinstance(s, dict):
            continue
        sid = s.get('id')
        stype = s.get('type')
        if not sid or stype == 'action':
            continue
        # Kodi a veces no devuelve 'value' para settings sin valor por
        # defecto (group headers, etc.). Skipear esos.
        if 'value' not in s:
            continue
        out[sid] = s['value']
    return out


def _check_gui_deps(dump):
    """Verifica que los addons referenciados por gui settings estén
    instalados antes de aplicarlos.

    Si una setting referencia un addon no instalado (caso típico: skin que
    el usuario tenía instalada en otro Kodi), aplicarla puede romper Kodi
    al arrancar (fallback a Estuary, sí, pero peor UX).

    Devuelve set de setting IDs que se deben omitir del restore.
    """
    skip = set()
    if not dump or not isinstance(dump, dict):
        return skip
    # Settings conocidas que referencian addons
    addon_referrers = (
        'lookandfeel.skin',
        'lookandfeel.skintheme',
        'subtitles.font',
    )
    # Construir set de addons instalados (incluyendo deshabilitados, los
    # contamos como "instalados" porque están presentes y pueden activarse)
    from lib import jsonrpc_safe
    addons_resp = jsonrpc_safe.call(
        'Addons.GetAddons',
        {'enabled': 'all', 'properties': []},
        timeout_s=10.0,
        default={'addons': []},
    )
    # Defensa: jsonrpc_safe puede devolver string si la response tiene un
    # 'result' no estructurado (e.g. 'OK' simple). Solo procesamos dicts.
    if not isinstance(addons_resp, dict):
        addons_resp = {}
    installed = {
        a.get('addonid') for a in addons_resp.get('addons', [])
        if isinstance(a, dict) and a.get('addonid')
    }
    for sid in addon_referrers:
        val = dump.get(sid)
        if not val or not isinstance(val, str):
            continue
        # El valor puede ser el addon ID directamente (e.g. 'skin.estuary')
        if val.startswith('skin.') or val.startswith('script.') or '.' in val:
            if val not in installed:
                log.info(
                    f'[backup] gui_setting {sid!r}={val!r} referencia '
                    'addon no instalado; se omite del restore'
                )
                skip.add(sid)
    return skip


def restore_gui_settings(dump, *, skip_ids=None):
    """Aplica un dump de GUI settings via JSON-RPC.

    Compara contra los valores actuales para minimizar cambios. Settings
    inexistentes en la Kodi target se ignoran con log.info. Type mismatch
    también skip.

    Devuelve `{applied: int, skipped: int, failed: list, total: int}`.
    """
    from lib import jsonrpc_safe
    if not dump or not isinstance(dump, dict):
        return {'applied': 0, 'skipped': 0, 'failed': [], 'total': 0,
                'deps_skipped': []}
    skip = set(skip_ids or [])
    # Añadir al skip los settings que referencian addons no instalados
    # (evita que Kodi falle al arrancar tras restore en otra máquina).
    deps_skip = _check_gui_deps(dump)
    skip |= deps_skip

    # Snapshot actual para comparar (solo aplicar los que difieren).
    current = dump_gui_settings()
    applied = 0
    skipped = 0
    failed = []
    total = 0
    for sid, val in dump.items():
        total += 1
        if sid in skip:
            skipped += 1
            continue
        if sid not in current:
            log.info(f'[backup] gui_setting {sid!r} no existe en target, skip')
            skipped += 1
            continue
        if current[sid] == val:
            skipped += 1
            continue
        ok = jsonrpc_safe.call_void(
            'Settings.SetSettingValue',
            {'setting': sid, 'value': val},
            timeout_s=5.0,
        )
        if ok:
            applied += 1
        else:
            failed.append(sid)
    return {
        'applied': applied,
        'skipped': skipped,
        'failed': failed[:50],
        'total': total,
        'deps_skipped': sorted(deps_skip),  # ids omitidos por deps no resueltas
    }


def _restore_kodi_categories_from_zip(zf, manifest, *,
                                       requested,
                                       cancel_check=None,
                                       progress_cb=None):
    """Restaura las categorías Kodi presentes en el ZIP.

    `requested`:
      - None (default) => no restaura ninguna categoría nueva (compat legacy)
      - 'all' => restaura todas las presentes en el ZIP que el manifest
                  marca como respaldadas
      - set/list de nombres => solo esas (si están en el ZIP)

    Devuelve dict `{name: {extracted: int, errors: list}}` para
    incluir en `result['categories_restored']`.
    """
    out = {}
    if requested is None:
        return out
    # Set normalizado de categorías a restaurar.
    manifest_cats = manifest.get('categories') or {}
    if requested == 'all':
        wanted_set = {n for n, v in manifest_cats.items() if v}
    else:
        wanted_set = set(requested)
    if not wanted_set:
        return out

    # Mapping nombre → (arc_prefix, dest_dir_under_profile)
    handlers = {}
    for name, subdir, arc, _default, _sql, _warn in KODI_CATEGORIES_SPEC:
        handlers[name] = (arc, os.path.join(_PROFILE_DIR, subdir))
    handlers[KODI_CONFIG_ROOT_NAME] = (KODI_CONFIG_ROOT_ARC, _PROFILE_DIR)

    # Indexar entries del ZIP por categoría
    entries_by_cat = {}
    for info in zf.infolist():
        name = info.filename.replace('\\', '/')
        for cat_name, (arc_prefix, _dest) in handlers.items():
            if cat_name not in wanted_set:
                continue
            prefix = arc_prefix.rstrip('/') + '/'
            if name.startswith(prefix):
                entries_by_cat.setdefault(cat_name, []).append(info)
                break

    for cat_name, infos in entries_by_cat.items():
        if cancel_check and cancel_check():
            raise InterruptedError('Restore cancelado')
        arc_prefix, dest_dir = handlers[cat_name]
        if progress_cb:
            progress_cb(0, 0, f'Restaurando {cat_name}...')
        os.makedirs(dest_dir, exist_ok=True)
        extracted = 0
        errors = []
        # dest_base es _PROFILE_DIR. El entry filename es
        # 'categories/<cat>/...resto', que dentro de _PROFILE_DIR se
        # mapearía a `userdata/categories/<cat>/...`. Eso NO es lo que
        # queremos; queremos descomprimirlo a `userdata/<subdir>/...`.
        # Por eso reescribimos info.filename eliminando el arc_prefix.
        prefix = arc_prefix.rstrip('/') + '/'
        for info in infos:
            if cancel_check and cancel_check():
                raise InterruptedError('Restore cancelado')
            name = info.filename.replace('\\', '/')
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
            if not rel or rel.endswith('/'):
                # Crear subdir
                target_dir = os.path.realpath(
                    os.path.join(dest_dir, rel.rstrip('/'))
                )
                base_real = os.path.realpath(dest_dir)
                if not (target_dir == base_real
                        or target_dir.startswith(base_real + os.sep)):
                    errors.append({
                        'entry': _sanitize_path_for_log(name),
                        'reason': 'traversal_dir',
                    })
                    log.security(
                        f'[backup] dir traversal en categoría {cat_name}: '
                        f'{name!r}'
                    )
                    continue
                try:
                    os.makedirs(target_dir, exist_ok=True)
                except OSError as e:
                    errors.append({
                        'entry': _sanitize_path_for_log(name),
                        'reason': _sanitize_path_for_log(str(e))[:80],
                    })
                continue
            # Crear un ZipInfo virtual con filename reescrito y usar el
            # extractor seguro existente (validación traversal, symlinks, etc).
            #
            # Truco: como `_extract_zip_entry_safely` resuelve dest_base/
            # info.filename, basta con sustituir info.filename. Lo hacemos
            # vía un shallow copy para no mutar el original.
            new_info = zipfile.ZipInfo(filename=rel)
            new_info.external_attr = info.external_attr
            new_info.file_size = info.file_size
            new_info.CRC = info.CRC
            new_info.compress_size = info.compress_size
            new_info.compress_type = info.compress_type
            # Necesitamos abrir el entry original, no el ZipInfo nuevo.
            # `_extract_zip_entry_safely` usa `zf.open(info)` con el info
            # del que conoce el offset. Como `new_info` no tiene offset,
            # extraemos manualmente aquí:
            resolved = os.path.realpath(os.path.join(dest_dir, rel))
            base_real = os.path.realpath(dest_dir)
            if not (resolved == base_real
                    or resolved.startswith(base_real + os.sep)):
                errors.append({
                    'entry': _sanitize_path_for_log(name),
                    'reason': 'traversal',
                })
                log.security(
                    f'[backup] traversal en categoría {cat_name}: {name!r}'
                )
                continue
            mode = (info.external_attr >> 16) & 0o170000
            if mode not in (0, 0o100000, 0o040000):
                log.security(
                    f'[backup] entry no-regular en {cat_name}: {name!r}'
                )
                errors.append({
                    'entry': _sanitize_path_for_log(name),
                    'reason': 'non_regular',
                })
                continue
            # Restaurar DBs de otra version major no sirve (Kodi crea una
            # nueva al arrancar) y confunde al user; verificamos schema
            # version y skipeamos si no coincide.
            if cat_name == 'databases' and rel.lower().endswith('.db'):
                # Textures*.db tiene política propia. Setting
                # backup.textures.policy: 0=respaldar y restaurar,
                # 1=respaldar pero no restaurar (Kodi reconstruye el cache),
                # 2=ignorar siempre.
                if 'textures' in rel.lower():
                    try:
                        textures_policy = int(
                            xbmcaddon.Addon().getSetting(
                                'backup.textures.policy') or 1
                        )
                    except (ValueError, RuntimeError):
                        textures_policy = 1
                    if textures_policy in (1, 2):
                        errors.append({
                            'entry': _sanitize_path_for_log(name),
                            'reason': (
                                'textures_policy_skip: Kodi reconstruirá '
                                'el cache automáticamente'
                            ),
                        })
                        log.info(
                            f'[backup] Textures DB omitida en restore por '
                            f'policy ({rel}); Kodi la reconstruirá'
                        )
                        continue
                current_major = _parse_kodi_major(
                    xbmc.getInfoLabel('System.BuildVersion') or ''
                )
                compat, warn = check_db_version_compat(rel, current_major)
                if not compat:
                    errors.append({
                        'entry': _sanitize_path_for_log(name),
                        'reason': f'db_version_mismatch: {warn}',
                    })
                    log.info(f'[backup] {warn}')
                    continue
            # guisettings.xml NO se vuelca como fichero: Kodi mantiene los
            # ajustes en memoria y lo REESCRIBE al cerrar, así que copiarlo
            # encima es un no-op que además engaña (el usuario ve "restaurado"
            # y reinicia para nada). Es un problema conocido de Kodi; el addon
            # oficial de backup lo esquiva dejando un `guisettings.xml.restored`
            # que hay que renombrar a mano con Kodi parado. La categoría
            # virtual `guisettings` sí funciona: aplica los ajustes por
            # JSON-RPC (`restore_gui_settings`), la única vía válida con Kodi
            # vivo. Se sigue RESPALDANDO (es un registro útil), solo no se
            # restaura por aquí.
            if (cat_name == KODI_CONFIG_ROOT_NAME
                    and rel.lower() == 'guisettings.xml'):
                errors.append({
                    'entry': _sanitize_path_for_log(name),
                    'reason': ('guisettings_no_restaurable: Kodi lo reescribe '
                               'al cerrar; usa la categoría "guisettings"'),
                })
                log.info(
                    '[backup] guisettings.xml omitido en config_root: Kodi lo '
                    'reescribe al salir. La categoría "guisettings" sí lo '
                    'aplica (JSON-RPC).'
                )
                continue

            # advancedsettings.xml en config_root: validamos XML antes de
            # escribir. Un XML roto deja a Kodi sin arrancar. El caller debe
            # avisar al usuario de que aplicarlo requiere reinicio.
            if (cat_name == KODI_CONFIG_ROOT_NAME
                    and rel.lower() == 'advancedsettings.xml'):
                try:
                    raw = zf.read(info)
                    ET.fromstring(raw)
                except (zipfile.BadZipFile, OSError) as e:
                    errors.append({
                        'entry': _sanitize_path_for_log(name),
                        'reason': _sanitize_path_for_log(str(e))[:80],
                    })
                    continue
                except ET.ParseError as e:
                    log.security(
                        f'[backup] advancedsettings.xml malformado en '
                        f'restore, omitido: {e}'
                    )
                    errors.append({
                        'entry': 'advancedsettings.xml',
                        'reason': f'xml_malformed: {e}',
                    })
                    continue
                try:
                    _atomic_write_bytes(resolved, raw)
                    extracted += 1
                except (OSError, BackupError) as e:
                    errors.append({
                        'entry': _sanitize_path_for_log(name),
                        'reason': _sanitize_path_for_log(str(e))[:80],
                    })
                continue

            try:
                # Atómico (tmp + replace). `config_root` reescribe la
                # configuración entera de Kodi (sources.xml, favourites.xml,
                # guisettings.xml, passwords.xml...): un corte a mitad de un
                # `open(dest,'wb')` la dejaba truncada. Es el mismo motivo por
                # el que existe `_atomic_write_bytes`, que solo cubría la otra
                # ruta de restore.
                _atomic_extract_entry(zf, info, resolved)
                extracted += 1
            except (OSError, BackupError, zipfile.BadZipFile) as e:
                # BackupError lo lanza `_replace_with_retry` cuando el destino
                # sigue bloqueado tras los reintentos (antivirus, indexador).
                errors.append({
                    'entry': _sanitize_path_for_log(name),
                    'reason': _sanitize_path_for_log(str(e))[:80],
                })
                log.warning(
                    f'[backup] extract category {cat_name}/{rel}: {e!r}'
                )
        out[cat_name] = {'extracted': extracted, 'errors': errors[:50]}
    return out


def _extract_zip_entry_safely(zf, info, dest_base, *, expected_hash=None,
                               hash_failures=None, strip_prefix=''):
    """Extrae UN entry del ZIP a dest_base, con validación anti-traversal.

    Idéntica filosofía que `installer._extract_zip_safely` pero adaptada
    para destinos distintos a `addons/`. dest_base debe ser absoluto.

    `strip_prefix`: parte inicial del arcname que NO forma parte de la ruta
    destino. Los addons se archivan como `addons/<id>/...` y su addon_data
    como `addon_data/<id>/...`, pero dest_base ya ES esa carpeta; sin quitar
    el prefijo acabarían en `addons/addons/<id>/...`, donde Kodi no los ve.
    Además acota el anti-traversal a la carpeta correcta: un entry hostil
    `addon_data/<id>/../../guisettings.xml` resolvería dentro del perfil (y
    pasaría el check) si validásemos contra el perfil entero.

    Si `expected_hash` no es None, verifica el SHA256 del archivo extraído;
    si difiere lo borra y devuelve False, y si `hash_failures` es una
    lista, le hace append con `{arc, expected, got}` para reporte al caller.
    """
    name = info.filename.replace('\\', '/')
    if strip_prefix:
        if not name.startswith(strip_prefix):
            log.security(f'[backup] entry fuera de {strip_prefix!r}: {name!r}')
            return False
        name = name[len(strip_prefix):]
    if not name or name.endswith('/'):
        # Es un directorio: lo creamos sin extraer contenido
        target_dir = os.path.realpath(os.path.join(dest_base, name))
        base_real = os.path.realpath(dest_base)
        if not (target_dir == base_real
                or target_dir.startswith(base_real + os.sep)):
            log.security(f'[backup] dir traversal en restore: {name!r}')
            return False
        os.makedirs(target_dir, exist_ok=True)
        return True
    # Whitelist de tipos
    mode = (info.external_attr >> 16) & 0o170000
    if mode not in (0, 0o100000, 0o040000):
        log.security(
            f'[backup] entry no-regular ignorada: {name!r} (mode={oct(mode)})'
        )
        return False
    # Validación anti-traversal
    resolved = os.path.realpath(os.path.join(dest_base, name))
    base_real = os.path.realpath(dest_base)
    if not (resolved == base_real
            or resolved.startswith(base_real + os.sep)):
        log.security(f'[backup] traversal en restore: {name!r}')
        return False
    # Extraer
    os.makedirs(os.path.dirname(resolved), exist_ok=True)
    with zf.open(info, 'r') as src, open(resolved, 'wb') as dst:
        shutil.copyfileobj(src, dst, length=64 * 1024)
    # Post-check para mode=0: rechazar symlinks materializados
    if mode == 0 and os.path.islink(resolved):
        try:
            os.unlink(resolved)
        except OSError:
            pass
        log.security(f'[backup] symlink materializado: {name!r}')
        return False
    # Si hay hash esperado y no coincide, borramos el archivo extraído y
    # reportamos: la entrega no pasa por restauración.
    if expected_hash:
        got = _hash_file_sha256(resolved)
        if got != expected_hash:
            try:
                os.unlink(resolved)
            except OSError:
                pass
            if hash_failures is not None:
                hash_failures.append({
                    'arc': name,
                    'expected': expected_hash,
                    'got': got,
                })
            log.warning(
                f'[backup] hash mismatch en {_sanitize_path_for_log(name)}'
            )
            return False
    return True


def dry_run_restore(zip_path):
    """Simula un restore sin tocar el disco.

    Ejecuta todos los checks (integrity, version, environment, db version,
    advancedsettings XML, dependencias) y devuelve un informe estructurado.
    Útil para que el usuario vea qué pasaría antes de comprometer cambios.

    Devuelve dict:
      {
        'ok': bool,
        'reason': str | None,
        'manifest_summary': {...},
        'integrity_check': {...},
        'kodi_version_check': {...},
        'environment_mismatch': [...],
        'addons_in_zip': [...],
        'addons_in_zip_count': int,
        'categories_in_zip': [...],
        'advancedsettings': {...},
        'db_warnings': [...],
        'would_overwrite': [...],  # addons que ya existen en disco
        'would_install': [...],    # addons nuevos
        'estimated_disk_use_mb': int,
      }
    """
    out = {
        'ok': False, 'reason': None,
        'manifest_summary': {},
        'integrity_check': None,
        'kodi_version_check': None,
        'environment_mismatch': [],
        'addons_in_zip': [],
        'addons_in_zip_count': 0,
        'categories_in_zip': [],
        'advancedsettings': None,
        'db_warnings': [],
        'would_overwrite': [],
        'would_install': [],
        'estimated_disk_use_mb': 0,
    }
    if not os.path.isfile(zip_path):
        out['reason'] = 'archivo no existe'
        return out
    try:
        manifest = load_manifest_from_zip(zip_path)
    except ManifestError as e:
        out['reason'] = f'manifest: {e}'
        return out
    out['manifest_summary'] = {
        'created': manifest.get('created'),
        'kodi_version': manifest.get('kodi_version'),
        'loiolink_version': manifest.get('loiolink_version'),
        'label': manifest.get('label'),
        'addons_count': len(manifest.get('addons') or []),
        'repos_count': len(manifest.get('repos') or []),
        'has_file_hashes': bool(manifest.get('file_hashes')),
        'has_watched_state': bool(manifest.get('watched_state')),
        'has_guisettings': bool(manifest.get('guisettings_dump')),
    }
    out['integrity_check'] = _check_zip_integrity(zip_path)
    out['kodi_version_check'] = check_kodi_version_compat(manifest)
    out['environment_mismatch'] = check_environment_mismatch(
        manifest.get('environment') or {},
    )
    adv = validate_advancedsettings_in_zip(zip_path)
    out['advancedsettings'] = {
        'present': adv['present'],
        'valid': adv['valid'],
        'reason': adv['reason'],
    }

    current_major = _parse_kodi_major(
        xbmc.getInfoLabel('System.BuildVersion') or ''
    )
    # Indexar ZIP para enumerar addons, categorías, y db warnings.
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            estimated_bytes = 0
            seen_addons = set()
            seen_categories = set()
            for info in zf.infolist():
                estimated_bytes += info.file_size
                name = info.filename.replace('\\', '/')
                if name.startswith('addons/'):
                    rest = name[len('addons/'):]
                    if '/' in rest:
                        seen_addons.add(rest.split('/', 1)[0])
                elif name.startswith('categories/'):
                    rest = name[len('categories/'):]
                    if '/' in rest:
                        cat = rest.split('/', 1)[0]
                        seen_categories.add(cat)
                        # R19: check db versions
                        if cat == 'databases' and name.lower().endswith('.db'):
                            db_name = name.rsplit('/', 1)[-1]
                            compat, warn = check_db_version_compat(
                                db_name, current_major,
                            )
                            if not compat:
                                out['db_warnings'].append({
                                    'db': db_name, 'warning': warn,
                                })
            out['addons_in_zip'] = sorted(seen_addons - {SELF_ADDON_ID})
            out['addons_in_zip_count'] = len(out['addons_in_zip'])
            out['categories_in_zip'] = sorted(seen_categories)
            out['estimated_disk_use_mb'] = estimated_bytes // (1024 * 1024)
    except zipfile.BadZipFile as e:
        out['reason'] = f'ZIP corrupto: {e}'
        return out

    # would_overwrite vs would_install
    for aid in out['addons_in_zip']:
        if os.path.isdir(os.path.join(_ADDONS_DIR, aid)):
            out['would_overwrite'].append(aid)
        else:
            out['would_install'].append(aid)

    # Debe coincidir con el filtro de restore_from_zip: si el dry-run no avisa
    # de Python mismatches, el user confirma "todo OK" y luego el restore real
    # skip addons silenciosamente.
    out['addon_python_warnings'] = []
    addons_meta = manifest.get('addons') or []
    addons_by_id = {a.get('id'): a for a in addons_meta if a.get('id')}
    for aid in out['addons_in_zip']:
        addon_meta = addons_by_id.get(aid)
        py_compat, py_warn = check_addon_python_compat(addon_meta, current_major)
        if not py_compat:
            out['addon_python_warnings'].append({
                'addon_id': aid,
                'warning': py_warn,
            })

    out['ok'] = True
    return out


def restore_from_zip(zip_path, *, addon_ids=None,
                     include_sources_mode='merge',
                     include_favourites=False,
                     restore_categories=None,
                     timeout_s=None,
                     password=None,
                     progress_cb=None, cancel_check=None):
    """Restaura addons desde el ZIP (archivos físicos).

    include_sources_mode:
        'merge' (default): añade fuentes del ZIP que no existan localmente
        'overwrite': reemplaza sources.xml entero
        'skip': no toca sources.xml
    addon_ids: si se pasa, solo restaura esos IDs. None = todos los que
        estén en el ZIP. SELF_ADDON_ID se filtra siempre.
    restore_categories: control de categorías Kodi. Posibles:
        - None (default): no restaura categorías nuevas (compat legacy)
        - 'all': restaura todas las categorías presentes en el manifest
        - set/list: solo las categorías nombradas
    timeout_s: deadline absoluto para el restore entero; al excederlo se
        levanta InterruptedError. Útil para SMB lentos donde la operación
        puede colgarse indefinidamente sin que el cancel_check sea
        suficiente. None = sin timeout.

    Devuelve dict con: {ok, failed, skipped, sources_merged,
        favourites_restored, categories_restored, kodi_version_check,
        integrity_check}.
    """
    if not acquire_backup_mutex(owner='backup_restore_zip'):
        raise BackupBusyError('Ya hay una operación de backup en curso')
    try:
        return _do_restore_from_zip(
            zip_path, addon_ids=addon_ids,
            include_sources_mode=include_sources_mode,
            include_favourites=include_favourites,
            restore_categories=restore_categories,
            timeout_s=timeout_s,
            password=password,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    finally:
        release_backup_mutex()


def _do_restore_from_zip(zip_path, *, addon_ids, include_sources_mode,
                         include_favourites, restore_categories,
                         progress_cb, cancel_check, timeout_s=None,
                         password=None):
    # Si el manifest está cifrado y no se pasa password, load_manifest
    # lanza ManifestError.
    manifest = load_manifest_from_zip(zip_path, password=password)
    if manifest.get('encrypted'):
        # Stub devuelto sin password: no podemos restaurar.
        raise BackupError('encrypted_no_password')
    if not os.path.isfile(zip_path):
        raise BackupError('ZIP no encontrado')

    def _cb(pct, msg):
        if progress_cb:
            progress_cb(pct, 100, msg)

    # Deadline absoluto opcional: evita cuelgues indefinidos en SMB lento
    # sin cancel manual.
    _deadline = (time.time() + timeout_s) if timeout_s else None

    def _tick():
        heartbeat_backup_mutex()
        return bool(cancel_check and cancel_check())

    def _check_cancel():
        if _tick():
            raise InterruptedError('Restore cancelado')
        if _deadline and time.time() > _deadline:
            raise InterruptedError(
                f'Restore excedió timeout de {timeout_s}s; abortado'
            )

    result = {
        'ok': [], 'failed': [], 'skipped': [],
        'sources_merged': 0,
        'favourites_restored': False,
        'categories_restored': {},  # {name: {extracted, errors}}
        'kodi_version_check': check_kodi_version_compat(manifest),
        'integrity_check': None,  # se rellena con _check_zip_integrity
        'hash_failures': [],  # archivos con SHA256 mismatch
        # Warnings de environment mismatch (OS, arch, etc.)
        'environment_mismatch': check_environment_mismatch(
            manifest.get('environment') or {},
        ),
    }
    wanted = set(addon_ids) if addon_ids else None
    # Hashes esperados del manifest. Si es v1 sin hashes, queda {} y la
    # verificación se skipea.
    expected_hashes = manifest.get('file_hashes') or {}
    hash_failures = result['hash_failures']

    # Un restore anterior que muriera a mitad deja `<id>.bak_<ns>` tanto en
    # addons/ como en addon_data/. Barrerlos aquí evita que se acumulen copias
    # completas de los datos del usuario, invisibles y sin caducidad.
    installer.cleanup_orphan_backups()

    _cb(2, 'Verificando integridad del ZIP...')
    integrity = _check_zip_integrity(zip_path)
    result['integrity_check'] = integrity
    if not integrity['ok']:
        raise BackupError(
            f'ZIP no pasa verificación de integridad: {integrity["reason"]}'
        )

    _cb(5, 'Analizando ZIP...')
    # Indexar entries por carpeta de primer nivel bajo addons/ y addon_data/
    addon_dirs = {}      # id -> [ZipInfo]
    addon_data_dirs = {}
    sources_info = None
    favourites_info = None

    with zipfile.ZipFile(zip_path, 'r') as zf:
        for info in zf.infolist():
            name = info.filename.replace('\\', '/')
            if name == 'sources.xml':
                sources_info = info
                continue
            if name == 'favourites.xml':
                favourites_info = info
                continue
            if name.startswith('addons/'):
                rest = name[len('addons/'):]
                if not rest or '/' not in rest:
                    # entry directo en addons/ → ignorar
                    continue
                aid = rest.split('/', 1)[0]
                if not _valid_addon_id(aid):
                    log.security(
                        f'[backup] restore: id sospechoso ignorado: {aid!r}'
                    )
                    continue
                addon_dirs.setdefault(aid, []).append(info)
                continue
            if name.startswith('addon_data/'):
                rest = name[len('addon_data/'):]
                if not rest or '/' not in rest:
                    continue
                aid = rest.split('/', 1)[0]
                if not _valid_addon_id(aid):
                    log.security(
                        f'[backup] restore: addon_data sospechoso: {aid!r}'
                    )
                    continue
                addon_data_dirs.setdefault(aid, []).append(info)
                continue
            # otros entries (manifest.*, raíz) los ignoramos en restore

        if wanted is not None:
            target_ids = [a for a in wanted if a in addon_dirs]
            for a in wanted:
                if a not in addon_dirs and a != SELF_ADDON_ID:
                    result['skipped'].append({
                        'id': a, 'reason': 'no_presente_en_zip',
                    })
        else:
            target_ids = list(addon_dirs.keys())

        # Filtrar SELF siempre
        target_ids = [a for a in target_ids if a != SELF_ADDON_ID]

        # Filtrar incompat Python ANTES de extraer: addons con
        # xbmc.python >= 3.0 instalados en Kodi 18 (Py 2) crashean al cargar.
        current_kodi_major = _parse_kodi_major(
            xbmc.getInfoLabel('System.BuildVersion') or ''
        )
        addons_by_id_manifest = {
            a.get('id'): a for a in manifest.get('addons') or []
            if a.get('id')
        }
        filtered_ids = []
        for aid in target_ids:
            addon_meta = addons_by_id_manifest.get(aid)
            py_compat, py_warn = check_addon_python_compat(
                addon_meta, current_kodi_major,
            )
            if not py_compat:
                log.info(f'[backup] {py_warn}; skip')
                result['skipped'].append({
                    'id': aid,
                    'reason': f'python_version_mismatch: {py_warn}',
                })
            else:
                filtered_ids.append(aid)
        target_ids = filtered_ids

        # Snapshot automático pre-restore: solo respalda lo que el restore
        # va a sobrescribir; rotación FIFO. Si falla, el restore continúa
        # (best effort).
        try:
            pre_restore_enabled = xbmcaddon.Addon().getSettingBool(
                'backup.auto_pre_restore.enabled')
        except (RuntimeError, AttributeError):
            pre_restore_enabled = True
        if pre_restore_enabled and (target_ids or restore_categories):
            _cb(6, 'Creando snapshot de seguridad pre-restore...')
            cats_for_snapshot = {}
            if restore_categories:
                if restore_categories == 'all':
                    cats_for_snapshot = manifest.get('categories') or {}
                else:
                    cats_for_snapshot = {
                        c: True for c in (restore_categories or [])
                    }
            pre_path = _make_pre_restore_snapshot(
                addon_ids=target_ids,
                addon_data_ids=list(addon_data_dirs.keys()),
                kodi_categories=cats_for_snapshot,
                cancel_check=_tick,
            )
            if pre_path:
                result['auto_pre_restore'] = os.path.basename(pre_path)

        total = max(len(target_ids), 1)
        for i, aid in enumerate(target_ids):
            _check_cancel()
            pct = 10 + int((i / total) * 75)
            _cb(pct, f'Restaurando {aid}...')
            try:
                # 1. Borrar/respaldar carpeta existente, atómico
                dest = os.path.join(_ADDONS_DIR, aid)
                backup_dir = None
                if os.path.isdir(dest):
                    # Sufijo con reloj de pared: es lo que permite a
                    # `installer.cleanup_orphan_backups` saber que este `.bak_`
                    # es de una operación EN CURSO y no barrerlo.
                    backup_dir = f'{dest}{installer.backup_dir_suffix()}'
                    shutil.move(dest, backup_dir)
                # Mismo trato para addon_data: la extracción SOBRESCRIBE los
                # datos del usuario (settings, cachés, tokens). Si luego falla
                # algo, borrar lo extraído no basta: los originales ya no
                # están. Apartamos la carpeta y la devolvemos en el rollback.
                data_dest = os.path.join(_ADDON_DATA_DIR, aid)
                data_backup_dir = None
                if aid in addon_data_dirs and os.path.isdir(data_dest):
                    data_backup_dir = (
                        f'{data_dest}{installer.backup_dir_suffix()}')
                    shutil.move(data_dest, data_backup_dir)
                try:
                    for info in addon_dirs[aid]:
                        exp_hash = expected_hashes.get(info.filename)
                        # dest_base es la carpeta addons y el arcname ya
                        # empieza por 'addons/': hay que quitar el prefijo o
                        # el addon acaba en addons/addons/<id>/ y Kodi no lo ve.
                        if not _extract_zip_entry_safely(
                            zf, info, _ADDONS_DIR,
                            expected_hash=exp_hash,
                            hash_failures=hash_failures,
                            strip_prefix='addons/',
                        ):
                            raise BackupError(
                                f'entry rechazada: {info.filename!r}'
                            )
                    # 2. addon_data si está en el ZIP
                    if aid in addon_data_dirs:
                        for info in addon_data_dirs[aid]:
                            exp_hash = expected_hashes.get(info.filename)
                            if not _extract_zip_entry_safely(
                                zf, info, _ADDON_DATA_DIR,
                                expected_hash=exp_hash,
                                hash_failures=hash_failures,
                                strip_prefix='addon_data/',
                            ):
                                raise BackupError(
                                    f'addon_data rechazado: {info.filename!r}'
                                )
                    # 3. Limpiar backups (el restore salió bien)
                    if backup_dir and os.path.isdir(backup_dir):
                        shutil.rmtree(backup_dir, ignore_errors=True)
                    if data_backup_dir and os.path.isdir(data_backup_dir):
                        shutil.rmtree(data_backup_dir, ignore_errors=True)
                    result['ok'].append(aid)
                except Exception:
                    # Rollback del addon.
                    if os.path.isdir(dest):
                        shutil.rmtree(dest, ignore_errors=True)
                    if backup_dir and os.path.isdir(backup_dir):
                        shutil.move(backup_dir, dest)
                    # Rollback del addon_data: solo lo tocamos si íbamos a
                    # sobrescribirlo. Devolvemos los datos del usuario si los
                    # habíamos apartado; si no había nada previo, lo extraído
                    # es huérfano y se va entero.
                    if aid in addon_data_dirs:
                        if os.path.isdir(data_dest):
                            shutil.rmtree(data_dest, ignore_errors=True)
                        if data_backup_dir and os.path.isdir(data_backup_dir):
                            shutil.move(data_backup_dir, data_dest)
                    raise
            except Exception as e:
                log.warning(f'[backup] restore de {aid} falló: {e!r}')
                result['failed'].append({'id': aid, 'error': str(e)})

    # Re-registrar addons en Kodi
    if result['ok']:
        # Secuencia batched para activar addons + restaurar enabled/disabled:
        # 1) UpdateLocalAddons() para que Kodi descubra los addons nuevos
        #    (ya están en disco tras extracción).
        # 2) Sleep porque UpdateLocalAddons es async.
        # 3) Una pasada en serie de SetAddonEnabled (JSON-RPC no tiene batch
        #    nativo).
        # 4) Fallback a try_recover solo para los que SetAddonEnabled falle:
        #    try_recover llama UpdateLocalAddons() en cascada y si lo
        #    hacemos por-addon en el caso común causa rescans masivos.
        _cb(88, 'Refrescando catálogo de Kodi...')
        xbmc.executebuiltin('UpdateLocalAddons()')
        xbmc.sleep(2000)
        manifest_by_id = {
            a.get('id'): a for a in manifest.get('addons', []) or []
            if a.get('id')
        }
        from lib import jsonrpc_safe
        # Pase 1: SetAddonEnabled para todos en serie (sin try_recover
        # per-addon, que llamaba UpdateLocalAddons en cascada → varios
        # rescans innecesarios). Acumulamos fallos para fallback.
        recover_pending = []
        for aid in result['ok']:
            meta = manifest_by_id.get(aid)
            want_enabled = (meta is None) or meta.get('enabled', True)
            ok = jsonrpc_safe.call_void(
                'Addons.SetAddonEnabled',
                {'addonid': aid, 'enabled': bool(want_enabled)},
                timeout_s=5.0,
            )
            if not ok and want_enabled:
                # SetAddonEnabled falló y lo queríamos enabled → fallback
                recover_pending.append(aid)
        # Pase 2: fallback solo para los que fallaron (espera no causar
        # rescans masivos en el caso común donde todos están listos)
        for aid in recover_pending:
            try:
                installer.try_recover(aid)
            except Exception as e:
                log.warning(f'[backup] no se pudo activar {aid}: {e!r}')

    # sources.xml
    if sources_info and include_sources_mode != 'skip':
        _cb(91, 'Aplicando sources.xml...')
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                zip_bytes = zf.read(sources_info)
            if include_sources_mode == 'overwrite':
                # Atómico: sobrescribir sources.xml en sitio y morir a mitad
                # (disco lleno, kill) dejaría al usuario sin ninguna fuente.
                _atomic_write_bytes(_SOURCES_PATH, zip_bytes)
                result['sources_merged'] = -1  # señala overwrite
            else:
                result['sources_merged'] = _merge_sources_from_xml(
                    zip_bytes.decode('utf-8', errors='replace'))
        except Exception as e:
            log.warning(f'[backup] sources merge falló: {e!r}')

    # favourites.xml
    if favourites_info and include_favourites:
        _cb(93, 'Restaurando favoritos...')
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                with zf.open(favourites_info) as src:
                    data = src.read()
            # Atómico por la misma razón que el resto de escrituras a
            # favourites.xml (ver _write_favourites_xml).
            _atomic_write_bytes(_FAVOURITES_PATH, data)
            result['favourites_restored'] = True
        except Exception as e:
            log.warning(f'[backup] restore favoritos falló: {e!r}')

    # Categorías Kodi (databases, guisettings, etc.). Solo si el caller
    # las pidió explícitamente.
    if restore_categories is not None:
        _cb(95, 'Restaurando categorías de Kodi...')
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                cats = _restore_kodi_categories_from_zip(
                    zf, manifest,
                    requested=restore_categories,
                    cancel_check=_tick,
                    progress_cb=progress_cb,
                )
            result['categories_restored'] = cats
        except InterruptedError:
            raise
        except Exception as e:
            log.warning(f'[backup] restore categorías falló: {e!r}')
            result['categories_restored'] = {
                '_error': _sanitize_path_for_log(str(e))[:120],
            }

    # GUI settings y watched state: solo si el caller los incluye en
    # restore_categories y el ZIP contiene el dump.
    if restore_categories is not None:
        if restore_categories == 'all':
            wanted_set = set(
                (manifest.get('categories') or {}).keys()
            )
        elif isinstance(restore_categories, (set, list, tuple)):
            wanted_set = set(restore_categories)
        else:
            wanted_set = set()

        if 'guisettings' in wanted_set:
            gui_dump = manifest.get('guisettings_dump')
            if not gui_dump:
                # Intentar leer del archivo dedicado del ZIP (puede que
                # un v1 no lo tuviera en el manifest pero sí el archivo).
                try:
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        raw = zf.read('guisettings_dump.json')
                    gui_dump = json.loads(raw.decode('utf-8'))
                except (KeyError, zipfile.BadZipFile, ValueError):
                    gui_dump = None
            if gui_dump:
                _cb(96, 'Restaurando ajustes de Kodi...')
                result['guisettings_restored'] = restore_gui_settings(gui_dump)

        if 'watched_state' in wanted_set:
            ws_dump = manifest.get('watched_state')
            if not ws_dump:
                try:
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        raw = zf.read('watched_state.json')
                    ws_dump = json.loads(raw.decode('utf-8'))
                except (KeyError, zipfile.BadZipFile, ValueError):
                    ws_dump = None
            if ws_dump:
                _cb(98, 'Restaurando estado de visionado...')
                try:
                    from lib import backup_watched
                    result['watched_state_restored'] = (
                        backup_watched.restore_watched_state(ws_dump)
                    )
                except Exception as e:  # noqa: BLE001
                    log.warning(
                        f'[backup] watched_state restore falló: {e!r}'
                    )

    _cb(100, 'Completado')
    log.info(
        f'[backup] restore desde ZIP: ok={len(result["ok"])} '
        f'failed={len(result["failed"])} skipped={len(result["skipped"])}'
    )
    return result


def _merge_sources_from_xml(xml_text):
    """Añade al sources.xml local las fuentes nuevas del XML del ZIP.

    Devuelve cuántas se añadieron.
    """
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return 0
    files_block = root.find('files')
    if files_block is None:
        return 0
    from lib import sources as _sources
    existing = {s.get('path'): s.get('name') for s in _sources.list_files_sources()}
    added = 0
    for src in files_block.findall('source'):
        name_el = src.find('name')
        path_el = src.find('path')
        if name_el is None or path_el is None:
            continue
        name = (name_el.text or '').strip()
        path = (path_el.text or '').strip()
        if not name or not path:
            continue
        if path in existing:
            continue
        try:
            _sources.add_source(name, path)
            added += 1
        except Exception as e:
            log.warning(f'[backup] no se pudo añadir fuente {name!r}: {e!r}')
    return added


# Restore: desde manifest (reinstala desde repos)
def restore_from_manifest(manifest, *, addon_ids=None,
                          progress_cb=None, cancel_check=None):
    """Reinstala addons descargándolos frescos desde sus repos.

    Estrategia:
    1. Topological sort por dependencias (instala dependencies antes).
    2. Para cada repo necesario: si no está instalado, lo instala desde
       zip_url_hint o desde el ZIP de la datadir.
    3. Para cada addon: install_addon_from_repo con el repo más nuevo.

    Los addons con `requires xbmc.python` incompatible con el major actual
    de Kodi se mueven a `result['skipped']` con reason `python_version_mismatch`
    sin intentar instalarlos. El caller no recibe excepción: examina `skipped`
    para ver qué addons quedaron fuera.

    addon_ids: subset a restaurar. None = todos los del manifest.
    """
    if not acquire_backup_mutex(owner='backup_restore_manifest'):
        raise BackupBusyError('Ya hay una operación de backup en curso')
    try:
        return _do_restore_from_manifest(
            manifest, addon_ids=addon_ids,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    finally:
        release_backup_mutex()


def _do_restore_from_manifest(manifest, *, addon_ids, progress_cb, cancel_check):
    def _cb(pct, msg):
        if progress_cb:
            progress_cb(pct, 100, msg)

    def _check_cancel():
        # El latido va aquí por lo mismo que en backup_addons y en el restore
        # de ficheros: es el único punto que se recorre en cada iteración de
        # los dos bucles. Cada repo o addon es una instalación de red entera,
        # así que con más de diez se superaban los 10 min de
        # _BACKUP_MUTEX_STALE_S sin que nadie tocara el token y otra operación
        # lo reclamaba como caducado.
        heartbeat_backup_mutex()
        if cancel_check and cancel_check():
            raise InterruptedError('Restore cancelado')

    result = {
        'ok': [], 'failed': [], 'skipped': [],
        'kodi_version_check': check_kodi_version_compat(manifest),
    }

    addons_by_id = {a['id']: a for a in manifest.get('addons', [])
                    if _valid_addon_id(a.get('id', ''))}
    repos_by_id = {r['id']: r for r in manifest.get('repos', [])
                   if _valid_addon_id(r.get('id', ''))}

    wanted = set(addon_ids) if addon_ids else set(addons_by_id.keys())
    wanted.discard(SELF_ADDON_ID)

    # Topological sort: incluir dependencias previas.
    ordered = _topo_sort(wanted, addons_by_id)

    # Recolectar repos necesarios para esos addons.
    repos_needed = []
    repos_seen = set()
    for aid in ordered:
        addon = addons_by_id.get(aid)
        if not addon:
            continue
        provided = addon.get('provided_by') or []
        newest = next((p for p in provided if p.get('is_newest')), None)
        if not newest and provided:
            newest = provided[0]
        if newest:
            rid = newest.get('repo_id')
            if rid and rid not in repos_seen:
                repos_seen.add(rid)
                repos_needed.append(rid)

    _cb(5, 'Instalando repos necesarios...')
    total_repos = max(len(repos_needed), 1)
    for i, rid in enumerate(repos_needed):
        _check_cancel()
        pct = 5 + int((i / total_repos) * 25)
        _cb(pct, f'Repo: {rid}')
        if installer.is_ready(rid):
            continue
        repo_data = repos_by_id.get(rid)
        zip_url = repo_data.get('zip_url_hint') if repo_data else None
        if not _http_only_url(zip_url):
            log.warning(
                f'[backup] repo {rid} sin URL http(s): no se puede instalar'
            )
            continue
        # La URL sale del manifest, o sea del ZIP, que puede venir de otra
        # persona (compartir backups es una función del addon). Restaurar
        # "desde repos" descarga y HABILITA código de una URL que eligió quien
        # hizo el backup. Sobre http:// además puede cambiarla un intermediario.
        # No lo rechazamos: muchos repos de Kodi siguen sirviéndose por http y
        # bloquearlos rompería restaurar backups propios perfectamente válidos.
        # Pero queda registrado.
        if zip_url.startswith('http://'):
            log.security(
                f'[backup] repo {rid} se instala desde HTTP sin cifrar '
                f'({zip_url[:80]!r}); la URL viene del manifest del backup'
            )
        try:
            installer.download_and_install_repo(zip_url, rid)
        except Exception as e:
            log.warning(f'[backup] install repo {rid} falló: {e!r}')

    # Kodi major actual para validar Python compat por addon.
    current_kodi_major = _parse_kodi_major(
        xbmc.getInfoLabel('System.BuildVersion') or ''
    )

    _cb(32, 'Instalando addons...')
    total = max(len(ordered), 1)
    for i, aid in enumerate(ordered):
        _check_cancel()
        pct = 32 + int((i / total) * 65)
        addon = addons_by_id.get(aid)
        if not addon:
            # Dependencia añadida por topo-sort que no estaba en el manifest
            if installer.is_ready(aid) or installer.try_recover(aid):
                continue
            if aid.startswith(SYSTEM_PREFIXES):
                # bundle Kodi: si no está, no podemos hacer nada útil
                result['skipped'].append({
                    'id': aid, 'reason': 'dep_sistema_no_instalada',
                })
                continue
            result['skipped'].append({
                'id': aid, 'reason': 'dep_no_resuelta',
            })
            continue
        # Skip si el addon declara `requires xbmc.python` incompatible.
        py_compat, py_warn = check_addon_python_compat(addon, current_kodi_major)
        if not py_compat:
            log.info(f'[backup] {py_warn}; skip')
            result['skipped'].append({
                'id': aid,
                'reason': f'python_version_mismatch: {py_warn}',
            })
            continue
        _cb(pct, f'Addon: {aid}')
        if installer.is_ready(aid):
            result['ok'].append(aid)
            continue
        provided = addon.get('provided_by') or []
        newest = next((p for p in provided if p.get('is_newest')), None)
        if not newest and provided:
            newest = provided[0]
        repo_id = newest.get('repo_id') if newest else None
        try:
            if repo_id:
                ok = installer.install_addon_from_repo(aid, repo_id=repo_id)
            else:
                # Sin repo conocido: intentar recovery local
                ok = installer.try_recover(aid)
            if ok:
                result['ok'].append(aid)
            else:
                result['failed'].append({
                    'id': aid, 'error': 'instalación no completada',
                })
        except installer.InstallBusyError as e:
            result['failed'].append({'id': aid, 'error': str(e)})
        except installer.InstallError as e:
            result['failed'].append({'id': aid, 'error': str(e)})
        except Exception as e:
            log.warning(f'[backup] install addon {aid} falló: {e!r}')
            result['failed'].append({'id': aid, 'error': str(e)})

    # Una sola pasada en serie para aplicar enabled/disabled del manifest.
    # Sin UpdateLocalAddons() intermedio: los addons recién instalados ya
    # quedan registrados por el installer.
    from lib import jsonrpc_safe
    for aid in result['ok']:
        meta = addons_by_id.get(aid)
        if meta is None or meta.get('enabled', True):
            continue
        if not jsonrpc_safe.call_void(
            'Addons.SetAddonEnabled',
            {'addonid': aid, 'enabled': False},
            timeout_s=5.0,
        ):
            log.warning(f'[backup] no se pudo desactivar {aid}')

    _cb(100, 'Completado')
    log.info(
        f'[backup] restore desde manifest: ok={len(result["ok"])} '
        f'failed={len(result["failed"])} skipped={len(result["skipped"])}'
    )
    return result


def _topo_sort(wanted_ids, addons_by_id):
    """Ordena IDs poniendo dependencias antes. Inserta IDs faltantes que
    sean dependencias no-sistema y estén en el manifest.

    No es un sort estricto: si hay ciclo (no debería ocurrir entre addons
    Kodi), cae a orden simple sin abortar.
    """
    result = []
    visited = set()
    visiting = set()

    def visit(aid):
        if aid in visited or aid == SELF_ADDON_ID:
            return
        # Filtrar dependencias de sistema (xbmc.*, metadata.*, service.xbmc.*,
        # repository.xbmc.*). Antes se usaba ('xbmc.', 'kodi.') que dejaba pasar
        # metadata.* y service.xbmc.* como dependencias instalables.
        if aid.startswith(SYSTEM_PREFIXES):
            return
        if aid in visiting:
            log.warning(f'[backup] ciclo de dependencias detectado en {aid}')
            return
        visiting.add(aid)
        addon = addons_by_id.get(aid)
        if addon:
            for req in addon.get('requires', []) or []:
                rid = req.get('id') if isinstance(req, dict) else None
                if not rid:
                    continue
                visit(rid)
        visiting.discard(aid)
        visited.add(aid)
        result.append(aid)

    for aid in wanted_ids:
        visit(aid)
    return result


# Install desde XML batch
def install_from_xml(xml_path, *, addon_ids=None, repo_ids=None,
                     progress_cb=None, cancel_check=None):
    """Parsea XML y dispara la cadena de instalaciones.

    Formato esperado:
      <kodi-addons>
        <repositories>
          <repo id="..." url="http(s)://..."/>
        </repositories>
        <addons>
          <addon id="..." repo="..."/>
        </addons>
      </kodi-addons>

    addon_ids/repo_ids:
        None: instalar todos los del XML (legacy/default).
        []: no instalar nada de esa categoría.
        list[str]: instalar solo ese subset.

    Semántica distinta de restore_from_zip/restore_from_manifest, que tratan
    `addon_ids=[]` como "todos" (rama `if addon_ids else None`). Aquí el
    filtro es `if addon_ids is not None`, así que `[]` filtra a cero.

    Devuelve dict {ok, failed, skipped} igual que restore.
    """
    if not acquire_backup_mutex(owner='install_from_xml'):
        raise BackupBusyError('Ya hay una operación de backup en curso')
    try:
        return _do_install_from_xml(
            xml_path,
            addon_ids=addon_ids, repo_ids=repo_ids,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    finally:
        release_backup_mutex()


def peek_xml(xml_path):
    """Lee un XML batch y devuelve (repos, addons) sin instalar nada.

    Útil para que la UI muestre selección granular antes de invocar
    install_from_xml. Reusa _parse_batch_xml (mismas validaciones de IDs
    y URLs http(s)).
    """
    return _parse_batch_xml(xml_path)


def _parse_batch_xml(xml_path):
    """Parsea el XML y devuelve (repos, addons). Lanza BackupError si inválido.

    Protección XXE/billion-laughs: ElementTree estándar no resuelve
    entidades externas por defecto (Python 3 con expat). Limitamos tamaño
    del archivo a 1 MB para acotar el coste de un billion-laughs interno.
    """
    if not os.path.isfile(xml_path):
        raise BackupError('XML no encontrado')
    if os.path.getsize(xml_path) > MAX_BATCH_XML_BYTES:
        raise BackupError('XML excede 1 MB')
    try:
        tree = ET.parse(xml_path)
    except ET.ParseError as e:
        raise BackupError(f'XML inválido: {e}')
    root = tree.getroot()
    if root.tag != 'kodi-addons':
        raise BackupError("raíz del XML debe ser <kodi-addons>")

    repos_block = root.find('repositories')
    addons_block = root.find('addons')
    repos = []
    addons = []
    if repos_block is not None:
        for r in repos_block.findall('repo'):
            rid = (r.get('id') or '').strip()
            url = (r.get('url') or '').strip()
            if not _valid_addon_id(rid):
                log.security(f'[backup] XML repo id sospechoso: {rid!r}')
                continue
            if not _http_only_url(url):
                log.security(f'[backup] XML repo url no http(s): {url!r}')
                continue
            repos.append({'id': rid, 'url': url})
    if addons_block is not None:
        for a in addons_block.findall('addon'):
            aid = (a.get('id') or '').strip()
            repo_id = (a.get('repo') or '').strip() or None
            if not _valid_addon_id(aid):
                log.security(f'[backup] XML addon id sospechoso: {aid!r}')
                continue
            if repo_id is not None and not _valid_addon_id(repo_id):
                log.security(
                    f'[backup] XML addon repo sospechoso: {repo_id!r}'
                )
                repo_id = None
            addons.append({'id': aid, 'repo': repo_id})
    return repos, addons


def _do_install_from_xml(xml_path, *, addon_ids=None, repo_ids=None,
                         progress_cb, cancel_check):
    def _cb(pct, msg):
        if progress_cb:
            progress_cb(pct, 100, msg)

    def _check_cancel():
        # Mismo motivo que en _do_restore_from_manifest: los dos bucles pasan
        # por aquí una vez por repo y por addon, y cada uno es una instalación
        # de red que puede tardar minutos.
        heartbeat_backup_mutex()
        if cancel_check and cancel_check():
            raise InterruptedError('Instalación cancelada')

    repos_list, addons_list = _parse_batch_xml(xml_path)
    if repo_ids is not None:
        wanted_repos = set(repo_ids)
        repos_list = [r for r in repos_list if r['id'] in wanted_repos]
    if addon_ids is not None:
        wanted_addons = set(addon_ids)
        addons_list = [a for a in addons_list if a['id'] in wanted_addons]
    result = {'ok': [], 'failed': [], 'skipped': []}

    total = max(len(repos_list) + len(addons_list), 1)
    step = 0

    _cb(2, 'Instalando repositorios...')
    for repo in repos_list:
        _check_cancel()
        rid = repo['id']
        url = repo['url']
        pct = 2 + int((step / total) * 90)
        step += 1
        _cb(pct, f'Repo: {rid}')
        if installer.is_ready(rid):
            result['ok'].append(rid)
            continue
        try:
            ok = installer.download_and_install_repo(url, rid)
            if ok:
                result['ok'].append(rid)
            else:
                result['failed'].append({
                    'id': rid, 'error': 'instalación no completada',
                })
        except installer.InstallError as e:
            result['failed'].append({'id': rid, 'error': str(e)})
        except Exception as e:
            log.warning(f'[backup] XML repo {rid} falló: {e!r}')
            result['failed'].append({'id': rid, 'error': str(e)})

    for addon in addons_list:
        _check_cancel()
        aid = addon['id']
        repo_id = addon.get('repo')
        pct = 2 + int((step / total) * 90)
        step += 1
        _cb(pct, f'Addon: {aid}')
        if installer.is_ready(aid):
            result['ok'].append(aid)
            continue
        try:
            ok = installer.install_addon_from_repo(aid, repo_id=repo_id)
            if ok:
                result['ok'].append(aid)
            else:
                result['failed'].append({
                    'id': aid, 'error': 'instalación no completada',
                })
        except installer.InstallError as e:
            result['failed'].append({'id': aid, 'error': str(e)})
        except Exception as e:
            log.warning(f'[backup] XML addon {aid} falló: {e!r}')
            result['failed'].append({'id': aid, 'error': str(e)})

    _cb(100, 'Completado')
    return result
