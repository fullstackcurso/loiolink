"""Grabador nativo de streams HLS al disco.

Implementa una clase `HLSRecorder` (subclase de `threading.Thread`)
que descarga los segmentos `.ts` de un master playlist HLS y los
concatena en un archivo local. Soporta:

- Selección de variante por bandwidth máximo.
- Detección de `#EXT-X-ENDLIST` (VOD completo) → para limpia.
- Detección de AES-128 / SAMPLE-AES → abort limpio (no podemos grabar
  contenido con DRM externo sin la clave).
- Reintento exponencial con cap (errores transitorios de red, HTTP 5xx).
- Captura de ENOSPC (disco lleno) con mensaje al usuario.
- Dedup de segmentos por nombre (deque de 1000) para playlists que
  repiten segmentos en live.
- Cancelación limpia por `_stop_event` y por `Monitor.abortRequested()`
  (cierre de Kodi).
- Archivo temporal `.partial` durante la grabación; rename al nombre
  final al terminar con éxito. Al cancelar/error, el `.partial` queda
  para que el usuario decida desde el panel.

Portado de plugin.video.espatv (mismo autor) bajo GPL-2.0-or-later.

Threading model: los recorders viven en el proceso del service, no en
el plugin. El registro `_ACTIVE` es global del módulo y protegido por
lock; los handlers HTTP de `server_permanent` lo usan para start/stop/list.
`recover_orphan_recordings()` se llama al arrancar el service para barrer
entradas con `recording_state='active'` que quedaron del run anterior
(crash de Kodi mid-grabación). `stop_all()` se llama al apagar el service.
"""
import collections
import errno
import os
import re
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Callable, Dict, List, Optional

import xbmc

from lib import log


_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
       'AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/120.0.0.0 Safari/537.36')

_HTTP_TIMEOUT = 15
_CHUNK_DEDUP_MAX = 1000
_EMPTY_CYCLES_LIMIT = 120        # ~6 min sin datos nuevos = canal muerto
_TRANSIENT_ERRORS_LIMIT = 720    # ~1 h de errores transitorios = abort
_OS_ERRORS_LIMIT = 20

_TERMINAL_HTTP_CODES = frozenset({404, 403, 410, 451})


def _is_http_url(url: str) -> bool:
    """True si el esquema es http/https.

    Un master playlist lo sirve un tercero; sus líneas de variante/segmento
    pasan por urljoin, que sustituye el esquema si la línea es una URL
    absoluta (`urljoin('http://h/', 'file:///etc/passwd')` -> 'file://...').
    El opener por defecto de urllib abre file://, ftp:// y data://, así que
    un stream hostil podría hacer que el grabador lea un fichero local (o
    haga SSRF) y lo vuelque en la grabación. Solo http/https son legítimos
    para un stream remoto.
    """
    return urllib.parse.urlparse(url).scheme.lower() in ('http', 'https')

# Lecturas de stderr de FFmpeg: aceptamos hasta 64 KB en el ring para sacar
# el motivo del fallo si el proceso muere. Más allá es ruido.
_FFMPEG_STDERR_RING_BYTES = 65536
_FFMPEG_PROGRESS_RX = re.compile(rb'time=(\d+):(\d+):(\d+(?:\.\d+)?)')


# Registro global de recorders activos.
_ACTIVE_LOCK = threading.Lock()
_ACTIVE: Dict[str, 'HLSRecorder'] = {}


def _bump_panel(reason: str) -> None:
    """Despierta el long-poll del panel para que el chip y la lista de
    grabaciones se refresquen al instante. Sin esto el cliente espera
    hasta `_STATUS_LONGPOLL_S` (25 s) para ver el cambio.

    Tolerante: si notify no está cargado (tests fuera del contexto Kodi),
    no propaga el error.
    """
    try:
        from lib.remote import notify
        notify.bump_status(f'hls.{reason}')
    except Exception:
        pass


def register(recorder: 'HLSRecorder') -> None:
    with _ACTIVE_LOCK:
        _ACTIVE[recorder.recording_id] = recorder
    _bump_panel('start')


def register_if_under_limit(recorder: 'HLSRecorder', limit: int) -> bool:
    """Registra el recorder solo si hay sitio bajo el límite. Atómico.

    Evita el TOCTOU de hacer `count_active() < limit` y luego `register()`
    en dos pasos: dos peticiones concurrentes podrían pasar el check con
    `limit-1` activas y acabar con `limit+1`. Aquí el check y el insert
    comparten lock.

    Returns True si se registró, False si ya estaba al límite.
    """
    with _ACTIVE_LOCK:
        if len(_ACTIVE) >= limit:
            return False
        _ACTIVE[recorder.recording_id] = recorder
    _bump_panel('start')
    return True


def unregister(recording_id: str) -> None:
    with _ACTIVE_LOCK:
        _ACTIVE.pop(recording_id, None)
    _bump_panel('end')


def get(recording_id: str) -> Optional['HLSRecorder']:
    with _ACTIVE_LOCK:
        return _ACTIVE.get(recording_id)


def count_active() -> int:
    with _ACTIVE_LOCK:
        return len(_ACTIVE)


def list_active() -> List[Dict]:
    """Devuelve un snapshot de las grabaciones activas para el panel."""
    with _ACTIVE_LOCK:
        return [r.snapshot() for r in _ACTIVE.values()]


# Regex precompiladas: se compilan una vez, no en cada llamada a probe_master.
# El look-behind negativo en _RX_BW evita matchear `AVERAGE-BANDWIDTH=` cuando
# el atributo va antes que `BANDWIDTH=` en la misma línea.
_RX_BW = re.compile(r'(?<![A-Z-])BANDWIDTH=(\d+)')
_RX_RES = re.compile(r'RESOLUTION=(\d+x\d+)')

# Tope defensivo al leer el master playlist: un master HLS legítimo cabe
# de sobra en 1 MB (suelen rondar 1-10 KB). Sin este cap, un endpoint
# adversarial podría servir un response gigante y agotar memoria del
# proceso del service.
_PROBE_MAX_BYTES = 1_048_576


def probe_master(url: str, timeout: float = 8.0) -> Dict:
    """Hace GET a `url` y, si es un master HLS, devuelve sus variantes.

    Pensado para el panel pre-grabación: si hay >1 variante el panel abre
    un diálogo de calidad; si solo hay 1 o no es master, graba directo.

    Nunca levanta excepción; siempre devuelve un dict serializable a JSON
    con la forma:
      {
        'is_master': bool,
        'variants': [{'bandwidth': int, 'resolution': 'WxH', 'url': str}, ...],
        'error': None | 'http_<code>' | 'timeout' | 'network',
      }
    Las variantes vienen ordenadas por bandwidth descendente.
    """
    try:
        req = urllib.request.Request(url, headers={'User-Agent': _UA})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            # Read con tope: protege contra responses gigantes (DoS por
            # memoria si el endpoint sirve un blob enorme).
            raw = resp.read(_PROBE_MAX_BYTES + 1)
            if len(raw) > _PROBE_MAX_BYTES:
                return {'is_master': False, 'variants': [], 'error': 'network'}
            content = raw.decode('utf-8', errors='ignore')
    except urllib.error.HTTPError as e:
        return {'is_master': False, 'variants': [], 'error': f'http_{e.code}'}
    except urllib.error.URLError as e:
        reason = 'timeout' if isinstance(e.reason, socket.timeout) else 'network'
        return {'is_master': False, 'variants': [], 'error': reason}
    except (socket.timeout, OSError):
        return {'is_master': False, 'variants': [], 'error': 'network'}

    lines = content.splitlines()
    variants = []
    for i, line in enumerate(lines):
        if not line.startswith('#EXT-X-STREAM-INF'):
            continue
        bw_m = _RX_BW.search(line)
        bw = int(bw_m.group(1)) if bw_m else 0
        res_m = _RX_RES.search(line)
        res = res_m.group(1) if res_m else ''
        # La URL de la variante es la primera línea no vacía y sin '#'
        # tras el tag #EXT-X-STREAM-INF.
        for j in range(i + 1, len(lines)):
            candidate = lines[j].strip()
            if candidate and not candidate.startswith('#'):
                variant_url = urllib.parse.urljoin(url, candidate)
                if not _is_http_url(variant_url):
                    log.security(
                        f'hls probe: variante no-http descartada: {variant_url[:120]!r}')
                    break
                variants.append({
                    'bandwidth': bw,
                    'resolution': res,
                    'url': variant_url,
                })
                break

    if not variants:
        return {'is_master': False, 'variants': [], 'error': None}

    variants.sort(key=lambda v: v['bandwidth'], reverse=True)
    return {'is_master': True, 'variants': variants, 'error': None}


def stop_all(timeout: float = 5.0) -> None:
    """Señaliza stop a todas las grabaciones y espera join con timeout.

    Pensado para llamarse desde el `finally` de `service.run()`.
    Cada recorder marca su estado en el historial como 'aborted' antes
    de salir si su flujo run() lo permite; los que no terminen en
    `timeout` quedan como 'active' en el historial y serán marcados
    como 'interrupted' en el próximo arranque del service.
    """
    with _ACTIVE_LOCK:
        recorders = list(_ACTIVE.values())
    for r in recorders:
        r.stop()
    deadline = time.time() + timeout
    for r in recorders:
        # Si el thread nunca se startó, join() levanta RuntimeError.
        # Edge case raro (register sin start) pero defensivo.
        if not r.is_alive():
            continue
        remaining = max(0.1, deadline - time.time())
        r.join(timeout=remaining)


def recover_orphan_recordings() -> int:
    """Marca como 'interrupted' las grabaciones del historial que quedaron
    con `recording_state='active'` tras un cierre forzado de Kodi.

    Llamar al arrancar el service (antes de levantar el HTTP server) para
    que el historial muestre el estado real. Si existe el `.partial`,
    se renombra al nombre final (sin sufijo) para que sea reproducible
    desde el historial; el usuario verá un badge "interrumpido" pero el
    archivo abre con un doble click.

    Cubre dos formas de path en el historial:

    1. `path` ya acaba en `.partial` (caso legacy si el publish parcial
       tocó el path antes del crash).
    2. `path` apunta al nombre final pero existe `path + '.partial'` en
       disco (caso normal: `history.add` guardó el output_file y el rename
       no llegó a ocurrir porque Kodi se cayó mid-grabación).

    Devuelve el número de entradas marcadas como interrumpidas.
    """
    from lib.transfers import history
    n = 0
    for entry in history.list_all():
        if entry.get('recording_state') != 'active':
            continue
        updates = {'recording_state': 'interrupted'}
        path = entry.get('path') or ''

        # Determinar partial y final con la convención `partial = final + .partial`.
        if path.endswith('.partial'):
            partial_path = path
            final_path = path[:-len('.partial')]
        elif path:
            partial_path = path + '.partial'
            final_path = path
        else:
            partial_path = ''
            final_path = ''

        if partial_path and os.path.exists(partial_path):
            try:
                # Si quedó el placeholder vacío de reserve_unique_path,
                # quitarlo antes del rename (Windows no sobreescribe).
                if final_path != partial_path and os.path.exists(final_path):
                    os.remove(final_path)
                os.rename(partial_path, final_path)
                updates['path'] = final_path
                try:
                    updates['size'] = os.path.getsize(final_path)
                except OSError:
                    pass
            except OSError as e:
                log.warning(f'[HLS] no se pudo promover .partial: {e!r}')
        history.update(entry['id'], **updates)
        n += 1
        log.info(f'[HLS] grabación huérfana marcada interrupted: {entry.get("name")!r}')
    return n


class HLSRecorder(threading.Thread):
    """Hilo que graba un stream HLS al disco.

    Parámetros del constructor:

    m3u8_url: URL del master playlist o del playlist plano.
    output_file: ruta destino final (sin sufijo .partial; lo añade el
        recorder durante la grabación y renombra al terminar bien).
    name: nombre legible del canal/grabación (para logs y UI).
    max_duration_mins: 0 = ilimitado.
    max_bandwidth: 0 = sin límite (máxima calidad).
    history_entry_id: si se pasa, el recorder actualiza la entrada
        correspondiente en `history.py` con `recording_state` y bytes.
    recording_id: identificador opaco (UUID hex); si se omite se genera.
    callback_progress: fn(recorder, state_str) opcional.
    callback_finish: fn(recorder) opcional.
    """

    def __init__(
        self,
        m3u8_url: str,
        output_file: str,
        name: str = '',
        max_duration_mins: int = 0,
        max_bandwidth: int = 0,
        history_entry_id: Optional[str] = None,
        recording_id: Optional[str] = None,
        callback_progress: Optional[Callable] = None,
        callback_finish: Optional[Callable] = None,
        *,
        compress: bool = False,
        compress_crf: int = 26,
    ):
        super().__init__(name=f'hls-recorder-{name or "stream"}', daemon=True)
        self.recording_id = recording_id or uuid.uuid4().hex
        self.m3u8_url = m3u8_url
        self.output_file = output_file
        self.partial_file = output_file + '.partial'
        self.channel_name = name
        self.max_duration_mins = max_duration_mins
        self.max_bandwidth = max_bandwidth
        self.history_entry_id = history_entry_id
        self.callback_progress = callback_progress
        self.callback_finish = callback_finish
        # Reencode con FFmpeg sobre la marcha. kw-only para no romper callers.
        # crf se clampa al rango razonable de libx264 (18=quasi-lossless, 35=feo).
        self.compress = bool(compress)
        self.compress_crf = max(18, min(35, int(compress_crf) if compress_crf else 26))

        self._stop_event = threading.Event()
        self._monitor = xbmc.Monitor()
        self.downloaded_bytes = 0
        self.start_time = time.time()
        self.is_recording = False
        # State: pending → active → (completed | aborted | error)
        self.state = 'pending'
        self.quality_status = 'pending'
        self.error_msg = ''

        self._dedup_queue: 'collections.deque[str]' = collections.deque(
            maxlen=_CHUNK_DEDUP_MAX,
        )
        self._dedup_set = set()

    # API pública

    def stop(self) -> None:
        self._stop_event.set()

    def elapsed_s(self) -> int:
        return int(time.time() - self.start_time)

    def snapshot(self) -> Dict:
        """Estado serializable para el endpoint /api/hls/list."""
        return {
            'recording_id': self.recording_id,
            'name': self.channel_name,
            'state': self.state,
            'bytes': self.downloaded_bytes,
            'elapsed_s': self.elapsed_s(),
            'quality_status': self.quality_status,
            'error_msg': self.error_msg,
        }

    # Internos

    def _sleep(self, seconds: float) -> bool:
        """Sleep que respeta abort de Kodi y stop_event. True si debe parar."""
        if self._monitor.waitForAbort(seconds):
            return True
        return self._stop_event.is_set()

    def _http_get(self, url: str, is_binary: bool = False):
        """GET con cap defensivo según tipo.

        Playlists (texto): cap 8 MB. Un master/media playlist legítimo
        rara vez pasa de unos KB; 8 MB cubre playlists largos de live con
        miles de segmentos. Sin cap, un endpoint adversarial podría servir
        un blob gigantesco y agotar memoria del service.

        Segmentos (binario): NO cap aquí; el flujo de grabación los
        consume sin acumularlos enteros y el tamaño legítimo varía mucho
        (los segmentos HLS pueden ser de 10 MB).
        """
        if not _is_http_url(url):
            log.security(f'hls: fetch de esquema no-http rechazado: {url[:120]!r}')
            raise urllib.error.URLError(f'esquema no permitido: {url[:60]!r}')
        req = urllib.request.Request(url, headers={'User-Agent': _UA})
        with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT) as resp:
            if is_binary:
                data = resp.read()
            else:
                cap = 8 * 1024 * 1024
                raw = resp.read(cap + 1)
                if len(raw) > cap:
                    raise OSError(f'playlist excede cap defensivo de {cap} bytes')
                data = raw
        return data if is_binary else data.decode('utf-8', errors='ignore')

    def _resolve_master_playlist(self, url: str) -> str:
        """Elige variante de mayor calidad que cumpla `max_bandwidth`.

        Devuelve la URL del playlist a grabar. Si no es master (no hay
        `#EXT-X-STREAM-INF`), devuelve la URL tal cual.
        """
        try:
            content = self._http_get(url)
        except Exception as e:
            log.warning(f'[HLS] error resolviendo master playlist: {e!r}')
            self.quality_status = 'error'
            return url

        lines = content.splitlines()
        variants = []
        for i, line in enumerate(lines):
            if not line.startswith('#EXT-X-STREAM-INF'):
                continue
            m = re.search(r'BANDWIDTH=(\d+)', line)
            bw = int(m.group(1)) if m else 0
            for j in range(i + 1, len(lines)):
                candidate = lines[j].strip()
                if candidate and not candidate.startswith('#'):
                    variant_url = urllib.parse.urljoin(url, candidate)
                    # Descartar variantes que urljoin haya reescrito a un
                    # esquema no-http (file://, ftp://...): en modo compress
                    # esta URL va directa a ffmpeg -i y leería un fichero local.
                    if _is_http_url(variant_url):
                        variants.append((bw, variant_url))
                    else:
                        log.security(
                            f'hls: variante no-http descartada: {variant_url[:120]!r}')
                    break

        if not variants:
            log.info('[HLS] sin lista maestra; única calidad disponible')
            self.quality_status = 'single'
            return url

        variants.sort(key=lambda x: x[0], reverse=True)

        if self.max_bandwidth > 0:
            eligible = [v for v in variants if v[0] <= self.max_bandwidth]
            if eligible:
                chosen = eligible[0]
                self.quality_status = 'matched'
            else:
                chosen = variants[-1]
                self.quality_status = 'forced_lowest'
                log.warning(
                    f'[HLS] ninguna variante <= {self.max_bandwidth} bps; '
                    f'forzando la más baja: {chosen[0]} bps',
                )
        else:
            chosen = variants[0]
            self.quality_status = 'matched'

        if len(variants) <= 1:
            self.quality_status = 'single'

        log.info(f'[HLS] variante elegida: {chosen[0]} bps -> {chosen[1][:120]!r}')
        return chosen[1]

    def _publish_progress(self, state_str: str) -> None:
        if self.callback_progress is not None:
            try:
                self.callback_progress(self, state_str)
            except Exception as e:
                log.warning(f'[HLS] callback_progress falló: {e!r}')

    def _update_history(self, **fields) -> None:
        if not self.history_entry_id:
            return
        try:
            from lib.transfers import history
            history.update(self.history_entry_id, **fields)
        except Exception as e:
            log.warning(f'[HLS] history.update falló: {e!r}')

    # FFmpeg (modo compress)

    def _check_drm_in_playlist(self, playlist_url: str) -> bool:
        """Devuelve True si el playlist contiene un `#EXT-X-KEY` con AES.

        Misma política que el modo TS (línea ~575 de `_process_playlist_once`):
        contenido cifrado no es grabable por copia directa ni por reencode sin
        la clave externa.

        Si la GET del playlist falla (red, timeout), devolvemos False
        conservativamente: que FFmpeg lo intente y reporte el error real es
        mejor que abortar por un fallo transitorio.
        """
        try:
            content = self._http_get(playlist_url)
        except Exception as e:
            log.warning(f'[HLS] no se pudo probar DRM antes de FFmpeg: {e!r}')
            return False
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if (line.startswith('#EXT-X-KEY:METHOD=AES-128')
                    or line.startswith('#EXT-X-KEY:METHOD=SAMPLE-AES')):
                return True
        return False

    def _kill_ffmpeg(self, proc) -> None:
        """Mata el proceso FFmpeg de forma escalonada.

        Mismo patrón que `_pipe_ffmpeg` en server_permanent: terminate +
        wait(2) → kill + wait(1). Sin propagar excepciones: el caller ya está
        en path de cleanup.
        """
        try:
            proc.terminate()
            proc.wait(timeout=2)
        except (subprocess.TimeoutExpired, OSError):
            try:
                proc.kill()
                proc.wait(timeout=1)
            except (subprocess.TimeoutExpired, OSError):
                pass

    def _ffmpeg_record(self, ffmpeg_path: str) -> None:
        """Graba el stream HLS reencodeando a MP4 con FFmpeg.

        Sustituye `_record_loop` cuando `self.compress` es True. La URL del
        master se entrega a FFmpeg que se encarga de demux, fetch de segmentos,
        decodificar y reencode en un solo proceso.

        Salida: MP4 fragmentado (`+frag_keyframe+empty_moov+default_base_moof`)
        para que el archivo sea reproducible aunque la grabación se interrumpa.
        """
        # 1. Resolver master para poder probar DRM en el playlist concreto que
        # FFmpeg también descargaría. Si el resolve falla, _resolve_master_playlist
        # devuelve la URL original; FFmpeg la manejará igual.
        playlist_url = self._resolve_master_playlist(self.m3u8_url)

        if self._stop_event.is_set() or self._monitor.abortRequested():
            self.state = 'aborted'
            return

        # 2. DRM check. Política idéntica al modo TS: si hay AES, abort.
        if self._check_drm_in_playlist(playlist_url):
            log.warning('[HLS] stream encriptado AES; abortando antes de FFmpeg')
            self.error_msg = (
                'Stream encriptado con DRM (AES). '
                'No es grabable por copia directa.'
            )
            self.state = 'aborted'
            return

        # 3. Construir comando FFmpeg.
        # Notas:
        # - `-rw_timeout` en microsegundos: 15_000_000 = 15 s.
        # - `-reconnect*`: tolerancia a hipos del CDN; alineado con el spirit
        #   de `_TRANSIENT_ERRORS_LIMIT` del modo TS.
        # - `-f mp4` forzado: el archivo destino acaba en `.partial` y FFmpeg
        #   no puede inferir el formato por extensión.
        # - `-movflags +frag_keyframe+empty_moov+default_base_moof`: MP4
        #   fragmentado, reproducible aunque la grabación se trunque.
        cmd = [
            ffmpeg_path,
            '-hide_banner', '-loglevel', 'info', '-nostats',
            '-user_agent', _UA,
            '-rw_timeout', '15000000',
            '-reconnect', '1',
            '-reconnect_streamed', '1',
            '-reconnect_delay_max', '5',
            '-i', playlist_url,
            '-c:v', 'libx264', '-crf', str(self.compress_crf), '-preset', 'veryfast',
            '-c:a', 'aac', '-b:a', '96k',
            '-f', 'mp4',
            '-movflags', '+frag_keyframe+empty_moov+default_base_moof',
        ]
        if self.max_duration_mins > 0:
            cmd += ['-t', str(self.max_duration_mins * 60)]
        cmd += ['-y', self.partial_file]

        log.info(
            f'[HLS] FFmpeg arrancando crf={self.compress_crf} '
            f'duration_cap={self.max_duration_mins}min'
        )

        # 4. Lanzar proceso.
        from lib.remote import transcode as _tc
        try:
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                bufsize=0,
                **_tc.no_console_flags(),
            )
        except OSError as e:
            log.error(f'[HLS] FFmpeg no pudo lanzarse: {e!r}')
            self.error_msg = f'No se pudo lanzar FFmpeg: {e}'
            self.state = 'error'
            return

        # 5. Lector de stderr en hilo aparte. Drena el pipe (si no, FFmpeg se
        # bloquea cuando llena el buffer ~64KB) y guarda el tail para
        # diagnosticar fallos.
        stderr_ring: 'collections.deque[bytes]' = collections.deque(
            maxlen=max(1, _FFMPEG_STDERR_RING_BYTES // 80)
        )
        stop_reader = threading.Event()

        def _reader():
            try:
                while not stop_reader.is_set():
                    line = proc.stderr.readline()
                    if not line:
                        break
                    stderr_ring.append(line)
            except Exception as e:
                log.debug(f'[HLS] reader thread ffmpeg: {e!r}')

        reader_thread = threading.Thread(
            target=_reader, daemon=True,
            name=f'hls-ffmpeg-reader-{self.recording_id[:8]}',
        )
        reader_thread.start()

        # 6. Loop de monitoreo: stop, abort de Kodi, espacio en disco, tamaño.
        self._update_history(recording_state='active', bytes=0)
        self._publish_progress('downloading')

        next_disk_check = time.time() + 30
        next_size_update = time.time() + 2

        while proc.poll() is None:
            if self._stop_event.is_set() or self._monitor.abortRequested():
                log.info('[HLS] FFmpeg parado por stop_event/abort')
                self._kill_ffmpeg(proc)
                self.state = 'aborted'
                break

            if (self.max_duration_mins > 0
                    and self.elapsed_s() // 60 >= self.max_duration_mins):
                # Defensa adicional: FFmpeg ya tiene `-t`, pero si la
                # sincronía falla el wall-clock corta igualmente.
                log.info(
                    f'[HLS] cap de duración alcanzado ({self.max_duration_mins} min)'
                )
                self._kill_ffmpeg(proc)
                self.state = 'completed'
                break

            now = time.time()
            if now >= next_size_update:
                next_size_update = now + 2
                try:
                    self.downloaded_bytes = os.path.getsize(self.partial_file)
                    self._update_history(bytes=self.downloaded_bytes)
                except OSError:
                    pass

            if now >= next_disk_check:
                next_disk_check = now + 30
                try:
                    free_b = shutil.disk_usage(
                        os.path.dirname(self.partial_file)
                    ).free
                    try:
                        import xbmcaddon
                        min_mb = xbmcaddon.Addon().getSettingInt(
                            'transfer.hls.min_free_space_mb'
                        ) or 500
                    except (TypeError, RuntimeError):
                        min_mb = 500
                    if free_b < min_mb * 1024 * 1024:
                        log.error('[HLS] queda poco espacio; parando FFmpeg')
                        self.error_msg = (
                            'Grabación detenida: no hay espacio en disco'
                        )
                        self.state = 'error'
                        self._kill_ffmpeg(proc)
                        break
                except OSError as e:
                    log.warning(f'[HLS] disk_usage falló: {e!r}')

            # waitForAbort sleep que respeta cierre de Kodi.
            if self._monitor.waitForAbort(0.5):
                log.info('[HLS] Kodi pide abort; parando FFmpeg')
                self._kill_ffmpeg(proc)
                self.state = 'aborted'
                break

        # 7. Finalizar lector y cerrar stderr.
        stop_reader.set()
        reader_thread.join(timeout=2.0)
        try:
            if proc.stderr:
                proc.stderr.close()
        except OSError:
            pass

        # Tamaño final del archivo (puede haber crecido tras el último tick).
        try:
            self.downloaded_bytes = os.path.getsize(self.partial_file)
        except OSError:
            pass

        # 8. Analizar returncode si el state aún es 'active' (FFmpeg salió por
        # sí mismo). Si ya pusimos aborted/error/completed dentro del loop,
        # respetamos eso.
        if self.state == 'active':
            rc = proc.returncode
            if rc == 0:
                self.state = 'completed'
            else:
                stderr_tail = b''.join(stderr_ring).decode('utf-8', errors='ignore')
                tail_short = stderr_tail.strip()[-200:].replace('\n', ' | ')
                self.error_msg = f'FFmpeg falló (código={rc}): {tail_short}'
                self.state = 'error'
                log.error(f'[HLS] {self.error_msg}')

    # Loop principal

    def run(self) -> None:
        self.is_recording = True
        self.state = 'active'
        # NO llamamos `register(self)` aquí: el caller (endpoint HTTP) ya lo
        # hizo de forma atómica con `register_if_under_limit` para no romper
        # el cap de concurrencia. Si alguien instancia y arranca el thread
        # sin registrar, list_active() no lo verá pero el thread funciona.
        self._update_history(recording_state='active', bytes=0)
        log.info(f'[HLS] grabación iniciada: {self.channel_name!r}')

        try:
            os.makedirs(os.path.dirname(self.partial_file), exist_ok=True)

            if self.compress:
                # Modo compress: FFmpeg reencode sobre la marcha. Si FFmpeg
                # no está disponible hacemos fallback a TS (mejor grabar sin
                # comprimir que no grabar nada). El usuario verá un badge
                # en el panel vía `compress_unavailable` notify.
                from lib.remote import transcode as _tc
                ffmpeg_path = _tc.find_ffmpeg()
                if ffmpeg_path:
                    self._ffmpeg_record(ffmpeg_path)
                else:
                    log.warning(
                        '[HLS] compress solicitado pero ffmpeg no está disponible; '
                        'fallback a copia TS sin reencode'
                    )
                    try:
                        from lib.remote import notify
                        notify.bump_status('hls.compress_unavailable')
                    except Exception:
                        pass
                    best_playlist_url = self._resolve_master_playlist(self.m3u8_url)
                    with open(self.partial_file, 'ab') as f_out:
                        self._record_loop(f_out, best_playlist_url)
            else:
                best_playlist_url = self._resolve_master_playlist(self.m3u8_url)
                with open(self.partial_file, 'ab') as f_out:
                    self._record_loop(f_out, best_playlist_url)

            # Rename siempre que hay bytes, sea cual sea el state final.
            # Antes solo se renombraba con `state == 'active'`, pero el loop
            # nunca sale con ese estado (se cambia a completed|aborted|error),
            # así que el archivo quedaba como `.partial` y Kodi no lo
            # reproducía desde el historial. El usuario verá `recording_state`
            # como badge para distinguir completed/aborted/error.
            if self.downloaded_bytes > 0:
                self._finalize_success()

        except Exception as e:
            self.state = 'error'
            self.error_msg = str(e)
            log.error(f'[HLS] error fatal del hilo: {e!r}')

        finally:
            self.is_recording = False
            self._cleanup_zero_bytes()
            self._publish_final_history()
            unregister(self.recording_id)
            log.info(
                f'[HLS] hilo finalizado: {self.channel_name!r} '
                f'state={self.state} bytes={self.downloaded_bytes}',
            )
            if self.callback_finish is not None:
                try:
                    self.callback_finish(self)
                except Exception as e:
                    log.warning(f'[HLS] callback_finish falló: {e!r}')

    def _record_loop(self, f_out, playlist_url: str) -> None:
        consecutive_errors = 0
        empty_cycles = 0

        while not self._stop_event.is_set():
            if self._monitor.abortRequested():
                log.info('[HLS] Kodi pide abort; parando')
                self.state = 'aborted'
                return

            if (self.max_duration_mins > 0
                    and self.elapsed_s() // 60 >= self.max_duration_mins):
                log.info(
                    f'[HLS] temporizador alcanzado '
                    f'({self.max_duration_mins} min)',
                )
                self.state = 'completed'
                return

            try:
                downloaded = self._process_playlist_once(f_out, playlist_url)
            except urllib.error.HTTPError as e:
                code = getattr(e, 'code', None)
                if code in _TERMINAL_HTTP_CODES:
                    log.info(f'[HLS] HTTP {code}: emisión terminada')
                    self.state = 'completed'
                    self.error_msg = ''
                    return
                consecutive_errors += 1
                log.warning(f'[HLS] HTTP transitorio {code}')
                self._publish_progress('reconnecting')
                if self._sleep(5):
                    self.state = 'aborted'
                    return
                continue
            except urllib.error.URLError as e:
                consecutive_errors += 1
                log.warning(
                    f'[HLS] error de red (intento {consecutive_errors}): '
                    f'{e.reason!r}',
                )
                self._publish_progress('reconnecting')
                if self._sleep(5):
                    self.state = 'aborted'
                    return
                if consecutive_errors > _TRANSIENT_ERRORS_LIMIT:
                    self.error_msg = 'Conexión perdida durante demasiado tiempo'
                    self.state = 'error'
                    return
                continue
            except OSError as e:
                if getattr(e, 'errno', None) == errno.ENOSPC:
                    log.error('[HLS] sin espacio en disco (ENOSPC)')
                    self.error_msg = (
                        'Grabación detenida: no hay espacio en disco'
                    )
                    self.state = 'error'
                    return
                consecutive_errors += 1
                log.warning(f'[HLS] OSError: {e!r}')
                if self._sleep(5):
                    self.state = 'aborted'
                    return
                if consecutive_errors > _OS_ERRORS_LIMIT:
                    self.error_msg = f'Error persistente de filesystem: {e}'
                    self.state = 'error'
                    return
                continue

            if downloaded > 0:
                consecutive_errors = 0
                empty_cycles = 0
                if self._sleep(1):
                    self.state = 'aborted'
                    return
            else:
                empty_cycles += 1
                if empty_cycles > _EMPTY_CYCLES_LIMIT:
                    log.warning('[HLS] demasiados ciclos sin datos nuevos')
                    self.error_msg = 'El canal dejó de emitir datos'
                    self.state = 'completed'
                    return
                self._publish_progress('waiting')
                if self._sleep(3):
                    self.state = 'aborted'
                    return

        # Salida del while: stop_event seteado externamente.
        if self.state == 'active':
            self.state = 'aborted'

    def _process_playlist_once(self, f_out, playlist_url: str) -> int:
        """Una pasada por el playlist. Devuelve número de chunks bajados."""
        content = self._http_get(playlist_url)
        chunks_in_cycle = 0

        for raw_line in content.splitlines():
            line = raw_line.strip()
            if not line:
                continue

            if (line.startswith('#EXT-X-KEY:METHOD=AES-128')
                    or line.startswith('#EXT-X-KEY:METHOD=SAMPLE-AES')):
                log.warning('[HLS] stream encriptado AES; abortando')
                self.error_msg = (
                    'Stream encriptado con DRM (AES). '
                    'No es grabable por copia directa.'
                )
                self.state = 'aborted'
                self._stop_event.set()
                return chunks_in_cycle

            if line.startswith('#EXT-X-ENDLIST'):
                log.info('[HLS] endlist alcanzada; VOD completo')
                self.state = 'completed'
                self._stop_event.set()
                return chunks_in_cycle

            if line.startswith('#'):
                continue

            chunk_id = line
            if chunk_id in self._dedup_set:
                continue

            if self._stop_event.is_set():
                return chunks_in_cycle

            chunk_url = urllib.parse.urljoin(playlist_url, line)
            self._publish_progress('downloading')
            chunk_data = self._http_get(chunk_url, is_binary=True)
            f_out.write(chunk_data)
            f_out.flush()
            self.downloaded_bytes += len(chunk_data)

            if len(self._dedup_queue) == _CHUNK_DEDUP_MAX:
                oldest = self._dedup_queue.popleft()
                self._dedup_set.discard(oldest)
            self._dedup_queue.append(chunk_id)
            self._dedup_set.add(chunk_id)
            chunks_in_cycle += 1

            # Actualizar bytes en el historial cada chunk; el coste es bajo
            # (escritura JSON con lock) y permite que el panel vea progreso
            # casi en tiempo real vía /remote/status (long-poll).
            self._update_history(bytes=self.downloaded_bytes)

        return chunks_in_cycle

    def _finalize_success(self) -> None:
        """Rename .partial → final si hay bytes; deja .partial si no."""
        if self.downloaded_bytes <= 0:
            log.warning('[HLS] grabación terminó con 0 bytes; no rename')
            return
        try:
            # En Windows, rename falla si existe el destino. Como
            # reserve_unique_path reservó un nombre vacío, lo borramos
            # antes de mover el .partial encima.
            if os.path.exists(self.output_file):
                os.remove(self.output_file)
            os.rename(self.partial_file, self.output_file)
            log.info(f'[HLS] renombrado: {self.output_file!r}')
        except OSError as e:
            log.warning(f'[HLS] rename falló, se conserva .partial: {e!r}')

    def _cleanup_zero_bytes(self) -> None:
        """Borra el .partial si quedó vacío (grabación que ni arrancó)."""
        try:
            if (os.path.exists(self.partial_file)
                    and os.path.getsize(self.partial_file) == 0):
                os.remove(self.partial_file)
                log.info(f'[HLS] .partial vacío eliminado: {self.partial_file!r}')
        except OSError:
            pass

    def _publish_final_history(self) -> None:
        """Actualiza la entrada del historial con el estado final."""
        # Map de state interno → recording_state público.
        public = {
            'active': 'aborted',     # raro: stopped sin pasar por record_loop
            'pending': 'aborted',
            'completed': 'completed',
            'aborted': 'aborted',
            'error': 'error',
        }.get(self.state, 'error')

        # Tras el rename de _finalize_success, output_file existe siempre
        # que hubo bytes. Si quedó solo el .partial (rename falló o no había
        # bytes), apuntamos a él como fallback.
        if os.path.exists(self.output_file):
            final_path = self.output_file
        elif os.path.exists(self.partial_file):
            final_path = self.partial_file
        else:
            final_path = self.output_file  # no existe ninguno; queda como referencia

        final_size = 0
        try:
            final_size = os.path.getsize(final_path)
        except OSError:
            pass

        self._update_history(
            recording_state=public,
            bytes=self.downloaded_bytes,
            size=final_size,
            path=final_path,
            error_msg=self.error_msg or None,
        )
