"""Scheduler de grabaciones HLS programadas.

Permite al usuario programar una grabación para una hora futura desde el
panel. El scheduler es un hilo daemon que duerme hasta el siguiente fire
y entonces invoca ``hls_start.start_recording_now`` igual que el endpoint
``/api/hls/start`` (mismas validaciones, mismo cap de concurrencia).

Persistencia: JSON en ``special://profile/.../hls_schedules.json``,
escritura atómica via tmp+rename con xbmcvfs (mismo patrón que
``history.py``). Sobrevive a restart de Kodi.

Recovery al arrancar (``recover_pending``):
- Entradas con ``start_time`` futuro → reinsertar en ``_pending``.
- Entradas dentro de la tolerancia (5 min pasadas) → fire inmediato.
- Entradas más antiguas → marcar como ``schedule_failed`` en historial
  y notificar al usuario una vez con xbmcgui.Dialog.notification.

Threading model:
- Un único hilo daemon corre el loop.
- Lock para mutaciones de ``_pending`` (add/cancel/fire-pop).
- ``_wake_event`` despierta el sleep ante add/cancel/stop.
- ``_stop_flag`` indica al loop que salga limpio.
"""
import json
import math
import threading
import time
import uuid
from typing import Dict, List, Optional, Tuple

import xbmc
import xbmcvfs

from lib import log


_PROFILE_VFS = 'special://profile/addon_data/plugin.program.loiolink/'
_SCHEDULES_VFS = _PROFILE_VFS + 'hls_schedules.json'
_SCHEDULES_TMP = _PROFILE_VFS + 'hls_schedules.json.tmp'
_SCHEMA_VERSION = 1

# Tolerancia para fire-on-late-start: si Kodi arranca poco después de la
# hora programada, intentamos grabar igual. Más allá (5 min), descartamos.
_LATE_TOLERANCE_S = 300

# Intervalo máximo entre wakeups del loop. El wake_event corta el wait
# antes si hay add/cancel/stop, así que con 30s tenemos buena precisión
# manteniendo el CPU muy bajo en idle.
_POLL_INTERVAL_S = 30

# Tolerancia entre el momento del POST y la hora futura programada.
# Menos de esto (5s) se rechaza como "no future"; evita carreras del
# usuario que pone una hora pasada por un par de segundos.
_FUTURE_TOLERANCE_S = 5

# Tope de grabaciones programadas pendientes. Defensa contra clientes
# autenticados que sembraran miles vía API. El JSON cargado en memoria
# debe quedar pequeño (~200B/entry) y el _calc_wait es O(N) por tick.
_MAX_PENDING = 100

# Horizonte máximo de programación (30 días). Más allá pierde sentido:
# el JSON puede perderse en mantenimiento del usuario y la fiabilidad
# baja con el tiempo.
_MAX_HORIZON_S = 30 * 24 * 3600


_INSTANCE_LOCK = threading.Lock()
_INSTANCE: Optional['RecordingScheduler'] = None

# Lock global para la persistencia del JSON. Add/cancel/fire pueden ocurrir
# en threads distintos (HTTP handlers vs scheduler thread) y, sin este lock,
# dos saves concurrentes podrían perderse un cambio (el último rename gana).
_PERSIST_LOCK = threading.Lock()


def set_instance(scheduler: Optional['RecordingScheduler']) -> None:
    """Registra el scheduler global. Llamar desde service.py al arrancar."""
    global _INSTANCE
    with _INSTANCE_LOCK:
        _INSTANCE = scheduler


def get_instance() -> Optional['RecordingScheduler']:
    """Devuelve el scheduler global o None si no se ha inicializado."""
    with _INSTANCE_LOCK:
        return _INSTANCE


def _bump_panel(reason: str) -> None:
    """Despierta el long-poll del panel para refresco inmediato.

    Tolerante: si notify no está cargado (tests), no propaga el error.
    """
    try:
        from lib.remote import notify
        notify.bump_status(f'hls.scheduled.{reason}')
    except Exception:
        pass


def _now() -> float:
    """Wrapper de time.time() para facilitar el mockeo en tests."""
    return time.time()


def _try_read(vfs_path: str) -> Optional[str]:
    """Lee un archivo VFS y devuelve su contenido o None si no existe/falla."""
    if not xbmcvfs.exists(vfs_path):
        return None
    try:
        f = xbmcvfs.File(vfs_path, 'r')
        try:
            return f.read()
        finally:
            f.close()
    except (OSError, ValueError) as e:
        # ValueError (UnicodeDecodeError) si el fichero tiene bytes con encoding
        # inválido: tratarlo como "no legible" para que el JSON corrupto caiga a
        # []; sin esto la excepción tumbaba el arranque del scheduler.
        log.warning(f'[scheduler] no se pudo leer {vfs_path}: {e!r}')
        return None


def _parse_schedules_blob(raw: str) -> List[Dict]:
    """Parsea el contenido JSON; devuelve [] si está corrupto o tiene
    una versión más nueva que la soportada."""
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        log.warning(f'[scheduler] JSON corrupto: {e!r}')
        return []
    if isinstance(data, dict):
        ver = data.get('version', 0)
        if ver > _SCHEMA_VERSION:
            log.warning(
                f'[scheduler] version {ver} > soportada ({_SCHEMA_VERSION}); '
                f'ignorando'
            )
            return []
        return list(data.get('schedules') or [])
    if isinstance(data, list):
        # Formato legado: lista plana.
        return data
    return []


def _load_schedules() -> List[Dict]:
    """Lee el JSON. Devuelve lista vacía si no existe o está corrupto.

    Recovery de TMP residual: si un crash dejó solo ``hls_schedules.json.tmp``
    (rename interrumpido), lo promovemos al nombre final antes de leer.
    Sin esto, los schedules persistidos se perderían en el próximo arranque.
    """
    # Recovery de TMP residual ANTES de leer el principal.
    if (not xbmcvfs.exists(_SCHEDULES_VFS)
            and xbmcvfs.exists(_SCHEDULES_TMP)):
        log.info('[scheduler] promoviendo TMP residual tras crash')
        try:
            xbmcvfs.rename(_SCHEDULES_TMP, _SCHEDULES_VFS)
        except OSError as e:
            log.warning(f'[scheduler] rename TMP→final falló: {e!r}')

    raw = _try_read(_SCHEDULES_VFS)
    if raw is None:
        return []
    return _parse_schedules_blob(raw)


def _save_schedules(schedules: List[Dict]) -> None:
    """Write atómico via tmp+rename bajo _PERSIST_LOCK.

    Sin el lock, dos `add()` concurrentes desde threads HTTP distintos
    podrían pisarse el TMP y perder una de las dos escrituras. El JSON
    es minúsculo (cap _MAX_PENDING entries), el coste del lock es nulo.
    Propaga OSError al caller para que sepa que la persistencia falló.
    """
    with _PERSIST_LOCK:
        if not xbmcvfs.exists(_PROFILE_VFS):
            xbmcvfs.mkdirs(_PROFILE_VFS)
        payload = {'version': _SCHEMA_VERSION, 'schedules': schedules}
        data = json.dumps(payload, indent=2, ensure_ascii=False).encode('utf-8')
        f = xbmcvfs.File(_SCHEDULES_TMP, 'wb')
        try:
            ok = f.write(bytearray(data))
            if ok is False:
                raise OSError('xbmcvfs.write devolvió False')
        finally:
            f.close()
        # Ventana sin archivo principal entre delete y rename: en Windows
        # xbmcvfs.rename no sobrescribe, así que debemos borrar primero.
        # Si el proceso muere aquí, `_load_schedules` detecta el TMP residual
        # y lo promueve al arrancar.
        if xbmcvfs.exists(_SCHEDULES_VFS):
            xbmcvfs.delete(_SCHEDULES_VFS)
        xbmcvfs.rename(_SCHEDULES_TMP, _SCHEDULES_VFS)


def _safe_int(raw, default: int) -> int:
    """int() defensivo: acepta None/string/float y rechaza inf/nan/overflow."""
    if raw is None:
        return default
    try:
        v = float(raw)
        if not math.isfinite(v):
            return default
        return int(v)
    except (TypeError, ValueError, OverflowError):
        return default


def _normalize_schedule(raw: Dict) -> Optional[Dict]:
    """Valida y normaliza un schedule cargado del JSON.

    Devuelve None si la entrada está malformada (campos requeridos
    ausentes, tipos equivocados, NaN/inf en start_time o start_time
    negativo). El JSON es no-confiable: el usuario puede editarlo a
    mano y un atacante con acceso al filesystem podría sembrar valores.
    """
    if not isinstance(raw, dict):
        return None
    sid = raw.get('schedule_id')
    url = raw.get('url')
    start_time = raw.get('start_time')
    if not isinstance(sid, str) or not sid:
        return None
    if not isinstance(url, str) or not url.strip():
        return None
    try:
        start_time = float(start_time)
    except (TypeError, ValueError):
        return None
    # Rechazo de NaN, ±Infinity y negativos: el resto del scheduler asume
    # comparables y finitos. `nan < x` es siempre False, así que un schedule
    # con NaN nunca expiraría ni dispararía: zombie permanente en _pending.
    if not math.isfinite(start_time) or start_time < 0:
        return None
    # CRF 0 es válido (lossless), distinto a "no proporcionado". Usamos
    # _safe_int con default 26 solo cuando el campo es None/missing.
    crf_raw = raw.get('compress_crf')
    crf = 26 if crf_raw is None else _safe_int(crf_raw, 26)
    return {
        'schedule_id': sid,
        'url': url.strip(),
        'start_time': start_time,
        'filename': str(raw.get('filename') or '') or None,
        'name': str(raw.get('name') or '') or None,
        'compress': bool(raw.get('compress', False)),
        'compress_crf': max(18, min(35, crf)),
        'quality': max(0, _safe_int(raw.get('quality'), 0)),
        'max_duration_mins': max(0, _safe_int(raw.get('max_duration_mins'), 0)),
        'created_at': float(raw.get('created_at') or _now()),
    }


def _to_start_params(schedule: Dict) -> Dict:
    """Convierte un schedule a params para ``start_recording_now``."""
    return {
        'url': schedule['url'],
        'filename': schedule.get('filename'),
        'name': schedule.get('name'),
        'compress': schedule.get('compress'),
        'compress_crf': schedule.get('compress_crf'),
        'quality': schedule.get('quality', 0),
        'max_duration_mins': schedule.get('max_duration_mins', 0),
    }


class RecordingScheduler(threading.Thread):
    """Hilo daemon que dispara grabaciones programadas.

    Uso:
        sch = RecordingScheduler()
        n_recovered, n_expired = sch.recover_pending()
        sch.start()
        ...
        sch.stop(timeout=5.0)
    """

    def __init__(self):
        super().__init__(name='hls-scheduler', daemon=True)
        self._lock = threading.Lock()
        self._pending: Dict[str, Dict] = {}
        # Set de schedule_ids que están siendo disparados ahora mismo. Lo
        # consultamos en `cancel()` para devolver al user que ya no se puede
        # cancelar (el fire ya pasó el punto de no retorno). Sin esto hay
        # una ventana entre el pop de _pending y el call a start_recording_now
        # donde cancel parecería trabajar pero la grabación arrancaría igual.
        self._firing_ids: set = set()
        self._wake = threading.Event()
        self._stop_flag = False
        self._monitor = xbmc.Monitor()
        # Notificación de fire fallido: cuando _scheduler_thread llama a
        # start_recording_now y obtiene `too_many_active` u otro error,
        # encolar una notificación para que el main thread la muestre.
        # Hacer Dialog().notification directamente desde aquí sería un
        # bug latente (kodi#15378: Dialog desde threads non-main).
        self._failure_notifications: List[str] = []
        self._notify_lock = threading.Lock()

    # API pública

    def add(self, params: Dict) -> Tuple[bool, str, Optional[Dict]]:
        """Añade una grabación programada.

        ``params`` debe incluir al menos ``url`` y ``start_time`` (epoch).
        Resto de campos opcionales con defaults seguros.

        Devuelve ``(ok, error_code, schedule_dict)``.

        Errores: 'missing_url' | 'invalid_scheme' | 'invalid_time' |
        'too_many_pending' | 'horizon_exceeded' | 'persist_failed'.
        """
        from lib.transfers import hls_start
        url = (params.get('url') or '').strip()
        ok, err = hls_start.validate_url(url)
        if not ok:
            return False, err, None

        # start_time: debe ser float finito, no NaN/inf, en el futuro.
        try:
            start_time = float(params.get('start_time') or 0)
        except (TypeError, ValueError):
            return False, 'invalid_time', None
        if not math.isfinite(start_time):
            return False, 'invalid_time', None
        now = _now()
        if start_time <= now + _FUTURE_TOLERANCE_S:
            return False, 'invalid_time', None
        # Horizonte: 30 días. Más allá pierde utilidad práctica.
        if start_time > now + _MAX_HORIZON_S:
            return False, 'horizon_exceeded', None

        # Cap de pendientes: defensa contra cliente buggy/malicioso.
        with self._lock:
            if len(self._pending) >= _MAX_PENDING:
                return False, 'too_many_pending', None

        schedule_id = uuid.uuid4().hex
        # CRF: 0 es lossless válido. Distinguir None de 0 (S-4).
        crf_param = params.get('compress_crf')
        crf = 26 if crf_param is None else _safe_int(crf_param, 26)
        crf = max(18, min(35, crf))

        schedule = {
            'schedule_id': schedule_id,
            'url': url,
            'start_time': start_time,
            'filename': (params.get('filename') or '').strip() or None,
            'name': (params.get('name') or '').strip() or None,
            'compress': bool(params.get('compress', False)),
            'compress_crf': crf,
            'quality': max(0, _safe_int(params.get('quality'), 0)),
            'max_duration_mins': max(0, _safe_int(params.get('max_duration_mins'), 0)),
            'created_at': now,
        }

        with self._lock:
            # Re-chequeo del cap bajo el lock (la primera lectura era sin lock
            # por short-path; aquí es atómico).
            if len(self._pending) >= _MAX_PENDING:
                return False, 'too_many_pending', None
            self._pending[schedule_id] = schedule
            snapshot = list(self._pending.values())
        try:
            _save_schedules(snapshot)
        except OSError as e:
            # Si la persistencia falla, revertimos: la grabación queda
            # solo en memoria hasta el próximo restart. Mejor avisar al
            # caller que mentir.
            log.error(f'[scheduler] add: persistencia falló: {e!r}')
            with self._lock:
                self._pending.pop(schedule_id, None)
            return False, 'persist_failed', None

        self._wake.set()
        _bump_panel('add')
        log.info(
            f'[scheduler] programada id={schedule_id[:8]} '
            f'start={start_time:.0f} url={url[:80]!r}'
        )
        return True, '', dict(schedule)

    def cancel(self, schedule_id: str) -> bool:
        """Cancela una grabación programada. True si existía y se canceló.

        Si la grabación ya está en proceso de fire (entró al loop de
        `_fire_due` y todavía no se completó el call a `start_recording_now`),
        devolvemos False: el cancel llegó tarde y la grabación arrancará.
        El usuario verá "ya no se puede cancelar" en el panel.
        """
        with self._lock:
            if schedule_id in self._firing_ids:
                # Carrera: el fire ya empezó. No tocamos _pending (ya no está
                # allí) ni _firing_ids (lo limpia _fire_due al terminar).
                return False
            removed = self._pending.pop(schedule_id, None) is not None
            snapshot = list(self._pending.values())
        if not removed:
            return False
        try:
            _save_schedules(snapshot)
        except OSError as e:
            log.warning(f'[scheduler] cancel: persistencia falló: {e!r}')
            # El cancel en memoria YA pasó. La persistencia inconsistente
            # solo causa que tras restart aparezca la entrada de nuevo;
            # peor que cancel-no-aplicado, así que loggeamos pero seguimos.
        self._wake.set()
        _bump_panel('cancel')
        log.info(f'[scheduler] cancelada id={schedule_id[:8]}')
        return True

    def list_pending(self) -> List[Dict]:
        """Snapshot serializable de las grabaciones programadas, ordenado
        por hora ascendente (la siguiente en disparar va primero)."""
        with self._lock:
            items = [dict(s) for s in self._pending.values()]
        items.sort(key=lambda s: s.get('start_time', 0))
        return items

    def stop(self, timeout: float = 5.0) -> None:
        """Señala stop y espera join del hilo."""
        self._stop_flag = True
        self._wake.set()
        if self.is_alive():
            self.join(timeout=timeout)

    def drain_failure_notifications(self) -> List[str]:
        """Devuelve y limpia la lista de notificaciones pendientes.

        El main thread del service la drena periódicamente y muestra
        Dialog().notification para cada una.
        """
        with self._notify_lock:
            items, self._failure_notifications = self._failure_notifications, []
        return items

    def recover_pending(self) -> Tuple[int, int]:
        """Carga el JSON al arrancar y devuelve (n_recovered, n_expired).

        - Entradas futuras → reinsertadas en _pending.
        - Entradas dentro de TOLERANCE pasadas → fire inmediato (se quedan
          en _pending para que el loop las procese al primer tick).
        - Entradas más antiguas → marcadas como schedule_failed en
          historial; NO se reinsertan.
        """
        from lib.transfers import history
        raw_list = _load_schedules()
        now = _now()
        recovered = 0
        expired = 0
        kept = []
        for raw in raw_list:
            sch = _normalize_schedule(raw)
            if sch is None:
                continue
            if sch['start_time'] < now - _LATE_TOLERANCE_S:
                expired += 1
                try:
                    history.add(
                        filepath='',
                        name=sch.get('name') or sch['url'][:80],
                        size=0,
                        kind='hls_schedule_expired',
                        source='hls',
                        action_taken='declined',
                    )
                except Exception as e:
                    log.warning(f'[scheduler] history.add expired falló: {e!r}')
                with self._notify_lock:
                    self._failure_notifications.append(
                        f'Grabación programada expirada: '
                        f'{sch.get("name") or sch["url"][:60]}'
                    )
                continue
            self._pending[sch['schedule_id']] = sch
            kept.append(sch)
            recovered += 1
        # Reescribir el JSON con la lista limpia (sin expiradas ni malformadas).
        if expired or len(kept) != len(raw_list):
            try:
                _save_schedules(kept)
            except OSError as e:
                log.warning(f'[scheduler] recover: persistencia falló: {e!r}')
        return recovered, expired

    # Internos

    def run(self) -> None:
        """Loop principal. Calcula siguiente fire, duerme, procesa."""
        log.info('[scheduler] arrancado')
        while not self._stop_flag:
            wait_s = self._calc_wait()
            # waitForAbort retorna True si Kodi quiere cerrar; corta el
            # sleep igual que _wake. Combinamos ambos:
            # - usar _wake.wait con timeout dejaría el monitor sin chequear
            # - usar waitForAbort sin _wake no respondería a add/cancel
            # Solución: chequeamos abort en un loop de waits cortos hasta
            # consumir el wait total, abortando si _wake o stop se activan.
            self._sleep_interruptible(wait_s)
            if self._stop_flag or self._monitor.abortRequested():
                break
            self._fire_due()
        log.info('[scheduler] saliendo')

    def _sleep_interruptible(self, total_s: float) -> None:
        """Sleep que respeta _wake, _stop_flag y abort de Kodi.

        Implementado como loop de chequeos cada `step` segundos en lugar
        de un único wait porque waitForAbort y Event.wait no se combinan
        bien. ``step=0.5`` da latencia razonable a stop/cancel sin quemar
        CPU.
        """
        step = 0.5
        deadline = _now() + max(0.0, total_s)
        while _now() < deadline:
            if self._stop_flag or self._monitor.abortRequested():
                return
            if self._wake.is_set():
                self._wake.clear()
                return
            remaining = min(step, deadline - _now())
            if remaining <= 0:
                return
            # Dormimos sobre _wake para wake-up inmediato si llega add/cancel.
            self._wake.wait(timeout=remaining)

    def _calc_wait(self) -> float:
        """Tiempo a esperar hasta el siguiente fire o el poll por defecto."""
        with self._lock:
            if not self._pending:
                return _POLL_INTERVAL_S
            next_due = min(s['start_time'] for s in self._pending.values())
        delta = next_due - _now()
        return max(0.0, min(_POLL_INTERVAL_S, delta))

    def _fire_due(self) -> None:
        """Saca y dispara las grabaciones cuyo start_time ya pasó.

        Distingue tres situaciones:
        - ``start_time <= now`` y dentro de _LATE_TOLERANCE_S: fire normal.
        - ``start_time < now - _LATE_TOLERANCE_S``: expirada (típico tras
          un retroceso grande del reloj o un sleep enorme del sistema);
          marcar como `schedule_failed` y notificar, sin disparar.
        - ``start_time > now``: aún no toca, no se procesa.

        Cubre C-5 (expiración en runtime, no solo en recover_pending).
        """
        from lib.transfers import history

        now = _now()
        expired_threshold = now - _LATE_TOLERANCE_S
        with self._lock:
            due_schedules = []
            expired_schedules = []
            for sid, s in list(self._pending.items()):
                st = s['start_time']
                if st < expired_threshold:
                    expired_schedules.append(self._pending.pop(sid))
                elif st <= now:
                    due_schedules.append(self._pending.pop(sid))
            # Marcar fire-in-progress ANTES de soltar el lock. Cancel los
            # ve aquí y devuelve False; sin esto habría ventana de carrera.
            for sch in due_schedules:
                self._firing_ids.add(sch['schedule_id'])
            # Orden determinista: el schedule con start_time más antiguo
            # se dispara primero (más predecible para el usuario; S-10).
            due_schedules.sort(key=lambda s: s.get('start_time', 0))
            snapshot = (list(self._pending.values())
                        if due_schedules or expired_schedules else None)

        if snapshot is not None:
            try:
                _save_schedules(snapshot)
            except OSError as e:
                log.warning(f'[scheduler] fire: persistencia falló: {e!r}')

        # Procesar expiradas: histórico + notificación + log.
        for sch in expired_schedules:
            log.warning(
                f'[scheduler] id={sch["schedule_id"][:8]} expirada '
                f'(start={sch["start_time"]:.0f} now={now:.0f})'
            )
            try:
                history.add(
                    filepath='',
                    name=sch.get('name') or sch['url'][:80],
                    size=0,
                    kind='hls_schedule_expired',
                    source='hls',
                    action_taken='declined',
                )
            except Exception as e:
                log.warning(f'[scheduler] history.add expired falló: {e!r}')
            with self._notify_lock:
                self._failure_notifications.append(
                    f'Grabación programada expirada: '
                    f'{sch.get("name") or sch["url"][:60]}'
                )
            _bump_panel('expired')

        # Procesar fires reales.
        for sch in due_schedules:
            try:
                self._fire_one(sch)
            finally:
                with self._lock:
                    self._firing_ids.discard(sch['schedule_id'])
                _bump_panel('fired')

    def _fire_one(self, schedule: Dict) -> None:
        """Dispara una grabación programada y maneja errores."""
        from lib.transfers import hls_start
        params = _to_start_params(schedule)
        sid_short = schedule['schedule_id'][:8]
        log.info(
            f'[scheduler] firing id={sid_short} url={schedule["url"][:80]!r}'
        )
        try:
            result = hls_start.start_recording_now(params, origin='scheduler')
        except Exception as e:
            # start_recording_now nunca DEBE lanzar excepción, pero por
            # robustez total capturamos. El fallo va al historial.
            log.error(f'[scheduler] start_recording_now lanzó: {e!r}')
            result = {'ok': False, 'error': 'start_failed', 'detail': str(e)}

        if result.get('ok'):
            log.info(
                f'[scheduler] id={sid_short} ok '
                f'recording_id={result.get("recording_id", "?")[:8]}'
            )
            return

        # Fallo: registrar en historial y encolar notificación.
        err = result.get('error', 'unknown')
        detail = result.get('detail') or ''
        from lib.transfers import history
        try:
            history.add(
                filepath='',
                name=schedule.get('name') or schedule['url'][:80],
                size=0,
                kind='hls_schedule_failed',
                source='hls',
                action_taken='declined',
            )
        except Exception as e:
            log.warning(f'[scheduler] history.add fail falló: {e!r}')
        msg = self._friendly_error_msg(err)
        with self._notify_lock:
            self._failure_notifications.append(
                f'Grabación programada falló: {msg}'
                + (f' ({detail[:60]})' if detail else '')
            )
        log.warning(f'[scheduler] id={sid_short} fallo: {err} {detail!r}')

    def _friendly_error_msg(self, err: str) -> str:
        """Mapea códigos de error a mensajes amables para el toast."""
        return {
            'hls_disabled': 'grabación HLS desactivada',
            'missing_url': 'URL inválida',
            'invalid_scheme': 'URL inválida',
            'dest_unavailable': 'carpeta de destino no disponible',
            'low_disk_space': 'poco espacio en disco',
            'reserve_failed': 'no se pudo reservar el archivo',
            'too_many_active': 'demasiadas grabaciones simultáneas',
            'start_failed': 'no se pudo arrancar la grabación',
        }.get(err, err)
