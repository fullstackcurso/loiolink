"""Instalador fiable de ZIPs (addons y repositorios) en Kodi.

También expone install_apk() para Fire TV / Android TV. Requiere copiar el
APK a Download/ porque scoped storage impide al installer leer
/Android/data/org.xbmc.kodi/.

Realidad de la instalación de APK desde un addon (verificado contra el
source de Kodi):
- Solo Kodi 22+ (Piers) puede lanzar el package installer: StartAndroidActivity
  convierte file:// → content:// vía FileProvider (xbmc/xbmc#26051). Ahí
  disparamos un intent VIEW y el instalador aparece.
- Kodi 21 (Omega) y anteriores NO tienen esa conversión. Pasar un file:// a
  otra app en Android 7+ (API 24) lanza FileUriExposedException: según la
  build, Kodi lo traga en silencio o se cierra de golpe. En ningún caso
  instala. Por eso en Kodi <22 NO disparamos el intent (evita el crash) y
  guiamos al usuario a instalar el APK a mano desde un gestor de archivos
  (o vía pm install si el dispositivo es root / Kodi es app de sistema).

Basado en plugin.video.atresdaily/default.py:847-1202 y
plugin.video.topzilla/espakodi_installer.py:115-400 (mis addons),
probados contra race conditions en producción.

API pública principal:
- is_ready(addon_id) / is_known(addon_id) / try_recover(addon_id)
- download_and_install_repo(url, repo_id, progress_cb, status_cb)
- install_addon_from_repo(addon_id, repo_id, status_cb)
- install_zip(zip_path, addon_id, kind)   ← para ZIPs ya descargados
- install_apk(apk_path)                  ← solo Android
- install_from_repo_zip_url(...)         ← wrapper de compatibilidad

Flujo interno:
1. Validar ZIP (PK header + tamaño + sin path traversal).
2. Extraer a special://home/addons/ con validación por entrada.
3. UpdateLocalAddons() + polling con EnableAddon en iters dispersos.
4. Cascada de enable: SetAddonEnabled JSON-RPC → UpdateLocalAddons →
   builtin EnableAddon (último recurso).
5. Si era addon dentro de un repo y InstallAddon falla, descargar ZIP del
   addon directo desde <datadir> del repo.

Bugs conocidos a tener en cuenta:
- Addons.SetAddonEnabled devuelve {"result":"OK"} INCLUSO si el addon no
  existe (kodi forum #238962; Kodi solo persiste el set de "disabled").
  Por eso siempre validamos post con xbmcaddon.Addon().
- El builtin EnableAddon(id) muestra confirm dialog en algunas builds; pero
  en Kodi 19+ con "unknown sources" activo suele ejecutar sin pedir nada.
- UpdateLocalAddons() es asíncrono; siempre polling después.
- InstallFromZip(path) NO existe como builtin; solo abre el diálogo manual.
"""
import json
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import uuid
import zipfile
from urllib.error import URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from lib import log, network_config


POLL_INTERVAL_MS = 500
REPO_POLL_TIMEOUT_S = 20
ADDON_POLL_TIMEOUT_S = 60
MAX_ZIP_SIZE_MB = 100
MAX_ADDON_ZIP_SIZE_MB = 200
MAX_APK_SIZE_MB = 500
MAX_ADDONS_XML_MB = 10

# Umbral a partir del cual mostramos un DialogProgress mientras copiamos
# el APK al directorio público. Por debajo, copia directa (atómica, sin UI)
# porque a >30 MB/s una copia <50 MB tarda <2s y el dialog ni se renderiza.
# Por encima, mostramos progreso cancelable para no congelar la UI.
_APK_PROGRESS_THRESHOLD_BYTES = 50 * 1024 * 1024
# Chunk para copia chunked: 1 MB equilibra throughput (no se gasta CPU en
# iterar) y latencia del check de cancelación (cada chunk = un check).
_APK_COPY_CHUNK_BYTES = 1024 * 1024

# Intent.FLAG_GRANT_READ_URI_PERMISSION = 1 (Android API constant).
# Crítico cuando Kodi 22+ convierte file:// a content:// vía FileProvider:
# el grantUriPermission(package, ...) interno de Kodi se llama con package=""
# (porque queremos que Android resuelva el chooser) y por tanto NO concede
# permiso a ningún paquete. Pasar el flag en el intent suple esto: cualquier
# Activity que resuelva el intent obtiene permiso de lectura del content URI.
# Referencia: docs Android, ACTION_INSTALL_PACKAGE "needs to always set
# FLAG_GRANT_READ_URI_PERMISSION". Lo mismo aplica para ACTION_VIEW con
# package-archive MIME cuando el data es content://.
_APK_INTENT_FLAGS = '1'

# Acción del intent de instalación. VIEW + MIME package-archive es el camino
# estándar; solo lo usamos en Kodi 22+, donde el FileProvider hace que resuelva
# de forma fiable.
_APK_INTENT_ACTION_VIEW = 'android.intent.action.VIEW'
# Primera versión de Kodi con conversión file:// → content:// vía FileProvider
# (xbmc/xbmc#26051, milestone Piers 22.0). Por debajo, lanzar el intent no
# instala y puede cerrar Kodi (FileUriExposedException en Android 7+).
_APK_FILEPROVIDER_MIN_MAJOR = 22

# Ajuste "Instalar apps desconocidas" (MANAGE_UNKNOWN_APP_SOURCES, Android 8+,
# API 26). El data URI con el package es opcional: sin él, Android abre la
# lista general de apps donde conceder el permiso, que es lo que queremos para la
# instalación manual, donde el permiso debe ir a la app que abre el APK
# (gestor de archivos), no a Kodi. Si la acción no existe en una build vieja,
# el sistema abre los ajustes genéricos en vez de fallar.
_SETTINGS_ACTION_UNKNOWN_SOURCES = 'android.settings.MANAGE_UNKNOWN_APP_SOURCES'
# Timeout del `pm install`: un APK grande sobre almacenamiento lento puede
# tardar; el caso de fallo por permisos retorna en <1s, así que el tope alto
# solo afecta a instalaciones reales en curso.
_PM_INSTALL_TIMEOUT_S = 180

# Carpeta pública preferida para depositar el APK antes de pasárselo al
# package installer. Scoped storage (Android 11+) impide al installer leer
# desde el sandbox privado de Kodi (/Android/data/org.xbmc.kodi/), así que
# necesitamos un destino accesible para otros UIDs.
#
# CRÍTICO sobre la cascada: en Kodi 22+ (PR xbmc/xbmc#26051) StartAndroidActivity
# convierte file:// → content:// vía FileProvider SOLO si el path empieza
# literalmente por "/storage/" (StringUtils::StartsWith en XBMCApp.cpp).
# Las variantes "/sdcard/" NO activan la conversión aunque sean simlinks
# a /storage/emulated/0/, así que las dejamos al final como último recurso.
APK_PUBLIC_DIR = '/storage/emulated/0/Download/loiolink/'
_APK_PUBLIC_DIR_CANDIDATES = (
    '/storage/emulated/0/Download/loiolink/',
    '/storage/emulated/0/Download/',
    '/storage/self/primary/Download/loiolink/',
    '/storage/self/primary/Download/',
    '/sdcard/Download/loiolink/',
    '/sdcard/Download/',
)

# Guía de instalación manual. En Kodi 21 (Omega) y anteriores es el único
# camino fiable: el APK queda en la carpeta pública y el usuario lo abre desde
# un gestor de archivos, que sí puede instalarlo (pidiendo a ESA app, no a
# Kodi, el permiso de apps desconocidas).
HINT_ANDROID_PERMISSIONS = (
    'Para instalar el APK a mano:\n'
    '1) Abre un gestor de archivos del dispositivo (en Fire TV, la app '
    '"Downloader"; en móvil, "Archivos" o "Mis archivos").\n'
    '2) Entra en la carpeta indicada y pulsa el APK.\n'
    '3) Si Android pide permiso para "instalar apps desconocidas", concédeselo '
    'a ESA app (el gestor de archivos), no a Kodi.\n\n'
    'En móvil, además: Ajustes -> Aplicaciones -> [gestor de archivos] -> '
    'Instalar apps desconocidas -> permitido.'
)

# Iteraciones del polling en las que se llama EnableAddon como empuje extra.
# Basado en topzilla/espakodi_installer.py; ayuda con repos que Kodi
# extrae deshabilitados y no se registran hasta que se fuerza el enable.
_POLL_ENABLE_AT = frozenset({4, 12, 24})


class InstallError(Exception):
    """Error semántico al instalar."""


class InstallBusyError(InstallError):
    """Otra instalación en curso. El caller decide cómo presentarlo."""


# Mutex global de instalación: serializa install_zip / install_apk a través
# de los 3 callers (file_browser, post_transfer, entry_actions). Vive en
# Window(10000) para sobrevivir entre subprocess Python que Kodi clona por
# cada invocación plugin. Stale a 90s cubre extract + REPO_POLL_TIMEOUT_S(20)
# + recover (~3s); por encima asumimos que el script se mató y reclamamos.
_INSTALL_MUTEX_PROP = 'loiolink.installer.busy'
_INSTALL_MUTEX_STALE_S = 90
_INSTALL_TOKEN = None
# Serializa acquire intra-proceso. ThreadingHTTPServer del panel web puede
# invocar install_zip en threads paralelos (handler thread A y B). Sin
# este lock, ambos pueden pasar el CAS-post-set y creer ambos tener el mutex.
_INSTALL_INTRA_LOCK = threading.Lock()


def _acquire_install_mutex():
    """Reclama el mutex. Formato 'timestamp:token_uuid' para que la
    verificación post-set distinga invocaciones del mismo segundo
    (sin token, dos invocaciones en el mismo segundo pasarían ambas)."""
    global _INSTALL_TOKEN
    win = xbmcgui.Window(10000)
    with _INSTALL_INTRA_LOCK:
        raw = win.getProperty(_INSTALL_MUTEX_PROP) or ''
        if raw:
            # Aceptamos el formato viejo "timestamp" y el nuevo "ts:token".
            ts_part = raw.split(':', 1)[0]
            try:
                held = int(ts_part)
            except (TypeError, ValueError):
                held = 0
            if time.time() - held < _INSTALL_MUTEX_STALE_S:
                return False
            log.warning(f'[installer] mutex stale ({int(time.time() - held)}s), reclamando')
        token = f'{int(time.time())}:{uuid.uuid4().hex}'
        win.setProperty(_INSTALL_MUTEX_PROP, token)
        # Spin-loop CAS-like: 3 lecturas con sleep micro entre ellas. Cierra
        # la ventana cross-process donde A.set→A.get pasa y luego B.set
        # sobrescribe y B.get también pasa (ambos creen tener el lock).
        # Mismo patrón que addon_ops_mutex._try_acquire.
        for attempt in range(3):
            if win.getProperty(_INSTALL_MUTEX_PROP) == token:
                _INSTALL_TOKEN = token
                return True
            if attempt < 2:
                xbmc.sleep(1)
        return False


_HEARTBEAT_EVERY_S = 30
_last_heartbeat = 0.0


def _heartbeat_install_mutex():
    """Renueva el token mientras la instalación sigue viva.

    `_INSTALL_MUTEX_STALE_S` no distingue "el proceso que lo tenía murió" de
    "sigue trabajando", y hay operaciones dentro del mutex que superan sus 90 s
    de sobra: la descarga del ZIP del repo con una conexión lenta, el polling
    de `_do_install_addon_from_repo` (hasta el timeout de red, 300 s por
    defecto) y la copia de un APK grande al almacenamiento público. Pasado el
    stale, otro proceso reclamaba el mutex y entraba a extraer sobre
    `addons/` en paralelo, que es justo lo que el mutex existe para impedir.

    Se llama desde los bucles largos; se estrangula por dentro, así que son
    como mucho una escritura de Window property cada `_HEARTBEAT_EVERY_S`,
    no una por chunk. Calcado de `backup.heartbeat_backup_mutex`.
    """
    global _last_heartbeat, _INSTALL_TOKEN
    now = time.time()
    if now - _last_heartbeat < _HEARTBEAT_EVERY_S:
        return
    _last_heartbeat = now

    # No-op si no somos dueños del coordinador. Cuando el installer corre
    # DENTRO de un restore de backup (install_from_xml, restore_from_manifest)
    # el dueño es este mismo proceso, y así una descarga larga tampoco deja
    # caducar el lock de arriba mientras el de aquí se mantiene fresco.
    from lib import addon_ops_mutex
    addon_ops_mutex.touch()

    with _INSTALL_INTRA_LOCK:
        if not _INSTALL_TOKEN:
            return
        win = xbmcgui.Window(10000)
        if win.getProperty(_INSTALL_MUTEX_PROP) != _INSTALL_TOKEN:
            return  # ya no es nuestro; no pisamos el token del nuevo dueño
        _, uid = _INSTALL_TOKEN.split(':', 1)
        token = f'{int(now)}:{uid}'
        win.setProperty(_INSTALL_MUTEX_PROP, token)
        _INSTALL_TOKEN = token


def _release_install_mutex():
    # Si nuestro lock superó el stale y otro proceso lo reclamó, NO debemos
    # borrar su token al hacer cleanup: nuestro release destruiría su lock
    # activo y un tercero entraría en simultáneo con él.
    global _INSTALL_TOKEN
    with _INSTALL_INTRA_LOCK:
        if not _INSTALL_TOKEN:
            return
        win = xbmcgui.Window(10000)
        if win.getProperty(_INSTALL_MUTEX_PROP) == _INSTALL_TOKEN:
            win.clearProperty(_INSTALL_MUTEX_PROP)
        else:
            log.warning(
                '[installer] release con token expirado; otro proceso adquirió '
                'el mutex tras nuestro stale. No tocamos su lock.',
            )
        _INSTALL_TOKEN = None


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


# API pública de consulta

def is_ready(addon_id):
    """True si Kodi puede construir el Addon (enabled + registrado)."""
    return _is_addon_ready(addon_id)


def is_known(addon_id):
    """True si Kodi tiene registrado el addon (aunque esté deshabilitado)."""
    resp = _jsonrpc('Addons.GetAddonDetails',
                    {'addonid': addon_id, 'properties': ['enabled']})
    return 'result' in resp and 'addon' in resp.get('result', {})


def try_recover(addon_id):
    """Intenta habilitar un addon conocido pero deshabilitado sin red.

    Útil antes de descargar: si el addon ya está instalado (aunque
    deshabilitado o sin registrar), lo reactiva. Devuelve True si quedó
    listo. Devuelve False si el addon no está en absoluto.
    """
    if is_ready(addon_id):
        return True
    if not is_known(addon_id) and not _addon_dir_present(addon_id):
        return False
    return _recover_and_enable(addon_id)


# API de instalación en dos fases

def download_and_install_repo(repo_zip_url, repo_id,
                               progress_cb=None, status_cb=None, timeout=None):
    """Descarga e instala el repo. Mutex global anti-race."""
    if not _acquire_install_mutex():
        raise InstallBusyError('Ya hay una instalación en curso')
    try:
        return _do_download_and_install_repo(
            repo_zip_url, repo_id, progress_cb, status_cb, timeout,
        )
    finally:
        _release_install_mutex()


def _do_download_and_install_repo(repo_zip_url, repo_id,
                                  progress_cb=None, status_cb=None, timeout=None):
    """Descarga el ZIP del repositorio e instala y activa el repo en Kodi.

    progress_cb(bytes_descargados, total_o_None) durante la descarga.
    status_cb(pct_0_100, msg) durante la instalación post-descarga.
    Devuelve True si el repo quedó habilitado.
    Lanza InstallError si el ZIP es inválido, trae varias carpetas raíz o
    contiene path traversal.
    Relanza InterruptedError si el usuario cancela via progress_cb.
    """
    if timeout is None:
        timeout = network_config.get_timeout('install')
    if is_ready(repo_id):
        return True

    temp_zip = os.path.join(
        xbmcvfs.translatePath('special://temp/'),
        f'{repo_id}_{uuid.uuid4().hex}.zip',
    )
    try:
        # Fase 1: descarga
        try:
            req = urllib.request.Request(repo_zip_url, headers={
                'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.1)',
            })
            with urllib.request.urlopen(req, timeout=timeout) as r:
                total = r.headers.get('Content-Length')
                total = int(total) if total and total.isdigit() else None
                # Servidor honesto pero corrompido o malicioso: descartar
                # antes de empezar si el Content-Length ya excede el límite.
                if total and total > MAX_ZIP_SIZE_MB * 1024 * 1024:
                    raise InstallError(
                        f'ZIP del repositorio demasiado grande '
                        f'({total // (1024*1024)} MB > {MAX_ZIP_SIZE_MB} MB)')
                downloaded = 0
                max_bytes = MAX_ZIP_SIZE_MB * 1024 * 1024
                with open(temp_zip, 'wb') as f:
                    while True:
                        chunk = r.read(64 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        # Defensa por si el servidor mintió en Content-Length
                        # (o no lo mandó): cortar antes de llenar el disco.
                        if downloaded > max_bytes:
                            raise InstallError(
                                f'ZIP del repositorio excede '
                                f'{MAX_ZIP_SIZE_MB} MB durante la descarga')
                        _heartbeat_install_mutex()
                        if progress_cb:
                            progress_cb(downloaded, total)
        except InterruptedError:
            raise
        except InstallError:
            raise
        except (URLError, OSError, ValueError) as e:
            raise InstallError(f'Error de red al descargar el repositorio: {e}') from e

        # Fase 2: instalación
        cleanup_orphan_backups()
        _cb(status_cb, 5, 'Validando ZIP...')
        if not _is_valid_zip(temp_zip):
            raise InstallError(f'ZIP descargado inválido: {repo_id}')

        _cb(status_cb, 12, 'Extrayendo repositorio...')
        if not _extract_zip_safely(temp_zip, expected_id=repo_id):
            raise InstallError(
                f'ZIP del repositorio rechazado: {repo_id} '
                '(motivo en el log de Kodi)')
        log.info(f'Extraído {repo_id} en special://home/addons/')

        _cb(status_cb, 28, 'Registrando en Kodi...')
        xbmc.executebuiltin('UpdateLocalAddons()')
        if not _poll_until_registered(repo_id, REPO_POLL_TIMEOUT_S):
            log.warning(f'{repo_id} no registrado en {REPO_POLL_TIMEOUT_S}s')

        _cb(status_cb, 72, 'Activando repositorio...')
        if not _recover_and_enable(repo_id):
            log.error(f'Recovery cascade falló para {repo_id}')
            return False

        _cb(status_cb, 92, 'Actualizando catálogo de addons...')
        xbmc.executebuiltin('UpdateAddonRepos()')
        xbmc.sleep(3000)

        return is_ready(repo_id)

    finally:
        try:
            os.unlink(temp_zip)
        except OSError:
            pass


def install_addon_from_repo(addon_id, repo_id=None, status_cb=None, timeout=None):
    """Instala addon_id desde un repositorio ya habilitado. Mutex global."""
    if not _acquire_install_mutex():
        raise InstallBusyError('Ya hay una instalación en curso')
    try:
        return _do_install_addon_from_repo(addon_id, repo_id, status_cb, timeout)
    finally:
        _release_install_mutex()


def _do_install_addon_from_repo(addon_id, repo_id=None, status_cb=None, timeout=None):
    """Llama InstallAddon() builtin y sondea hasta timeout. Si el addon
    no aparece, intenta try_recover y, con repo_id, fallback directo al
    ZIP del datadir del repo.
    status_cb(pct_0_100, msg) durante el sondeo.

    Nota para callers: si tienes un DialogProgress modal abierto,
    ciérralo ANTES de llamar; Kodi abre su propio modal de InstallAddon
    y apilar dos modales pierde foco en algunas skins (Estuary mod,
    Arctic Zephyr). Patrón heredado de plugin.video.atresdaily y
    plugin.video.topzilla.
    """
    if timeout is None:
        timeout = network_config.get_timeout('install')

    if is_ready(addon_id):
        return True

    # Refrescar el índice del repo ANTES de InstallAddon: si Kodi aún no
    # ha bajado addons.xml del repo, InstallAddon falla silenciosamente
    # con "addon no encontrado". Patrón comprobado en atresdaily/topzilla.
    _cb(status_cb, 2, 'Refrescando catálogo del repositorio...')
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.sleep(3000)

    xbmc.executebuiltin(f'InstallAddon({addon_id})')

    total_iters = max(int(timeout * 1000 / POLL_INTERVAL_MS), 1)
    for i in range(total_iters):
        if is_ready(addon_id):
            return True
        _heartbeat_install_mutex()
        _cb(status_cb, int(i * 90 / total_iters), 'Esperando instalación...')
        xbmc.sleep(POLL_INTERVAL_MS)

    log.warning(f'{addon_id} no instalado en {timeout}s tras InstallAddon')

    _cb(status_cb, 91, 'Comprobando estado...')
    if try_recover(addon_id):
        return True

    if repo_id:
        _cb(status_cb, 95, 'Instalación directa desde repositorio...')
        if _install_addon_zip_directly(addon_id, repo_id):
            return True

    return False


# Instalación desde ZIP ya descargado (para post_transfer, entry_actions)

def install_zip(zip_path, addon_id, kind='addon', source_repo_id=None,
                status_cb=None):
    """Instala un ZIP de addon o repositorio. Mutex global anti race."""
    if not _acquire_install_mutex():
        raise InstallBusyError('Ya hay una instalación en curso')
    try:
        return _do_install_zip(
            zip_path, addon_id, kind, source_repo_id, status_cb,
        )
    finally:
        _release_install_mutex()


def _do_install_zip(zip_path, addon_id, kind='addon', source_repo_id=None,
                    status_cb=None):
    """kind: 'addon' o 'repo'. Para 'repo', tras instalar se llama
    UpdateAddonRepos para refrescar el catálogo.
    source_repo_id: si el addon viene de un repo conocido, pasarlo aquí
    habilita el fallback _install_addon_zip_directly.
    status_cb(pct_0_100, msg): callback opcional de progreso.

    Devuelve True si quedó enabled, False si falló (con log de la causa).
    """
    cleanup_orphan_backups()
    _cb(status_cb, 5, 'Validando ZIP...')
    if not _is_valid_zip(zip_path):
        raise InstallError(f'ZIP inválido: {zip_path}')

    _cb(status_cb, 15, 'Extrayendo en addons...')
    if not _extract_zip_safely(zip_path, expected_id=addon_id):
        raise InstallError(
            f'ZIP rechazado: {os.path.basename(zip_path)} '
            '(motivo en el log de Kodi)')
    log.info(f'Extraído {addon_id} en special://home/addons/')

    _cb(status_cb, 35, 'Actualizando lista local...')
    xbmc.executebuiltin('UpdateLocalAddons()')

    _cb(status_cb, 45, 'Registrando addon...')
    if not _poll_until_registered(addon_id, REPO_POLL_TIMEOUT_S):
        log.warning(f'{addon_id} no registrado en {REPO_POLL_TIMEOUT_S}s')
        if source_repo_id:
            _cb(status_cb, 70, 'Fallback desde datadir del repo...')
            log.info(f'Fallback: descargando desde datadir de {source_repo_id}')
            if _install_addon_zip_directly(addon_id, source_repo_id):
                _cb(status_cb, 100, 'Completado')
                return True
        return False

    _cb(status_cb, 75, 'Habilitando addon...')
    if not _recover_and_enable(addon_id):
        log.error(f'Recovery cascade falló para {addon_id}')
        if source_repo_id:
            _cb(status_cb, 90, 'Fallback desde datadir...')
            return _install_addon_zip_directly(addon_id, source_repo_id)
        return False

    if kind == 'repo':
        _cb(status_cb, 92, 'Refrescando repositorios...')
        xbmc.executebuiltin('UpdateAddonRepos()')
        xbmc.sleep(1500)

    _cb(status_cb, 100, 'Completado')
    return _is_addon_ready(addon_id)


def install_apk(apk_path):
    """Lanza el installer Android. Mutex global anti race."""
    if not _acquire_install_mutex():
        raise InstallBusyError('Ya hay una instalación en curso')
    try:
        return _do_install_apk(apk_path)
    finally:
        _release_install_mutex()


def _do_install_apk(apk_path):
    """Prepara el APK en almacenamiento público y, en Kodi 22+, lanza el
    package installer nativo de Android.

    Devuelve la ruta pública donde quedó depositado el APK. Los callers la
    usan para guiar la instalación manual cuando el lanzamiento automático no
    está disponible (Kodi <22) o por si el installer no aparece.
    Lanza InstallError si la preparación falla.

    Comportamiento por versión de Kodi:
    - Kodi 22+ (Piers): StartAndroidActivity convierte file:// a content://
      vía FileProvider automáticamente para paths bajo /storage/, y otorga
      FLAG_GRANT_READ_URI_PERMISSION al installer (xbmc/xbmc#26051). Disparamos
      un intent VIEW + MIME application/vnd.android.package-archive.
    - Kodi 21 (Omega) y anteriores: NO hay conversión automática. Pasar el
      file:// a otra app en Android 7+ lanza FileUriExposedException, que según
      la build cierra Kodi de golpe (lo que reportan los usuarios) o se traga
      en silencio; nunca instala. Por eso NO disparamos el intent: dejamos el
      APK en la carpeta pública y el caller guía la instalación manual.

    Notas operativas:
    - Solo Android (Fire TV, Android TV). En otras plataformas: InstallError.
    - Resuelve un directorio público escribible (cascada de candidatos)
      porque scoped storage impide al installer leer archivos privados de
      Kodi. Prioriza paths bajo /storage/ porque /sdcard/ NO activa
      FileProvider en Kodi 22+ aunque sea simlink al primero.
    - Usa xbmcvfs.copy primero (respeta los hooks del SO en Android 11+),
      con fallback a shutil.copyfile si xbmcvfs devuelve False. Para APKs
      grandes (>50 MB) la copia se hace en thread con DialogProgress
      cancelable.
    - chmod 0o644 tras la copia para asegurar que el installer (otro UID)
      pueda leer el archivo.
    - El installer es asíncrono: StartAndroidActivity no espera al usuario.
      No podemos confirmar la instalación efectiva desde aquí.
    """
    if not is_android():
        raise InstallError(
            'La instalación de APK solo funciona en Android (Fire TV / Android TV).')

    if not os.path.isfile(apk_path):
        raise InstallError(f'APK no encontrado: {apk_path}')

    size = os.path.getsize(apk_path)
    if size > MAX_APK_SIZE_MB * 1024 * 1024:
        raise InstallError(
            f'APK demasiado grande ({size // (1024*1024)} MB > {MAX_APK_SIZE_MB} MB).')

    # APKs son ZIPs internamente: header PK. Detecta archivos renombrados
    # (HTML/JSON con extensión .apk) antes de lanzar el installer Android,
    # que solo mostraría "Hubo un problema al analizar el paquete".
    try:
        with open(apk_path, 'rb') as f:
            if f.read(2) != b'PK':
                raise InstallError('Archivo no es un APK válido (header incorrecto).')
    except OSError as e:
        raise InstallError(f'No se puede leer APK: {e}')

    public_dir = _resolve_public_dir()
    if public_dir is None:
        raise InstallError(
            'No se pudo encontrar un directorio público escribible para '
            'depositar el APK. Comprueba que Kodi tiene permiso de '
            'almacenamiento en Ajustes del dispositivo.')

    _cleanup_old_public_apks(public_dir)

    # urllib.parse.unquote: el nombre puede venir URL-encoded si el cliente
    # mandó Content-Disposition legacy (ej: "Ace.Stream%2Bfirestick.apk").
    # Re-basename tras unquote: %2F/%5C/%2E%2E decodifican a separadores;
    # sin este paso un nombre como "%2Fetc%2Ffoo.apk" produciría un path
    # absoluto que os.path.join descartaría el primer arg en POSIX,
    # escapando del directorio público.
    unquoted = urllib.parse.unquote(os.path.basename(apk_path))
    safe_name = os.path.basename(unquoted.replace('\\', '/'))
    if safe_name in ('', '.', '..'):
        safe_name = 'archivo.apk'
    if not safe_name.lower().endswith('.apk'):
        safe_name += '.apk'
    public_path = os.path.join(public_dir, safe_name)

    # Si ya existe un APK con el mismo nombre (descarga previa, otro
    # proceso, app distinta de Kodi), intentar usar el path libre. En
    # NVIDIA Shield y otros dispositivos con scoped storage estricto,
    # Kodi no puede sobrescribir archivos que no creó (Lunatixz issue
    # #273). Resolverlo aquí evita PermissionError silencioso al copiar.
    public_path = _resolve_unique_public_path(public_path)

    log.info(
        f'install_apk: src={apk_path} dst={public_path} '
        f'size={size // 1024} KB (Kodi build: {_kodi_build_version()})')
    _copy_to_public(apk_path, public_path)

    if not apk_autoinstall_supported():
        # Kodi <22: lanzar el intent file:// no instala y puede cerrar Kodi.
        # El APK queda listo en public_path para instalación manual / pm install.
        log.info(
            'install_apk: Kodi <22 sin FileProvider; no se lanza intent '
            '(evita FileUriExposedException). Instalación manual.')
        return public_path

    # URI-encode preservando "/" (paths con espacios o caracteres unicode).
    # El installer Android puede rechazar URIs con caracteres no-ASCII
    # según el receptor (PackageInstaller del sistema vs forks vendor).
    uri = 'file://' + urllib.parse.quote(public_path, safe='/')
    builtin = _build_install_apk_builtin(uri)
    log.info(f'install_apk: lanzando intent VIEW: {builtin}')
    xbmc.executebuiltin(builtin)
    return public_path


def _build_install_apk_builtin(uri):
    """Builtin StartAndroidActivity para Kodi 22+ (único caso donde lo lanzamos).

    Kodi 22+ convierte file:// a content:// vía FileProvider (xbmc#26051), así
    que un solo intent VIEW + MIME package-archive resuelve de forma fiable.
    Pasamos `flags="1"` (FLAG_GRANT_READ_URI_PERMISSION) como 5º param (válido
    desde Kodi v20, y 22 > 20) para que el PackageInstaller pueda leer el
    content URI (lo pasamos con package="" y el grantUriPermission interno no
    concedería a nadie sin el flag).
    """
    return (
        f'StartAndroidActivity("", "{_APK_INTENT_ACTION_VIEW}", '
        f'"application/vnd.android.package-archive", "{uri}", '
        f'"{_APK_INTENT_FLAGS}")'
    )


def apk_autoinstall_supported():
    """True si esta build puede lanzar el instalador de APK automáticamente.

    Solo Kodi 22+ (Piers) sobre Android: tiene la conversión file:// →
    content:// vía FileProvider. En Kodi <22 el intent no instala (y puede
    cerrar Kodi), así que los callers caen a la guía de instalación manual.
    Conservador: si no se puede parsear la versión, asumimos que NO (manual).
    """
    if not is_android():
        return False
    major = _kodi_major_version()
    return major is not None and major >= _APK_FILEPROVIDER_MIN_MAJOR


def open_unknown_sources_settings():
    """Abre los ajustes de 'apps de fuentes desconocidas' de Android.

    Atajo a la pantalla donde se concede el permiso de instalar APKs; en Fire
    TV está muy enterrada en los menús. Abrimos la lista general (sin package)
    porque en la instalación manual el permiso debe ir a la app con la que se
    abre el APK (gestor de archivos / Downloader), no a Kodi. Best-effort: si
    la acción no existe en una build vieja o un fork, el sistema abre los
    ajustes genéricos. No-op fuera de Android.
    """
    if not is_android():
        return False
    builtin = f'StartAndroidActivity("", "{_SETTINGS_ACTION_UNKNOWN_SOURCES}")'
    log.info(f'open_unknown_sources_settings: {builtin}')
    xbmc.executebuiltin(builtin)
    return True


def try_pm_install(apk_path):
    """Último recurso para cajas Android TV con Kodi de sistema o rooteadas.

    Intenta `pm install` (Kodi como app de sistema con permiso INSTALL_PACKAGES)
    y, si falla, `su -c pm install` (dispositivo rooteado). En un dispositivo
    normal ambos fallan (falta el permiso de firma o no hay `su`) y devolvemos
    False con log, sin molestar al usuario. No-op fuera de Android.

    Devuelve True solo si pm reporta 'Success'.
    """
    if not is_android():
        return False
    attempts = (
        ['pm', 'install', '-r', apk_path],
        ['su', '-c', f'pm install -r "{apk_path}"'],
    )
    for cmd in attempts:
        try:
            proc = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=_PM_INSTALL_TIMEOUT_S, check=False,
            )
        except (OSError, ValueError, subprocess.SubprocessError) as e:
            log.info(f'pm install ({cmd[0]}) no disponible: {e}')
            continue
        out = (proc.stdout or b'').decode('utf-8', errors='replace').strip()
        if proc.returncode == 0 and 'Success' in out:
            log.info(f'pm install ({cmd[0]}): éxito')
            return True
        log.info(f'pm install ({cmd[0]}) rc={proc.returncode}: {out[:200]}')
    return False


def apk_confirm_body(name):
    """Cuerpo del diálogo de confirmación de instalación de APK, adaptado a la
    versión de Kodi. Centraliza el texto para los tres callers (entry_actions,
    post_transfer, file_browser) y evita prometer que "se abrirá el instalador"
    en builds donde eso no ocurre.
    """
    if apk_autoinstall_supported():
        return (
            f'{name}\n\n'
            '¿Instalar este APK? Se abrirá el instalador de Android.\n\n'
            'Requiere activar la instalación de apps desconocidas para Kodi '
            'en los Ajustes de Android.'
        )
    return (
        f'{name}\n\n'
        '¿Preparar este APK para instalarlo?\n\n'
        'Tu versión de Kodi (21 o anterior) no puede abrir el instalador de '
        'Android directamente. Dejaremos el APK listo y te indicaremos cómo '
        'instalarlo a mano.'
    )


def apk_install_followup(public_path):
    """Diálogo accionable cuando el lanzamiento automático no está disponible
    (Kodi <22). Devuelve True si lo mostró (el caller omite su notificación
    normal), False si no aplica (Kodi 22+: el intent ya se lanzó, basta toast).

    En Kodi <22 no disparamos el intent (cerraría Kodi), así que las vías
    reales son: instalar a mano desde un gestor de archivos (fiable en cualquier
    dispositivo) o pm install (root / Kodi como app de sistema). Ofrecemos
    además el atajo a "fuentes desconocidas" porque es la fricción nº1 en Fire
    TV (la opción está muy enterrada) y la app que abra el APK la necesita.
    """
    if apk_autoinstall_supported():
        return False

    from lib.ui_select import SelectItem, info, select

    items = [
        SelectItem('Instalar a mano (cualquier dispositivo)',
                   plot='Muestra dónde quedó el APK para abrirlo desde un gestor '
                        'de archivos. Es la vía fiable en Kodi 21 y anteriores.'),
        SelectItem('Abrir ajustes de fuentes desconocidas',
                   plot='Lleva a la pantalla donde se concede el permiso de '
                        'instalar APKs. Concédeselo a la app con la que abras el '
                        'APK (gestor de archivos / Downloader).'),
        SelectItem('Instalar ahora (root / Kodi como app de sistema)',
                   plot='Instala vía pm install. Solo funciona si el dispositivo '
                        'está rooteado o Kodi es app de sistema (algunas cajas '
                        'Android TV).'),
        SelectItem('Cerrar', plot=''),
    ]
    idx = select('loiolink: instalación', items)
    if idx == 0:
        info(
            f'El APK está en:\n{public_path}\n\n' + HINT_ANDROID_PERMISSIONS,
            title='loiolink: instalación',
        )
    elif idx == 1:
        open_unknown_sources_settings()
    elif idx == 2:
        if try_pm_install(public_path):
            info('APK instalado correctamente.', title='loiolink: instalación')
        else:
            info(
                'No se pudo instalar en modo avanzado: el dispositivo no está '
                'rooteado o Kodi no es app de sistema.\n\n'
                + HINT_ANDROID_PERMISSIONS,
                title='loiolink: instalación',
            )
    return True


def _kodi_major_version():
    """Devuelve el major version de Kodi como int (e.g. 21) o None.

    Usa System.BuildVersion ("21.0 Git:..."). Devuelve None si no se puede
    parsear; en ese caso los callers deben asumir comportamiento legacy
    (sin parámetros extendidos de StartAndroidActivity).
    """
    raw = _kodi_build_version()
    if raw in (None, '?'):
        return None
    try:
        return int(raw.split('.')[0])
    except (ValueError, AttributeError):
        return None


def _kodi_build_version():
    """Devuelve System.BuildVersion (e.g. '21.0 Git:...') o '?'.

    Lo usamos solo para logging: si el install_apk falla en runtime real,
    saber la versión exacta ayuda a diagnosticar (Kodi 22+ tiene
    FileProvider; Kodi 21- no).
    """
    try:
        v = xbmc.getInfoLabel('System.BuildVersion')
        return v.split(' ')[0] if v else '?'
    except (RuntimeError, AttributeError):
        return '?'


def _resolve_public_dir():
    """Devuelve el primer dir público escribible o None.

    Itera _APK_PUBLIC_DIR_CANDIDATES: crea el dir si no existe y hace un
    write-probe para confirmar que escribir un archivo y leerlo de vuelta
    funciona (cubre scoped storage de Android 11+ y USB read-only).
    """
    for candidate in _APK_PUBLIC_DIR_CANDIDATES:
        if _try_public_dir(candidate):
            return candidate
    return None


def _try_public_dir(candidate):
    """True si candidate existe (o se crea) Y acepta una escritura real."""
    try:
        os.makedirs(candidate, exist_ok=True)
    except OSError as e:
        log.info(f'install_apk: dir {candidate} no creable ({e})')
        return False
    # Probe único por PID + ns para no colisionar con installs paralelas.
    probe = os.path.join(
        candidate, f'.loiolink_probe_{os.getpid()}_{time.monotonic_ns()}')
    try:
        with open(probe, 'wb') as f:
            f.write(b'x')
    except OSError as e:
        log.info(f'install_apk: dir {candidate} no escribible ({e})')
        return False
    finally:
        try:
            os.unlink(probe)
        except OSError:
            pass
    return True


def _copy_to_public(src, dst):
    """Copia src → dst eligiendo estrategia según tamaño.

    - Pequeño (<50 MB): _copy_direct, atómico, sin UI.
    - Grande (≥50 MB): _copy_with_progress, en thread daemon con
      DialogProgress cancelable para no bloquear el main thread.

    Tras copiar, chmod 0o644 para que el installer (UID distinto) pueda
    leer; en FAT/scoped storage el chmod puede ser no-op pero no daña.
    """
    try:
        size = os.path.getsize(src)
    except OSError:
        size = 0
    if size > _APK_PROGRESS_THRESHOLD_BYTES:
        _copy_with_progress(src, dst, size)
    else:
        _copy_direct(src, dst)
    try:
        os.chmod(dst, 0o644)
    except OSError as e:
        log.info(f'install_apk: chmod 644 sobre {dst} falló ({e}); seguimos')


def _copy_direct(src, dst):
    """Cascada atómica: xbmcvfs.copy → shutil.copyfile.

    xbmcvfs.copy respeta los hooks del SO (scoped storage Android 11+);
    shutil.copyfile es fallback puro Python por si xbmcvfs falla en una
    build concreta de Kodi.
    """
    try:
        ok = xbmcvfs.copy(src, dst)
    except (RuntimeError, OSError) as e:
        log.warning(f'install_apk: xbmcvfs.copy lanzó {e}, intentando shutil')
        ok = False
    if not ok:
        try:
            shutil.copyfile(src, dst)
        except OSError as e:
            raise InstallError(
                f'No se puede copiar APK a {dst}: {e}. '
                f'Verifica que Kodi tiene permiso de almacenamiento.') from e


def _copy_with_progress(src, dst, size):
    """Copia en thread daemon con DialogProgress cancelable.

    El main thread no puede bloquearse 20-30s copiando un APK grande:
    Kodi congela la UI, los IR del mando se acumulan y al volver el
    usuario ve respuestas en cascada. Solución: copia chunked en thread,
    main thread refresca el dialog cada 200ms y comprueba cancelación.

    Si el usuario cancela, abort_flag.set() hace que el thread pare y
    borre el archivo parcial; lanzamos InstallError.
    Si la copia falla con OSError dentro del thread, lo capturamos en
    error_holder y lo re-lanzamos como InstallError en el main thread.
    """
    abort_flag = threading.Event()
    error_holder = [None]

    def worker():
        try:
            _chunked_copy(src, dst, abort_flag)
        except InterruptedError:
            _unlink_quiet(dst)
        except Exception as e:
            # Catch ancho justificado (CLAUDE.md sec. 5.2): thread daemon,
            # cualquier excepción no propagada al main thread haría que
            # _copy_with_progress retornara como si todo hubiera ido bien y
            # luego lanzaríamos StartAndroidActivity sobre un archivo
            # corrupto. xbmcvfs.File.write puede lanzar RuntimeError además
            # de OSError. Guardamos el error y limpiamos el parcial.
            error_holder[0] = e
            _unlink_quiet(dst)
            log.error(f'install_apk: copia chunked falló en thread: {e}')

    t = threading.Thread(
        target=worker, name='loiolink-apk-copy', daemon=True,
    )
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Preparando instalación de APK...')
    t.start()
    try:
        size_mb = max(1, size // (1024 * 1024))
        while t.is_alive():
            if progress.iscanceled():
                abort_flag.set()
                break
            _heartbeat_install_mutex()
            try:
                done = os.path.getsize(dst)
            except OSError:
                done = 0
            pct = min(99, int(done * 100 / size))
            progress.update(
                pct,
                f'Copiando APK al almacenamiento público...\n'
                f'{done // (1024 * 1024)} MB / {size_mb} MB',
            )
            xbmc.sleep(200)
        # Si el usuario canceló, esperar un poco a que el thread vea el
        # flag y limpie. Sin timeout el join podría colgar si write se
        # quedó atascado en disco lento.
        t.join(timeout=5)
    finally:
        progress.close()

    if abort_flag.is_set():
        raise InstallError('Instalación de APK cancelada por el usuario.')
    if error_holder[0] is not None:
        raise InstallError(
            f'No se puede copiar APK a {dst}: {error_holder[0]}. '
            f'Verifica que Kodi tiene permiso de almacenamiento.'
        ) from error_holder[0]


def _chunked_copy(src, dst, abort_flag):
    """Copia src → dst en chunks de 1 MB, comprobando abort_flag entre cada.

    Usa xbmcvfs.File('wb') para el destino (respeta scoped storage en
    Android 11+); si abrir con xbmcvfs falla, fallback a open() puro
    Python para que en escritorio (Windows/Linux de test) la copia siga
    funcionando.

    Lanza InterruptedError si abort_flag se setea.
    Lanza OSError si IO falla.
    """
    vfs_out = None
    try:
        vfs_out = xbmcvfs.File(dst, 'wb')
        use_vfs = True
    except (RuntimeError, OSError, AttributeError):
        use_vfs = False

    try:
        with open(src, 'rb') as inp:
            if use_vfs:
                while True:
                    if abort_flag.is_set():
                        raise InterruptedError()
                    buf = inp.read(_APK_COPY_CHUNK_BYTES)
                    if not buf:
                        break
                    ok = vfs_out.write(bytearray(buf))
                    if ok is False:
                        raise OSError('xbmcvfs.File.write devolvió False')
            else:
                with open(dst, 'wb') as out:
                    while True:
                        if abort_flag.is_set():
                            raise InterruptedError()
                        buf = inp.read(_APK_COPY_CHUNK_BYTES)
                        if not buf:
                            break
                        out.write(buf)
    finally:
        if vfs_out is not None:
            try:
                vfs_out.close()
            except (OSError, RuntimeError):
                pass


def _unlink_quiet(path):
    try:
        os.unlink(path)
    except OSError:
        pass


def _resolve_unique_public_path(dst):
    """Si dst ya existe, intenta borrarlo; si no se puede, devuelve un path
    libre con sufijo numérico.

    Bug del Lunatixz issue #273: en NVIDIA Shield (y Android 10+ con scoped
    storage estricto) Kodi no puede sobrescribir archivos que no creó él
    mismo. Sin esta resolución, _copy_to_public lanza PermissionError
    silencioso si una descarga previa (o de otra app) tiene el mismo nombre.

    Estrategia: si dst no existe, devolverlo tal cual. Si existe e
    intentamos borrarlo y falla, generar `name-1.apk`, `name-2.apk`, etc.
    hasta encontrar uno libre.
    """
    if not os.path.exists(dst):
        return dst
    try:
        os.unlink(dst)
        return dst
    except OSError as e:
        log.info(
            f'install_apk: no se pudo borrar APK preexistente {dst} '
            f'({e}); usando nombre alternativo')
    base, ext = os.path.splitext(dst)
    n = 1
    while True:
        candidate = f'{base}-{n}{ext}'
        if not os.path.exists(candidate):
            return candidate
        n += 1
        if n > 999:
            # Defensa contra dirs saturados: a este punto el cleanup horario
            # claramente no funciona y mejor fallar con mensaje útil que
            # bucle infinito.
            raise InstallError(
                f'Demasiados APKs en {os.path.dirname(dst)}; '
                f'limpia el directorio manualmente.')


def _cleanup_old_public_apks(public_dir=None, max_age_s=600):
    """Borra APKs antiguos del dir público para no acumular GBs.

    El package installer suele leer el APK en segundos. Tras 10 minutos
    es seguro asumir que el usuario completó o canceló y el archivo ya
    no se necesita; este timeout corto evita acumular APKs tras intents
    fallidos (StartAndroidActivity es fire-and-forget). Mejor esfuerzo:
    errores de IO se ignoran para no abortar la instalación nueva por
    un cleanup que falla.

    public_dir: si None, usa APK_PUBLIC_DIR (compat con código previo).
    """
    if public_dir is None:
        public_dir = APK_PUBLIC_DIR
    if not os.path.isdir(public_dir):
        return
    cutoff = time.time() - max_age_s
    try:
        names = os.listdir(public_dir)
    except OSError:
        return
    for name in names:
        if not name.lower().endswith('.apk'):
            continue
        path = os.path.join(public_dir, name)
        try:
            if os.path.getmtime(path) < cutoff:
                os.unlink(path)
        except OSError:
            pass


# Wrapper de compatibilidad (callers que no necesitan split de fases)

def install_from_repo_zip_url(repo_zip_url, repo_id, addon_id,
                               progress_cb=None, status_cb=None, timeout=None):
    """Wrapper: download_and_install_repo + install_addon_from_repo en un paso.

    Callers que no necesitan controlar el diálogo entre fases (diagnostics,
    file_browser) pueden seguir usando esta función sin cambios.

    Adquiere el mutex UNA vez para todo el flujo (descarga + install addon)
    para evitar que otra invocación se cuele entre las dos fases.
    """
    if not _acquire_install_mutex():
        raise InstallBusyError('Ya hay una instalación en curso')
    try:
        ok = _do_download_and_install_repo(
            repo_zip_url, repo_id,
            progress_cb=progress_cb, status_cb=status_cb, timeout=timeout,
        )
        if not ok:
            return False
        return _do_install_addon_from_repo(
            addon_id, repo_id=repo_id, status_cb=status_cb, timeout=timeout,
        )
    finally:
        _release_install_mutex()


# Privados

def _cb(cb, pct, msg):
    if cb:
        cb(pct, msg)


def _try_rename(src, dst, attempts=5, base_delay_ms=50):
    """Retry exponencial: en Windows, Kodi puede tener handles abiertos
    al directorio brevemente (UpdateLocalAddons() escaneando), y rename
    falla con OSError(WinError 32). Retry corto resuelve la mayoría.
    Devuelve True si lo logró, False si agotó intentos."""
    delay = base_delay_ms / 1000.0
    last_err = None
    for i in range(attempts):
        try:
            os.rename(src, dst)
            return True
        except OSError as e:
            last_err = e
            if i < attempts - 1:
                time.sleep(delay)
                delay *= 2
    log.warning(f'[installer] rename {src} -> {dst} falló tras {attempts} intentos: {last_err}')
    return False


_BACKUP_NAME_RE = re.compile(r'\.bak_(\d+)$')

# Un `.bak_` más joven que esto puede ser el rollback de una operación EN
# CURSO, no un huérfano. Ver `cleanup_orphan_backups`.
_BACKUP_MIN_AGE_S = 3600


def backup_dir_suffix():
    """Sufijo `.bak_<ns>` con reloj de PARED, no monotónico.

    Antes se usaba `time.monotonic_ns()`, que cuenta desde un origen
    arbitrario por proceso: no se puede comparar con `time.time()`, así que
    no había forma de saber la edad de un `.bak_`. Y el mtime tampoco sirve,
    porque el directorio llega ahí por un `rename` y conserva la fecha
    original del addon, que puede ser de hace meses.
    """
    return f'.bak_{time.time_ns()}'


def cleanup_orphan_backups():
    """Borra carpetas `*.bak_<ns>` huérfanas de addons/ y de addon_data/.

    Si Kodi mata el script Python entre el rename del backup y la limpieza
    final, el `.bak_` queda en disco. Barrer al inicio de cada operación evita
    que se acumulen. Regex anclado al sufijo: no borra addons reales cuyo
    nombre incluya '.bak_' en medio. Mejor esfuerzo: errores se ignoran.

    Solo se borra lo que lleve más de `_BACKUP_MIN_AGE_S` parado. El
    installer y el backup tienen mutexes SEPARADOS, así que una instalación
    puede correr a la vez que un restore. Un barrido sin edad mínima borraría
    el `.bak_` que el restore acaba de apartar, que es la ÚNICA copia de los
    datos del usuario mientras dura la extracción: si luego el restore falla,
    el rollback no encuentra nada que devolver. Misma cautela que
    `backup._cleanup_orphan_tmp`, y por el mismo motivo.

    Los `.bak_` antiguos con sufijo monotónico quedan como muy viejos y se
    barren, que es justo lo que queremos con ellos.
    """
    dirs = (
        xbmcvfs.translatePath('special://home/addons/'),
        xbmcvfs.translatePath('special://profile/addon_data/'),
    )
    cutoff_ns = (time.time() - _BACKUP_MIN_AGE_S) * 1_000_000_000
    for base in dirs:
        try:
            entries = os.listdir(base)
        except OSError:
            continue
        for name in entries:
            m = _BACKUP_NAME_RE.search(name)
            if not m:
                continue
            if int(m.group(1)) > cutoff_ns:
                continue  # demasiado reciente: puede ser una op en curso
            full = os.path.join(base, name)
            try:
                shutil.rmtree(full, ignore_errors=True)
                log.info(f'[installer] cleanup huérfano: {name}')
            except OSError as e:
                log.warning(f'[installer] no se pudo borrar {name}: {e}')


def _is_valid_zip(path):
    if not os.path.isfile(path):
        return False
    # MAX_ADDON_ZIP_SIZE_MB (200) en lugar de MAX_ZIP_SIZE_MB (100): los
    # 100 MB son límite del flujo de descarga remota; los ZIPs locales
    # legítimos (skins con assets, video addons) llegan a ~150 MB.
    if os.path.getsize(path) > MAX_ADDON_ZIP_SIZE_MB * 1024 * 1024:
        return False
    try:
        with open(path, 'rb') as f:
            return f.read(2) == b'PK'
    except OSError:
        return False


# Basura que los SO cuelan en los ZIP. No es código y no debe extraerse:
# `__MACOSX/` son los AppleDouble que macOS añade al comprimir una carpeta.
# Ignorarla (en vez de rechazar el ZIP) permite instalar un addon legítimo
# comprimido en un Mac, que antes fallaba.
_ZIP_JUNK_DIRS = frozenset({'__macosx'})
_ZIP_JUNK_FILES = frozenset({'.ds_store', 'thumbs.db', 'desktop.ini'})


def _is_zip_junk(name):
    parts = name.split('/')
    return (parts[0].lower() in _ZIP_JUNK_DIRS
            or parts[-1].lower() in _ZIP_JUNK_FILES)


def _zip_addon_root(zf):
    """Carpeta raíz única del ZIP, o OSError si el ZIP no sirve.

    Kodi exige que cada addon viva en su propia carpeta, y un ZIP de addon
    trae exactamente una. Esto NUNCA se comprobaba: se deducía la raíz del
    primer entry pero se extraían todos, así que un ZIP con una segunda
    carpeta (los "todo en uno" que empaquetan repo + addon juntos)
    sobrescribía otro addon ya instalado sin backup ni rollback, y la
    instalación reportaba éxito.
    """
    roots = set()
    # Normalizado: el resto del módulo ya asume que un ZIP puede traer `\` en
    # vez de `/` (los escribe alguna herramienta de Windows), así que la
    # comprobación del addon.xml tiene que mirar los nombres normalizados o
    # rechazaría un ZIP perfectamente válido.
    names = set()
    for info in zf.infolist():
        name = info.filename.replace('\\', '/')
        names.add(name)
        if _is_zip_junk(name):
            continue
        if '/' not in name:
            # Un addon suelto en la raíz ensuciaría addons_dir y Kodi no
            # lo cargaría.
            log.security(f'ZIP con entry en raíz (sin carpeta): {name!r}')
            raise OSError(f'ZIP mal formado: entry en raíz {name!r}')
        first = name.split('/', 1)[0]
        if first:
            roots.add(first)

    if not roots:
        raise OSError('ZIP sin carpeta de addon')
    if len(roots) > 1:
        log.security(f'ZIP con varias carpetas raíz: {sorted(roots)}')
        raise OSError(
            'ZIP con varias carpetas raíz '
            f'({", ".join(sorted(roots))}); se instala un addon por ZIP',
        )

    root = roots.pop()
    if f'{root}/addon.xml' not in names:
        raise OSError(f'ZIP sin {root}/addon.xml')
    return root


def _extract_zip_safely(zip_path, expected_id=None):
    """Extrae el ZIP a special://home/addons/ rechazando paths sospechosos.

    Bug clásico: sin os.sep al final del prefijo, "addons_evil/" pasaría como
    válido al comparar con "addons". Usamos `realpath == base or
    startswith(base + sep)` para cubrir ambos casos.

    Rollback: si una extracción previa había dejado <addon_id>/ con una
    versión funcional, hacer rename atómico a backup ANTES de extraer.
    Si la nueva extracción falla a media, restauramos el backup; si
    completa, lo borramos.

    expected_id: si se proporciona y la carpeta raíz del ZIP no coincide
    (releases GitHub con tag prefix tipo "addon-v1.2.3/"), renombramos
    al id real tras extraer para que Kodi reconozca el addon.
    """
    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    addons_dir_real = os.path.realpath(addons_dir)
    safe_prefix = addons_dir_real + os.sep

    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            root = _zip_addon_root(zf)

            # target = carpeta donde quedará el addon. Si expected_id se
            # pasó y difiere del root del ZIP, target es expected_id (el
            # rename ocurre al final). Backup va sobre target (la final).
            final_id = expected_id if expected_id else root
            # Validación anti path-traversal: ni el root del ZIP ni
            # expected_id pueden contener separadores o `..`. Si lo hacen
            # (ZIP malicioso o id corrupto), el os.path.join escaparía
            # de addons_dir_real.
            for candidate in (root, final_id):
                if candidate and (
                    '/' in candidate or '\\' in candidate
                    or candidate in ('.', '..')
                ):
                    log.security(f'id sospechoso rechazado: {candidate!r}')
                    raise OSError(f'id no válido: {candidate!r}')
            target = os.path.join(addons_dir_real, final_id) if final_id else None
            extracted_path = os.path.join(addons_dir_real, root) if root else None
            backup = None
            if target and os.path.isdir(target):
                candidate = f'{target}{backup_dir_suffix()}'
                if _try_rename(target, candidate):
                    backup = candidate
                else:
                    # Sin backup no podemos rollback: si la extracción falla
                    # luego, el except borraría `target` sin poder restaurar
                    # (rmtree de líneas 1096-1097 + backup=None salta el
                    # rename de restauración). Abortar antes de tocar nada.
                    log.error(
                        f'[installer] no se pudo respaldar {target} '
                        '(archivos en uso); abortando para no destruir '
                        'la instalación existente',
                    )
                    raise OSError(
                        f'No se pudo respaldar el addon preexistente: {target}',
                    )

            try:
                for info in zf.infolist():
                    if _is_zip_junk(info.filename.replace('\\', '/')):
                        continue
                    # Whitelist de tipos. zipfile.extract crearía symlinks,
                    # device files o FIFOs si el ZIP los declara; vector
                    # de ataque para escapar de addons_dir o exponer dispositivos.
                    # Aceptamos regular files (S_IFREG), directorios
                    # (S_IFDIR) y entries con mode=0 (ZIPs Windows sin
                    # metadata Unix).
                    mode = (info.external_attr >> 16) & 0o170000
                    if mode not in (0, 0o100000, 0o040000):
                        log.security(
                            f'ZIP entry con tipo no-regular rechazada: '
                            f'{info.filename} (mode={oct(mode)})',
                        )
                        raise OSError(f'entry no-regular: {info.filename}')

                    resolved = os.path.realpath(os.path.join(addons_dir, info.filename))
                    if not (resolved == addons_dir_real
                            or resolved.startswith(safe_prefix)):
                        log.security(f'ZIP entry sospechosa: {info.filename}')
                        raise OSError(f'path traversal: {info.filename}')
                    # Extraer entry por entry tras validar. Si dejamos
                    # extractall post-validate, el encoding interno de
                    # zipfile puede divergir entre namelist() y extract.
                    zf.extract(info, addons_dir)
                    _heartbeat_install_mutex()
                    # Defensa en profundidad: aceptamos mode=0 (ZIPs
                    # Windows sin metadata) pero NO confiamos en que el
                    # contenido sea regular file. Tras extraer chequeamos
                    # que zipfile no haya materializado un symlink (Python
                    # 3.12+ honra symlinks declarados aunque mode==0 en
                    # external_attr) que escape de addons_dir.
                    if mode == 0:
                        extracted = os.path.join(addons_dir, info.filename)
                        if os.path.islink(extracted):
                            log.security(
                                f'ZIP entry materializó symlink: {info.filename}',
                            )
                            raise OSError(f'symlink no permitido: {info.filename}')

                # Si la carpeta extraída no coincide con el id esperado
                # (caso "addon-v1.2.3/" vs "addon"), renombrar para que
                # Kodi reconozca el addon.
                if (extracted_path and target
                        and extracted_path != target
                        and os.path.isdir(extracted_path)):
                    if not _try_rename(extracted_path, target):
                        raise OSError(
                            f'No se pudo renombrar {root} a {final_id}')

                if backup:
                    shutil.rmtree(backup, ignore_errors=True)
                return True
            except Exception:
                # Rollback: limpiar lo que quedó a medias y restaurar backup.
                if extracted_path and os.path.isdir(extracted_path):
                    shutil.rmtree(extracted_path, ignore_errors=True)
                if target and target != extracted_path and os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)
                if backup:
                    if not _try_rename(backup, target):
                        log.error(f'Rollback falló al restaurar {target}; '
                                  f'backup queda en {backup}')
                raise

    except (zipfile.BadZipFile, OSError) as e:
        log.error(f'Error extrayendo ZIP: {e}')
        return False


def _poll_until_registered(addon_id, timeout_s):
    """Espera a que JSON-RPC reconozca el addon (aunque sea disabled).

    Llama EnableAddon en iters dispersas para ayudar con repos que Kodi
    extrae deshabilitados y no registra sin un empuje explícito.
    """
    deadline = time.time() + timeout_s
    i = 0
    while time.time() < deadline:
        resp = _jsonrpc('Addons.GetAddonDetails',
                        {'addonid': addon_id, 'properties': ['enabled']})
        if 'result' in resp and 'addon' in resp.get('result', {}):
            return True
        if i in _POLL_ENABLE_AT:
            xbmc.executebuiltin(f'EnableAddon({addon_id})')
        xbmc.sleep(POLL_INTERVAL_MS)
        i += 1
    return False


def _recover_and_enable(addon_id):
    """Cascada de recovery (basada en topzilla/espakodi_installer.py).

    1. SetAddonEnabled JSON-RPC + xbmcaddon.Addon() check.
    2. UpdateLocalAddons() + SetAddonEnabled.
    3. EnableAddon builtin (último recurso; puede mostrar confirm en algunas
       builds, pero a veces es lo único que funciona).
    """
    if _set_enabled_jsonrpc(addon_id):
        xbmc.sleep(800)
        if _is_addon_ready(addon_id):
            return True

    if not _addon_dir_present(addon_id):
        return False
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1500)
    if _set_enabled_jsonrpc(addon_id):
        xbmc.sleep(800)
        if _is_addon_ready(addon_id):
            return True

    xbmc.executebuiltin(f'EnableAddon({addon_id})')
    xbmc.sleep(1500)
    return _is_addon_ready(addon_id)


def _set_enabled_jsonrpc(addon_id):
    resp = _jsonrpc('Addons.SetAddonEnabled',
                    {'addonid': addon_id, 'enabled': True})
    return resp.get('result') == 'OK'


def _addon_dir_present(addon_id):
    return xbmcvfs.exists(f'special://home/addons/{addon_id}/addon.xml')


# Cache de _is_addon_ready: solo cachea True. Justificación: el flow de
# cast hace varios lookups consecutivos (YouTube → Piped → Tubed →
# SendToKodi); cachear los True evita martillear a `xbmcaddon.Addon()`
# entre casts del mismo addon. El False NO se cachea porque es estado
# transitorio durante instalaciones: los polling loops de
# `_recover_and_enable` (~5 s), `_do_install_addon_from_repo` (~60 s) y
# `_install_addon_zip_directly` (~10 s) llaman a is_ready varias veces
# esperando una transición False → True; cachear False enmascararía esa
# transición durante 30 s y los polling loops nunca verían el addon listo.
_READY_CACHE_TTL_S = 30.0
_ready_cache: dict = {}  # addon_id -> expires_at (float)
_ready_cache_lock = threading.Lock()


def _is_addon_ready(addon_id):
    """¿Kodi construye el Addon? Detecta enabled+registered.

    Cachea solo el True (estado estable). Ver comentario del módulo.
    """
    now = time.time()
    with _ready_cache_lock:
        expires_at = _ready_cache.get(addon_id, 0.0)
        if expires_at > now:
            return True
    try:
        xbmcaddon.Addon(addon_id)
        ready = True
    except RuntimeError:
        ready = False
    if ready:
        with _ready_cache_lock:
            _ready_cache[addon_id] = now + _READY_CACHE_TTL_S
    return ready


def _invalidate_ready_cache():
    """Limpia el cache de `_is_addon_ready`. Para tests."""
    with _ready_cache_lock:
        _ready_cache.clear()


def _install_addon_zip_directly(addon_id, repo_id):
    """Fallback: descarga el ZIP del addon directo desde <datadir> del repo.

    Cuando InstallAddon falla o el polling expira, descarga el ZIP del addon
    directamente desde <datadir>/<addon_id>/<addon_id>-<version>.zip del repo
    instalado y lo extrae. Bypassa la restricción 'Unknown sources' de Kodi.
    """
    datadir = _get_repo_datadir(repo_id)
    if not datadir:
        log.warning(f'No se pudo leer datadir de {repo_id}')
        return False

    try:
        with urllib.request.urlopen(
            datadir + 'addons.xml', timeout=network_config.get_timeout('install'),
        ) as r:
            raw = r.read(MAX_ADDONS_XML_MB * 1024 * 1024 + 1)
    except (URLError, OSError, ValueError) as e:
        log.warning(f'No se pudo leer addons.xml de {repo_id}: {e}')
        return False

    if len(raw) > MAX_ADDONS_XML_MB * 1024 * 1024:
        log.warning(f'addons.xml de {repo_id} demasiado grande')
        return False
    addons_xml = raw.decode('utf-8', errors='replace')

    version = _find_addon_version_in_index(addons_xml, addon_id)
    if not version:
        log.warning(f'{addon_id} no aparece en addons.xml de {repo_id}')
        return False

    addon_zip_url = f'{datadir}{addon_id}/{addon_id}-{version}.zip'
    temp_zip = os.path.join(
        xbmcvfs.translatePath('special://temp/'),
        f'{addon_id}-{version}_{uuid.uuid4().hex}.zip',
    )
    try:
        try:
            with urllib.request.urlopen(
                addon_zip_url, timeout=network_config.get_timeout('install'),
            ) as r:
                downloaded = 0
                with open(temp_zip, 'wb') as f:
                    while True:
                        chunk = r.read(64 * 1024)
                        if not chunk:
                            break
                        downloaded += len(chunk)
                        if downloaded > MAX_ADDON_ZIP_SIZE_MB * 1024 * 1024:
                            log.warning(f'Addon ZIP demasiado grande: {addon_id}')
                            return False
                        f.write(chunk)
                        _heartbeat_install_mutex()
        except (URLError, OSError, ValueError) as e:
            log.warning(f'Descarga del addon ZIP falló: {e}')
            return False

        if not _is_valid_zip(temp_zip):
            log.warning(f'Addon ZIP corrupto o inválido: {addon_id}')
            return False

        if not _extract_zip_safely(temp_zip, expected_id=addon_id):
            return False
    finally:
        try:
            os.unlink(temp_zip)
        except OSError:
            pass

    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1500)
    for _ in range(20):
        if _is_addon_ready(addon_id):
            return True
        _heartbeat_install_mutex()
        xbmc.executebuiltin(f'EnableAddon({addon_id})')
        xbmc.sleep(POLL_INTERVAL_MS)
    return _recover_and_enable(addon_id)


def _get_repo_datadir(repo_id):
    """Extrae la URL del <datadir> del addon.xml del repo instalado."""
    repo_xml = xbmcvfs.translatePath(f'special://home/addons/{repo_id}/addon.xml')
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, 'r', encoding='utf-8') as f:
            content = f.read()
    except OSError:
        return None
    m = re.search(r'<datadir[^>]*>\s*([^<\s]+)\s*</datadir>', content)
    if not m:
        return None
    url = m.group(1).strip()
    return url if url.endswith('/') else url + '/'


def _find_addon_version_in_index(addons_xml_text, addon_id):
    """Versión declarada de addon_id en el addons.xml del repo."""
    escaped = re.escape(addon_id)
    for pattern in (
        rf'<addon[^>]*\bid="{escaped}"[^>]*\bversion="([^"]+)"',
        rf'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="{escaped}"',
    ):
        m = re.search(pattern, addons_xml_text)
        if m:
            return m.group(1)
    return None


def _jsonrpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        req['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except (ValueError, RuntimeError) as e:
        log.warning(f'_jsonrpc({method}) falló: {e}')
        return {}
