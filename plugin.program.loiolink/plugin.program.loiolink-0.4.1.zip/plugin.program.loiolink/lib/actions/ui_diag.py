# -*- coding: utf-8 -*-
"""Diagnóstico de las ventanas custom (WindowDialog) de loiolink.

Las ventanas de ui_select/qr_dialog se dibujan a mano sobre la rejilla
1280x720 que Kodi escala a pantalla completa. A veces el contenido se sale
del panel "por un lado". Este diagnóstico ayuda a aislar la causa:

1. Dibuja el borde de la rejilla (1280x720) en rojo y el del panel en verde.
   Si el rojo no llega a los bordes de la pantalla, la rejilla NO se está
   escalando a full-screen en este skin/dispositivo (causa de tamaño).
2. Sondea las fuentes del skin (font12/font14/font20) en cajas de la altura
   que ui_select asume. Si el texto sobresale de su caja, las fuentes del
   skin son más altas de lo previsto (causa de desbordamiento vertical).
3. Abre el ui_select REAL con etiquetas y plots largos para reproducir el
   desbordamiento horizontal sobre el código de producción.

Todo se vuelca también al log de Kodi con prefijo [loiolink] para copiarlo.
"""
import xbmc
import xbmcaddon
import xbmcgui

from lib import log

_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MEDIA = _ADDON_PATH + '/resources/media/'
_WHITE = _MEDIA + 'white.png'

# Misma rejilla base que ui_select/qr_dialog.
_W, _H = 1280, 720

# Fuentes que usa ui_select y la altura de caja que asume para cada una.
# (row=ROW_H, title=title_h, hint=hint_h en _build_header/_build_footer.)
_FONT_PROBES = (
    ('font12', 22, 'hint/footer'),
    ('font13', 30, 'genérica'),
    ('font14', 64, 'filas/plot'),
    ('font16', 40, 'qr body'),
    ('font20', 30, 'título'),
)

_SAMPLE = 'ÁÉÍ jpqg ÑÜ 1234 áéíóú prueba'

_CLOSE_ACTIONS = {
    xbmcgui.ACTION_PREVIOUS_MENU,
    xbmcgui.ACTION_NAV_BACK,
    xbmcgui.ACTION_STOP,
    xbmcgui.ACTION_SELECT_ITEM,
}

_XBFONT_CENTER_Y = 0x00000004


def _collect_env():
    """Recopila resolución, skin y versión. Devuelve lista de líneas."""
    lines = []

    def infolabel(name):
        try:
            return (xbmc.getInfoLabel(name) or '').strip()
        except Exception as e:
            return f'<error: {e}>'

    lines.append(f'Kodi: {infolabel("System.BuildVersion")}')
    try:
        lines.append(f'Skin: {xbmc.getSkinDir()}')
    except Exception as e:
        lines.append(f'Skin: <error: {e}>')
    lines.append(f'System.ScreenResolution: {infolabel("System.ScreenResolution")}')
    lines.append(f'System.ScreenWidth x Height: '
                 f'{infolabel("System.ScreenWidth")} x {infolabel("System.ScreenHeight")}')

    # El getattr mantiene vivo el volcado de diagnóstico si un build no
    # expone estas funciones.
    gsw = getattr(xbmcgui, 'getScreenWidth', None)
    gsh = getattr(xbmcgui, 'getScreenHeight', None)
    if callable(gsw) and callable(gsh):
        try:
            lines.append(f'xbmcgui.getScreen W x H: {gsw()} x {gsh()}')
        except Exception as e:
            lines.append(f'xbmcgui.getScreen*: <error: {e}>')
    else:
        lines.append('xbmcgui.getScreenWidth/Height: no disponible')

    return lines


class _ProbeWindow(xbmcgui.WindowDialog):
    """Overlay con bordes de rejilla/panel y sondeo de fuentes."""

    def __init__(self, env_lines):
        super().__init__()
        self._env_lines = env_lines
        self._size_label = None
        self._size_reported = False
        self._build()

    def _rect(self, x, y, w, h, color):
        self.addControl(xbmcgui.ControlImage(
            x, y, w, h, _WHITE, aspectRatio=0, colorDiffuse=color,
        ))

    def _border(self, x, y, w, h, color, t=3):
        self._rect(x, y, w, t, color)              # arriba
        self._rect(x, y + h - t, w, t, color)      # abajo
        self._rect(x, y, t, h, color)              # izquierda
        self._rect(x + w - t, y, t, h, color)      # derecha

    def _build(self):
        from lib.ui_select import tv_safe_area_pct
        sa = tv_safe_area_pct()

        # Scrim semitransparente para que los bordes se lean sobre cualquier skin.
        self._rect(0, 0, _W, _H, '0xCC000000')

        # Borde de la rejilla 1280x720. Si NO llega a los bordes físicos de la
        # pantalla, la rejilla no se escala a full-screen aquí.
        self._border(0, 0, _W, _H, '0xFFFF3030', t=4)

        # Zona de seguridad TV (cian): si este borde se corta en tu televisor,
        # sube el margen en Ajustes > Accesibilidad hasta que se vea entero.
        inset_x = int(_W * sa / 100)
        inset_y = int(_H * sa / 100)
        if sa > 0:
            self._border(inset_x, inset_y, _W - inset_x * 2, _H - inset_y * 2,
                         '0xFF35D0E0', t=2)

        # Panel tal y como lo calcula ui_select (inset de seguridad + margen 40).
        margin = int(_W * 40 / 1280)
        px, py = inset_x + margin, inset_y + margin
        pw, ph = _W - 2 * (inset_x + margin), _H - 2 * (inset_y + margin)
        self._border(px, py, pw, ph, '0xFF30FF60', t=3)

        header_h = int(_H * 52 / 720)
        footer_h = int(_H * 48 / 720)
        pad = int(_W * 28 / 1280)
        self._rect(px, py + header_h, pw, 1, '0xFF30FF60')          # línea header
        self._rect(px, py + ph - footer_h, pw, 1, '0xFF30FF60')     # línea footer

        # Leyenda + números de entorno (mitad izquierda).
        box_x = px + pad
        box_y = py + header_h + pad
        box_w = pw // 2 - pad * 2
        box_h = ph - header_h - footer_h - pad * 2
        sa_line = (
            f'[COLOR FF35D0E0]Cian[/COLOR] = zona de seguridad TV '
            f'(margen actual: {sa}%). Si este borde se corta en tu televisor, '
            f'súbelo en Ajustes > Accesibilidad.\n'
            if sa > 0 else
            '[COLOR FF35D0E0]Cian[/COLOR] = zona de seguridad TV (margen actual: '
            '0%, desactivado). Si el contenido se sale en tu televisor, súbelo '
            'en Ajustes > Accesibilidad.\n'
        )
        legend = (
            '[B]Diagnóstico de UI[/B]\n'
            '[COLOR FFFF3030]Rojo[/COLOR] = rejilla 1280x720 '
            '(debe tocar los bordes de la pantalla).\n'
            + sa_line +
            '[COLOR FF30FF60]Verde[/COLOR] = panel de ui_select.\n'
            'Las cajas de la derecha sondean fuentes del skin: si el texto '
            'se sale de su caja, la fuente es más alta de lo que ui_select asume.\n\n'
            + '\n'.join(self._env_lines)
            + '\n\n[I]Pulsa OK o Atrás para cerrar.[/I]'
        )
        tb = xbmcgui.ControlTextBox(box_x, box_y, box_w, box_h,
                                    font='font13', textColor='0xFFE6EDF3')
        self.addControl(tb)
        tb.setText(legend)

        # Sondeo de fuentes (mitad derecha): cada fuente en una caja de la
        # altura que ui_select le asigna; el texto que sobresalga es la pista.
        col_x = px + pw // 2 + pad
        col_w = pw // 2 - pad * 2
        y = py + header_h + pad
        for font, assumed_h, usage in _FONT_PROBES:
            self._border(col_x, y, col_w, assumed_h, '0xFF8B949E', t=1)
            lbl = xbmcgui.ControlLabel(
                col_x + 6, y, col_w - 12, assumed_h,
                f'{font} ({usage}): {_SAMPLE}',
                font=font, textColor='0xFFFFFFFF', alignment=_XBFONT_CENTER_Y,
            )
            self.addControl(lbl)
            y += assumed_h + 14

        # Tamaño real de la ventana (se rellena tras show, en onAction).
        self._size_label = xbmcgui.ControlLabel(
            col_x, y + 6, col_w, 28,
            'getWidth/getHeight: (interactúa para medir)',
            font='font12', textColor='0xFFD29922',
        )
        self.addControl(self._size_label)

    def _report_size(self):
        if self._size_reported:
            return
        try:
            w, h = self.getWidth(), self.getHeight()
        except Exception as e:
            log.warning(f'ui_diag: getWidth/getHeight falló: {e}')
            self._size_label.setLabel('getWidth/getHeight: no disponible')
            self._size_reported = True
            return
        txt = f'WindowDialog.getWidth x getHeight (px reales): {w} x {h}'
        self._size_label.setLabel(txt)
        log.info(f'ui_diag: {txt}')
        self._size_reported = True

    def onAction(self, action):
        self._report_size()
        if action.getId() in _CLOSE_ACTIONS:
            self.close()


def _stress_items():
    from lib.ui_select import SelectItem
    long_label = ('Etiqueta muy larga para comprobar el truncado horizontal: '
                  'instalar en otro Kodi, restaurar, sanitizar y migrar todo')
    long_plot = (
        'Texto de descripción deliberadamente largo para forzar el desbordamiento '
        'del plot. ' * 12
    ).strip()
    items = [SelectItem(long_label, plot=long_plot)]
    items.append(SelectItem('Etiqueta corta', plot='Plot corto.'))
    for i in range(18):
        items.append(SelectItem(
            f'Item {i + 1} con texto medio para llenar la lista y forzar scroll',
            plot=f'Descripción del item {i + 1}. ' + 'relleno ' * (i % 7),
        ))
    return items


def run():
    """Lanza el diagnóstico de UI. Solo lectura: no cambia ningún ajuste."""
    env_lines = _collect_env()
    log.info('ui_diag: ' + ' | '.join(env_lines))

    dlg = _ProbeWindow(env_lines)
    try:
        dlg.doModal()
    finally:
        del dlg

    from lib import ui_select
    if ui_select.confirm(
            '¿Abrir la prueba de estrés del ui_select real (etiquetas y '
            'descripciones largas, 20 items)? Haz una captura si algo se '
            'sale del panel.',
            title='Diagnóstico de UI'):
        idx = ui_select.select('Prueba de estrés (ui_select real)',
                               _stress_items())
        log.info(f'ui_diag: stress select devolvió idx={idx}')
