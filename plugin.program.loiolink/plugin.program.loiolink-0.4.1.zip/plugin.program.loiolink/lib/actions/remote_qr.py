"""Acción 'Controlar Kodi desde el móvil': muestra QR con URL del panel.

Lee el puerto del server permanente de Window property (lo expone el
service.py al arrancar). Si no está disponible, avisa al usuario.

Modal con dos vistas conmutables con OK/Enter:

- Vista QR: enseña la URL CORTA (sin token) en texto y el QR que sí
  lleva `?t=TOKEN` embebido. El móvil escanea, el server le pone
  cookie persistente, y el favorito guarda la URL corta para siempre.
- Vista PIN: por si no se puede escanear (TV lejos, cámara estropeada).
  Muestra un PIN de 6 cifras generado en `lib.remote.pairing` y la
  URL corta. El móvil va a la URL, ve un formulario y teclea el PIN.

BACK/STOP cierra. El modal también se cierra solo si Kodi empieza a
reproducir algo (cast desde el móvil) o si el server avisa por
Window property `loiolink.modal.dismiss` (el móvil cargó el panel
autenticado, o va a aparecer un diálogo importante detrás).
"""
import os
import threading
import webbrowser

import xbmc
import xbmcaddon
import xbmcgui

import qr_generator
from lib import log
from lib.remote import pairing, server_permanent
from lib.ui_select import confirm, info


REMOTE_PORT_PROP = 'loiolink.remote.port'
MODAL_DISMISS_PROP = 'loiolink.modal.dismiss'
HOME_WINDOW_ID = 10000
_POLL_INTERVAL_S = 0.4


def _open_browser_for_remote(url):
    try:
        if xbmc.getCondVisibility('System.Platform.Android'):
            xbmc.executebuiltin(
                f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")'
            )
        else:
            try:
                ok = webbrowser.open(url)
                if not ok:
                    log.warning('webbrowser.open devolvio False (sin navegador disponible)')
            except webbrowser.Error as e:
                log.warning(f'webbrowser.open fallo: {e}')
            except OSError as e:
                log.warning(f'webbrowser.open OSError: {e}')
    except RuntimeError as e:
        log.warning(f'No se pudo abrir el navegador: {e}')


def _get_remote_port():
    val = xbmcgui.Window(10000).getProperty(REMOTE_PORT_PROP)
    try:
        return int(val) if val else None
    except (TypeError, ValueError):
        return None


def _resource_media():
    return os.path.join(
        xbmcaddon.Addon().getAddonInfo('path'),
        'resources', 'media',
    )


def _format_pin(pin):
    """Formatea '427981' como '427  981' para lectura humana."""
    if len(pin) == 6:
        return f'{pin[:3]}  {pin[3:]}'
    return pin


class _QRInfoDialog(xbmcgui.WindowDialog):
    """Modal con dos vistas (QR / PIN).

    `short_url` es la URL que se muestra en pantalla (sin token).
    `qr_url` es la que va en el QR (lleva `?t=TOKEN`). Si se omite,
    se usa `short_url` para ambas (modo legacy).
    `show_pin_option` permite ocultar la conmutación a PIN si la URL
    de destino no es el panel raíz (por ej. la página de un stream
    concreto, donde el PIN no podría redirigir bien).
    `initial_mode` ('qr' o 'pin') controla en qué vista arranca el modal.
    La generación del QR es lazy cuando arranca en 'pin': no se genera
    hasta que el usuario cambia a vista QR, evitando I/O innecesario.
    """

    _W, _H = 1280, 720
    _PANEL_W, _PANEL_H = 680, 580
    _PANEL_X = (_W - _PANEL_W) // 2
    _PANEL_Y = (_H - _PANEL_H) // 2

    _C_TITLE = '0xFFFFFFFF'
    _C_ADDR = '0xFF58A6FF'
    _C_DIM = '0xFF8B949E'
    _C_HINT = '0xFFD29922'
    _C_PIN = '0xFFFFFFFF'

    _FONT_H1 = 'font20'
    _FONT_BODY = 'font16'
    _FONT_SM = 'font14'
    _FONT_PIN = 'font40'

    _ALIGN_CENTER = 0x00000002  # XBFONT_CENTER_X

    _CLOSE_ACTIONS = {
        xbmcgui.ACTION_PREVIOUS_MENU,
        xbmcgui.ACTION_NAV_BACK,
        xbmcgui.ACTION_STOP,
    }
    _TOGGLE_ACTIONS = {
        xbmcgui.ACTION_SELECT_ITEM,
    }

    def __init__(self, short_url, qr_url=None, show_pin_option=True, initial_mode='qr'):
        super().__init__()
        self._short_url = short_url
        self._qr_url = qr_url or short_url
        self._show_pin_option = show_pin_option
        self._mode = 'qr'
        self._qr_path = None
        self._qr_only_controls = []
        self._pin_only_controls = []
        self._stop_event = threading.Event()
        # Capturamos el estado inicial del player para que el trigger
        # auto-close detecte la TRANSICIÓN a playing (no el estado).
        # Si abrieras el modal con un vídeo ya en reproducción, sin esta
        # guarda el modal se cerraría al instante.
        self._initial_playing = self._is_player_active()
        # Limpiamos la dismiss-flag por si quedó colgada de un cierre
        # anterior; empezamos limpios.
        xbmcgui.Window(HOME_WINDOW_ID).clearProperty(MODAL_DISMISS_PROP)

        px, py = self._PANEL_X, self._PANEL_Y
        pw, ph = self._PANEL_W, self._PANEL_H
        media = _resource_media()

        self._bg = xbmcgui.ControlImage(
            0, 0, self._W, self._H,
            os.path.join(media, 'transparent.png'),
            aspectRatio=2, colorDiffuse='0xCC000000',
        )
        self.addControl(self._bg)

        self._panel = xbmcgui.ControlImage(
            px, py, pw, ph,
            os.path.join(media, 'white.png'),
            aspectRatio=2, colorDiffuse='0xEE161B22',
        )
        self.addControl(self._panel)

        # Cabecera. El texto cambia entre modos.
        self._lbl_title = xbmcgui.ControlLabel(
            px, py + 20, pw, 36,
            'Controlar Kodi de forma remota',
            font=self._FONT_H1,
            textColor=self._C_TITLE,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_title)

        # Vista QR.
        self._lbl_qr_sub = xbmcgui.ControlLabel(
            px, py + 64, pw, 28,
            'Escanea el QR con la camara de tu dispositivo',
            font=self._FONT_BODY,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_qr_sub)
        self._qr_only_controls.append(self._lbl_qr_sub)

        qr_size = 280
        qr_x = px + (pw - qr_size) // 2
        qr_y = py + 100
        self._qr_x, self._qr_y, self._qr_size = qr_x, qr_y, qr_size

        # Fondo blanco sólido detrás del QR. Sin esto, los cuadros negros del
        # PNG se mezclan visualmente con el panel oscuro semi-transparente y
        # el QR parece "no salir".
        qr_pad = 12
        self._qr_bg = xbmcgui.ControlImage(
            qr_x - qr_pad, qr_y - qr_pad,
            qr_size + qr_pad * 2, qr_size + qr_pad * 2,
            os.path.join(media, 'white.png'),
            aspectRatio=2, colorDiffuse='0xFFFFFFFF',
        )
        self.addControl(self._qr_bg)
        self._qr_only_controls.append(self._qr_bg)

        # Fallback que solo se ve si la generación del QR falla.
        # El ControlImage del QR se añade encima al final del __init__ y lo
        # tapa cuando todo va bien.
        self._lbl_qr_fallback = xbmcgui.ControlLabel(
            qr_x, qr_y + qr_size // 2 - 20, qr_size, 40,
            '',
            font=self._FONT_BODY,
            textColor='0xFF000000',
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_qr_fallback)
        self._qr_only_controls.append(self._lbl_qr_fallback)

        # URL corta visible (sin token): la que el usuario marca como favorito.
        self._lbl_addr = xbmcgui.ControlLabel(
            px, qr_y + qr_size + 16, pw, 28,
            f'[B]{self._short_url}[/B]',
            font=self._FONT_BODY,
            textColor=self._C_ADDR,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_addr)
        self._qr_only_controls.append(self._lbl_addr)

        # Help partido en tres líneas cortas: ControlLabel no hace wrap.
        self._lbl_qr_help_1 = xbmcgui.ControlLabel(
            px, qr_y + qr_size + 48, pw, 24,
            'Guarda esta direccion como favorito.',
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_qr_help_1)
        self._qr_only_controls.append(self._lbl_qr_help_1)

        # HTTPS autofirmado: el navegador muestra pantalla roja. El usuario
        # tiene que entender que NO es un fallo del addon, sino comportamiento
        # normal de los certificados autofirmados en LAN.
        is_https = self._short_url.startswith('https://')
        help_2_text = (
            'Aviso: el navegador dira "Conexion no privada".'
            if is_https
            else 'Puedes cerrar la ventana al terminar.'
        )
        help_3_text = (
            'Pulsa Avanzado y Continuar (es normal con autofirmado).'
            if is_https
            else 'El panel funciona hasta que cierres Kodi.'
        )
        help_2_color = self._C_HINT if is_https else self._C_DIM

        self._lbl_qr_help_2 = xbmcgui.ControlLabel(
            px, qr_y + qr_size + 74, pw, 24,
            help_2_text,
            font=self._FONT_SM,
            textColor=help_2_color,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_qr_help_2)
        self._qr_only_controls.append(self._lbl_qr_help_2)

        self._lbl_qr_help_3 = xbmcgui.ControlLabel(
            px, qr_y + qr_size + 100, pw, 24,
            help_3_text,
            font=self._FONT_SM,
            textColor=help_2_color,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_qr_help_3)
        self._qr_only_controls.append(self._lbl_qr_help_3)

        # Vista PIN.
        self._lbl_pin_step1 = xbmcgui.ControlLabel(
            px, py + 80, pw, 28,
            '1) Abre en el navegador de tu dispositivo:',
            font=self._FONT_BODY,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_pin_step1)
        self._pin_only_controls.append(self._lbl_pin_step1)

        self._lbl_pin_addr = xbmcgui.ControlLabel(
            px, py + 118, pw, 36,
            f'[B]{self._short_url}[/B]',
            font=self._FONT_H1,
            textColor=self._C_ADDR,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_pin_addr)
        self._pin_only_controls.append(self._lbl_pin_addr)

        self._lbl_pin_step2 = xbmcgui.ControlLabel(
            px, py + 188, pw, 28,
            '2) Escribe este codigo:',
            font=self._FONT_BODY,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_pin_step2)
        self._pin_only_controls.append(self._lbl_pin_step2)

        self._lbl_pin_value = xbmcgui.ControlLabel(
            px, py + 232, pw, 80,
            '------',
            font=self._FONT_PIN,
            textColor=self._C_PIN,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_pin_value)
        self._pin_only_controls.append(self._lbl_pin_value)

        self._lbl_pin_ttl = xbmcgui.ControlLabel(
            px, py + 326, pw, 24,
            'Valido durante 5 minutos.',
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_pin_ttl)
        self._pin_only_controls.append(self._lbl_pin_ttl)

        # Pie. Toggle hint solo si la opción de PIN está habilitada.
        if self._show_pin_option:
            self._lbl_toggle = xbmcgui.ControlLabel(
                px, py + ph - 72, pw, 28,
                '[OK / Enter] No puedo escanear el QR',
                font=self._FONT_BODY,
                textColor=self._C_HINT,
                alignment=self._ALIGN_CENTER,
            )
            self.addControl(self._lbl_toggle)
        else:
            self._lbl_toggle = None

        self._lbl_help = xbmcgui.ControlLabel(
            px, py + ph - 40, pw, 24,
            'Pulsa Atras para cerrar',
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=self._ALIGN_CENTER,
        )
        self.addControl(self._lbl_help)

        # WindowDialog.onInit no se dispara en la API de Kodi Python, así que
        # los controles se inicializan aquí. El QR (PNG en disco) solo se
        # genera si arrancamos en vista QR; si arrancamos en PIN se difiere al
        # primer cambio a QR (cero I/O si el usuario siempre empareja por PIN).
        # `start_in_pin` unifica la condición: las dos ramas no pueden
        # desincronizarse.
        start_in_pin = initial_mode == 'pin' and self._show_pin_option
        if not start_in_pin:
            self._add_qr_control()

        for c in self._pin_only_controls:
            c.setVisible(False)

        if start_in_pin:
            self._toggle_mode()

        # Thread daemon que cierra el modal cuando algo importante pasa
        # detrás (reproducción iniciada, diálogo a mostrar, abort de Kodi).
        threading.Thread(
            target=self._poll_loop,
            name='loiolink-qr-autoclose',
            daemon=True,
        ).start()

    def _add_qr_control(self):
        self._qr_path = qr_generator.generate(self._qr_url)
        if not self._qr_path:
            log.warning('qr_generator devolvio None')
            self._lbl_qr_fallback.setLabel('No se pudo generar el QR')
            return
        try:
            self._qr_img = xbmcgui.ControlImage(
                self._qr_x, self._qr_y, self._qr_size, self._qr_size,
                self._qr_path,
            )
            self.addControl(self._qr_img)
            self._qr_only_controls.append(self._qr_img)
            log.info(f'QR mostrado desde {self._qr_path}')
        except (OSError, ValueError, RuntimeError, TypeError) as e:
            log.warning(f'No se pudo cargar el QR en ControlImage: {e}')
            self._lbl_qr_fallback.setLabel('No se pudo cargar el QR')

    def _is_player_active(self):
        try:
            p = xbmc.Player()
            return bool(p.isPlaying())
        except RuntimeError:
            return False

    def _poll_loop(self):
        """Cierra el modal cuando hay reproducción o el server avisa.

        Patrón heredado de ui_dialog._QRDialog._poll_loop:
        - Monitor.waitForAbort para sleep cooperativo + abort detection.
        - Solo lecturas desde este thread; el close() es idempotente y
          tolera ser llamado en paralelo con onAction.
        - El _stop_event sale del bucle si ya cerramos por otra vía.
        """
        monitor = xbmc.Monitor()
        win = xbmcgui.Window(HOME_WINDOW_ID)
        while not self._stop_event.is_set():
            if monitor.waitForAbort(_POLL_INTERVAL_S):
                # Kodi cerrándose: salimos sin tocar UI (puede estar caída).
                return
            if self._stop_event.is_set():
                return
            playing = self._is_player_active()
            if playing and not self._initial_playing:
                self.close()
                return
            # Una vez deja de reproducir se rearma el trigger (por si el
            # usuario para y vuelve a mandar contenido sin cerrar el modal).
            if not playing:
                self._initial_playing = False
            if win.getProperty(MODAL_DISMISS_PROP) == '1':
                win.clearProperty(MODAL_DISMISS_PROP)
                self.close()
                return

    def onAction(self, action):
        aid = action.getId()
        if aid in self._CLOSE_ACTIONS:
            self.close()
            return
        if aid in self._TOGGLE_ACTIONS and self._show_pin_option:
            self._toggle_mode()

    def _toggle_mode(self):
        if self._mode == 'qr':
            pin = pairing.generate_pin()
            self._lbl_pin_value.setLabel(_format_pin(pin))
            for c in self._qr_only_controls:
                c.setVisible(False)
            for c in self._pin_only_controls:
                c.setVisible(True)
            if self._lbl_toggle is not None:
                self._lbl_toggle.setLabel('[OK / Enter] Volver al QR')
            self._lbl_title.setLabel('Empareja sin escanear')
            self._mode = 'pin'
        else:
            if self._qr_path is None:
                self._add_qr_control()
            for c in self._pin_only_controls:
                c.setVisible(False)
            for c in self._qr_only_controls:
                c.setVisible(True)
            if self._lbl_toggle is not None:
                self._lbl_toggle.setLabel(
                    '[OK / Enter] No puedo escanear el QR',
                )
            self._lbl_title.setLabel('Controlar Kodi de forma remota')
            self._mode = 'qr'

    def close(self):
        # Señalamos al poll thread antes de cerrar la ventana para evitar
        # que intente llamar a Kodi UI mientras el modal ya está bajando.
        self._stop_event.set()
        try:
            super().close()
        except RuntimeError:
            pass

    def cleanup(self):
        self._stop_event.set()
        try:
            xbmcgui.Window(HOME_WINDOW_ID).clearProperty(MODAL_DISMISS_PROP)
        except RuntimeError:
            pass
        if self._qr_path:
            try:
                qr_generator.cleanup(self._qr_path)
            except OSError:
                pass


def run():
    port = _get_remote_port()
    if port is None:
        try:
            enabled = xbmcaddon.Addon().getSettingBool('remote_server_enabled')
        except RuntimeError:
            enabled = True
        if not enabled:
            if confirm(
                'El panel web de control remoto está apagado.\n\n¿Quieres encenderlo ahora?',
                title='loiolink',
                default_no=False,
            ):
                xbmcaddon.Addon().setSettingBool('remote_server_enabled', True)
                info(
                    'Encendiendo el panel web. Vuelve a abrir esta opción '
                    'en unos segundos.',
                    title='loiolink',
                )
            return
        info(
            'El servicio de control remoto aún no está disponible.\n\n'
            'Asegúrate de que Kodi terminó de arrancar y vuelve a intentar.',
            title='loiolink',
        )
        return

    ip = server_permanent.get_local_ip()
    if not ip:
        info(
            'No se pudo detectar la IP local.\n\n'
            'Asegúrate de estar conectado a WiFi o Ethernet.',
            title='loiolink',
        )
        return

    # URL corta (sin token): la que el usuario guarda como favorito.
    # El QR lleva `?t=TOKEN`: cada apertura del modal crea una sesión nueva
    # con su propio token. En el primer acceso desde el móvil el server
    # actualiza el label de "QR (sin escanear)" al UA real ("Chrome en
    # Android", etc.) y pone una cookie persistente (1 año).
    from lib.remote import sessions, tls
    sessions.purge_unscanned()
    try:
        session = sessions.add(label=sessions.UNSCANNED_LABEL, ua='')
    except OSError as e:
        # Sin sesión guardada, el QR sería inservible: el móvil lo escanearía
        # y el server lo rechazaría con un 401 inexplicable.
        log.error(f'no se pudo crear la sesión del QR: {e!r}')
        info('No se pudo preparar el control remoto: no se pudieron guardar '
             'las sesiones. Revisa el espacio en disco y los permisos.',
             title='loiolink')
        return
    token = session['token']
    session_id = session['id']
    short_url = f'{tls.scheme_in_use()}://{ip}:{port}/'
    qr_url = f'{short_url}?t={token}'
    log.info(
        f'Modal control remoto: short={short_url} '
        f'sesion_id={session_id}',
    )

    try:
        initial_mode = 'pin' if xbmcaddon.Addon().getSetting('remote.default_mode') == '1' else 'qr'
    except (RuntimeError, TypeError):
        initial_mode = 'qr'

    dlg = _QRInfoDialog(short_url, qr_url=qr_url, show_pin_option=True, initial_mode=initial_mode)
    try:
        try:
            auto_open = xbmcaddon.Addon().getSettingBool('remote.auto_open_browser')
        except (RuntimeError, TypeError):
            auto_open = False
        if auto_open:
            _open_browser_for_remote(qr_url)
        dlg.doModal()
    finally:
        dlg.cleanup()
        sessions.revoke_if_unscanned(session_id)
