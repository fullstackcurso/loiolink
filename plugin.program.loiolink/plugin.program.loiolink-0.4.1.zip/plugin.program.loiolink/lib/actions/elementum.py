"""Instalación JIT de Elementum.

A diferencia de StreamNinja, Elementum NO aparece como entrada del menú
principal. Solo se ofrece instalarlo cuando un flujo lo necesita y no está
disponible:
- service.py: llega un magnet y Elementum no está instalado.
- entry_actions.py:_act_play_torrent: el usuario pulsa "Reproducir con
  Elementum" sobre un .torrent del historial y Elementum no está.

API:
- `install_with_progress() -> bool`: instala el repositorio elementumorg +
  el addon Elementum, mostrando un DialogProgress con cancel durante la
  descarga del repo y un DialogProgressBG durante la instalación del addon.
  Devuelve True si el addon final quedó habilitado.
"""
import xbmcaddon
import xbmcgui

from lib import installer, log
from lib.ui_select import confirm, info


ELEMENTUM_ID = 'plugin.video.elementum'
ELEMENTUM_REPO_ID = 'repository.elementumorg'

# URL del ZIP del repositorio oficial de Elementum. El repo descarga
# binarios nativos según la arquitectura del sistema al instalar el addon.
# Override desde Ajustes -> Avanzado si elementumorg publica una versión
# nueva y borra esta.
_DEFAULT_REPO_URL = (
    'https://elementumorg.github.io/repository.elementumorg-1.0.6.zip'
)


def _get_repo_url():
    try:
        override = (xbmcaddon.Addon().getSetting(
            'elementum_repo_url_override',
        ) or '').strip()
    except RuntimeError:
        override = ''
    if override and not override.lower().startswith(('http://', 'https://')):
        log.warning(f'Override de repo inválido (no http/https): {override!r}')
        override = ''
    return override or _DEFAULT_REPO_URL


def install_with_progress():
    """Ofrece instalar Elementum con confirm + DialogProgress + DialogProgressBG.

    Devuelve True si el addon final quedó instalado y habilitado.
    """
    if not confirm(
        'Elementum no está instalado.\n¿Instalarlo ahora?\n\n'
        '(Se instala primero el repositorio elementumorg y después el '
        'addon, que descarga binarios nativos según tu sistema.)',
        title='loiolink',
        default_no=False,
    ):
        return False

    dp = xbmcgui.DialogProgress()
    dp.create('loiolink', 'Descargando repositorio Elementum...')

    def download_cb(done, total):
        if dp.iscanceled():
            raise InterruptedError()
        if total:
            dp.update(int(done * 55 / total), f'{done // 1024} KB / {total // 1024} KB')
        else:
            dp.update(0, f'{done // 1024} KB')

    def repo_status(pct, msg):
        dp.update(55 + int(pct * 0.40), msg)

    try:
        ok = installer.download_and_install_repo(
            _get_repo_url(), ELEMENTUM_REPO_ID,
            progress_cb=download_cb,
            status_cb=repo_status,
        )
    except InterruptedError:
        return False
    except installer.InstallError as e:
        log.error(f'InstallError Elementum: {e}')
        info(f'Error de instalación: {e}', title='loiolink')
        return False
    finally:
        dp.close()

    if not ok:
        info(
            'El repositorio de Elementum no se instaló.\n\n'
            'Verifica que "Orígenes desconocidos" está activo en '
            'Ajustes -> Sistema -> Addons.',
            title='loiolink',
        )
        return False

    xbmcgui.Dialog().notification(
        'loiolink', 'Confirmando instalación de Elementum...',
        xbmcgui.NOTIFICATION_INFO, 4000,
    )

    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Instalando Elementum...')

    def addon_status(pct, msg):
        bg.update(pct, 'loiolink', msg)

    try:
        ok = installer.install_addon_from_repo(
            ELEMENTUM_ID, repo_id=ELEMENTUM_REPO_ID, status_cb=addon_status,
        )
    finally:
        bg.close()

    if ok:
        from lib import accessibility
        accessibility.notify('Elementum instalado', ms=2500)
        return True

    info(
        'El repositorio se instaló pero Elementum no terminó.\n'
        'Pruébalo desde: Addons -> Instalar desde repositorio -> elementumorg.',
        title='loiolink',
    )
    return False
