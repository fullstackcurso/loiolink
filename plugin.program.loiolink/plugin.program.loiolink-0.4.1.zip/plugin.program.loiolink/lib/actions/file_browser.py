"""Explorador de archivos de loiolink.

Vista nativa Kodi (xbmcplugin) con dos modos:
- Raíz: lista las fuentes de sources.xml con "Añadir fuente" fijada arriba.
- Directorio: contenido de una carpeta con operaciones (copiar, mover,
  renombrar, eliminar) y opción de fijar el destino de subida.
"""
import concurrent.futures
import json
import os
import sys
import time
import urllib.request
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import clipboard
from lib import (
    accessibility, github_pages, installer, log, qr_dialog, source_state, source_status,
    sources, url_utils,
)
from lib.transfers.classifier import classify
from lib.ui_select import confirm, info


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_MENU_ICONS = os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'menu',
)

_HIDDEN = {'.', '..'}
_VFS_SCHEMES = ('smb://', 'nfs://', 'special://', 'http://', 'https://', 'ftp://')
_FILTER_PROP = 'loiolink.fb.only_active'
_DIR_SEARCH_PROP = 'loiolink.fb.dir_search'
_DIR_SORT_PROP = 'loiolink.fb.dir_sort'

_DIR_SORT_MODES = (
    ('name_asc',  'Nombre (A-Z)'),
    ('name_desc', 'Nombre (Z-A)'),
    ('size_desc', 'Tamaño (mayor primero)'),
    ('size_asc',  'Tamaño (menor primero)'),
    ('date_desc', 'Fecha (más reciente)'),
    ('date_asc',  'Fecha (más antigua)'),
    ('type_asc',  'Tipo de archivo'),
)
_DIR_SORT_DEFAULT = 'name_asc'


def _icon(filename):
    if not filename:
        return None
    p = os.path.join(_MENU_ICONS, filename)
    return p if os.path.isfile(p) else None


def _url(**kwargs):
    return f'{_BASE_URL}?{urlencode(kwargs)}'


def _item(label, url, is_folder=False, icon=None, plot='', ctx=None,
          replace_ctx=False, acc=None, info_type='video', playable=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label, **(acc or {})))
    if plot and not playable:
        # setInfo solo para items navegables. Para playable Kodi puede
        # rechazar keys ('plot' no existe en InfoTagMusic) y disparar
        # content lookup que se traga el click sin reproducir.
        li.setInfo(info_type, {'plot': plot, 'mediatype': info_type})
    if icon:
        li.setArt({'icon': icon, 'thumb': icon})
    if ctx:
        li.addContextMenuItems(ctx, replace_ctx)
    if playable:
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=li, isFolder=is_folder)


def _is_http(path):
    return path.startswith('http://') or path.startswith('https://')


def _is_local(path):
    return not any(path.lower().startswith(s) for s in _VFS_SCHEMES)


def _path_under_source(path):
    """True si `path` está dentro de una fuente registrada.

    La navegación del explorador solo DESCIENDE desde una fuente (los items de
    carpeta enlazan a subrutas; para subir se usa el Back de Kodi), así que
    todo path legítimo que llega a una operación está bajo una fuente. Validarlo
    bloquea que un deep-link externo -otro addon vía RunPlugin, un keymap o el
    JSON-RPC de la LAN (Addons.ExecuteAddon)- invoque una operación (borrar,
    mover, renombrar...) sobre un path arbitrario del sistema.

    Reutiliza la misma validación endurecida del explorador web
    (realpath+commonpath para local, prefix-match para rutas de red, rechazo
    de `..`) en vez de duplicar la lógica.
    """
    if not path:
        return False
    from lib.remote import library
    return library.is_path_under_source(path, strict_local=True)


def _norm(path):
    """Normaliza a forward slashes con trailing slash."""
    return path.replace('\\', '/').rstrip('/') + '/'


_UNIVERSAL_INVALID_CHARS = set('/\\\x00')
_WINDOWS_INVALID_CHARS = set(':*?"<>|')
_WIN_RESERVED_NAMES = frozenset({
    'con', 'prn', 'aux', 'nul',
    'com1', 'com2', 'com3', 'com4', 'com5', 'com6', 'com7', 'com8', 'com9',
    'lpt1', 'lpt2', 'lpt3', 'lpt4', 'lpt5', 'lpt6', 'lpt7', 'lpt8', 'lpt9',
})
_IS_WINDOWS = os.name == 'nt'


def _is_valid_name(name):
    """Valida nombre según la plataforma donde corre Kodi.

    Universal: vacío, '/' '\\' NUL, '.' '..', >255 chars.
    Windows además: :*?"<>|, trailing dot/space, reservados (CON, PRN, etc.).
    """
    if not name or not name.strip():
        return False
    stripped = name.strip()
    if stripped in ('.', '..'):
        return False
    if len(name) > 255:
        return False
    if any(c in _UNIVERSAL_INVALID_CHARS for c in name):
        return False
    if _IS_WINDOWS:
        if any(c in _WINDOWS_INVALID_CHARS for c in name):
            return False
        if name[-1] in ('.', ' '):
            return False
        if name.split('.', 1)[0].lower() in _WIN_RESERVED_NAMES:
            return False
    return True


def _refresh():
    xbmc.executebuiltin('Container.Refresh')


# --- Puntos de entrada ---

def run(path=None):
    if path:
        _track_source_visit(path)
        _browse_dir(path)
    else:
        _browse_sources()


def _track_source_visit(path):
    norm = url_utils.normalize_for_compare(path)
    if not norm:
        return
    for src in sources.list_files_sources():
        if url_utils.normalize_for_compare(src['path']) == norm:
            prev = source_state.get(src['path'])
            source_state.upsert(
                src['path'],
                visit_count=int(prev.get('visit_count', 0)) + 1,
                last_visit_ts=int(time.time()),
            )
            return


# Ops que operan sobre un path del filesystem: solo se permiten sobre paths
# dentro de una fuente registrada (ver _path_under_source). Las ops sobre
# fuentes (que reciben `name`, no un path arbitrario) y las de UI no entran aquí.
_PATH_GUARDED_OPS = frozenset({
    'upload', 'delete', 'rename', 'copy', 'move', 'mkdir',
    'upload_qr_here', 'file_info',
})


def op(op_name, path=None, name=None):
    if op_name in _PATH_GUARDED_OPS and not _path_under_source(path):
        log.security(
            f'[file_browser] op {op_name!r} rechazada: path fuera de las '
            f'fuentes registradas: {(path or "")[:120]!r}')
        accessibility.notify(
            'Operación no permitida: la ruta está fuera de tus fuentes.',
            xbmcgui.NOTIFICATION_WARNING, 3500)
        return
    handlers = {
        'add_source':        lambda: _op_add_source(),
        'upload':            lambda: _op_upload(path),
        'delete':            lambda: _op_delete(path),
        'rename':            lambda: _op_rename(path),
        'copy':              lambda: _op_copy(path),
        'move':              lambda: _op_move(path),
        'rename_source':     lambda: _op_rename_source(name),
        'delete_source':     lambda: _op_delete_source(name),
        'source_info':       lambda: _op_source_info(name, path),
        'change_url_source': lambda: _op_change_url_source(name, path),
        'copy_url':          lambda: _op_copy_url(path),
        'qr_url':            lambda: _op_qr_url(name, path),
        'sources_options':   lambda: _op_sources_options(),
        'export_sources':    lambda: _op_export_sources(),
        'import_sources':    lambda: _op_import_sources(),
        'test_url':          lambda: _op_test_url(path),
        'https_upgrade':     lambda: _op_https_upgrade(name, path),
        'install_repo':      lambda: _op_install_repo(name, path),
        'move_up':           lambda: _op_move_source(name, 'up'),
        'move_down':         lambda: _op_move_source(name, 'down'),
        'file_info':         lambda: _op_file_info(path),
        'mkdir':             lambda: _op_mkdir(path),
        'upload_qr_here':   lambda: _op_upload_qr_here(path),
        'verify_all':       lambda: _op_verify_all(),
        'restore_backup':   lambda: _op_restore_backup(),
        'toggle_favorite':  lambda: _op_toggle_favorite(path),
        'import_from_url':  lambda: _op_import_from_url(),
        'qr_all_sources':   lambda: _op_qr_all_sources(),
        'dir_filter':       lambda: _op_dir_filter(),
    }
    handler = handlers.get(op_name)
    if handler:
        handler()


# --- Vistas de navegación ---

def _browse_sources():
    acc = {
        'bold': accessibility.get_force_bold(),
        'strip': accessibility.get_strip_symbols(),
        'color_mode': accessibility.get_color_mode(),
        'font_size': accessibility.get_font_size(),
    }
    _item(
        '[COLOR gold][B]+ Añadir fuente nueva[/B][/COLOR]',
        _url(action='file_browser_op', op='add_source'),
        icon=_icon('add_source.png'),
        plot='Añade una nueva fuente al file manager de Kodi (sources.xml). '
             'Kodi la verá tras reiniciar.',
        acc=acc,
    )
    filter_tag = '  [COLOR red][Filtro activo][/COLOR]' if _active_filter() else ''
    _item(
        f'[COLOR gold][B]· Opciones[/B][/COLOR]  [COLOR grey]({_sort_mode_label()})[/COLOR]{filter_tag}',
        _url(action='file_browser_op', op='sources_options'),
        icon=_icon('sources.png'),
        plot='Cambiar el orden de las fuentes, exportar la lista a un archivo o '
             'importar fuentes desde un archivo JSON exportado previamente.',
        acc=acc,
    )

    for src in _sorted_sources(sources.list_files_sources()):
        name = src['name']
        path = src['path']
        http = _is_http(path)
        st = source_state.get(path) if path else {}
        is_fav = st.get('favorite', False)
        fav_ctx_label = 'Quitar de favoritos' if is_fav else 'Marcar como favorita'
        ctx = [
            (fav_ctx_label,      f'RunPlugin({_url(action="file_browser_op", op="toggle_favorite", path=path)})'),
            ('Información',      f'RunPlugin({_url(action="file_browser_op", op="source_info",   name=name, path=path)})'),
            ('Copiar URL',       f'RunPlugin({_url(action="file_browser_op", op="copy_url",      path=path)})'),
            ('QR de la URL',     f'RunPlugin({_url(action="file_browser_op", op="qr_url",        name=name, path=path)})'),
            ('Probar ahora',     f'RunPlugin({_url(action="file_browser_op", op="test_url",      path=path)})'),
        ]
        if path.startswith('http://'):
            ctx.append((
                'Migrar a HTTPS',
                f'RunPlugin({_url(action="file_browser_op", op="https_upgrade", name=name, path=path)})',
            ))
        if st.get('kind') == 'repo':
            ctx.append((
                'Instalar repositorio...',
                f'RunPlugin({_url(action="file_browser_op", op="install_repo", name=name, path=path)})',
            ))
        ctx.extend([
            ('Renombrar fuente', f'RunPlugin({_url(action="file_browser_op", op="rename_source", name=name)})'),
            ('Cambiar URL',      f'RunPlugin({_url(action="file_browser_op", op="change_url_source", name=name, path=path)})'),
            ('Mover arriba',     f'RunPlugin({_url(action="file_browser_op", op="move_up",   name=name)})'),
            ('Mover abajo',      f'RunPlugin({_url(action="file_browser_op", op="move_down", name=name)})'),
            ('Eliminar fuente',  f'RunPlugin({_url(action="file_browser_op", op="delete_source", name=name)})'),
        ])

        tag = source_status.status_tag(path)
        fav_prefix = '[COLOR gold]*[/COLOR] ' if is_fav else ''
        label = f'{fav_prefix}{tag} {name}' if tag else f'{fav_prefix}{name}'
        icon = _icon(source_status.status_icon(path))
        if http:
            item_url = _url(action='file_browser_op', op='source_info', name=name, path=path)
            is_folder = False
            plot = f'{path}\n\nFuente HTTP: no navegable como directorio. Usa el menú contextual para más opciones.'
        else:
            item_url = _url(action='file_browser', path=path)
            is_folder = True
            plot = f'{path}\n\nMenú contextual: información, copiar URL, QR, renombrar, cambiar URL o eliminar.'
        _item(label, item_url, is_folder=is_folder, icon=icon, plot=plot, ctx=ctx, replace_ctx=True, acc=acc)

    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)


# --- Orden ---

_SORT_LABELS = (
    'Por defecto (sources.xml)',
    'Alfabético',
    'Por estado',
    'Por última comprobación',
    'Por uso',
)


def _sort_mode():
    """Lee el modo activo del setting. 0 = no ordenar."""
    try:
        return int(xbmcaddon.Addon().getSetting('file_browser.sort_mode') or '0')
    except ValueError:
        return 0


def _sort_mode_label():
    mode = _sort_mode()
    return _SORT_LABELS[mode] if 0 <= mode < len(_SORT_LABELS) else _SORT_LABELS[0]


def _active_filter():
    return xbmcgui.Window(10000).getProperty(_FILTER_PROP) == '1'


def _sorted_sources(items):
    mode = _sort_mode()
    state = source_state.load()

    def st(src):
        return state.get(source_state.path_key(src['path']), {})

    def status_key(src):
        s = st(src)
        last_ts = -int(s.get('last_check_ts', 0))
        if int(s.get('errors', 0)) >= 3:
            return (5, last_ts, src['name'].lower())
        kind = s.get('kind')
        if kind == 'repo' and not s.get('acknowledged', True):
            return (0, last_ts, src['name'].lower())
        if kind == 'repo':
            return (1, last_ts, src['name'].lower())
        if kind == 'generic':
            return (2, last_ts, src['name'].lower())
        if kind == 'local':
            return (3, last_ts, src['name'].lower())
        return (4, last_ts, src['name'].lower())

    def last_check_key(src):
        s = st(src)
        ts = int(s.get('last_check_ts', 0))
        return (0 if ts > 0 else 1, -ts, src['name'].lower())

    def usage_key(src):
        s = st(src)
        return (-int(s.get('visit_count', 0)), -int(s.get('last_visit_ts', 0)), src['name'].lower())

    sort_key = {
        1: lambda s: s['name'].lower(),
        2: status_key,
        3: last_check_key,
        4: usage_key,
    }.get(mode)

    if _active_filter():
        def _is_active(src):
            s = st(src)
            return s.get('reachable', True) and int(s.get('errors', 0)) < 3
        items = [s for s in items if _is_active(s)]

    favs = [s for s in items if st(s).get('favorite')]
    rest = [s for s in items if not st(s).get('favorite')]
    if sort_key:
        return sorted(favs, key=sort_key) + sorted(rest, key=sort_key)
    return favs + rest


_VIDEO_EXTS = {
    '.mp4', '.mkv', '.avi', '.mov', '.webm', '.flv', '.ts', '.m3u8', '.mpd',
    '.mpg', '.mpeg', '.wmv', '.3gp', '.m4v', '.ogv',
}
_AUDIO_EXTS = {
    '.mp3', '.m4a', '.aac', '.flac', '.wav', '.ogg', '.opus', '.wma',
}
_IMAGE_EXTS = {
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.tif',
}


def _media_kind(filename):
    """Devuelve 'video', 'audio', 'image' o None según la extensión."""
    ext = os.path.splitext(filename.lower())[1]
    if ext in _VIDEO_EXTS:
        return 'video'
    if ext in _AUDIO_EXTS:
        return 'audio'
    if ext in _IMAGE_EXTS:
        return 'image'
    return None


def _dir_search():
    return xbmcgui.Window(10000).getProperty(_DIR_SEARCH_PROP) or ''


def _dir_sort():
    mode = xbmcgui.Window(10000).getProperty(_DIR_SORT_PROP) or _DIR_SORT_DEFAULT
    if mode not in dict(_DIR_SORT_MODES):
        return _DIR_SORT_DEFAULT
    return mode


def _dir_filter_label():
    """Texto descriptivo del filtro/orden activo, p.ej. ' [Z-A · "video"]'."""
    parts = []
    search = _dir_search()
    if search:
        parts.append(f'"{search}"')
    sort_mode = _dir_sort()
    if sort_mode != _DIR_SORT_DEFAULT:
        parts.append(dict(_DIR_SORT_MODES)[sort_mode])
    return f'  [COLOR grey]({" · ".join(parts)})[/COLOR]' if parts else ''


def _apply_dir_filter(names, base_path, is_folder):
    """Filtra por nombre y ordena según el modo activo. names: lista de
    nombres de archivo o carpeta. base_path: path padre normalizado.
    Devuelve lista de nombres ya filtrados y ordenados."""
    search = _dir_search().lower()
    filtered = [n for n in names if n and n not in _HIDDEN]
    if search:
        filtered = [n for n in filtered if search in n.lower()]

    sort_mode = _dir_sort()
    if sort_mode in ('name_asc', 'name_desc'):
        filtered.sort(key=lambda n: n.lower(), reverse=(sort_mode == 'name_desc'))
        return filtered

    if sort_mode == 'type_asc':
        # Agrupar por extensión, luego por nombre. Carpetas: nombre solo.
        if is_folder:
            filtered.sort(key=lambda n: n.lower())
        else:
            filtered.sort(key=lambda n: (os.path.splitext(n.lower())[1], n.lower()))
        return filtered

    # size_* / date_* requieren stat. Las carpetas no tienen tamaño útil,
    # así que para esos modos se ordenan por nombre (siempre van arriba).
    if is_folder:
        filtered.sort(key=lambda n: n.lower())
        return filtered

    def stat_attr(name):
        try:
            st = xbmcvfs.Stat(base_path + name)
            if sort_mode in ('size_asc', 'size_desc'):
                return st.st_size()
            return st.st_mtime()
        except (OSError, RuntimeError):
            return 0

    filtered.sort(key=stat_attr, reverse=sort_mode.endswith('_desc'))
    return filtered


def _browse_dir(path):
    norm = _norm(path)

    if not xbmcvfs.exists(norm):
        accessibility.notify('Directorio no encontrado o sin acceso.', xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    acc = {
        'bold': accessibility.get_force_bold(),
        'strip': accessibility.get_strip_symbols(),
        'color_mode': accessibility.get_color_mode(),
        'font_size': accessibility.get_font_size(),
    }

    _item(
        '[COLOR gold][B]Subir archivo aquí[/B][/COLOR]',
        _url(action='file_browser_op', op='upload', path=norm),
        icon=_icon('remote.png'),
        plot=f'Cambia el destino de subida a:\n{norm}\n\n'
             'Los archivos que envíes desde el panel remoto llegarán a esta carpeta.',
        acc=acc,
    )
    _item(
        '[COLOR gold][B]· QR para subir aquí[/B][/COLOR]',
        _url(action='file_browser_op', op='upload_qr_here', path=norm),
        icon=_icon('remote.png'),
        plot=f'Fija el destino a esta carpeta y abre el QR del panel remoto. '
             f'Escanea, sube desde el móvil, y los archivos llegarán a:\n{norm}',
        acc=acc,
    )
    _item(
        '[COLOR gold][B]· Crear carpeta[/B][/COLOR]',
        _url(action='file_browser_op', op='mkdir', path=norm),
        icon=_icon('add_source.png'),
        plot=f'Crea una nueva subcarpeta dentro de:\n{norm}',
        acc=acc,
    )
    _item(
        f'[COLOR gold][B]· Filtro / Buscar[/B][/COLOR]{_dir_filter_label()}',
        _url(action='file_browser_op', op='dir_filter', path=norm),
        icon=_icon('sources.png'),
        plot='Buscar archivos por nombre y elegir el orden (nombre, tamaño o fecha).\n\n'
             'El filtro se conserva mientras navegas por las carpetas; se pierde al reiniciar Kodi.',
        acc=acc,
    )

    try:
        folders, files = xbmcvfs.listdir(norm)
    except OSError as e:
        accessibility.notify(f'No se pudo leer el directorio: {e}', ms=3000)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    for folder in _apply_dir_filter(folders, norm, is_folder=True):
        full = norm + folder + '/'
        _item(
            folder + '/',
            _url(action='file_browser', path=full),
            is_folder=True,
            icon='DefaultFolder.png',
            plot=full,
            ctx=_file_ctx(full),
            acc=acc,
        )

    for fname in _apply_dir_filter(files, norm, is_folder=False):
        full = norm + fname
        kind = _media_kind(fname)
        if kind == 'video':
            _item(fname, _url(action='play_media', path=full),
                  is_folder=False, icon='DefaultVideo.png',
                  ctx=_file_ctx(full), acc=acc)
        elif kind == 'audio':
            _item(fname, _url(action='play_media', path=full, kind='audio'),
                  is_folder=False, icon='DefaultAudio.png',
                  ctx=_file_ctx(full), acc=acc)
        elif kind == 'image':
            _item(fname, _url(action='open_image', path=full),
                  is_folder=False, icon='DefaultPicture.png',
                  plot=full, ctx=_file_ctx(full), acc=acc)
        elif os.path.splitext(fname.lower())[1] in ('.apk', '.zip'):
            _item(fname, _url(action='install_file', path=full),
                  is_folder=False, icon='DefaultAddonInstall.png',
                  plot=full, ctx=_file_ctx(full), acc=acc)
        else:
            _item(fname, _url(action='noop'), icon='DefaultFile.png',
                  plot=full, ctx=_file_ctx(full), acc=acc)

    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)


def _file_ctx(path):
    return [
        ('Información', f'RunPlugin({_url(action="file_browser_op", op="file_info", path=path)})'),
        ('Copiar',      f'RunPlugin({_url(action="file_browser_op", op="copy",      path=path)})'),
        ('Mover',       f'RunPlugin({_url(action="file_browser_op", op="move",      path=path)})'),
        ('Renombrar',   f'RunPlugin({_url(action="file_browser_op", op="rename",    path=path)})'),
        ('Eliminar',    f'RunPlugin({_url(action="file_browser_op", op="delete",    path=path)})'),
    ]


def play_media(path, kind='video'):
    log.sensitive(f'[file_browser.play_media] handle={_HANDLE} kind={kind} path={path!r}')
    if path and not _path_under_source(path):
        # Deep-link a un path fuera de las fuentes (p.ej. una UNC \\atacante\x
        # que en Windows filtraría el hash NTLM al autenticar contra el SMB).
        log.security(f'[file_browser.play_media] path fuera de fuentes: {path[:120]!r}')
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    try:
        if path:
            from lib.remote import player as remote_player
            log.info('[file_browser.play_media] llamando remote_player.play_file()')
            remote_player.play_file(path, title=os.path.basename(path), kind=kind)
            log.info('[file_browser.play_media] play_file OK')
        else:
            log.warning('[file_browser.play_media] path vacío')
    except Exception as e:
        import traceback
        log.error(f'[file_browser.play_media] EXCEPCIÓN: {e}\n{traceback.format_exc()}')
        accessibility.notify(f'No se pudo reproducir: {e}', ms=5000)
    # endOfDirectory: mismo patrón que open_image. No usar setResolvedUrl
    # porque el item no es IsPlayable; Kodi llama esperando un listing.
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)


def open_image(path):
    if path and not _path_under_source(path):
        log.security(f'[file_browser.open_image] path fuera de fuentes: {path[:120]!r}')
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    if path:
        # Comillas dobles para tolerar paths con ',' o ')'. Escape al estilo de
        # Kodi (StringUtils::Paramify): PRIMERO las barras invertidas, LUEGO las
        # comillas. Sin escapar antes el `\`, un path con `\"` (válido en
        # Linux/Android/SMB) cerraría la comilla y truncaría el parámetro.
        escaped = path.replace('\\', '\\\\').replace('"', '\\"')
        xbmc.executebuiltin(f'ShowPicture("{escaped}")')
    # endOfDirectory(succeeded=False) evita el spinner de "navegando":
    # el ListItem apunta a este plugin, Kodi espera un directorio o setResolvedUrl.
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)


def install_file(path):
    # Mutex global vive ahora en installer.py: lo aplican install_zip y
    # install_apk internamente y lanzan InstallBusyError si está ocupado.
    # Esto cubre también los callers post_transfer y entry_actions.
    try:
        _do_install_file(path)
    finally:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)


def _do_install_file(path):
    if not path:
        return
    if not _is_local(path):
        info(
            'Solo se pueden instalar archivos locales.\n\n'
            'Cópialo primero a un directorio del dispositivo y vuelve a pulsar.',
            title='Instalar',
        )
        return
    if not xbmcvfs.exists(path):
        info(f'No se encuentra el archivo:\n{path}', title='Instalar')
        return

    name = os.path.basename(path)
    try:
        kind, addon_id = classify(path)
    except (OSError, ValueError) as e:
        info(f'No se pudo analizar el archivo:\n{e}', title='Instalar')
        return

    if kind == 'apk':
        _install_apk_flow(path, name)
        return

    if kind in ('addon_zip', 'repo_zip'):
        zip_kind = 'repo' if kind == 'repo_zip' else 'addon'
        label = 'repositorio' if zip_kind == 'repo' else 'addon'
        if not confirm(
            f'{name}\n\n¿Instalar {label} en Kodi?',
            title='Instalar en Kodi',
            default_no=False,
        ):
            return
        _install_zip_flow(path, addon_id, zip_kind, label)
        return

    if kind == 'unknown_zip':
        choice = xbmcgui.Dialog().select(
            f'{name}\nNo se detectó addon.xml válido. ¿Intentar como?',
            ['Addon de Kodi', 'Repositorio de Kodi'],
        )
        if choice < 0:
            return
        zip_kind = 'addon' if choice == 0 else 'repo'
        label = 'addon' if zip_kind == 'addon' else 'repositorio'
        guessed_id = os.path.splitext(name)[0]
        if not confirm(
            f'{name}\n\n¿Instalar como {label} en Kodi?\n'
            f'(Se asumirá id "{guessed_id}". Si la estructura interna no '
            'coincide, la instalación fallará.)',
            title='Instalar en Kodi',
            default_no=True,
        ):
            return
        _install_zip_flow(path, guessed_id, zip_kind, label)


def _install_apk_flow(path, name):
    if not installer.is_android():
        accessibility.notify(
            f'{name}: APK solo instalable en Android (Fire TV, Android TV)',
            ms=4500,
        )
        return
    if not confirm(
        installer.apk_confirm_body(name),
        title='Instalar APK',
        default_no=False,
    ):
        return
    bg = xbmcgui.DialogProgressBG()
    try:
        bg.create('Instalar APK', f'Preparando {name}...')
    except Exception as e:
        log.error(f'DialogProgressBG.create falló: {e}')
        bg = None
    public_path = None
    error_msg = None
    busy = False
    try:
        public_path = installer.install_apk(path)
    except installer.InstallBusyError:
        busy = True
    except installer.InstallError as e:
        error_msg = str(e)
    except Exception as e:
        log.error(f'install_apk error inesperado: {e}')
        error_msg = f'Error inesperado: {e}'
    finally:
        if bg is not None:
            try:
                bg.close()
            except Exception:
                pass  # dialog ya cerrado o Kodi en shutdown; ignorar

    if busy:
        accessibility.notify(
            'Ya hay una instalación en curso. Espera a que termine.',
            ms=3500,
        )
        return
    if error_msg:
        info(
            f'No se pudo preparar el APK.\n\n{error_msg}\n\n'
            + installer.HINT_ANDROID_PERMISSIONS,
            title='Instalar APK',
        )
        return
    # En Kodi <22 no se lanza el instalador (cerraría Kodi): mostramos un
    # diálogo accionable (pm install / instalación manual). En Kodi 22+ el
    # intent ya se lanzó, así que basta el toast con la ruta.
    if not installer.apk_install_followup(public_path):
        accessibility.notify(
            f'APK preparado en {public_path}. '
            'Si el instalador no aparece, ábrelo desde un gestor de archivos.',
            title='Instalar APK', ms=7000,
        )


def _install_zip_flow(path, addon_id, zip_kind, label):
    bg = xbmcgui.DialogProgressBG()
    try:
        bg.create('Instalar en Kodi', f'Preparando {os.path.basename(path)}...')
    except Exception as e:
        log.error(f'DialogProgressBG.create falló: {e}')
        bg = None

    def cb(pct, msg):
        if bg is None:
            return
        try:
            bg.update(int(pct), 'Instalar en Kodi', msg)
        except Exception:
            pass  # dialog cerrado mientras instalaba; cb se ignora

    ok = False
    error_msg = None
    busy = False
    try:
        ok = installer.install_zip(
            path, addon_id, kind=zip_kind, status_cb=cb,
        )
    except installer.InstallBusyError:
        busy = True
    except installer.InstallError as e:
        error_msg = str(e)
    except Exception as e:
        log.error(f'install_zip error inesperado: {e}')
        error_msg = f'Error inesperado: {e}'
    finally:
        if bg is not None:
            try:
                bg.close()
            except Exception:
                pass  # dialog ya cerrado o Kodi en shutdown; ignorar

    if busy:
        accessibility.notify(
            'Ya hay una instalación en curso. Espera a que termine.',
            ms=3500,
        )
        return
    if error_msg:
        info(f'Error instalando {label}:\n{error_msg}', title='Instalar en Kodi')
        return
    if ok:
        accessibility.notify(f'{addon_id} instalado.', title='Instalar en Kodi')
    else:
        info(
            f'La instalación de {addon_id} no terminó correctamente.\n'
            'Ver kodi.log para detalles.',
            title='Instalar en Kodi',
        )


def _op_dir_filter():
    win = xbmcgui.Window(10000)
    current_search = _dir_search()
    current_sort = _dir_sort()

    options = []
    actions = []

    label = 'Buscar por nombre...'
    if current_search:
        label = f'Buscar por nombre...  (actual: "{current_search}")'
    options.append(label)
    actions.append('search')

    if current_search:
        options.append('Limpiar búsqueda')
        actions.append('clear_search')

    for mode, mode_label in _DIR_SORT_MODES:
        marker = '[B]>[/B] ' if mode == current_sort else '   '
        options.append(f'{marker}{mode_label}')
        actions.append(('sort', mode))

    if current_search or current_sort != _DIR_SORT_DEFAULT:
        options.append('Restablecer (sin filtro, orden por defecto)')
        actions.append('reset')

    choice = xbmcgui.Dialog().select('Filtro y orden', options)
    if choice < 0:
        return

    action = actions[choice]
    if action == 'search':
        new_text = xbmcgui.Dialog().input(
            'Buscar archivos por nombre (vacío = sin filtro)',
            defaultt=current_search,
        )
        # input() devuelve '' si el usuario cancela O si vacía el texto.
        # En ambos casos lo interpretamos como "sin filtro": el botón
        # 'Limpiar búsqueda' es el camino dedicado, así que aquí es seguro.
        win.setProperty(_DIR_SEARCH_PROP, new_text or '')
    elif action == 'clear_search':
        win.setProperty(_DIR_SEARCH_PROP, '')
    elif action == 'reset':
        win.setProperty(_DIR_SEARCH_PROP, '')
        win.setProperty(_DIR_SORT_PROP, '')
    elif isinstance(action, tuple) and action[0] == 'sort':
        win.setProperty(_DIR_SORT_PROP, action[1])

    _refresh()


# --- Operaciones ---

def _input_url(heading, default=''):
    """Como Dialog().input pero pre-rellena con la URL del clipboard si:

    - el setting `menu.detect_clipboard` está activo, y
    - no hay `default` ya pasado, y
    - el clipboard contiene una URL válida.

    Devuelve '' si el usuario cancela.
    """
    if not default:
        try:
            allow = xbmcaddon.Addon().getSettingBool('menu.detect_clipboard')
        except (TypeError, ValueError):
            allow = True
        if allow:
            clip = clipboard.get()
            url = url_utils.extract_first_url(clip) if clip else None
            if url:
                default = url
    return xbmcgui.Dialog().input(heading, defaultt=default or '') or ''


def _check_url_before_save(url, exclude_name=None):
    """Valida URL nueva: detecta duplicados y comprueba alcance.

    Devuelve True si el usuario quiere seguir adelante, False si cancela.
    Si la URL es duplicada o no responde, pregunta al usuario si guardar
    igualmente.
    """
    if not url_utils.is_source_url(url):
        if not confirm(
            f'La URL "{url}" no parece http/https/smb/nfs/ftp. ¿Guardar igualmente?',
            title='loiolink', default_no=True,
        ):
            return False

    target = url_utils.normalize_for_compare(url)
    for src in sources.list_files_sources():
        if exclude_name is not None and src['name'] == exclude_name:
            continue
        if url_utils.normalize_for_compare(src['path']) == target:
            if not confirm(
                f'Ya existe la fuente "{src["name"]}" apuntando a esta misma URL. '
                '¿Guardar igualmente?',
                title='loiolink', default_no=True,
            ):
                return False
            break

    if url.startswith('http://') or url.startswith('https://'):
        progress = xbmcgui.DialogProgress()
        progress.create('loiolink', f'Probando {url}...')
        try:
            ok, info = url_utils.test_http_reachable(url, timeout=4)
        finally:
            progress.close()
        if not ok:
            if not confirm(
                f'La URL no respondió ({info}).\n\n¿Guardarla igualmente?',
                title='loiolink', default_no=True,
            ):
                return False

    return True


def _browse_for_path():
    """Abre el selector nativo de carpetas de Kodi. Devuelve '' si cancela."""
    path = xbmcgui.Dialog().browse(0, 'Selecciona la carpeta de la fuente', 'files')
    return _norm(path) if path else ''


def _op_add_source():
    choice = xbmcgui.Dialog().select(
        'Origen de la fuente',
        [
            'Repositorio de GitHub Pages',
            'Escribir URL o ruta',
            'Examinar carpetas con el explorador de Kodi',
        ],
    )
    if choice < 0:
        return

    if choice == 0:
        result = github_pages.prompt_source_url()
        if not result:
            return
        path, suggested = result
    elif choice == 2:
        path = _browse_for_path()
        if not path:
            return
        # suggest_source_name() solo entiende URLs; para rutas locales usamos
        # el nombre de la última carpeta.
        suggested = os.path.basename(path.rstrip('/'))
        # Validación reducida: solo duplicados, sin check HTTP ni de scheme.
        target = url_utils.normalize_for_compare(path)
        for src in sources.list_files_sources():
            if url_utils.normalize_for_compare(src['path']) == target:
                if not confirm(
                    f'Ya existe la fuente "{src["name"]}" apuntando a esta misma ruta. '
                    '¿Guardar igualmente?',
                    title='loiolink', default_no=True,
                ):
                    return
                break
    else:
        path = _input_url('URL de la fuente (http://, smb://, ruta local...)')
        if not path:
            return
        if not _check_url_before_save(path):
            return
        suggested = url_utils.suggest_source_name(path)

    name = xbmcgui.Dialog().input('Nombre de la fuente', defaultt=suggested)
    if not name:
        return
    sources.add_source(name, path)
    accessibility.notify('Fuente añadida. Reinicia Kodi para que la vea.', ms=3500)
    _refresh()


def _op_upload(path):
    if not path:
        return
    xbmcaddon.Addon().setSetting('transfer.dest_folder', path)
    accessibility.notify(f'Destino de subida cambiado a:\n{path}', ms=4000)


def _op_delete(path):
    if not path:
        return
    name = os.path.basename(path.rstrip('/'))
    if not accessibility.confirm_destructive(f'¿Eliminar "{name}"?'):
        return
    is_dir = path.endswith('/')
    ok = False
    if is_dir:
        clean = path.rstrip('/')
        if _is_local(clean):
            try:
                import shutil
                shutil.rmtree(clean)
                ok = True
            except OSError:
                pass
        if not ok:
            try:
                ok = bool(xbmcvfs.rmdir(clean, True))
            except TypeError:
                ok = bool(xbmcvfs.rmdir(clean))
    else:
        ok = bool(xbmcvfs.delete(path))
    if ok:
        accessibility.notify('Eliminado.', ms=2000)
    else:
        accessibility.notify('No se pudo eliminar.', xbmcgui.NOTIFICATION_WARNING, 2500)
    _refresh()


def _op_rename(path):
    if not path:
        return
    stripped = path.rstrip('/')
    old_name = os.path.basename(stripped)
    parent = _norm(os.path.dirname(stripped))
    new_name = xbmcgui.Dialog().input('Nuevo nombre', defaultt=old_name)
    if not new_name or new_name == old_name:
        return
    if not _is_valid_name(new_name):
        accessibility.notify(
            'Nombre no válido.', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    ok = bool(xbmcvfs.rename(stripped, parent + new_name))
    if ok:
        accessibility.notify('Renombrado.', ms=2000)
    else:
        accessibility.notify('No se pudo renombrar.', xbmcgui.NOTIFICATION_WARNING, 2500)
    _refresh()


def _op_copy(path):
    if not path:
        return
    dest_dir = xbmcgui.Dialog().browse(3, 'Seleccionar destino', 'files')
    if not dest_dir:
        return
    dest = _norm(dest_dir)
    name = os.path.basename(path.rstrip('/'))
    is_dir = path.endswith('/')
    if is_dir:
        ok = _copy_dir(path, dest + name + '/')
    else:
        ok = bool(xbmcvfs.copy(path, dest + name))
    if ok:
        accessibility.notify('Copiado.', ms=2000)
    else:
        accessibility.notify('No se pudo copiar.', xbmcgui.NOTIFICATION_WARNING, 2500)


def _copy_dir(src, dst):
    src = _norm(src)
    dst = _norm(dst)
    if not xbmcvfs.mkdirs(dst):
        return False
    folders, files = xbmcvfs.listdir(src)
    ok = True
    for fname in (f for f in files if f and f not in _HIDDEN):
        ok = bool(xbmcvfs.copy(src + fname, dst + fname)) and ok
    for folder in (f for f in folders if f and f not in _HIDDEN):
        ok = _copy_dir(src + folder + '/', dst + folder + '/') and ok
    return ok


def _op_move(path):
    if not path:
        return
    dest_dir = xbmcgui.Dialog().browse(3, 'Seleccionar destino', 'files')
    if not dest_dir:
        return
    dest = _norm(dest_dir)
    name = os.path.basename(path.rstrip('/'))
    src = path.rstrip('/')
    new_path = dest + name
    ok = bool(xbmcvfs.rename(src, new_path))
    if not ok:
        if path.endswith('/'):
            accessibility.notify(
                'No se pudo mover la carpeta. Para mover entre unidades: copia y luego elimina el original.',
                xbmcgui.NOTIFICATION_WARNING, 5000,
            )
            return
        ok = bool(xbmcvfs.copy(src, new_path))
        if ok:
            xbmcvfs.delete(src)
    if ok:
        accessibility.notify('Movido.', ms=2000)
    else:
        accessibility.notify('No se pudo mover.', xbmcgui.NOTIFICATION_WARNING, 2500)
    _refresh()


def _op_rename_source(name):
    if not name:
        return
    new_name = xbmcgui.Dialog().input('Nuevo nombre', defaultt=name)
    if not new_name or new_name == name:
        return
    path = next((s['path'] for s in sources.list_files_sources() if s['name'] == name), None)
    if sources.rename_source(name, new_name):
        if path:
            source_state.upsert(path, name=new_name)
        accessibility.notify('Fuente renombrada. Reinicia Kodi.', ms=3000)
        _refresh()
    else:
        accessibility.notify('No se pudo renombrar.', xbmcgui.NOTIFICATION_WARNING, 2500)


def _op_delete_source(name):
    if not name:
        return
    if not accessibility.confirm_destructive(f'¿Eliminar la fuente "{name}"?'):
        return
    path = next((s['path'] for s in sources.list_files_sources() if s['name'] == name), None)
    if sources.remove_source(name):
        if path:
            source_state.remove(path)
        accessibility.notify('Fuente eliminada. Reinicia Kodi.', ms=3000)
        _refresh()
    else:
        accessibility.notify('No se encontró la fuente.', xbmcgui.NOTIFICATION_WARNING, 2500)


def _version_tuple(v):
    try:
        return tuple(int(x) for x in str(v).split('.')[:4])
    except ValueError:
        return (0,)


def _version_gt(a, b):
    return _version_tuple(a) > _version_tuple(b)


def _get_installed_addon_versions():
    req = json.dumps({
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Addons.GetAddons',
        'params': {'enabled': True, 'properties': ['version']},
    })
    try:
        resp = json.loads(xbmc.executeJSONRPC(req))
        return {a['addonid']: a['version'] for a in resp.get('result', {}).get('addons', [])}
    except (ValueError, KeyError, TypeError):
        return {}


def _op_source_info(name, path):
    st = source_state.get(path) if path else {}
    kind_map = {
        'repo':    'Repositorio monitorizado',
        'generic': 'Fuente genérica (sin addons.xml)',
        'local':   'Ruta local',
    }
    kind = kind_map.get(st.get('kind', ''), 'Sin clasificar')
    last_ts = st.get('last_check_ts')
    last_check = time.strftime('%Y-%m-%d %H:%M', time.localtime(last_ts)) if last_ts else 'Nunca'
    errors = int(st.get('errors', 0))
    reachable = st.get('reachable')
    addons_count = len(st.get('last_seen_addons', {}))
    visit_count = int(st.get('visit_count', 0))
    last_visit_ts = st.get('last_visit_ts')
    last_visit = time.strftime('%Y-%m-%d %H:%M', time.localtime(last_visit_ts)) if last_visit_ts else 'Nunca'

    lines = [
        f'Nombre: {name or "-"}',
        f'URL: {path or "-"}',
        f'Tipo: {kind}',
        f'Accesible: {"Si" if reachable else ("No" if reachable is not None else "Sin datos")}',
        f'Ultima comprobacion: {last_check}',
        f'Visitas: {visit_count} (ultima: {last_visit})',
    ]
    if errors:
        lines.append(f'Errores consecutivos: {errors}')
    if addons_count:
        lines.append(f'Addons en el indice: {addons_count}')
    if st.get('kind') == 'repo' and st.get('last_seen_addons'):
        installed = _get_installed_addon_versions()
        updates = [
            f'  {aid}: {installed[aid]} -> {ver}'
            for aid, ver in sorted(st['last_seen_addons'].items())
            if aid in installed and _version_gt(ver, installed[aid])
        ]
        if updates:
            lines.append(f'Actualizaciones disponibles: {len(updates)}')
            lines.extend(updates[:5])
            if len(updates) > 5:
                lines.append(f'  ... y {len(updates) - 5} mas')
        elif installed:
            lines.append('Actualizaciones: ninguna')

    xbmcgui.Dialog().ok(name or 'Fuente', '\n'.join(lines))


def _op_change_url_source(name, path):
    if not name:
        return
    new_url = _input_url('Nueva URL de la fuente', default=path or '')
    if not new_url or new_url == path:
        return
    if not _check_url_before_save(new_url, exclude_name=name):
        return
    if sources.change_source_url(name, new_url):
        if path:
            source_state.remove(path)
        accessibility.notify('URL cambiada. Reinicia Kodi para verla.', ms=3500)
        _refresh()
    else:
        accessibility.notify('No se pudo cambiar la URL.', xbmcgui.NOTIFICATION_WARNING, 2500)


def _op_copy_url(path):
    if not path:
        return
    clipboard.set(path)
    accessibility.notify('URL copiada al portapapeles.', ms=2500)


def _op_qr_url(name, path):
    if not path:
        accessibility.notify('Esta fuente no tiene URL.', xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    qr_dialog.show(name or 'Fuente', path)


def _op_sources_options():
    filter_label = 'Solo activas: ON (mostrar todas)' if _active_filter() else 'Solo activas: OFF (solo activas)'
    options = [
        'Cambiar orden de la lista',
        filter_label,
        'Verificar todas las fuentes HTTP ahora...',
        'Exportar fuentes a un archivo...',
        'QR del pack completo (compartir todas)...',
        'Importar fuentes desde un archivo...',
        'Importar fuentes desde una URL...',
        'Restaurar copia de seguridad...',
    ]
    idx = xbmcgui.Dialog().select('Opciones de fuentes', options)
    if idx == 0:
        _op_change_sort_mode()
    elif idx == 1:
        _op_toggle_active_filter()
    elif idx == 2:
        _op_verify_all()
    elif idx == 3:
        _op_export_sources()
    elif idx == 4:
        _op_qr_all_sources()
    elif idx == 5:
        _op_import_sources()
    elif idx == 6:
        _op_import_from_url()
    elif idx == 7:
        _op_restore_backup()


def _op_change_sort_mode():
    current = _sort_mode()
    idx = xbmcgui.Dialog().select(
        'Orden de las fuentes', list(_SORT_LABELS), preselect=current,
    )
    if idx < 0 or idx == current:
        return
    xbmcaddon.Addon().setSetting('file_browser.sort_mode', str(idx))
    accessibility.notify(f'Orden: {_SORT_LABELS[idx]}', ms=2000)
    _refresh()


def _op_toggle_active_filter():
    win = xbmcgui.Window(10000)
    active = win.getProperty(_FILTER_PROP) == '1'
    win.setProperty(_FILTER_PROP, '' if active else '1')
    label = 'Filtro desactivado: mostrando todas las fuentes' if active else 'Filtro activo: solo fuentes alcanzables'
    accessibility.notify(label, ms=2500)
    _refresh()


def _write_share_token(token):
    data = {
        'token': token,
        'expires_at': time.time() + 3600,
    }
    path = xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.program.loiolink/sources_share_token.json'
    )
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Atomic write: si se interrumpe a mitad, el .json final no queda
    # con JSON parcial (el validador del server lee y haría fallback a
    # ValueError → 403, lo que invalidaría tokens legítimos previos).
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def _op_qr_all_sources():
    from lib.remote import api as _remote_api
    base = _remote_api.start_remote()
    if not base:
        accessibility.notify(
            'El servidor del panel no está activo. Actívalo en los settings.',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return
    import uuid
    token = uuid.uuid4().hex
    _write_share_token(token)
    url = f'{base}/api/sources-export?share={token}'
    qr_dialog.show('Pack de fuentes (1h)', url)


def _op_export_sources():
    all_items = sources.list_files_sources()
    if not all_items:
        accessibility.notify('No hay fuentes para exportar.', ms=2500)
        return
    labels = [f'{s["name"]}  [COLOR grey]{s["path"]}[/COLOR]' for s in all_items]
    selected = xbmcgui.Dialog().multiselect('Selecciona fuentes a exportar', labels)
    if selected is None:
        return
    items = [all_items[i] for i in selected] if selected else all_items
    if not items:
        accessibility.notify('No hay fuentes seleccionadas.', ms=2500)
        return
    dest_dir = xbmcgui.Dialog().browse(3, 'Carpeta destino del export', 'files')
    if not dest_dir:
        return
    payload = {
        'addon': 'plugin.program.loiolink',
        'version': 1,
        'exported_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'sources': items,
    }
    fname = f'loiolink_fuentes_{time.strftime("%Y%m%d_%H%M%S")}.json'
    dest_path = _norm(dest_dir) + fname
    try:
        with open(xbmcvfs.translatePath(dest_path), 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
    except OSError as e:
        log.warning(f'export_sources: no se pudo escribir: {type(e).__name__}')
        log.sensitive(f'export_sources: dest={dest_path} err={e!r}')
        accessibility.notify(
            f'No se pudo exportar: {e}', xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return
    accessibility.notify(f'Exportadas {len(items)} fuentes a {fname}', ms=4000)


def _process_import_payload(payload):
    raw = payload.get('sources') if isinstance(payload, dict) else None
    if not isinstance(raw, list):
        accessibility.notify(
            'El JSON no tiene la clave "sources" con una lista.',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return

    incoming = []
    for it in raw:
        if not isinstance(it, dict):
            continue
        n = (it.get('name') or '').strip()
        p = (it.get('path') or '').strip()
        if n and p:
            incoming.append({'name': n, 'path': p})
    if not incoming:
        accessibility.notify('No hay fuentes válidas en el JSON.', ms=3000)
        return

    existing = sources.list_files_sources()
    existing_urls = {url_utils.normalize_for_compare(s['path']) for s in existing}
    existing_names = {s['name'] for s in existing}

    to_add = []
    for it in incoming:
        if url_utils.normalize_for_compare(it['path']) in existing_urls:
            continue
        name = it['name'] if it['name'] not in existing_names else f'{it["name"]} (import)'
        to_add.append({'name': name, 'path': it['path']})

    skipped = len(incoming) - len(to_add)
    if not to_add:
        accessibility.notify(f'Nada que importar: las {skipped} fuentes ya existen.', ms=3500)
        return

    if not confirm(
        f'Se importarán {len(to_add)} fuentes nuevas. {skipped} se descartan '
        'porque ya existen con la misma URL. ¿Continuar?',
        title='loiolink', default_no=False,
    ):
        return

    for it in to_add:
        sources.add_source(it['name'], it['path'])
    accessibility.notify(f'Importadas {len(to_add)} fuentes. Reinicia Kodi para que las vea.', ms=4000)
    _refresh()


def _op_import_sources():
    src_path = xbmcgui.Dialog().browse(1, 'Selecciona JSON exportado', 'files', '.json')
    if not src_path or os.path.basename(src_path) == '':
        return
    try:
        with open(xbmcvfs.translatePath(src_path), 'r', encoding='utf-8') as fh:
            payload = json.load(fh)
    except (OSError, ValueError) as e:
        accessibility.notify(f'Archivo inválido: {e}', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    _process_import_payload(payload)


# --- Acciones de fuente: probar / pasar a https / instalar repo / mover ---

def _op_test_url(path):
    if not path:
        return
    if not (path.startswith('http://') or path.startswith('https://')):
        accessibility.notify(
            'Solo se puede probar URLs http/https.', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Probando {path}...')
    try:
        ok, info = url_utils.test_http_reachable(path, timeout=5)
    finally:
        progress.close()
    icon = xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING
    accessibility.notify(f'{"OK" if ok else "FALLO"}: {info}', icon, 4000)


def _op_https_upgrade(name, path):
    if not name or not path:
        return
    new_url = url_utils.to_https(path)
    if not new_url:
        accessibility.notify(
            'Esta fuente ya no es http://.', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Probando {new_url}...')
    try:
        ok, info = url_utils.test_http_reachable(new_url, timeout=5)
    finally:
        progress.close()
    if not ok:
        accessibility.notify(
            f'La versión HTTPS no responde ({info}). Se mantiene la actual.',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        return
    if not confirm(
        f'La versión HTTPS responde correctamente.\n\n'
        f'¿Cambiar la URL a "{new_url}"?',
        title='loiolink', default_no=False,
    ):
        return
    if sources.change_source_url(name, new_url):
        source_state.remove(path)
        accessibility.notify('URL migrada a HTTPS. Reinicia Kodi para verla.', ms=3500)
        _refresh()
    else:
        accessibility.notify('No se pudo migrar.', xbmcgui.NOTIFICATION_WARNING, 2500)


_REPO_ZIP_PATTERNS = (
    '{base}{id}/{id}-{version}.zip',
    '{base}{id}-{version}.zip',
    '{base}zips/{id}/{id}-{version}.zip',
)


def _find_repo_zip_url(source_url, addon_id, version, timeout=4):
    """Prueba los layouts comunes hasta encontrar el .zip del repo."""
    base = source_url if source_url.endswith('/') else source_url + '/'
    for tpl in _REPO_ZIP_PATTERNS:
        candidate = tpl.format(base=base, id=addon_id, version=version)
        ok, _info = url_utils.test_http_reachable(candidate, timeout=timeout)
        if ok:
            return candidate
    return None


def _op_install_repo(name, path):
    if not path:
        return
    if not (path.startswith('http://') or path.startswith('https://')):
        accessibility.notify(
            'Solo se puede instalar desde fuentes HTTP/HTTPS.',
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    st = source_state.get(path) or {}
    addons_map = st.get('last_seen_addons') or {}
    repos_found = sorted(
        (aid, ver) for aid, ver in addons_map.items() if aid.startswith('repository.')
    )
    if not repos_found:
        accessibility.notify(
            'Esta fuente no expone ningún repository.* en su addons.xml. '
            'Abre el gestor de fuentes y vuelve a escanear si crees que es un error.',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        return

    if len(repos_found) == 1:
        addon_id, version = repos_found[0]
    else:
        labels = [f'{aid} ({ver})' for aid, ver in repos_found]
        idx = xbmcgui.Dialog().select(
            f'Repositorios disponibles en "{name}"', labels,
        )
        if idx < 0:
            return
        addon_id, version = repos_found[idx]

    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Buscando .zip de {addon_id} en {path}...')
    try:
        zip_url = _find_repo_zip_url(path, addon_id, version)
    finally:
        progress.close()
    if not zip_url:
        accessibility.notify(
            f'No se encontró el .zip de {addon_id} en los layouts conocidos. '
            'Instálalo a mano desde el file manager de Kodi.',
            xbmcgui.NOTIFICATION_WARNING, 6000,
        )
        return

    if not confirm(
        f'¿Descargar e instalar el repositorio "{addon_id}" v{version} desde:\n'
        f'{zip_url}?',
        title='loiolink', default_no=False,
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Instalando {addon_id}...')

    def _cb(downloaded, total):
        if progress.iscanceled():
            raise InterruptedError()
        if total:
            pct = int(downloaded * 100 / total)
            progress.update(pct, f'{downloaded // 1024} / {total // 1024} KB')
        else:
            progress.update(0, f'{downloaded // 1024} KB')

    try:
        from lib import installer
        ok = installer.install_from_repo_zip_url(
            zip_url, repo_id=addon_id, addon_id=addon_id, progress_cb=_cb,
        )
    except InterruptedError:
        return
    except Exception as e:
        log.error(f'install_repo: fallo durante install_from_repo_zip_url: {e!r}')
        ok = False
    finally:
        progress.close()

    if ok:
        accessibility.notify(f'Repositorio {addon_id} instalado.', ms=4000)
    else:
        accessibility.notify(
            f'No se pudo instalar {addon_id}. Revisa el log.',
            xbmcgui.NOTIFICATION_WARNING, 4500,
        )


def _op_move_source(name, direction):
    if not name:
        return
    if sources.move_source(name, direction):
        _refresh()
    else:
        accessibility.notify(
            'Ya está en el extremo de la lista.',
            xbmcgui.NOTIFICATION_INFO, 2000,
        )


# --- Acciones de archivo: info / crear carpeta / QR de subida ---

def _format_size(n):
    units = ('B', 'KB', 'MB', 'GB', 'TB')
    i = 0
    f = float(n)
    while f >= 1024 and i < len(units) - 1:
        f /= 1024
        i += 1
    return f'{f:.1f} {units[i]}' if i > 0 else f'{int(f)} B'


def _op_file_info(path):
    if not path:
        return
    is_dir = path.endswith('/')
    target = path.rstrip('/') if is_dir else path
    name = os.path.basename(target) or target

    size_str = '-'
    mtime_str = '-'
    if not is_dir:
        local = xbmcvfs.translatePath(target)
        try:
            size_str = _format_size(os.path.getsize(local))
            mtime_str = time.strftime(
                '%Y-%m-%d %H:%M', time.localtime(os.path.getmtime(local)),
            )
        except OSError as e:
            size_str = f'(no se pudo leer: {e})'

    kind_str = 'Carpeta' if is_dir else (_media_kind(name) or 'Archivo').capitalize()
    lines = [
        f'Nombre: {name}',
        f'Tipo: {kind_str}',
        f'Ruta: {path}',
        f'Tamaño: {size_str}',
        f'Modificado: {mtime_str}',
    ]
    xbmcgui.Dialog().ok(name, '\n'.join(lines))


def _op_mkdir(path):
    if not path:
        return
    folder = xbmcgui.Dialog().input('Nombre de la nueva carpeta')
    if not folder:
        return
    if not _is_valid_name(folder):
        accessibility.notify(
            'Nombre no válido.', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    new_dir = _norm(path) + folder + '/'
    if xbmcvfs.exists(new_dir):
        accessibility.notify('Esa carpeta ya existe.', xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    if xbmcvfs.mkdirs(new_dir):
        accessibility.notify('Carpeta creada.', ms=2000)
        _refresh()
    else:
        accessibility.notify('No se pudo crear la carpeta.', xbmcgui.NOTIFICATION_WARNING, 3000)


def _op_upload_qr_here(path):
    if not path:
        return
    xbmcaddon.Addon().setSetting('transfer.dest_folder', path)
    # Reusamos el flow ya completo del panel remoto (puerto, token, modal).
    from lib.actions import remote_qr
    remote_qr.run()


# --- Operaciones de fuentes: verificar todas / restaurar backup / favoritos / importar URL ---

def _op_verify_all():
    all_srcs = sources.list_files_sources()
    http_srcs = [s for s in all_srcs if _is_http(s['path'])]
    if not http_srcs:
        accessibility.notify('No hay fuentes HTTP para comprobar.', ms=2500)
        return

    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Comprobando fuentes...')
    results = []
    cancelled = False

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            futs = {pool.submit(url_utils.test_http_reachable, s['path'], 5): s
                    for s in http_srcs}
            total = len(futs)
            done = 0
            for fut in concurrent.futures.as_completed(futs):
                if progress.iscanceled():
                    cancelled = True
                    break
                src = futs[fut]
                try:
                    ok, _ = fut.result(timeout=0)
                except Exception:
                    ok = False
                results.append((src, ok))
                done += 1
                pct = int(done * 100 / total) if total else 0
                progress.update(pct, f'{src["name"]}\n{done}/{total}')
    finally:
        progress.close()

    now = int(time.time())
    with source_state.transaction() as state:
        for src, ok in results:
            key = source_state.path_key(src['path'])
            entry = state.get(key, {})
            entry.setdefault('path', src['path'])
            entry['name'] = src['name']
            entry['reachable'] = ok
            entry['last_check_ts'] = now
            entry['errors'] = 0 if ok else int(entry.get('errors', 0)) + 1
            state[key] = entry

    ok_n = sum(1 for _, ok in results if ok)
    fail_n = len(results) - ok_n
    skipped = len(all_srcs) - len(http_srcs)
    parts = [f'{ok_n} OK', f'{fail_n} con error']
    if skipped:
        parts.append(f'{skipped} omitidas (no HTTP)')
    if cancelled:
        parts.append('cancelado')
    accessibility.notify(', '.join(parts), ms=4000)
    _refresh()


def _op_restore_backup():
    backups = sources.list_backups()
    if not backups:
        accessibility.notify('No hay copias de seguridad disponibles.', ms=3000)
        return
    labels = []
    for bp in backups:
        fname = os.path.basename(bp)
        try:
            stamp = fname[8:23]
            dt = time.strptime(stamp, '%Y%m%d_%H%M%S')
            labels.append(time.strftime('%Y-%m-%d %H:%M:%S', dt))
        except (ValueError, IndexError):
            labels.append(fname)
    idx = xbmcgui.Dialog().select('Restaurar copia de seguridad', labels)
    if idx < 0:
        return
    if not confirm(
        f'¿Restaurar el backup del {labels[idx]}? Se guardara el estado actual antes.',
        title='loiolink', default_no=True,
    ):
        return
    if sources.restore_backup(backups[idx]):
        accessibility.notify('Backup restaurado. Reinicia Kodi para verlo.', ms=3500)
        _refresh()
    else:
        accessibility.notify('No se pudo restaurar.', xbmcgui.NOTIFICATION_WARNING, 3000)


def _op_toggle_favorite(path):
    if not path:
        return
    st = source_state.get(path)
    new_val = not st.get('favorite', False)
    source_state.upsert(path, favorite=new_val)
    accessibility.notify(
        'Añadida a favoritas.' if new_val else 'Quitada de favoritas.', ms=2000,
    )
    _refresh()


_IMPORT_URL_MAX_BYTES = 10 * 1024 * 1024  # 10 MB: una lista de fuentes nunca debería acercarse


def _op_import_from_url():
    url = _input_url('URL del JSON de fuentes (http:// o https://)')
    if not url:
        return
    if not (url.startswith('http://') or url.startswith('https://')):
        accessibility.notify(
            'Solo se puede importar desde URLs http/https.',
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', f'Descargando {url}...')
    try:
        req = urllib.request.Request(
            url, headers={'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)'},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            # Leemos un byte extra para distinguir "exactamente el límite"
            # de "más grande del límite" sin tragarnos GBs si el servidor
            # devuelve un blob malicioso o mal configurado.
            data = r.read(_IMPORT_URL_MAX_BYTES + 1)
        if len(data) > _IMPORT_URL_MAX_BYTES:
            accessibility.notify(
                f'JSON demasiado grande (>{_IMPORT_URL_MAX_BYTES // (1024 * 1024)} MB). '
                'Se aborta la importación.',
                xbmcgui.NOTIFICATION_WARNING, 5000,
            )
            return
        payload = json.loads(data.decode('utf-8', errors='replace'))
    except (OSError, ValueError) as e:
        accessibility.notify(
            f'No se pudo descargar o parsear: {e}', xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return
    finally:
        progress.close()
    _process_import_payload(payload)
