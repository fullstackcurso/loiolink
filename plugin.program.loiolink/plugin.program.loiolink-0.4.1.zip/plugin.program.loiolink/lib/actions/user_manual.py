import os
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui


def run():
    if xbmc.getCondVisibility('System.Platform.Android'):
        url = 'https://loiolo.io/'
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
        xbmcgui.Dialog().notification('loiolink', 'Abriendo manual de usuario...', xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'index.html')
        if not os.path.isfile(path):
            xbmcgui.Dialog().notification('loiolink', 'Manual no encontrado', xbmcgui.NOTIFICATION_ERROR, 3000)
            return
        url = Path(path).as_uri()
        import webbrowser
        try:
            ok = webbrowser.open(url)
        except webbrowser.Error:
            ok = False
        if ok:
            xbmcgui.Dialog().notification('loiolink', 'Abriendo manual de usuario...', xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().ok('loiolink', 'No se pudo abrir el navegador.\n\nPuedes consultar el manual en:\nhttps://loiolo.io/')
