"""Menú de accesibilidad.

Reúne los toggles que aplican a labels y notificaciones del addon. Usa
el menú propio del addon (lib.ui_select.menu): cada entrada muestra el
valor actual en el label y la descripción larga en el plot, y tras
cada cambio el menú reconstruye la lista para reflejar al instante el
nuevo estado.

Las claves de setting y la semántica son las mismas que tienen topzilla
y espadaily, así un usuario que ya viene de esos addons no tiene que
aprender un esquema nuevo.
"""
import os

import xbmcaddon

from lib.ui_select import SelectItem, menu


_ADDON = xbmcaddon.Addon()
_MENU_ICONS = os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'media', 'menu')


def _icon_path(filename):
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


_COLOR_LABELS = (
    'Sin modificar',
    'Texto blanco',
    'Daltónico rojo-verde',
    'Daltónico azul-amarillo',
    'Alto contraste fondo oscuro',
    'Alto contraste fondo claro',
)

_NOTIF_LABELS = (
    'Normal',
    'Larga (x2)',
    'Muy larga (x4)',
)

# Presets del margen de seguridad TV. Cada pulsación salta al siguiente y
# vuelve a 0 tras el máximo. Coincide con el range del slider en settings.xml.
_SA_PRESETS = (0, 2, 4, 6, 8, 10, 12)


def _get_int(key, default=0):
    raw = _ADDON.getSetting(key) or str(default)
    try:
        return int(raw)
    except ValueError:
        return default


def _get_bool(key, default=False):
    raw = _ADDON.getSetting(key)
    if not raw:
        return default
    return raw == 'true'


def _on_off(v):
    if v:
        return '[COLOR green]Activado[/COLOR]'
    return '[COLOR red]Desactivado[/COLOR]'


def _cycle_color_mode():
    cur = _get_int('acc_color_mode')
    nxt = (cur + 1) % len(_COLOR_LABELS)
    _ADDON.setSetting('acc_color_mode', str(nxt))


def _cycle_notif_multiplier():
    cur = _get_int('acc_notif_multiplier')
    nxt = (cur + 1) % len(_NOTIF_LABELS)
    _ADDON.setSetting('acc_notif_multiplier', str(nxt))


def _cycle_safe_area():
    cur = _get_int('ui.tv_safe_area', default=4)
    # Siguiente preset estrictamente mayor; si ya está en el máximo, vuelve a 0.
    nxt = next((p for p in _SA_PRESETS if p > cur), 0)
    _ADDON.setSetting('ui.tv_safe_area', str(nxt))


def _toggle(key):
    _ADDON.setSettingBool(key, not _ADDON.getSettingBool(key))


def _build_items():
    items = []

    color_idx = _get_int('acc_color_mode')
    color_label = _COLOR_LABELS[color_idx] if 0 <= color_idx < len(_COLOR_LABELS) else _COLOR_LABELS[0]
    items.append(SelectItem(
        label=f'Modo de color: {color_label}',
        plot='Reescribe los colores que el addon usa en sus labels para adaptarlos a quien '
             'tiene daltonismo o necesita alto contraste. El modo "Sin modificar" deja todo '
             'como está. Los modos daltónicos sustituyen rojos/verdes o azules/amarillos por '
             'tonos que sí se distinguen entre sí. Los modos de alto contraste fuerzan '
             'amarillo sobre fondo oscuro o negro sobre fondo claro, útiles cuando se ve '
             'desde lejos o con poca luz.',
        icon=_icon_path('color_mode.png'),
        action=_cycle_color_mode,
    ))

    bold = _get_bool('acc_force_bold', default=True)
    items.append(SelectItem(
        label=f'Negrita forzada en los labels: {_on_off(bold)}',
        plot='Envuelve todos los labels del addon en negrita. Si lo desactivas, '
             'los textos se ven en peso normal. Útil para mejorar la legibilidad '
             'desde lejos o cuando el skin usa una tipografía de trazo fino.',
        icon=_icon_path('bold.png'),
        action=lambda: _toggle('acc_force_bold'),
    ))

    strip = _get_bool('acc_strip_symbols')
    items.append(SelectItem(
        label=f'Sustituir símbolos especiales: {_on_off(strip)}',
        plot='Cambia caracteres decorativos (estrellas, viñetas, flechas, marcas de '
             'verificación, comillas angulares) por equivalentes en ASCII normal '
             '(*, -, ->, OK, <<, >>). Algunos skins de Kodi no tienen glifos para estos '
             'símbolos y los pintan como cuadrados vacíos, así que esta opción los hace '
             'legibles a costa de perder algo de estética.',
        icon=_icon_path('symbols.png'),
        action=lambda: _toggle('acc_strip_symbols'),
    ))

    fs = _get_bool('acc_font_size')
    items.append(SelectItem(
        label=f'Texto de los labels en mayúsculas: {_on_off(fs)}',
        plot='Envuelve los labels con la marca de mayúsculas de Kodi para que el skin los '
             'pinte en caja alta. Mejora la legibilidad cuando se lee desde lejos en pantallas '
             'grandes. El cambio es visual; los textos guardados internamente no se modifican.',
        icon=_icon_path('uppercase.png'),
        action=lambda: _toggle('acc_font_size'),
    ))

    notif_idx = _get_int('acc_notif_multiplier')
    notif_label = _NOTIF_LABELS[notif_idx] if 0 <= notif_idx < len(_NOTIF_LABELS) else _NOTIF_LABELS[0]
    items.append(SelectItem(
        label=f'Duración de las notificaciones: {notif_label}',
        plot='Multiplica el tiempo que cada notificación del addon permanece visible. En '
             'modo normal Kodi las muestra unos pocos segundos, en larga el doble y en muy '
             'larga el cuádruple. Sirve cuando la lectura rápida cuesta y se prefiere tener '
             'tiempo de sobra para enterarse del mensaje antes de que se vaya.',
        icon=_icon_path('notification.png'),
        action=_cycle_notif_multiplier,
    ))

    confirm = _get_bool('acc_confirm_destructive', default=True)
    items.append(SelectItem(
        label=f'Pedir confirmación antes de acciones destructivas: {_on_off(confirm)}',
        plot='Cuando está activo, el addon muestra un cuadro de sí/no antes de regenerar '
             'el token de control remoto, eliminar una fuente o cualquier otra acción que '
             'no se pueda deshacer fácilmente. Desactivarlo agiliza el uso para quien tiene '
             'el flujo memorizado y prefiere no ver el cuadro cada vez.',
        icon=_icon_path('shield.png'),
        action=lambda: _toggle('acc_confirm_destructive'),
    ))

    sa = _get_int('ui.tv_safe_area', default=4)
    items.append(SelectItem(
        label=f'Margen de seguridad TV (overscan): {sa}%',
        plot='Algunos televisores recortan los bordes de la imagen (overscan) y el contenido '
             'de las ventanas propias del addon se sale por un lado. Este margen mete el panel '
             'hacia dentro ese porcentaje para que se vea entero. Súbelo si en tu tele se corta; '
             'déjalo en 0 si no tienes el problema. El cambio se aplica la próxima vez que abras '
             'una ventana. Para verlo en vivo usa Debug > Diagnóstico de ventanas (borde cian).',
        icon=_icon_path('uppercase.png'),
        action=_cycle_safe_area,
    ))

    return items


def run():
    menu('Accesibilidad - loiolink', _build_items)
