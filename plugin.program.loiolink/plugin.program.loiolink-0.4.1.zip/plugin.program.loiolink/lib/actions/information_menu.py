"""Submenu 'Información': punto de entrada para loioloio addons y datos del addon."""
import os
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from lib import accessibility, i18n


_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if sys.argv else 'plugin://plugin.program.loiolink/'
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
_MENU_ICONS = os.path.join(_ADDON_PATH, 'resources', 'media', 'menu')


def _icon(filename):
    p = os.path.join(_MENU_ICONS, filename)
    return p if os.path.isfile(p) else None


def _item(label, action, plot='', icon=None, is_folder=False):
    li = xbmcgui.ListItem(accessibility.apply_label(label))
    if plot:
        li.setInfo('video', {'plot': plot, 'mediatype': 'video'})
    icon_p = _icon(icon) if icon else None
    if icon_p:
        li.setArt({'icon': icon_p, 'thumb': icon_p})
    url = f'{_BASE_URL}?action={action}'
    xbmcplugin.addDirectoryItem(handle=_HANDLE, url=url, listitem=li, isFolder=is_folder)


def run():
    _item(
        i18n.L(30042),
        'about',
        plot=(
            'Muestra la versión instalada, quién mantiene el addon y el estado de los '
            'repositorios que conoce. Desde la misma ventana puedes lanzar un escaneo '
            'de actualizaciones de los repositorios instalados.'
        ),
        icon='info.png',
    )
    _item(
        i18n.L(30043),
        'loioloio_addons_menu',
        plot=(
            'Instaladores de los addons del ecosistema loioloio: FlowFav y LoioLog. '
            'Descarga e instala automáticamente el repositorio y el addon en un solo paso. '
            'Si ya están instalados, los abre directamente.'
        ),
        icon='loioloio_addons.png',
        is_folder=True,
    )
    _item(
        i18n.L(30044),
        'loioloio_about',
        plot='Información de autoría del ecosistema loioloio.',
        icon='about.png',
    )
    _item(
        i18n.L(30045),
        'open_user_manual',
        plot='Abre la guía de usuario de loiolink en el navegador.',
        icon='manual.png',
    )
    _item(
        f'[COLOR skyblue]{i18n.L(30046)}[/COLOR]',
        'show_universo',
        plot=(
            'Ventana con los enlaces del ecosistema EspaKodi: contacto del '
            'desarrollador, canales de Telegram y web del proyecto.'
        ),
        icon='info_universo.png',
    )
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=True, cacheToDisc=False)
