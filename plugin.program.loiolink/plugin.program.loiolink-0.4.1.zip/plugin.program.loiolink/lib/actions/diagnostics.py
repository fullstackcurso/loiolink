"""Acción 'Diagnóstico / Logs': lanza LoioLog o lo instala si no está.

LoioLog es el gestor de logs avanzado del ecosistema EspaKodi (ver/filtrar/
buscar/exportar logs de Kodi). Patrón heredado de plugin.video.espadaily
(constantes _EK_LOIOLOG_*).

En lugar de reimplementar un visor propio, delegamos a LoioLog (mi propio
addon) que ya existe y mantengo aparte. Si no está instalado, ofrecemos
instalarlo con el flow estándar (repo + InstallAddon).
"""
import xbmc
import xbmcaddon
import xbmcgui

from lib import installer, log
from lib.ui_select import info


LOIOLOG_ID = 'plugin.program.loiolog'
LOIOLOG_REPO_ID = 'repository.loiolog'
_DEFAULT_REPO_URL = (
    'https://raw.githubusercontent.com/loioloio/loiolog/'
    'main/repository.loiolog-1.0.0.zip'
)


def _get_repo_url():
    try:
        override = (xbmcaddon.Addon().getSetting(
            'loiolog_repo_url_override',
        ) or '').strip()
    except RuntimeError:
        override = ''
    if override and not override.lower().startswith(('http://', 'https://')):
        log.warning(f'Override de repo inválido (no http/https): {override!r}')
        override = ''
    return override or _DEFAULT_REPO_URL


def is_installed():
    return installer.is_ready(LOIOLOG_ID)


def run():
    if installer.is_ready(LOIOLOG_ID):
        xbmc.executebuiltin(f'RunAddon({LOIOLOG_ID})')
        return

    # Si está instalado pero deshabilitado, recuperarlo sin red.
    if installer.try_recover(LOIOLOG_ID):
        xbmcgui.Dialog().notification(
            'loiolink', 'LoioLog reactivado correctamente',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        xbmc.executebuiltin(f'RunAddon({LOIOLOG_ID})')
        return

    idx = xbmcgui.Dialog().select(
        'LoioLog',
        ['Instalar automáticamente', 'Ver instrucciones manuales'],
    )
    if idx == -1:
        return
    if idx == 1:
        xbmcgui.Dialog().textviewer(
            'Cómo instalar LoioLog',
            '[B]Cómo instalar LoioLog[/B]\n\n'
            'Visor avanzado de logs de Kodi: filtra, busca, analiza y exporta.\n\n'
            '1. Ajustes -> Sistema -> Addons -> activa Orígenes desconocidos\n\n'
            '2. Ajustes -> Explorador de archivos -> Añadir fuente:\n'
            '   https://loiolo.io/loiolog/\n'
            '   (alternativa: loioloio.github.io/loiolog/)\n\n'
            '3. Ajustes -> Addons -> Instalar desde un archivo zip -> LoioLog\n'
            '   -> repository.loiolog-x.x.x.zip\n\n'
            '4. Instalar desde repositorio -> LoioLog Repository\n'
            '   -> Addons de programa -> LoioLog',
        )
        return

    dp = xbmcgui.DialogProgress()
    dp.create('loiolink', 'Descargando repositorio LoioLog...')

    def download_cb(done, total):
        if dp.iscanceled():
            raise InterruptedError()
        if total:
            dp.update(int(done * 55 / total), f'{done // 1024} KB / {total // 1024} KB')
        else:
            dp.update(0, f'{done // 1024} KB')

    def repo_status(pct, msg):
        dp.update(55 + int(pct * 0.40), msg)

    try:
        ok = installer.download_and_install_repo(
            _get_repo_url(), LOIOLOG_REPO_ID,
            progress_cb=download_cb,
            status_cb=repo_status,
        )
    except InterruptedError:
        return
    except installer.InstallError as e:
        log.error(f'InstallError LoioLog: {e}')
        info(f'Error de instalación: {e}', title='loiolink')
        return
    finally:
        dp.close()

    if not ok:
        info(
            'El repositorio de LoioLog no se instaló.\n\n'
            'Verifica que "Orígenes desconocidos" está activo en '
            'Ajustes -> Sistema -> Addons.',
            title='loiolink',
        )
        return

    xbmcgui.Dialog().notification(
        'loiolink', 'Confirmando instalación de LoioLog...',
        xbmcgui.NOTIFICATION_INFO, 4000,
    )

    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Instalando LoioLog...')

    def addon_status(pct, msg):
        bg.update(pct, 'loiolink', msg)

    try:
        ok = installer.install_addon_from_repo(
            LOIOLOG_ID, repo_id=LOIOLOG_REPO_ID, status_cb=addon_status,
        )
    finally:
        bg.close()

    if ok:
        from lib import accessibility
        accessibility.notify('LoioLog instalado', ms=2500)
        xbmc.executebuiltin(f'RunAddon({LOIOLOG_ID})')
    else:
        info(
            'No se pudo instalar LoioLog automáticamente.\n\n'
            'Pruébalo desde: Addons -> Instalar desde repositorio.',
            title='loiolink',
        )
