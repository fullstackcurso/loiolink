"""Gestor de fuentes y repositorios.

Aglutina dos cosas que en Kodi son distintas pero conceptualmente cercanas:

- Fuentes (sources.xml): las direcciones que el usuario añade desde
  "Añadir fuente" del file manager para luego instalar repos o ver archivos.
  El gestor ofrece añadir, renombrar, eliminar y revisar cambios en cada
  fuente.

- Repositorios instalados (addons de tipo repository.*): el gestor
  permite escanear todos los repos a la vez y listar qué addons tienen
  versión nueva disponible.

La detección de cambios y el escaneo NO ocurren al arrancar Kodi ni al
abrir el addon, solo al entrar a este gestor. Cero notificaciones cuando
el usuario está fuera. Cuando hay cambios pendientes, la primera entrada
del menú es un resumen "Hay N fuentes con cambios desde tu última visita".
"""
import concurrent.futures
import hashlib
import os
import time
import urllib.error
import urllib.request

import xbmcaddon
import xbmcgui

from lib import (
    accessibility, github_pages, log, repos, source_state, source_status, sources, url_utils,
)
from lib.ui_select import CloseMenu, SelectItem, confirm, menu, select


_FETCH_TIMEOUT = 10
_SCAN_TOTAL_TIMEOUT = 30
_SCAN_WORKERS = 4
_MENU_ICONS = os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'menu',
)


def _icon_path(filename):
    if not filename:
        return None
    full = os.path.join(_MENU_ICONS, filename)
    return full if os.path.isfile(full) else None


def _http_only(path):
    return path.startswith('http://') or path.startswith('https://')


def _fetch_addons_xml(path):
    """Descarga addons.xml de la fuente. Devuelve (texto, error_str|None)."""
    url = path if path.endswith('/') else path + '/'
    url += 'addons.xml'
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; loiolink/0.3)',
    })
    try:
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as r:
            return (r.read().decode('utf-8', errors='replace'), None)
    except (urllib.error.URLError, OSError, ValueError) as e:
        return (None, str(e))


def _check_source(source):
    """Comprueba una sola fuente. Diseñado para ejecutarse en thread."""
    name = source['name']
    path = source['path']

    if not _http_only(path):
        return {'name': name, 'path': path, 'kind': 'local',
                'change': False, 'error': None}

    text, err = _fetch_addons_xml(path)
    if err:
        return {'name': name, 'path': path, 'kind': None,
                'change': False, 'error': err}

    if not repos.looks_like_addons_xml(text):
        return {'name': name, 'path': path, 'kind': 'generic',
                'change': False, 'error': None}

    new_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
    prev = source_state.get(path)
    old_hash = prev.get('last_hash')
    addons_map = repos.parse_addons_xml(text)
    return {
        'name': name, 'path': path, 'kind': 'repo',
        'change': bool(old_hash and old_hash != new_hash),
        'new_hash': new_hash,
        'addons': addons_map,
        'prev_addons': prev.get('last_seen_addons', {}),
        'error': None,
    }


def _scan_sources(items):
    """Escaneo paralelo con timeout total. Devuelve lista de resultados."""
    progress = xbmcgui.DialogProgress()
    progress.create('loiolink', 'Comprobando fuentes...')
    results = []
    cancelled = False
    deadline = time.time() + _SCAN_TOTAL_TIMEOUT

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
            futures = {pool.submit(_check_source, s): s for s in items}
            total = len(futures)
            done = 0
            for fut in concurrent.futures.as_completed(futures):
                if progress.iscanceled() or time.time() > deadline:
                    cancelled = True
                    break
                src = futures[fut]
                try:
                    results.append(fut.result(timeout=0))
                except Exception as e:  # un fallo en una fuente no aborta el lote
                    log.warning(f'scan: fuente {src["name"]!r} falló: {e!r}')
                    results.append({'name': src['name'], 'path': src['path'],
                                    'kind': None, 'change': False,
                                    'error': str(e)})
                done += 1
                pct = int(done * 100 / total) if total else 0
                progress.update(pct, f'{src["name"]}\n{done}/{total}')
    finally:
        progress.close()

    if cancelled:
        log.info(f'scan cancelado, {len(results)}/{len(items)} fuentes comprobadas')
    return results


def _persist_results(results):
    """Actualiza source_state.json con los resultados del escaneo.

    Usa `transaction()` para aplicar todos los cambios en una sola
    operación atómica (1 read + 1 write en disco, sin race entre items).
    """
    now = int(time.time())
    max_diff_age_s = 30 * 24 * 3600
    with source_state.transaction() as state:
        for r in results:
            path = r['path']
            key = source_state.path_key(path)
            entry = state.get(key, {})
            entry.setdefault('path', path)
            entry['name'] = r['name']
            if r.get('error'):
                entry['errors'] = int(entry.get('errors', 0)) + 1
                entry['last_check_ts'] = now
                entry['reachable'] = False
                state[key] = entry
                continue
            if r['kind'] == 'local':
                entry['kind'] = 'local'
                entry['errors'] = 0
                entry['reachable'] = True
                state[key] = entry
                continue
            if r['kind'] == 'generic':
                entry['kind'] = 'generic'
                entry['errors'] = 0
                entry['reachable'] = True
                entry['last_check_ts'] = now
                state[key] = entry
                continue
            # repo monitorizado
            entry['kind'] = 'repo'
            entry['errors'] = 0
            entry['reachable'] = True
            entry['last_check_ts'] = now
            entry['last_hash'] = r['new_hash']
            entry['last_seen_addons'] = r['addons']
            if r['change']:
                entry['acknowledged'] = False
                # Guardamos el snapshot anterior para poder mostrar el diff cuando
                # el usuario abra el detail. Si no lo guardamos aquí, la siguiente
                # línea sobrescribe last_seen_addons y se pierde la información.
                entry['prev_seen_addons'] = r.get('prev_addons', {})
                history = [
                    h for h in entry.get('diff_history', [])
                    if now - h.get('ts', 0) < max_diff_age_s
                ]
                history.append({'ts': now, 'prev': r.get('prev_addons', {}), 'current': r['addons']})
                entry['diff_history'] = history[-5:]
            state[key] = entry


_status_tag = source_status.status_tag
_source_icon = source_status.status_icon


def _close():
    raise CloseMenu()


def _ack_source(path):
    source_state.mark_acknowledged(path)
    accessibility.notify('Fuente marcada como revisada', ms=2000)


def _action_add_source():
    choice = select('¿Cómo quieres añadir la fuente?', [
        SelectItem(
            label='Repositorio de GitHub Pages',
            plot='Asistente para repos alojados en GitHub Pages. Solo escribes el '
                 'usuario y el nombre del repositorio; el https://, el .github.io y '
                 'la barra final los pone el addon.',
            icon=_icon_path('wizard.png'),
        ),
        SelectItem(
            label='Escribir la URL completa o una ruta',
            plot='Introduces la dirección entera a mano: una URL http(s):// de '
                 'cualquier servidor, o una ruta smb://, nfs:// o local.',
            icon=_icon_path('url.png'),
        ),
    ])
    if choice < 0:
        return

    if choice == 0:
        result = github_pages.prompt_source_url()
        if not result:
            return
        url, suggested = result
    else:
        url = xbmcgui.Dialog().input('URL de la fuente (http:// o https://)')
        if not url:
            return
        suggested = url_utils.suggest_source_name(url)

    if not _http_only(url) and not url.startswith(('smb://', 'nfs://', '/', '\\')):
        if not confirm(
            f'La URL "{url}" no parece http/https. ¿Añadirla igualmente?',
            title='loiolink',
            default_no=True,
        ):
            return

    name = xbmcgui.Dialog().input('Nombre de la fuente', defaultt=suggested)
    if not name:
        return

    sources.add_source(name, url)
    # Fetch inicial dentro de un DialogProgress para que la fuente aparezca
    # ya clasificada en la lista en vez de quedar [Sin comprobar] hasta el
    # siguiente scan automático. Sin progress el UI queda bloqueado hasta 10s
    # sin feedback visual.
    if _http_only(url):
        progress = xbmcgui.DialogProgress()
        progress.create('loiolink', f'Comprobando {url}...')
        try:
            _persist_results([_check_source({'name': name, 'path': url})])
        finally:
            progress.close()
    accessibility.notify('Fuente añadida. Reinicia Kodi para que la vea.', ms=3500)


def _rename_source(old_name):
    new_name = xbmcgui.Dialog().input('Nuevo nombre', defaultt=old_name)
    if not new_name or new_name == old_name:
        return
    # El path lo necesitamos para mantener sincronizado el name en state.
    path = None
    for src in sources.list_files_sources():
        if src['name'] == old_name:
            path = src['path']
            break
    if sources.rename_source(old_name, new_name):
        if path:
            source_state.upsert(path, name=new_name)
        accessibility.notify('Fuente renombrada. Reinicia Kodi.', ms=3000)
        # Cerramos el detail para que la próxima vista del submenú refleje
        # el nombre nuevo. Si no, el título y los labels del detail
        # seguirían con el nombre viejo hasta navegar fuera.
        raise CloseMenu()
    accessibility.notify(
        'No se pudo renombrar', xbmcgui.NOTIFICATION_WARNING, 2500,
    )


def _remove_source(name):
    if not accessibility.confirm_destructive(
        f'¿Eliminar la fuente "{name}" del sources.xml?',
    ):
        return
    # Capturamos el path ANTES de borrar la entrada del XML para poder limpiar
    # también su entry en source_state. Si solo borráramos del XML, la entry
    # del state quedaría huérfana ocupando espacio para siempre.
    path = None
    for src in sources.list_files_sources():
        if src['name'] == name:
            path = src['path']
            break
    if sources.remove_source(name):
        if path:
            source_state.remove(path)
        accessibility.notify('Fuente eliminada. Reinicia Kodi.', ms=3000)
        raise CloseMenu()
    accessibility.notify(
        'No se encontró la fuente', xbmcgui.NOTIFICATION_WARNING, 2500,
    )


def _action_rescan():
    items = sources.list_files_sources()
    results = _scan_sources(items)
    _persist_results(results)
    accessibility.notify(
        f'Comprobadas {len(results)}/{len(items)} fuentes', ms=2500,
    )


def _action_scan_repos():
    from lib.actions import about
    about.scan_installed_repos_ui()


# --- Submenú Backup y restauración ---

def _backup_show_text(text, title='loiolink: lista de addons'):
    xbmcgui.Dialog().textviewer(title, text)


def _friendly(e):
    """Traduce código técnico (string o Exception) a frase amigable.

    Acepta str o cualquier objeto con __str__. Si no encuentra mapping en
    el diccionario de backup.friendly_error_message, devuelve el string crudo.
    """
    from lib import backup
    try:
        return backup.friendly_error_message(str(e), fallback=str(e))
    except Exception:
        return str(e)


def _format_snapshot_option(s):
    """Formato consistente para items de select dialogs de snapshots.

    Devuelve `'{filename}{origin_tag}  ({size_mb} MB · {when}){label_part}'`.
    """
    size_mb = s.get('size', 0) / (1024 * 1024)
    created = s.get('created') or 0
    when = time.strftime('%Y-%m-%d %H:%M', time.localtime(created)) if created else '?'
    label_part = f' [{s["label"]}]' if s.get('label') else ''
    origin_tag = ' [custom]' if s.get('origin') == 'custom' else ''
    return f'{s.get("filename", "?")}{origin_tag}  ({size_mb:.1f} MB · {when}){label_part}'


def _render_restore_result(result, kind='restore'):
    """Muestra notif resumen + textviewer detallado si hay fallos/skipped.

    `kind`: 'restore' o 'install' (afecta texto del notif resumen).
    Detecta categorías que requieren reinicio Kodi y avisa al final.
    """
    ok = len(result.get('ok') or [])
    failed = result.get('failed') or []
    skipped = result.get('skipped') or []
    verb = 'Restaurados' if kind == 'restore' else 'Instalados'
    if failed:
        accessibility.notify(
            f'{verb} {ok}, fallaron {len(failed)}',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        lines = []
        if failed:
            lines.append(f'Fallidos ({len(failed)}):')
            for f in failed[:30]:
                fid = f.get('id', '?')
                err = _friendly(f.get('error', '?'))
                lines.append(f'  - {fid}: {err}')
            if len(failed) > 30:
                lines.append(f'  ... y {len(failed) - 30} más')
        if skipped:
            if lines:
                lines.append('')
            lines.append(f'Omitidos ({len(skipped)}):')
            for s in skipped[:30]:
                sid = s.get('id', '?')
                reason = _friendly(s.get('reason', '?'))
                lines.append(f'  - {sid}: {reason}')
            if len(skipped) > 30:
                lines.append(f'  ... y {len(skipped) - 30} más')
        xbmcgui.Dialog().textviewer(
            f'{verb} con incidencias',
            '\n'.join(lines),
        )
    else:
        accessibility.notify(
            f'{verb} {ok} elementos',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
    # Aviso de reinicio si se aplicaron cambios que lo requieren.
    cats = result.get('categories_restored') or {}
    needs_restart = ('config_root' in cats or 'guisettings' in cats
                     or 'keymaps' in cats or 'peripheral_data' in cats)
    if needs_restart:
        xbmcgui.Dialog().ok(
            'Reinicia Kodi',
            'Se han aplicado ajustes de sistema (config, keymaps o '
            'guisettings) que requieren reiniciar Kodi para tener efecto.',
        )


def _estimate_addons_size_mb(addons_dir, ids, timeout_s=2.0):
    """Suma os.path.getsize recursivo de los `ids` bajo addons_dir.

    Devuelve int (MB) o None si tarda más de `timeout_s` (en cuyo caso
    los callers deben tratar el resultado como desconocido). Cero o
    valores muy bajos son normales en addons recién instalados sin datos.
    """
    deadline = time.time() + timeout_s
    total = 0
    for aid in ids:
        if time.time() > deadline:
            return None
        d = os.path.join(addons_dir, aid)
        if not os.path.isdir(d):
            continue
        try:
            for root, _dirs, files in os.walk(d):
                if time.time() > deadline:
                    return None
                for f in files:
                    try:
                        total += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        continue
        except OSError:
            continue
    return int(total / (1024 * 1024))


def _check_disk_space(dest_dir, needed_mb):
    """Comprueba si dest_dir tiene `needed_mb * 1.2` libres. Devuelve True si OK
    o si no se puede determinar; False solo cuando hay certeza de que no cabe.
    """
    try:
        import shutil
        free_mb = shutil.disk_usage(dest_dir).free / (1024 * 1024)
    except (OSError, ValueError):
        return True
    return free_mb >= needed_mb * 1.2


def _resolve_encrypt_password():
    """Devuelve (password, ok). Si encryption.enabled está desactivado: (None, True).

    Si está activado y hay password almacenado, lo devuelve. Si no, lo pide al
    usuario con prompt oculto. Si el user cancela el prompt cuando encryption
    está activo, devuelve (None, False) para abortar el backup.
    """
    addon = xbmcaddon.Addon()
    try:
        enabled = addon.getSettingBool('backup.encryption.enabled')
    except (RuntimeError, AttributeError):
        return None, True
    if not enabled:
        return None, True
    from lib import backup_crypto
    stored = addon.getSetting('backup.encryption.password') or ''
    if stored:
        try:
            pwd = backup_crypto.deobfuscate_password_from_storage(stored)
            if pwd:
                return pwd, True
        except Exception as e:
            # Password de backup corrupta o formato antiguo: no bloqueamos el
            # flujo (pedimos la password abajo), pero lo dejamos en el log para
            # no enmascarar una corrupción silenciosa del setting cifrado.
            log.warning(f'deobfuscate password falló, se pedirá de nuevo: {e}')
    pwd = xbmcgui.Dialog().input(
        'Password de cifrado (mínimo 8 caracteres)',
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    if not pwd or len(pwd) < 8:
        accessibility.notify('Password vacío o demasiado corto; backup cancelado',
                             xbmcgui.NOTIFICATION_WARNING, 3500)
        return None, False
    return pwd, True


def _notify_backup_created(filename):
    """Notif corta + dialog OK con ruta absoluta y tamaño del backup creado."""
    from lib import backup
    accessibility.notify(f'Backup creado: {filename}',
                         xbmcgui.NOTIFICATION_INFO, 3500)
    path = backup.snapshot_path(filename)
    folder = os.path.dirname(path)
    try:
        size_mb = os.path.getsize(path) / (1024 * 1024)
        size_line = f'\nTamaño: {size_mb:.1f} MB'
    except OSError:
        size_line = ''
    xbmcgui.Dialog().ok(
        'Backup creado',
        f'{filename}\n\nCarpeta:\n{folder}{size_line}',
    )


def _show_snapshot_details(snap):
    """Dialog OK con info completa de un snapshot."""
    from lib import backup
    filename = snap.get('filename', '?')
    full_path = backup.snapshot_path(filename)
    size_mb = snap.get('size', 0) / (1024 * 1024)
    created = snap.get('created') or 0
    when = (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(created))
            if created else '?')
    origin = snap.get('origin') or 'default'
    lines = [
        f'Archivo: {filename}',
        f'Ruta: {full_path}',
        f'Origen: {origin}',
        f'Tamaño: {size_mb:.2f} MB',
        f'Fecha: {when}',
    ]
    if snap.get('label'):
        lines.append(f'Etiqueta: {snap["label"]}')
    xbmcgui.Dialog().ok('Detalles del backup', '\n'.join(lines))


def _confirm_kodi_version_mismatch(zip_path):
    """Si la versión Kodi del backup no coincide con la actual, pide confirmar.

    Devuelve True si se puede continuar (sin mismatch o confirmado), False si
    el usuario cancela. Si el manifest no es legible devuelve True (el restore
    fallará después con un mensaje más claro).
    """
    from lib import backup
    try:
        manifest = backup.load_manifest_from_zip(zip_path)
    except backup.BackupError:
        return True
    info = backup.check_kodi_version_compat(manifest)
    if not info.get('major_mismatch'):
        return True
    return xbmcgui.Dialog().yesno(
        'Aviso de versión',
        (f'Este backup se hizo en Kodi {info["backup_major"]} y estás en '
         f'Kodi {info["current_major"]}. Algunos addons o configuraciones '
         'podrían no funcionar correctamente. ¿Continuar?'),
        nolabel='Cancelar',
        yeslabel='Continuar',
    )


def _ask_password_if_encrypted(zip_path):
    """Si el backup está cifrado, pide password al usuario.

    Devuelve `(ok: bool, password: str | None)`:
      - (True, None) si el backup NO está cifrado
      - (True, '<pwd>') si está cifrado y el user introdujo password
      - (False, None) si el user canceló el prompt
      - (True, None) tolerante a errores (peek falla → restore decidirá)
    """
    from lib import backup
    try:
        manifest = backup.load_manifest_from_zip(zip_path)
    except backup.BackupError:
        return True, None
    if not manifest.get('encrypted'):
        return True, None
    # Pedir password al user
    pwd = xbmcgui.Dialog().input(
        'Backup cifrado: introduce el password',
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    if not pwd:
        return False, None
    return True, pwd


def _backup_progress_dialog(title='loiolink'):
    """Crea un DialogProgress y devuelve (dialog, progress_cb, cancel_check)."""
    dlg = xbmcgui.DialogProgress()
    dlg.create(title, 'Preparando...')

    def progress_cb(done, total, msg=''):
        try:
            if total and total > 0:
                pct = max(0, min(100, int(done * 100 / total)))
            else:
                pct = max(0, min(100, int(done)))
        except (TypeError, ValueError):
            pct = 0
        try:
            dlg.update(pct, msg or '')
        except RuntimeError:
            pass

    def cancel_check():
        try:
            return dlg.iscanceled()
        except RuntimeError:
            return False

    return dlg, progress_cb, cancel_check


def _action_backup_show_list():
    from lib import backup, backup_storage
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Generando lista de addons')
    try:
        manifest = backup.build_manifest(progress_cb=progress_cb)
    except Exception as e:
        log.error(f'[backup] build_manifest falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()

    # Guardar la lista como .txt en la carpeta del storage activo. Write
    # atómico (tmp + replace) por si hay dos generaciones simultáneas.
    saved_path = None
    try:
        backup._ensure_snapshots_dir()
        storages = backup_storage.get_active_storages(backup.SNAPSHOTS_DIR)
        write_storage = next((s for s in storages if s.writable()), None)
        root = write_storage.root_path if write_storage else backup.SNAPSHOTS_DIR
        stamp = time.strftime('%Y-%m-%d_%H%M%S')
        target = os.path.join(root, f'addons_list_{stamp}.txt')
        tmp = target + '.tmp'
        text_for_disk = backup.export_txt(manifest, saved_to_path=target)
        with open(tmp, 'w', encoding='utf-8') as fh:
            fh.write(text_for_disk)
        os.replace(tmp, target)
        saved_path = target
    except OSError as e:
        log.warning(f'[backup] no se pudo guardar lista a disco: {e!r}')

    text = backup.export_txt(manifest, saved_to_path=saved_path)
    _backup_show_text(text)
    if saved_path:
        accessibility.notify(f'Guardado: {os.path.basename(saved_path)}',
                             xbmcgui.NOTIFICATION_INFO, 3000)


def _action_backup_export_xml():
    """Genera un XML <kodi-addons> con addons y repos elegidos.

    El XML resultante lo consume "Instalar desde XML" en otro Kodi para
    reinstalar los mismos addons en cadena.
    """
    from lib import backup, backup_storage
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Analizando addons')
    try:
        manifest = backup.build_manifest(progress_cb=progress_cb)
    except Exception as e:
        log.error(f'[backup] build_manifest falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()

    addons = [a for a in manifest.get('addons', [])
              if backup.is_backupable(a['id'])]
    repo_list = manifest.get('repos', [])
    if not addons and not repo_list:
        accessibility.notify('Nada para exportar',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return

    options = []
    keys = []
    preselect = []
    for r in repo_list:
        options.append(f'[REPO] {r["id"]}  v{r.get("version", "?")}')
        keys.append(('repo', r['id']))
        preselect.append(len(options) - 1)
    for a in addons:
        name = a.get('name') or a['id']
        options.append(f'{name}  v{a.get("version", "?")}')
        keys.append(('addon', a['id']))
        preselect.append(len(options) - 1)

    chosen = xbmcgui.Dialog().multiselect(
        'Selecciona qué incluir en el XML', options, preselect=preselect,
    )
    if not chosen:
        return

    selected_addons = []
    selected_repos = []
    for idx in chosen:
        kind, aid = keys[idx]
        if kind == 'repo':
            selected_repos.append(aid)
        else:
            selected_addons.append(aid)

    try:
        # Pasamos las listas literales (NO `... or None`): el user marcó
        # explícitamente qué incluir. `repo_ids=[]` significa "ningún repo",
        # distinto de `repo_ids=None` (= todos). export_xml lo respeta en
        # su rama `if repo_ids is not None`.
        xml_text, info = backup.export_xml(
            manifest,
            addon_ids=selected_addons,
            repo_ids=selected_repos,
        )
    except Exception as e:
        log.error(f'[backup] export_xml falló: {e!r}')
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    # Si hay addons que apuntan a repos no incluidos, ofrecer auto-incluirlos.
    # Sin esto el import falla silenciosamente en el otro Kodi (los addons
    # se instalan en `failed` porque su repo no existe allí).
    orphans = info.get('orphan_addon_repos') or []
    if orphans:
        nice = ', '.join(orphans)
        if confirm(
            f'Los addons elegidos apuntan a repos no seleccionados:\n\n{nice}\n\n'
            '¿Auto-incluir esos repos en el XML? '
            'Marca "No" si ya están instalados en el Kodi de destino.',
            title='Repos huérfanos detectados',
        ):
            selected_repos = list(set(selected_repos) | set(orphans))
            try:
                xml_text, info = backup.export_xml(
                    manifest,
                    addon_ids=selected_addons,
                    repo_ids=selected_repos,
                )
            except Exception as e:
                log.error(f'[backup] export_xml (con orphans) falló: {e!r}')
                accessibility.notify(f'Error: {_friendly(e)}',
                                     xbmcgui.NOTIFICATION_WARNING, 3000)
                return

    saved_path = None
    try:
        backup._ensure_snapshots_dir()
        storages = backup_storage.get_active_storages(backup.SNAPSHOTS_DIR)
        write_storage = next((s for s in storages if s.writable()), None)
        root = write_storage.root_path if write_storage else backup.SNAPSHOTS_DIR
        stamp = time.strftime('%Y-%m-%d_%H%M%S')
        target = os.path.join(root, f'addons_install_{stamp}.xml')
        tmp = target + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            fh.write(xml_text)
        os.replace(tmp, target)
        saved_path = target
    except OSError as e:
        log.warning(f'[backup] no se pudo guardar XML a disco: {e!r}')
        accessibility.notify(f'Error guardando XML: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    warnings = []
    if info.get('skipped_repos'):
        log.warning(
            f'[backup] export_xml: repos sin URL ZIP omitidos: '
            f'{info["skipped_repos"]!r}'
        )
        nice = ', '.join(info['skipped_repos'])
        warnings.append(
            f'Repos sin URL ZIP conocida (no incluidos): {nice}. '
            'Los addons que dependan de ellos fallarán al instalarse en '
            'otro Kodi salvo que el repo ya esté instalado allí.'
        )
    if info.get('exceeds_parser_limit'):
        warnings.append(
            f'El XML ocupa {info["size_bytes"] // 1024} KB y excede el '
            f'límite de {backup.MAX_BATCH_XML_BYTES // 1024} KB del '
            'importador. No podrá reinstalarse en cadena tal cual: '
            'tendrás que dividirlo manualmente o reducir la selección.'
        )
    if warnings:
        xbmcgui.Dialog().ok(
            'XML generado con avisos', '\n\n'.join(warnings),
        )
    accessibility.notify(f'Guardado: {os.path.basename(saved_path)}',
                         xbmcgui.NOTIFICATION_INFO, 4000)


def _action_backup_full():
    from lib import backup
    # Enumerar lo backupeable primero para poder mostrar resumen real.
    try:
        names = os.listdir(backup._ADDONS_DIR)
    except OSError:
        names = []
    addon_ids = []
    repo_ids = []
    for name in names:
        if not backup._valid_addon_id(name):
            continue
        if name.startswith('repository.'):
            if name.startswith('repository.xbmc.'):
                continue
            repo_ids.append(name)
        elif backup.is_backupable(name):
            addon_ids.append(name)

    estimated_mb = _estimate_addons_size_mb(
        backup._ADDONS_DIR, addon_ids + repo_ids,
    )
    if estimated_mb is None:
        size_part = 'tamaño desconocido'
    else:
        size_part = f'~{estimated_mb} MB estimados'
    if not confirm(
        f'Vas a respaldar {len(addon_ids)} addons + {len(repo_ids)} repos '
        f'({size_part}).\n\n'
        'Se incluyen archivos físicos + datos de usuario + sources.xml + '
        'favoritos. El ZIP queda guardado en este Kodi y podrás descargarlo '
        'desde el panel web.\n\n¿Continuar?',
        title='Backup completo',
    ):
        return

    # Pre-check espacio libre.
    if estimated_mb is not None:
        if not _check_disk_space(backup.SNAPSHOTS_DIR, estimated_mb):
            if not confirm(
                'Puede que no quede espacio suficiente en la carpeta de '
                f'backups (~{estimated_mb} MB necesarios). ¿Continuar igualmente?',
                title='Espacio insuficiente', default_no=True,
            ):
                return

    dlg, progress_cb, cancel_check = _backup_progress_dialog('Backup completo')

    encrypt_password, pw_ok = _resolve_encrypt_password()
    if not pw_ok:
        dlg.close()
        return

    try:
        filename = backup.create_backup(
            addon_ids=addon_ids,
            repo_ids=repo_ids,
            include_addon_data=True,
            include_sources=True,
            include_favourites=True,
            encrypt_password=encrypt_password,
            progress_cb=progress_cb,
            cancel_check=cancel_check,
        )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otro backup en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Backup cancelado',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] create_backup falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        addon = xbmcaddon.Addon()
        keep = int(addon.getSetting('backup.snapshots.keep') or 5)
    except (ValueError, RuntimeError):
        keep = 5
    backup.rotate_snapshots(keep)

    dlg.close()
    _notify_backup_created(filename)


def _action_backup_custom():
    from lib import backup

    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Analizando addons')
    try:
        manifest = backup.build_manifest(progress_cb=progress_cb)
    except Exception as e:
        log.error(f'[backup] build_manifest falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()

    addons = [a for a in manifest.get('addons', [])
              if backup.is_backupable(a['id'])]
    repo_list = manifest.get('repos', [])

    # Multi-select unificado: repos primero, addons después.
    options = []
    keys = []
    for r in repo_list:
        options.append(f'[REPO] {r["id"]}  v{r.get("version", "?")}')
        keys.append(('repo', r['id']))
    for a in addons:
        name = a.get('name') or a['id']
        options.append(f'{name}  v{a.get("version", "?")}')
        keys.append(('addon', a['id']))

    if not options:
        accessibility.notify('No hay addons que respaldar',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return

    chosen = xbmcgui.Dialog().multiselect('Selecciona qué incluir', options)
    if not chosen:
        return

    selected_addons = []
    selected_repos = []
    for idx in chosen:
        kind, aid = keys[idx]
        if kind == 'repo':
            selected_repos.append(aid)
        else:
            selected_addons.append(aid)

    include_data = confirm(
        '¿Incluir datos de usuario (configuración, historial) de los addons?',
        title='Backup personalizado',
    )

    # Multiselect adicional para categorías Kodi. Etiquetas en español, no
    # técnicas, agrupadas por riesgo de tamaño.
    cat_options = [
        # name, label_es, default
        ('config_root', 'Archivos raíz (advancedsettings, passwords, ...)', True),
        ('guisettings', 'Ajustes de Kodi (snapshot JSON-RPC)', True),
        ('keymaps', 'Keymaps (atajos de teclado/mando)', True),
        ('peripheral_data', 'Peripheral data (configs de mando)', True),
        ('library', 'Library (smart playlists, video nodes)', True),
        ('playlists', 'Playlists (.m3u/.xsp)', True),
        ('databases', 'Bases de datos (Music/Video/Textures/EPG) [grande]', False),
        ('thumbnails', 'Thumbnails (cache, grande) [grande]', False),
        ('profiles', 'Perfiles de Kodi', False),
        ('game_saves', 'Game saves (savestates)', False),
    ]
    cat_labels = [o[1] for o in cat_options]
    cat_preselected = [i for i, o in enumerate(cat_options) if o[2]]
    cat_chosen = xbmcgui.Dialog().multiselect(
        'Categorías de Kodi a incluir (opcional)',
        cat_labels,
        preselect=cat_preselected,
    )
    if cat_chosen is None:
        # El usuario canceló con back → asumimos defaults sanos
        cat_chosen = cat_preselected
    kodi_categories = {
        o[0]: (i in cat_chosen) for i, o in enumerate(cat_options)
    }

    label = xbmcgui.Dialog().input(
        'Etiqueta opcional (40 caracteres máx)') or None

    # Aviso si el usuario activó categorías que pueden ocupar varios GB.
    big_cats = [name for name, _, _ in cat_options
                if name in ('databases', 'thumbnails')
                and kodi_categories.get(name)]
    if big_cats:
        nice = ', '.join(big_cats)
        if not confirm(
            f'Las categorías "{nice}" pueden añadir varios GB al backup. '
            '¿Continuar?',
            title='Categorías grandes',
            default_no=True,
        ):
            return

    encrypt_password, pw_ok = _resolve_encrypt_password()
    if not pw_ok:
        return

    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Backup personalizado')
    try:
        filename = backup.create_backup(
            addon_ids=selected_addons,
            repo_ids=selected_repos,
            include_addon_data=include_data,
            include_sources=True,
            include_favourites=True,
            kodi_categories=kodi_categories,
            label=label,
            encrypt_password=encrypt_password,
            progress_cb=progress_cb,
            cancel_check=cancel_check,
        )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otro backup en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Backup cancelado',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] create_backup falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        keep = int(xbmcaddon.Addon().getSetting('backup.snapshots.keep') or 5)
    except (ValueError, RuntimeError):
        keep = 5
    backup.rotate_snapshots(keep)

    dlg.close()
    _notify_backup_created(filename)


def _action_backup_favourites():
    from lib import backup
    try:
        path = backup.backup_favourites_only()
    except backup.BackupError as e:
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    accessibility.notify(f'Favoritos guardados: {os.path.basename(path)}',
                         xbmcgui.NOTIFICATION_INFO, 2500)
    xbmcgui.Dialog().ok('Favoritos guardados', path)


def _action_backup_favourites_submenu():
    def build():
        return [
            SelectItem(
                label='Crear backup de favoritos',
                plot='Guarda una copia del fichero favourites.xml del perfil '
                     'activo en la carpeta de snapshots.',
                icon=_icon_path('download.png'),
                action=_action_backup_favourites,
            ),
            SelectItem(
                label='Ver backups de favoritos',
                plot='Lista los backups de favoritos guardados. Desde aquí '
                     'puedes restaurar o eliminar cada uno.',
                icon=_icon_path('history.png'),
                action=_action_view_favourites_backups,
            ),
            SelectItem(
                label='Restaurar favoritos...',
                plot='Elige un backup guardado y lo aplica sobre el perfil '
                     'activo, sobreescribiendo el favourites.xml actual.',
                icon=_icon_path('file_browser.png'),
                action=_action_restore_favourites_pick,
            ),
            SelectItem(
                label='Volver',
                plot='',
                icon=_icon_path('back.png'),
                action=_close,
            ),
        ]
    menu('Backup de favoritos', build)


def _action_view_favourites_backups():
    from lib import backup
    import datetime

    def build():
        bkps = backup.list_favourites_backups()
        items = []
        for b in bkps:
            dt = datetime.datetime.fromtimestamp(b['created']).strftime('%d/%m/%Y %H:%M')
            size_kb = b['size'] / 1024
            items.append(SelectItem(
                label=b['filename'],
                plot=f'Fecha: {dt}\nTamaño: {size_kb:.1f} KB\n\n'
                     'Pulsa para restaurar o eliminar.',
                icon=_icon_path('xml.png'),
                action=lambda bk=b: _favourites_backup_ops(bk),
            ))
        if not items:
            items.append(SelectItem(
                label='(sin backups de favoritos)',
                plot='Aún no hay ningún backup de favoritos guardado.',
            ))
        items.append(SelectItem(
            label='Volver',
            plot='',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu('Backups de favoritos', build)


def _favourites_backup_ops(b):
    filename = b['filename']
    choice = xbmcgui.Dialog().select(filename, [
        'Ver contenido',
        'Restaurar sobre el perfil activo',
        'Eliminar',
        'Cancelar',
    ])
    if choice == 0:
        _do_preview_favourites_backup(filename)
    elif choice == 1:
        _do_restore_favourites(filename)
    elif choice == 2:
        _do_delete_favourites_backup(filename)


def _do_preview_favourites_backup(filename):
    from lib import backup
    try:
        path = backup._validate_favourites_backup_name(filename)
    except backup.BackupError as e:
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    # utf-8-sig tolera BOM de editores que lo añaden (Notepad en Windows).
    try:
        with open(path, 'r', encoding='utf-8-sig') as fh:
            xml_text = fh.read()
    except OSError as e:
        accessibility.notify(f'No se pudo leer: {e}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    xbmcgui.Dialog().textviewer(filename, xml_text)


def _action_restore_favourites_pick():
    from lib import backup
    bkps = backup.list_favourites_backups()
    if not bkps:
        xbmcgui.Dialog().ok(
            'Sin backups',
            'No hay backups de favoritos guardados.',
        )
        return
    import datetime
    opts = [
        f'{b["filename"]}  '
        f'({datetime.datetime.fromtimestamp(b["created"]).strftime("%d/%m/%Y %H:%M")})'
        for b in bkps
    ]
    idx = xbmcgui.Dialog().select('Selecciona backup a restaurar', opts)
    if idx < 0:
        return
    _do_restore_favourites(bkps[idx]['filename'])


def _do_restore_favourites(filename):
    from lib import backup
    if backup.favourites_exists():
        choice = xbmcgui.Dialog().select(
            f'Restaurar {filename}',
            [
                'Sobrescribir: reemplaza todos los favoritos actuales',
                'Añadir al final: mantiene los actuales y suma los nuevos',
                'Cancelar',
            ],
        )
        if choice in (-1, 2):
            return
        mode = 'overwrite' if choice == 0 else 'add'
        if mode == 'overwrite' and not accessibility.confirm_destructive(
            f'Se borrarán los favoritos actuales y se dejarán solo los de '
            f'"{filename}". ¿Continuar?',
        ):
            return
    else:
        if not xbmcgui.Dialog().yesno(
            'Restaurar favoritos',
            f'No hay favoritos en el perfil. Se creará favourites.xml con:\n'
            f'{filename}\n\n¿Confirmas?',
            nolabel='Cancelar',
            yeslabel='Restaurar',
        ):
            return
        mode = 'overwrite'
    try:
        res = backup.restore_favourites_backup(filename, mode=mode)
    except backup.BackupError as e:
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if mode == 'overwrite':
        msg = f'Favoritos sobrescritos ({res["imported"]})'
    else:
        msg = f'Favoritos añadidos: {res["imported"]}, duplicados: {res["skipped"]}'
    accessibility.notify(msg, xbmcgui.NOTIFICATION_INFO, 2500)


def _do_delete_favourites_backup(filename):
    from lib import backup
    if not accessibility.confirm_destructive(
        f'¿Eliminar el backup "{filename}"? No se puede deshacer.',
    ):
        return
    try:
        backup.delete_favourites_backup(filename)
        accessibility.notify(f'{filename} eliminado',
                             xbmcgui.NOTIFICATION_INFO, 2000)
    except backup.BackupError as e:
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3000)


_RESTORE_CANCELLED = object()


def _pick_addons_to_restore(manifest):
    """Pregunta al usuario qué addons restaurar del manifest.

    Devuelve uno de:
      None: restaurar todos (mantiene comportamiento legacy).
      list[str]: IDs del subset elegido.
      _RESTORE_CANCELLED: el usuario canceló o desmarcó todo. El caller debe
        abortar el restore. No basta devolver lista vacía: las APIs internas
        tratan `addon_ids=[]` (falsy) como "todos".
    """
    from lib import backup
    addons = [a for a in (manifest.get('addons') or [])
              if a.get('id') and a['id'] != backup.SELF_ADDON_ID]
    if not addons:
        return None
    choice = xbmcgui.Dialog().select(
        'Selección de addons',
        ['Restaurar todos los addons del backup',
         'Elegir addons concretos...',
         'Cancelar'],
    )
    if choice in (-1, 2):
        return _RESTORE_CANCELLED
    if choice == 0:
        return None
    options = [f'{a.get("name") or a["id"]}  v{a.get("version", "?")}'
               for a in addons]
    preselect = list(range(len(addons)))
    chosen = xbmcgui.Dialog().multiselect(
        'Marca los addons a restaurar', options, preselect=preselect,
    )
    if not chosen:
        accessibility.notify('Cancelado: no marcaste nada',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return _RESTORE_CANCELLED
    return [addons[i]['id'] for i in chosen]


def _pick_install_xml_items(xml_repos, xml_addons):
    """Pregunta qué entradas del XML batch instalar.

    Devuelve uno de:
      (None, None): instalar TODO lo del XML (mantiene comportamiento legacy).
      (addon_ids, repo_ids): subsets concretos (cualquiera puede ser None
        para "todos" si el usuario marcó todas las entradas de esa categoría).
      _RESTORE_CANCELLED: el usuario canceló o desmarcó todo.
    """
    if not xml_repos and not xml_addons:
        return (None, None)
    choice = xbmcgui.Dialog().select(
        '¿Qué instalar del XML?',
        [f'Instalar todo ({len(xml_repos)} repos + {len(xml_addons)} addons)',
         'Elegir concretos...',
         'Cancelar'],
    )
    if choice in (-1, 2):
        return _RESTORE_CANCELLED
    if choice == 0:
        return (None, None)
    options = []
    keys = []
    for r in xml_repos:
        options.append(f'[REPO] {r["id"]}')
        keys.append(('repo', r['id']))
    for a in xml_addons:
        rid = a.get('repo')
        suffix = f'  (repo: {rid})' if rid else ''
        options.append(f'{a["id"]}{suffix}')
        keys.append(('addon', a['id']))
    preselect = list(range(len(options)))
    chosen = xbmcgui.Dialog().multiselect(
        'Marca lo que quieres instalar', options, preselect=preselect,
    )
    if not chosen:
        accessibility.notify('Cancelado: no marcaste nada',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return _RESTORE_CANCELLED
    addon_ids = []
    repo_ids = []
    for idx in chosen:
        kind, aid = keys[idx]
        if kind == 'repo':
            repo_ids.append(aid)
        else:
            addon_ids.append(aid)
    # Si el usuario marcó todo de una categoría, equivale a None ("todos");
    # eso mantiene la semántica de install_from_xml sin filtros para esa
    # parte. Si marcó subset, devolvemos lista.
    if len(repo_ids) == len(xml_repos):
        repo_ids = None
    if len(addon_ids) == len(xml_addons):
        addon_ids = None
    return (addon_ids, repo_ids)


def _action_backup_my_snapshots():
    from lib import backup
    snaps = backup.list_snapshots()
    if not snaps:
        accessibility.notify('No hay backups todavía',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return
    options = [_format_snapshot_option(s) for s in snaps]
    idx = xbmcgui.Dialog().select('Mis backups', options)
    if idx < 0:
        return
    chosen_snap = snaps[idx]
    chosen = chosen_snap['filename']
    action_idx = xbmcgui.Dialog().select(chosen, [
        'Ver detalles',
        'Restaurar archivos tal como están en el ZIP',
        'Reinstalar versiones más nuevas desde los repos',
        'Eliminar',
        'Cancelar',
    ])
    if action_idx in (-1, 4):
        return
    if action_idx == 0:
        _show_snapshot_details(chosen_snap)
        return
    if action_idx == 3:
        if accessibility.confirm_destructive(
            f'¿Eliminar el backup "{chosen}"? No se puede deshacer.',
        ):
            try:
                backup.delete_snapshot(chosen)
                accessibility.notify('Backup eliminado',
                                     xbmcgui.NOTIFICATION_INFO, 2000)
            except backup.BackupError as e:
                accessibility.notify(_friendly(e),
                                     xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    mode = 'files' if action_idx == 1 else 'repos'
    zip_path = backup.snapshot_path(chosen)
    if not _confirm_kodi_version_mismatch(zip_path):
        return
    pwd_ok, password = _ask_password_if_encrypted(zip_path)
    if not pwd_ok:
        accessibility.notify('Cancelado',
                             xbmcgui.NOTIFICATION_INFO, 1500)
        return
    try:
        manifest = backup.load_manifest_from_zip(zip_path, password=password)
    except backup.BackupError as e:
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    selected_ids = _pick_addons_to_restore(manifest)
    if selected_ids is _RESTORE_CANCELLED:
        return
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        f'Restaurando {chosen}')
    try:
        if mode == 'files':
            result = backup.restore_from_zip(
                zip_path,
                addon_ids=selected_ids,
                include_sources_mode='merge',
                include_favourites=False,
                password=password,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )
        else:
            result = backup.restore_from_manifest(
                manifest,
                addon_ids=selected_ids,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otra operación en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Restauración cancelada',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] restore falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    _render_restore_result(result, kind='restore')


def _action_backup_undo_restore():
    """Restaura el snapshot que se guarda automáticamente antes de un restore.

    Ese snapshot se creaba y se rotaba, pero vivía en un directorio que no
    lista nadie: el "rollback de emergencia" del ajuste existía en disco y no
    había forma de usarlo desde el addon.
    """
    from lib import backup
    snaps = backup.list_pre_restore_snapshots()
    if not snaps:
        xbmcgui.Dialog().ok(
            'Nada que deshacer',
            'No hay ninguna copia de seguridad previa a una restauración.\n\n'
            'Se crean automáticamente antes de cada restauración, si tienes '
            'activo el ajuste "Crear snapshot automático antes de cada '
            'restore".',
        )
        return

    options = [_format_snapshot_option(s) for s in snaps]
    idx = xbmcgui.Dialog().select(
        'Volver al estado anterior a...', options)
    if idx < 0:
        return
    chosen = snaps[idx]['filename']
    zip_path = backup.pre_restore_snapshot_path(chosen)
    created = snaps[idx].get('created') or 0
    cuando = (time.strftime('%Y-%m-%d %H:%M', time.localtime(created))
              if created else chosen)

    if not accessibility.confirm_destructive(
        'Se van a sobrescribir los addons y sus datos con la copia guardada '
        f'justo antes de la restauración del {cuando}.\n\n¿Continuar?',
    ):
        return

    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Deshaciendo la restauración')
    try:
        result = backup.restore_from_zip(
            zip_path,
            include_sources_mode='skip',
            include_favourites=False,
            restore_categories='all',
            progress_cb=progress_cb,
            cancel_check=cancel_check,
        )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otra operación en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Cancelado', xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] undo restore falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    _render_restore_result(result, kind='restore')


def _action_backup_restore_file():
    from lib import backup
    path = xbmcgui.Dialog().browseSingle(
        1, 'Selecciona el ZIP de backup', 'files', '.zip', False, False,
    )
    if not path or not os.path.isfile(path):
        return
    # Validar que es un backup loiolink antes de pedir modo. Sin esto, el
    # usuario elige opciones y solo al final ve "manifest.json no está en el ZIP".
    try:
        backup.load_manifest_from_zip(path)
    except backup.ManifestError as e:
        accessibility.notify(f'No es un backup loiolink válido: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 4500)
        return
    action_idx = xbmcgui.Dialog().select('¿Cómo restaurar?', [
        'Restaurar archivos tal como están en el ZIP',
        'Reinstalar versiones más nuevas desde los repos',
        'Cancelar',
    ])
    if action_idx in (-1, 2):
        return
    mode = 'files' if action_idx == 0 else 'repos'
    if not _confirm_kodi_version_mismatch(path):
        return
    pwd_ok, password = _ask_password_if_encrypted(path)
    if not pwd_ok:
        return
    try:
        manifest = backup.load_manifest_from_zip(path, password=password)
    except backup.BackupError as e:
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    selected_ids = _pick_addons_to_restore(manifest)
    if selected_ids is _RESTORE_CANCELLED:
        return
    dlg, progress_cb, cancel_check = _backup_progress_dialog('Restaurando')
    try:
        if mode == 'files':
            result = backup.restore_from_zip(
                path,
                addon_ids=selected_ids,
                include_sources_mode='merge',
                include_favourites=False,
                password=password,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )
        else:
            result = backup.restore_from_manifest(
                manifest,
                addon_ids=selected_ids,
                progress_cb=progress_cb,
                cancel_check=cancel_check,
            )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otra operación en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except backup.ManifestError as e:
        dlg.close()
        accessibility.notify(f'Manifest inválido: {e}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Restauración cancelada',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] restore falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    _render_restore_result(result, kind='restore')


def _action_backup_install_xml():
    from lib import backup
    path = xbmcgui.Dialog().browseSingle(
        1, 'Selecciona el XML', 'files', '.xml', False, False,
    )
    if not path or not os.path.isfile(path):
        return
    # Peek primero: si el XML es inválido, abortar antes del progress dialog.
    try:
        xml_repos, xml_addons = backup.peek_xml(path)
    except backup.BackupError as e:
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3500)
        return
    selection = _pick_install_xml_items(xml_repos, xml_addons)
    if selection is _RESTORE_CANCELLED:
        return
    selected_addon_ids, selected_repo_ids = selection
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Instalando desde XML')
    try:
        result = backup.install_from_xml(
            path,
            addon_ids=selected_addon_ids,
            repo_ids=selected_repo_ids,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    except backup.BackupBusyError:
        dlg.close()
        accessibility.notify('Hay otra operación en curso',
                             xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    except backup.BackupError as e:
        dlg.close()
        accessibility.notify(_friendly(e),
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    except InterruptedError:
        dlg.close()
        accessibility.notify('Instalación cancelada',
                             xbmcgui.NOTIFICATION_INFO, 2000)
        return
    except Exception as e:
        log.error(f'[backup] install_xml falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    _render_restore_result(result, kind='install')


def _action_backup_import():
    """Importa un ZIP de backup externo a la carpeta de snapshots."""
    from lib import backup
    path = xbmcgui.Dialog().browseSingle(
        1, 'Selecciona el ZIP a importar', 'files', '.zip', False, False,
    )
    if not path or not os.path.isfile(path):
        return
    label_input = xbmcgui.Dialog().input(
        'Etiqueta opcional para el backup importado') or None
    dlg, progress_cb, cancel_check = _backup_progress_dialog('Importando backup')
    try:
        res = backup.import_snapshot(
            path, label=label_input, validate=True,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    except Exception as e:
        log.error(f'[backup] import falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    if res.get('ok'):
        accessibility.notify(
            f'Importado en Mis backups: {res.get("filename", "")}',
            xbmcgui.NOTIFICATION_INFO, 3500,
        )
    else:
        accessibility.notify(
            f'No se pudo importar: {_friendly(res.get("error") or "error desconocido")}',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )


def _action_backup_sanitize_share():
    """Crea una versión compartible de un backup, sin credenciales."""
    from lib import backup
    snaps = backup.list_snapshots()
    if not snaps:
        accessibility.notify('No hay backups todavía',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return
    options = [_format_snapshot_option(s) for s in snaps]
    idx = xbmcgui.Dialog().select('¿Qué backup sanitizar para compartir?', options)
    if idx < 0:
        return
    chosen = snaps[idx]['filename']
    if not confirm(
        'Se creará una copia del backup SIN passwords.xml, tokens de '
        'addon_data ni datos personales del manifiesto. Es seguro para '
        'compartir con otros usuarios.\n\n¿Continuar?',
        title='Sanitizar para compartir',
        default_no=False,
    ):
        return
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        'Sanitizando backup para compartir')
    try:
        res = backup.sanitize_backup_for_sharing(
            chosen,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    except Exception as e:
        log.error(f'[backup] sanitize falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    if not res.get('ok'):
        accessibility.notify(
            f'No se pudo sanitizar: {_friendly(res.get("error") or "error desconocido")}',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return
    new_filename = res['filename']
    removed_entries = res.get('removed_entries') or []
    pii_fields = res.get('pii_fields_removed') or []
    removed_count = len(removed_entries)
    new_path = backup.snapshot_path(new_filename)
    accessibility.notify(
        f'Copia creada: {new_filename}',
        xbmcgui.NOTIFICATION_INFO, 3500,
    )
    pii_labels = {
        'addon_data_path': 'Ruta de datos del usuario',
        'device_id': 'ID de dispositivo',
        'hostname_hash': 'Hash de nombre de equipo',
    }
    redacted = res.get('redacted_settings') or []
    redacted_count = sum(len(r['ids']) for r in redacted)
    if removed_entries or pii_fields or redacted:
        detail_lines = ['Eliminado del backup:']
        if removed_entries:
            detail_lines.append('')
            detail_lines.append(f'Archivos sensibles ({len(removed_entries)}):')
            for entry in removed_entries[:30]:
                detail_lines.append(f'  - {entry}')
            if len(removed_entries) > 30:
                detail_lines.append(f'  ... y {len(removed_entries) - 30} más')
        if redacted:
            # Lo más importante que se quita, y lo que el usuario no puede
            # comprobar por su cuenta sin abrir el ZIP a mano.
            detail_lines.append('')
            detail_lines.append(
                f'Claves y tokens dentro de los ajustes ({redacted_count}):')
            for item in redacted[:20]:
                origen = item['entry'].split('/')
                origen = origen[1] if len(origen) > 1 else item['entry']
                detail_lines.append(f'  - {origen}: {", ".join(item["ids"])}')
            if len(redacted) > 20:
                detail_lines.append(f'  ... y {len(redacted) - 20} archivos más')
        if pii_fields:
            detail_lines.append('')
            detail_lines.append(f'Campos del manifiesto ({len(pii_fields)}):')
            for field in pii_fields:
                detail_lines.append(f'  - {pii_labels.get(field, field)}')
        xbmcgui.Dialog().textviewer('Datos eliminados', '\n'.join(detail_lines))
    if confirm(
        f'Copia compartible creada en:\n{new_path}\n\n'
        f'{removed_count} archivos excluidos y {redacted_count} claves o '
        'tokens borrados de dentro de los ajustes.\n\n'
        '¿Exportarla ahora a otra ubicación (USB, NAS, etc.)?',
        title='Compartir backup',
        default_no=True,
    ):
        dest_dir = xbmcgui.Dialog().browseSingle(
            3, 'Carpeta destino para la copia compartible',
            'files', '', False, False,
        )
        if dest_dir:
            try:
                exp = backup.export_snapshot(
                    new_filename, dest_dir, overwrite=False,
                )
            except Exception as e:
                accessibility.notify(f'Export falló: {_friendly(e)}',
                                     xbmcgui.NOTIFICATION_WARNING, 3500)
                return
            if exp.get('ok'):
                xbmcgui.Dialog().ok('Exportado', exp.get('dest_path', ''))
            else:
                accessibility.notify(
                    f'No se pudo exportar: {_friendly(exp.get("error") or "error desconocido")}',
                    xbmcgui.NOTIFICATION_WARNING, 4000,
                )


def _action_backup_export():
    """Exporta un snapshot existente a una ruta arbitraria."""
    from lib import backup
    snaps = backup.list_snapshots()
    if not snaps:
        accessibility.notify('No hay backups todavía',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return
    options = [_format_snapshot_option(s) for s in snaps]
    idx = xbmcgui.Dialog().select('¿Qué backup exportar?', options)
    if idx < 0:
        return
    chosen = snaps[idx]['filename']
    dest_dir = xbmcgui.Dialog().browseSingle(
        3, 'Carpeta destino', 'files', '', False, False,
    )
    if not dest_dir:
        return
    # Pre-check escribibilidad y colisión solo para paths locales; rutas Kodi
    # VFS (smb://, nfs://) se delegan al backend que ya tiene checks propios.
    is_kodi_vfs = '://' in dest_dir
    if not is_kodi_vfs:
        if not os.access(dest_dir, os.W_OK):
            accessibility.notify(
                'La carpeta destino no es escribible',
                xbmcgui.NOTIFICATION_WARNING, 3500,
            )
            return
        target = os.path.join(dest_dir, chosen)
        if os.path.exists(target):
            if not confirm(
                f'Ya existe "{chosen}" en el destino. ¿Sobrescribir?',
                title='Archivo existente', default_no=True,
            ):
                return
            overwrite = True
        else:
            overwrite = False
    else:
        overwrite = False
    dlg, progress_cb, cancel_check = _backup_progress_dialog(
        f'Exportando {chosen}')
    try:
        res = backup.export_snapshot(
            chosen, dest_dir, overwrite=overwrite,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    except Exception as e:
        log.error(f'[backup] export falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    if res.get('ok'):
        dest_path = res.get('dest_path', '')
        accessibility.notify(
            f'Exportado: {os.path.basename(dest_path)}',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmcgui.Dialog().ok('Exportado', dest_path)
    else:
        accessibility.notify(
            f'No se pudo exportar: {_friendly(res.get("error") or "error desconocido")}',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )


def _action_backup_migrate():
    """Migra todos los snapshots entre destino default y custom."""
    from lib import backup, backup_storage
    # Si no hay custom path configurado, no tiene sentido ofrecer migración.
    custom_root = backup_storage._read_custom_path_setting()
    if not custom_root:
        if confirm(
            'No tienes configurada una carpeta personalizada. '
            'Sin ella no se puede migrar. ¿Abrir ajustes para configurarla?',
            title='Carpeta personalizada no configurada',
            default_no=False,
        ):
            try:
                xbmcaddon.Addon().openSettings()
            except Exception:
                # openSettings puede fallar si Kodi está cerrando la ventana;
                # no es crítico (el usuario puede abrir ajustes a mano).
                pass
        return
    idx = xbmcgui.Dialog().select('¿Hacia dónde migrar?', [
        'Del destino por defecto -> carpeta personalizada',
        'De la carpeta personalizada -> destino por defecto',
        'Cancelar',
    ])
    if idx in (-1, 2):
        return
    from_to = ('default', 'custom') if idx == 0 else ('custom', 'default')
    delete_source = confirm(
        '¿Borrar los snapshots del origen tras copiarlos al destino?',
        title='Migrar backups', default_no=True,
    )
    dlg, progress_cb, cancel_check = _backup_progress_dialog('Migrando backups')
    try:
        res = backup.migrate_snapshots(
            from_to[0], from_to[1],
            delete_source=delete_source,
            progress_cb=progress_cb, cancel_check=cancel_check,
        )
    except Exception as e:
        log.error(f'[backup] migrate falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    if res.get('error'):
        accessibility.notify(
            f'No se pudo migrar: {res["error"]}',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return
    migrated = res.get('migrated', 0)
    failed_n = len(res.get('failed') or [])
    msg = f'Migrados {migrated}'
    if failed_n:
        msg += f', fallaron {failed_n}'
    accessibility.notify(
        msg,
        xbmcgui.NOTIFICATION_INFO if not failed_n else xbmcgui.NOTIFICATION_WARNING,
        4000,
    )


def _action_backup_dry_run():
    """Informe pre-restore sin tocar disco."""
    from lib import backup
    snaps = backup.list_snapshots()
    if not snaps:
        accessibility.notify('No hay backups todavía',
                             xbmcgui.NOTIFICATION_INFO, 2500)
        return
    options = [_format_snapshot_option(s) for s in snaps]
    idx = xbmcgui.Dialog().select('¿Qué backup comprobar?', options)
    if idx < 0:
        return
    chosen = snaps[idx]['filename']
    zip_path = backup.snapshot_path(chosen)
    dlg = xbmcgui.DialogProgress()
    dlg.create('Comprobando backup', 'Analizando integridad y contenido...')
    try:
        report = backup.dry_run_restore(zip_path)
    except Exception as e:
        log.error(f'[backup] dry_run falló: {e!r}')
        dlg.close()
        accessibility.notify(f'Error: {_friendly(e)}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    dlg.close()
    if not report.get('ok'):
        reason = report.get('reason') or 'Razón desconocida'
        xbmcgui.Dialog().ok(
            'Backup no analizable',
            f'{chosen}\n\nRuta:\n{zip_path}\n\nMotivo:\n{_friendly(reason)}',
        )
        return
    try:
        lines = _build_dry_run_report(chosen, zip_path, report)
    except Exception as e:
        log.error(f'[backup] dry_run render falló: {e!r}')
        accessibility.notify(f'Error mostrando informe: {e}',
                             xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    xbmcgui.Dialog().textviewer(
        f'Informe del backup: {chosen}',
        '\n'.join(lines),
    )


def _build_dry_run_report(chosen, zip_path, report):
    """Construye las líneas legibles del informe dry_run."""
    lines = []
    lines.append(f'Archivo: {chosen}')
    lines.append(f'Ruta: {zip_path}')
    lines.append('')
    summ = report.get('manifest_summary') or {}
    lines.append(f'Creado: {summ.get("created", "?")}')
    lines.append(f'Kodi origen: {summ.get("kodi_version", "?")}')
    if summ.get('label'):
        lines.append(f'Etiqueta: {summ["label"]}')
    lines.append(f'Addons en ZIP: {report.get("addons_in_zip_count", 0)}')
    lines.append(
        f'Tamaño descomprimido estimado: '
        f'{report.get("estimated_disk_use_mb", 0)} MB'
    )
    integrity = report.get('integrity_check') or {}
    if integrity.get('ok'):
        lines.append('Integridad: OK')
    else:
        lines.append(f'Integridad: {integrity.get("reason", "?")}')
    version_check = report.get('kodi_version_check') or {}
    if version_check.get('major_mismatch'):
        lines.append(
            f'AVISO: Backup hecho en Kodi {version_check.get("backup_major")}, '
            f'tú tienes {version_check.get("current_major")}'
        )
    env_warnings = report.get('environment_mismatch') or []
    for w in env_warnings:
        if w.get('severity') == 'warning':
            lines.append(f'AVISO: {w.get("message", "")}')
    db_warnings = report.get('db_warnings') or []
    for w in db_warnings:
        lines.append(f'DB incompatible: {w.get("db", "?")}')
    advanced = report.get('advancedsettings') or {}
    if advanced.get('present'):
        if advanced.get('valid'):
            lines.append('advancedsettings.xml: presente y válido '
                         '(requerirá reiniciar Kodi)')
        else:
            lines.append(f'advancedsettings.xml malformado: '
                         f'{advanced.get("reason")}')
    py_warnings = report.get('addon_python_warnings') or []
    if py_warnings:
        lines.append('')
        lines.append(f'Addons con Python incompatible ({len(py_warnings)}):')
        for w in py_warnings[:10]:
            lines.append(f'  - {w.get("addon_id")}: {w.get("warning")}')
        if len(py_warnings) > 10:
            lines.append(f'  ... y {len(py_warnings) - 10} más')
    return lines


def _action_backup_folder_info():
    """Muestra la ruta del storage activo y ofrece abrir ajustes."""
    from lib import backup, backup_storage
    storages = backup_storage.get_active_storages(backup.SNAPSHOTS_DIR)
    lines = ['Carpetas de backup activas:', '']
    for s in storages:
        marker = ' (escribible)' if s.writable() else ''
        lines.append(f'[{s.origin}] {s.root_path}{marker}')
    lines.append('')
    lines.append('Para cambiar la carpeta personalizada abre los ajustes '
                 'del addon (categoría "Backup", opción "Carpeta '
                 'personalizada para los backups").')
    if confirm(
        '\n'.join(lines) + '\n\n¿Abrir ajustes del addon ahora?',
        title='Carpeta de backups',
        default_no=True,
    ):
        try:
            xbmcaddon.Addon().openSettings()
        except Exception as e:
            log.warning(f'[backup] openSettings falló: {e!r}')


def _action_show_remote_qr():
    from lib.actions import remote_qr
    remote_qr.run()


def _open_backup_submenu():
    """Submenú de backup. Bloqueante hasta que el usuario vuelve."""

    def build():
        items = []
        # --- Crear backups ---
        items.append(SelectItem(
            label='Backup completo',
            plot='Empaqueta en un ZIP los archivos de todos los addons y '
                 'repositorios (excepto el propio loiolink y los del sistema '
                 'Kodi), sus datos de usuario, sources.xml y favoritos. Queda '
                 'guardado en este Kodi y podrás descargarlo desde el panel web.',
            icon=_icon_path('download.png'),
            action=_action_backup_full,
        ))
        items.append(SelectItem(
            label='Backup personalizado',
            plot='Igual que el backup completo pero eligiendo qué addons y '
                 'repos entran, y si se incluyen los datos de usuario. Útil '
                 'para snapshots ligeros o para llevarte solo un addon concreto.',
            icon=_icon_path('edit.png'),
            action=_action_backup_custom,
        ))
        items.append(SelectItem(
            label='Backup de favoritos',
            plot='Crea backups del favourites.xml, consulta los guardados o '
                 'restaura uno anterior.',
            icon=_icon_path('flowfav.png'),
            action=_action_backup_favourites_submenu,
        ))
        items.append(SelectItem(
            label='Generar lista de addons',
            plot='Construye un listado con todos los addons y repositorios '
                 'que tienes instalados, indicando qué repo proporciona cada '
                 'addon y la versión más nueva disponible en ese momento.',
            icon=_icon_path('loiolog.png'),
            action=_action_backup_show_list,
        ))
        items.append(SelectItem(
            label='Generar XML de addons (para instalar en otro Kodi)',
            plot='Genera un archivo XML con los addons y repos elegidos, '
                 'listo para llevártelo a otro Kodi y reinstalarlos en cadena '
                 'con la opción "Instalar desde XML". Útil para clonar un '
                 'setup sin copiar archivos físicos.',
            icon=_icon_path('xml.png'),
            action=_action_backup_export_xml,
        ))
        # --- Restaurar / inspeccionar ---
        items.append(SelectItem(
            label='Mis backups',
            plot='Lista los ZIPs de backup creados desde este Kodi. Para cada '
                 'uno puedes ver detalles, restaurar (desde archivos o '
                 'reinstalando desde sus repos) o eliminarlo.',
            icon=_icon_path('history.png'),
            action=_action_backup_my_snapshots,
        ))
        items.append(SelectItem(
            label='Comprobar un backup antes de restaurar...',
            plot='Hace un informe detallado de qué contiene un backup, '
                 'detecta problemas (versión Kodi, DBs incompatibles, '
                 'archivos corruptos) y muestra qué addons restauraría, sin '
                 'tocar nada del sistema. Dry-run.',
            icon=_icon_path('diagnostics.png'),
            action=_action_backup_dry_run,
        ))
        items.append(SelectItem(
            label='Restaurar desde archivo...',
            plot='Selecciona un ZIP de backup desde el file browser y elige '
                 'si restaurar los archivos físicos o reinstalar todo desde '
                 'los repositorios listados en su manifest.',
            icon=_icon_path('file_browser.png'),
            action=_action_backup_restore_file,
        ))
        items.append(SelectItem(
            label='Deshacer la última restauración',
            plot='Antes de cada restauración se guarda automáticamente una '
                 'copia de lo que se va a sobrescribir. Aquí puedes volver a '
                 'ese estado si la restauración dejó Kodi peor que antes. Se '
                 'controla con el ajuste "Crear snapshot automático antes de '
                 'cada restore".',
            icon=_icon_path('migrate.png'),
            action=_action_backup_undo_restore,
        ))
        # --- Gestionar / avanzado ---
        items.append(SelectItem(
            label='Carpeta de backups',
            plot='Muestra dónde se guardan tus backups y permite abrir los '
                 'ajustes del addon para cambiar la carpeta personalizada.',
            icon=_icon_path('folder.png'),
            action=_action_backup_folder_info,
        ))
        items.append(SelectItem(
            label='Importar backup desde disco...',
            plot='Copia un ZIP de backup desde cualquier ubicación accesible '
                 '(USB, NAS, etc.) a la carpeta de snapshots para que aparezca '
                 'en "Mis backups". Diferente de "Restaurar desde archivo": '
                 'esto solo lo añade a la lista, no lo restaura.',
            icon=_icon_path('sync.png'),
            action=_action_backup_import,
        ))
        items.append(SelectItem(
            label='Exportar un backup a otra ubicación...',
            plot='Copia un snapshot existente a una ruta accesible (USB, NAS, '
                 'smb://). Útil para llevarse el backup a otro Kodi o como '
                 'copia de seguridad off-site.',
            icon=_icon_path('upload.png'),
            action=_action_backup_export,
        ))
        items.append(SelectItem(
            label='Migrar todos los backups a otra carpeta...',
            plot='Mueve todos los snapshots existentes entre el destino por '
                 'defecto y la carpeta personalizada (o viceversa). Útil tras '
                 'configurar un destino USB/NAS si tenías backups en el '
                 'storage interno.',
            icon=_icon_path('migrate.png'),
            action=_action_backup_migrate,
        ))
        items.append(SelectItem(
            label='Crear copia segura para compartir...',
            plot='Genera una copia del backup eliminando passwords.xml, '
                 'tokens OAuth de addon_data y rutas con tu nombre de '
                 'usuario. Útil para enviar el backup a otra persona sin '
                 'filtrar tus credenciales SMB/Plex/etc.',
            icon=_icon_path('shield.png'),
            action=_action_backup_sanitize_share,
        ))
        items.append(SelectItem(
            label='Instalar desde XML...',
            plot='Selecciona un fichero XML con una lista de repositorios y '
                 'addons. Se instalan en cadena en un solo click. Formato '
                 'detallado en la documentación.',
            icon=_icon_path('add_source.png'),
            action=_action_backup_install_xml,
        ))
        items.append(SelectItem(
            label='Subir archivos desde el móvil o PC...',
            plot='Abre el panel web de loiolink en tu teléfono o PC y desde '
                 'ahí puedes subir ZIPs de backup directamente a Kodi, sin '
                 'USB ni carpeta compartida. Requiere estar en la misma WiFi.',
            icon=_icon_path('qr.png'),
            action=_action_show_remote_qr,
        ))
        items.append(SelectItem(
            label='Volver',
            plot='Vuelve al menú anterior del gestor.',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu('Backup y restauración', build)


def _maybe_scan_on_open(items):
    """Lanza scan solo si la última comprobación es vieja."""
    threshold = 5 * 60  # 5 minutos
    now = time.time()
    state = source_state.load()
    should_scan = False
    for src in items:
        st = state.get(source_state.path_key(src['path']), {})
        last = int(st.get('last_check_ts', 0))
        if now - last > threshold and _http_only(src['path']):
            should_scan = True
            break
    if not should_scan:
        return
    results = _scan_sources(items)
    _persist_results(results)


def _format_diff(prev, current, limit=12):
    """Devuelve un texto multilínea con los deltas entre dos snapshots.

    prev y current son {addon_id: version}. La salida incluye altas,
    bajas y subidas de versión. Si hay más de `limit` líneas, se trunca
    para no inundar el plot.
    """
    prev_keys = set(prev)
    cur_keys = set(current)
    added = sorted(cur_keys - prev_keys)
    removed = sorted(prev_keys - cur_keys)
    bumped = []
    for k in sorted(prev_keys & cur_keys):
        if prev[k] != current[k]:
            bumped.append((k, prev[k], current[k]))

    lines = []
    for a in added:
        lines.append(f'+ {a} ({current[a]})')
    for r in removed:
        lines.append(f'- {r}')
    for k, old, new in bumped:
        lines.append(f'{k}: {old} -> {new}')

    if not lines:
        return 'El contenido remoto ha cambiado pero no se aprecia diferencia de addons.'
    if len(lines) > limit:
        more = len(lines) - limit
        lines = lines[:limit] + [f'... y {more} cambios más']
    return '\n'.join(lines)


def _purge_orphan_state(items):
    """Elimina entries de source_state cuyo path ya no está en sources.xml.

    Esto cubre el caso de que el usuario elimine una fuente desde el file
    manager nativo de Kodi (fuera del addon). Sin esta limpieza el JSON
    crecería con basura cada vez que pasara.
    """
    live_keys = {source_state.path_key(s['path']) for s in items}
    state = source_state.load()
    orphans = [k for k in state if k not in live_keys]
    if not orphans:
        return
    for k in orphans:
        state.pop(k, None)
    source_state.save(state)


def _pending_changes_count():
    state = source_state.load()
    n = 0
    for v in state.values():
        if v.get('kind') == 'repo' and not v.get('acknowledged', True):
            n += 1
    return n


def _source_detail(src):
    """Submenú del detalle de una fuente concreta. Bloqueante hasta que
    el usuario vuelve o se cierra por rename/remove."""
    name = src['name']
    path = src['path']

    def build():
        items = []
        st = source_state.get(path)

        # Si hay cambios pendientes, mostrar deltas concretos como primera fila.
        if not st.get('acknowledged', True) and st.get('kind') == 'repo':
            diff_text = _format_diff(
                st.get('prev_seen_addons', {}),
                st.get('last_seen_addons', {}),
            )
            items.append(SelectItem(
                label='[B]Hay cambios desde tu última visita[/B]',
                plot=diff_text + '\n\nPulsa para marcar la fuente como revisada.',
                icon=_icon_path('notification.png'),
                action=lambda: _ack_source(path),
            ))

        items.append(SelectItem(
            label=f'Nombre: {name}',
            plot='Identificador legible de la fuente. Es el nombre que ves en el file '
                 'manager de Kodi y aquí.',
            icon=_icon_path('edit.png'),
            action=lambda: _rename_source(name),
        ))
        items.append(SelectItem(
            label=f'URL: {path}',
            plot='URL configurada para esta fuente. La URL no se puede modificar desde '
                 'aquí; tienes que eliminar la fuente y añadir una nueva con la URL '
                 'corregida.',
            icon=_icon_path('url.png'),
        ))

        last_check = st.get('last_check_ts')
        if last_check:
            when = time.strftime('%Y-%m-%d %H:%M', time.localtime(last_check))
            items.append(SelectItem(
                label=f'Última comprobación: {when}',
                plot='Fecha de la última vez que el gestor consultó si esta fuente respondía.',
                icon=_icon_path('history.png'),
            ))

        history = st.get('diff_history', [])
        if history:
            history_lines = []
            for entry in reversed(history):
                entry_when = time.strftime('%Y-%m-%d %H:%M', time.localtime(entry.get('ts', 0)))
                diff_text = _format_diff(entry.get('prev', {}), entry.get('current', {}))
                history_lines.append(f'[B]{entry_when}[/B]\n{diff_text}')
            items.append(SelectItem(
                label=f'Historial de cambios ({len(history)})',
                plot='\n\n'.join(history_lines),
                icon=_icon_path('history.png'),
            ))

        items.append(SelectItem(
            label='Renombrar',
            plot='Cambia el nombre legible que aparece en el file manager y aquí. La URL '
                 'no se toca. Kodi solo verá el nombre nuevo tras reiniciar.',
            icon=_icon_path('edit.png'),
            action=lambda: _rename_source(name),
        ))
        items.append(SelectItem(
            label='Eliminar',
            plot='Borra la fuente de sources.xml. Si por error eliminas una que usabas, '
                 'tendrás que volver a añadirla con su URL.',
            icon=_icon_path('delete.png'),
            action=lambda: _remove_source(name),
        ))
        items.append(SelectItem(
            label='Volver',
            plot='Vuelve a la lista de fuentes.',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu(f'Fuente: {name}', build)


def _open_sources_submenu():
    """Submenú de gestión de fuentes. Bloqueante hasta que el usuario vuelve."""

    def build():
        items = []
        items.append(SelectItem(
            label='Añadir una fuente nueva',
            plot='Elige entre el asistente de GitHub Pages (solo escribes usuario y '
                 'repositorio) o escribir la URL completa, y añade la entrada al bloque '
                 'de fuentes para archivos de sources.xml. Kodi solo verá la fuente '
                 'nueva tras reiniciar.',
            icon=_icon_path('add_source.png'),
            action=_action_add_source,
        ))
        items.append(SelectItem(
            label='Volver a comprobar todas las fuentes ahora',
            plot='Lanza el escaneo paralelo de todas las fuentes HTTP/HTTPS para detectar '
                 'cambios y caídas. Útil cuando no quieres esperar a la próxima entrada al '
                 'gestor.',
            icon=_icon_path('sync.png'),
            action=_action_rescan,
        ))

        for src in sources.list_files_sources():
            tag = _status_tag(src['path'])
            label = f'{tag} {src["name"]}' if tag else src['name']
            items.append(SelectItem(
                label=label,
                plot=f'URL: {src["path"]}\n\nPulsa para ver el detalle, renombrar o eliminar '
                     'esta fuente.',
                icon=_icon_path(_source_icon(src['path'])),
                action=lambda s=src: _source_detail(s),
            ))

        items.append(SelectItem(
            label='Volver',
            plot='Vuelve al menú anterior del gestor.',
            icon=_icon_path('back.png'),
            action=_close,
        ))
        return items

    menu('Fuentes', build)


def _build_main_items():
    items = []

    pending = _pending_changes_count()
    if pending:
        items.append(SelectItem(
            label=f'[B]Hay {pending} fuente{"s" if pending != 1 else ""} con cambios[/B]',
            plot='Una o más fuentes han cambiado su contenido desde la última vez que '
                 'entraste al gestor. Pulsa para ir directamente al listado y revisar '
                 'cada fuente con el flag de cambios.',
            icon=_icon_path('notification.png'),
            action=_open_sources_submenu,
        ))

    items.append(SelectItem(
        label='Gestionar fuentes',
        plot='Ver, añadir, renombrar y eliminar las fuentes del bloque de archivos de '
             'sources.xml. Es el equivalente intuitivo al gestor de fuentes nativo de '
             'Kodi, pensado para que añadir repositorios resulte más cómodo.',
        icon=_icon_path('sources.png'),
        action=_open_sources_submenu,
    ))

    items.append(SelectItem(
        label='Comprobar actualizaciones en los repositorios instalados',
        plot='Recorre los addons del tipo repository.* que tienes instalados, descarga '
             'su index remoto y compara las versiones publicadas con las que tienes '
             'activas. Lista al final qué addons tienen actualización disponible.',
        icon=_icon_path('sync.png'),
        action=_action_scan_repos,
    ))

    items.append(SelectItem(
        label='Backup y restauración',
        plot='Crea copias de seguridad de tus addons y repositorios, restaura desde un '
             'backup previo o instala lotes de addons desde un fichero XML. Las copias '
             'se guardan en este Kodi y se pueden descargar desde el panel web.',
        icon=_icon_path('download.png'),
        action=_open_backup_submenu,
    ))

    items.append(SelectItem(
        label='Salir',
        plot='Cierra el gestor y vuelve al menú principal.',
        icon=_icon_path('exit.png'),
        action=_close,
    ))

    return items


def run():
    # Lanzamos un scan al abrir si los datos son viejos. No bloqueante para
    # el usuario porque el progress es cancelable.
    items_first = sources.list_files_sources()
    # Limpieza primero: si una fuente fue eliminada desde el file manager
    # nativo, su entry en source_state queda huérfana hasta que entre aquí.
    _purge_orphan_state(items_first)
    if items_first:
        _maybe_scan_on_open(items_first)

    menu('Gestor de fuentes y repositorios', _build_main_items)


def run_backup():
    _open_backup_submenu()
