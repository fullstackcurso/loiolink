"""Acción 'Instalar/Abrir StreamNinja'."""
import xbmc
import xbmcaddon
import xbmcgui

from lib import installer, log
from lib.ui_select import info


STREAMNINJA_ID = 'plugin.video.streamninja'
STREAMNINJA_REPO_ID = 'repository.streamninja'

# Mi repo de StreamNinja en GitHub. Si publico una versión nueva y borro
# el ZIP 1.0.0, el usuario puede override la URL desde Ajustes -> Avanzado
# sin necesidad de actualizar el addon.
_DEFAULT_REPO_URL = (
    'https://raw.githubusercontent.com/fullstackcurso/estreamninja/'
    'main/repository.streamninja-1.0.0.zip'
)


def _get_repo_url():
    try:
        override = (xbmcaddon.Addon().getSetting(
            'streamninja_repo_url_override',
        ) or '').strip()
    except RuntimeError:
        override = ''
    if override and not override.lower().startswith(('http://', 'https://')):
        log.warning(f'Override de repo inválido (no http/https): {override!r}')
        override = ''
    return override or _DEFAULT_REPO_URL


def is_installed():
    return installer.is_ready(STREAMNINJA_ID)


def run():
    if installer.is_ready(STREAMNINJA_ID):
        xbmc.executebuiltin(f'RunAddon({STREAMNINJA_ID})')
        return

    # Si está instalado pero deshabilitado, recuperarlo sin red.
    if installer.try_recover(STREAMNINJA_ID):
        xbmcgui.Dialog().notification(
            'loiolink', 'StreamNinja reactivado correctamente',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        return

    idx = xbmcgui.Dialog().select(
        'StreamNinja',
        ['Instalar automáticamente', 'Ver instrucciones manuales'],
    )
    if idx == -1:
        return
    if idx == 1:
        xbmcgui.Dialog().textviewer(
            'Cómo instalar StreamNinja',
            '[B]Cómo instalar StreamNinja[/B]\n\n'
            '1. Ajustes -> Sistema -> Addons -> activa Orígenes desconocidos\n\n'
            '2. Ajustes -> Explorador de archivos -> Añadir fuente:\n'
            '   https://fullstackcurso.github.io/estreamninja/\n\n'
            '3. Ajustes -> Addons -> Instalar desde un archivo zip -> StreamNinja\n'
            '   -> repository.streamninja-x.x.x.zip\n\n'
            '4. Instalar desde repositorio -> StreamNinja Repository\n'
            '   -> Addons de vídeo -> StreamNinja',
        )
        return

    dp = xbmcgui.DialogProgress()
    dp.create('loiolink', 'Descargando repositorio StreamNinja...')

    def download_cb(done, total):
        if dp.iscanceled():
            raise InterruptedError()
        if total:
            dp.update(int(done * 55 / total), f'{done // 1024} KB / {total // 1024} KB')
        else:
            dp.update(0, f'{done // 1024} KB')

    def repo_status(pct, msg):
        dp.update(55 + int(pct * 0.40), msg)

    try:
        ok = installer.download_and_install_repo(
            _get_repo_url(), STREAMNINJA_REPO_ID,
            progress_cb=download_cb,
            status_cb=repo_status,
        )
    except InterruptedError:
        return
    except installer.InstallError as e:
        log.error(f'InstallError StreamNinja: {e}')
        info(f'Error de instalación: {e}', title='loiolink')
        return
    finally:
        dp.close()

    if not ok:
        info(
            'El repositorio de StreamNinja no se instaló.\n\n'
            'Verifica que "Orígenes desconocidos" está activo en '
            'Ajustes -> Sistema -> Addons.',
            title='loiolink',
        )
        return

    xbmcgui.Dialog().notification(
        'loiolink', 'Confirmando instalación de StreamNinja...',
        xbmcgui.NOTIFICATION_INFO, 4000,
    )

    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Instalando StreamNinja...')

    def addon_status(pct, msg):
        bg.update(pct, 'loiolink', msg)

    try:
        ok = installer.install_addon_from_repo(
            STREAMNINJA_ID, repo_id=STREAMNINJA_REPO_ID, status_cb=addon_status,
        )
    finally:
        bg.close()

    if ok:
        from lib import accessibility
        accessibility.notify('StreamNinja instalado', ms=2500)
    else:
        info(
            'Instalación falló. Pruébalo desde:\n'
            'Addons -> Instalar desde repositorio -> StreamNinja.',
            title='loiolink',
        )
