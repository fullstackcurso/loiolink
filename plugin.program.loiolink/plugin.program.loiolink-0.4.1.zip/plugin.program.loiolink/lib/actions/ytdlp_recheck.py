"""Acción 'Re-comprobar yt-dlp': invalida el cache y fuerza re-detección.

Útil cuando el usuario acaba de instalar yt-dlp en el sistema sin
reiniciar Kodi y quiere que loiolink lo detecte de inmediato.
"""
import xbmc
import xbmcgui

from lib import accessibility, ytdlp_resolver
from lib.ui_select import confirm, info


def _deno_install_cmd():
    """Comando para instalar Deno en la plataforma actual. Deno es el runtime
    JS que yt-dlp 2025.11+ necesita para YouTube.
    """
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return 'winget install DenoLand.Deno'
    if xbmc.getCondVisibility('System.Platform.OSX'):
        return 'brew install deno'
    return 'curl -fsSL https://deno.land/install.sh | sh'


def _platform_install_command():
    """Comandos ejecutables (yt-dlp + Deno) listos para pegar en una terminal.
    Cadena vacía en Android, donde yt-dlp no aplica.
    """
    if xbmc.getCondVisibility('System.Platform.Android'):
        return ''
    if xbmc.getCondVisibility('System.Platform.Windows'):
        ytdlp = 'winget install Python.Python.3.12\npython -m pip install -U yt-dlp'
    elif xbmc.getCondVisibility('System.Platform.OSX'):
        ytdlp = 'brew install yt-dlp'
    else:
        ytdlp = 'pipx install yt-dlp'
    return f'{ytdlp}\n{_deno_install_cmd()}'


def _platform_install_hint():
    """Instrucciones de instalación específicas por plataforma. Devuelve
    string multilínea listo para mostrar en textviewer/info().
    """
    if xbmc.getCondVisibility('System.Platform.Android'):
        return (
            'Plataforma: Android\n\n'
            'En Android no se puede usar yt-dlp (Kodi no expone subprocess '
            'al sistema operativo). loiolink usa dm_gujal interno como '
            'fallback para Dailymotion, y el regex scanner cubre los sitios '
            'mainstream (YouTube, Vimeo, Twitch...) cuando hay un plugin '
            'instalado para resolverlos.'
        )
    if xbmc.getCondVisibility('System.Platform.Windows'):
        return (
            'Plataforma: Windows\n\n'
            'Instalación recomendada (PowerShell con permisos de usuario):\n\n'
            '  winget install Python.Python.3.12\n'
            '  python -m pip install -U yt-dlp\n'
            '  winget install DenoLand.Deno\n\n'
            'Deno es el runtime JavaScript que yt-dlp 2025.11+ necesita para '
            'YouTube; el resto de sitios funcionan sin él.\n\n'
            'Verifica abriendo PowerShell o cmd y ejecutando:\n'
            '  python --version    (debe imprimir 3.10 o superior)\n'
            '  python -m yt_dlp --version    (debe imprimir 2024.x.x o similar)\n'
            '  deno --version\n\n'
            'Si Python ya estaba instalado, asegúrate que está en el PATH del '
            'usuario que ejecuta Kodi (Variables de entorno -> Path).'
        )
    if xbmc.getCondVisibility('System.Platform.OSX'):
        return (
            'Plataforma: macOS\n\n'
            'Instalación recomendada (Terminal con Homebrew):\n\n'
            '  brew install yt-dlp\n'
            '  brew install deno\n\n'
            'Deno es el runtime JavaScript que yt-dlp 2025.11+ necesita para '
            'YouTube; el resto de sitios funcionan sin él.\n\n'
            'Verifica:\n'
            '  python3 --version\n'
            '  yt-dlp --version\n'
            '  deno --version'
        )
    # Linux/LibreELEC/CoreELEC y resto.
    return (
        'Plataforma: Linux (o similar)\n\n'
        'Instalación recomendada (Terminal):\n\n'
        '  sudo apt install python3 python3-pip      # Debian/Ubuntu\n'
        '  sudo dnf install python3 python3-pip      # Fedora\n'
        '  sudo pacman -S python python-pip          # Arch\n\n'
        '  pipx install yt-dlp     (recomendado, evita pisar paquetes de sistema)\n'
        '  # o si pipx no está:\n'
        '  pip install --user -U yt-dlp\n\n'
        'Para YouTube hace falta además Deno (runtime JavaScript de '
        'yt-dlp 2025.11+):\n\n'
        '  curl -fsSL https://deno.land/install.sh | sh\n\n'
        'Verifica:\n'
        '  python3 --version    (debe imprimir 3.10 o superior)\n'
        '  yt-dlp --version\n'
        '  deno --version\n\n'
        'En LibreELEC/CoreELEC el sistema es read-only y NO suele haber '
        'Python del sistema disponible para Kodi: yt-dlp no es posible ahí, '
        'pero loiolink usa dm_gujal interno y los plugins de Kodi (YouTube, '
        'Dailymotion, Vimeo) como fallback.'
    )


def _copy_install_command():
    """Copia el comando de instalación al portapapeles del SO. Usa
    os_clipboard directamente (no clipboard.set, que sanea saltos de línea
    y dejaría el comando en una sola línea inservible).
    """
    cmd = _platform_install_command()
    if not cmd:
        return
    if not confirm('¿Copiar el comando de instalación al portapapeles?',
                   default_no=False):
        return
    from lib import os_clipboard
    try:
        ok = os_clipboard.set_system_clipboard(cmd)
    except os_clipboard.NotSupportedError:
        ok = False
    if ok:
        accessibility.notify('Comando copiado al portapapeles', ms=3000)
    else:
        accessibility.notify(
            'No se pudo copiar; cópialo a mano del texto mostrado',
            level=xbmcgui.NOTIFICATION_WARNING, ms=4000,
        )


def _report_installed():
    if ytdlp_resolver.has_js_runtime():
        accessibility.notify('yt-dlp detectado correctamente', ms=3000)
        return
    # yt-dlp resuelve, pero sin runtime JS YouTube fallará: avisamos para no
    # dar falsa confianza justo en el caso de uso más común.
    accessibility.notify('yt-dlp detectado (falta Deno para YouTube)', ms=4000)
    info(
        'yt-dlp funciona, pero no se ha encontrado un runtime JavaScript '
        '(Deno o Node) en el sistema. yt-dlp 2025.11+ lo necesita para '
        'resolver YouTube; el resto de sitios funcionan sin él.\n\n'
        'Para habilitar YouTube, instala Deno:\n\n'
        '  ' + _deno_install_cmd() + '\n\n'
        'Si YouTube ya te reproduce, puedes ignorar este aviso.',
        title='loiolink',
    )


def _report_missing():
    body = (
        'No se ha encontrado yt-dlp utilizable en el sistema.\n\n'
        'yt-dlp es OPCIONAL — loiolink funciona sin él, usando regex scanner '
        'y dm_gujal interno como fallback. Sin embargo, instalarlo añade '
        'soporte para más de 1800 sitios web (YouTube, TikTok, Instagram, '
        'sitios de streaming, redes sociales) con resolución de JavaScript '
        'dinámico que el regex no cubre.\n\n'
        'Requisitos:\n'
        '- Python >= 3.10 accesible desde el PATH (python3, python o py).\n'
        '- yt-dlp instalado vía pip/pipx.\n'
        '- Deno (runtime JavaScript) para YouTube.\n\n'
        + _platform_install_hint() +
        '\n\nAlternativa sin instalar nada en el sistema: el addon '
        '"youtube-dl Control" (script.module.youtube.dl). loiolink lo usa como '
        'fallback in-process si está instalado; es más limitado para YouTube, '
        'pero funciona en Android y sin Python de sistema.'
        '\n\nTras instalar, vuelve a Opciones avanzadas -> '
        '"Re-comprobar yt-dlp" para forzar la detección sin reiniciar Kodi.'
    )
    xbmcgui.Dialog().textviewer('Cómo instalar yt-dlp', body)
    _copy_install_command()


def run():
    ytdlp_resolver.invalidate_installed_cache()
    bg = xbmcgui.DialogProgressBG()
    bg.create('loiolink', 'Detectando yt-dlp…')
    try:
        installed = ytdlp_resolver.is_installed()
    finally:
        bg.close()
    if installed:
        _report_installed()
    else:
        _report_missing()
