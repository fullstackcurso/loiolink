"""Marcadores persistentes de URLs (favoritos curados por el usuario).

Distinto del historial (lib/url_input_history.py): el historial es transitorio
y se llena al pegar/clicar URLs; los marcadores son una lista curada que el
usuario añade explícitamente y nombra a su gusto.

Mismo patrón de persistencia que el historial: JSON en addon_data, atomic save
race-safe (tempfile.mkstemp), validación de tipo en load(). Diferencias:
- _MAX_ENTRIES = 100 (vs 20 del historial)
- add() NO sobrescribe entries existentes: retorna False si ya estaba, para
  que el caller notifique al usuario y no pise un nombre custom que hubiera
  renombrado.
- rename() para modificar el campo `name` explícitamente.
"""
import json
import os
import tempfile
import time

import xbmcvfs

from lib import log


_PROFILE = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.program.loiolink/',
)
_BOOKMARKS_PATH = os.path.join(_PROFILE, 'url_bookmarks.json')
_MAX_ENTRIES = 100
_NAME_MAX = 80


def _ensure_dir():
    try:
        os.makedirs(_PROFILE, exist_ok=True)
    except OSError as e:
        log.warning(f'[url_bookmarks] mkdir falló: {e!r}')


def load():
    if not os.path.isfile(_BOOKMARKS_PATH):
        return []
    try:
        with open(_BOOKMARKS_PATH, encoding='utf-8') as f:
            data = json.load(f)
    except ValueError as e:
        # Corrupto de verdad: apartarlo antes de devolver vacío. La siguiente
        # operación llama a save(), que reescribe el fichero entero, así que
        # sin esta copia los 100 marcadores desaparecían sin rastro. Mismo
        # patrón que sessions._load_unlocked para el mismo perfil de riesgo.
        log.warning(f'[url_bookmarks] JSON corrupto, tratando como vacío: {e!r}')
        try:
            if os.path.getsize(_BOOKMARKS_PATH) > 0:
                os.replace(_BOOKMARKS_PATH,
                           f'{_BOOKMARKS_PATH}.corrupt.{int(time.time())}.bak')
        except OSError as e2:
            log.warning(f'[url_bookmarks] no se pudo apartar el corrupto: {e2!r}')
        return []
    except OSError as e:
        # Transitorio (el antivirus tiene el fichero abierto, disco ocupado):
        # el contenido está bien y NO se aparta. Antes se logueaba como "JSON
        # corrupto", que mandaba a buscar la causa al sitio equivocado.
        log.warning(f'[url_bookmarks] no se pudo leer: {e!r}')
        return []
    if not isinstance(data, list):
        return []
    return [
        e for e in data
        if isinstance(e, dict)
        and isinstance(e.get('url'), str)
        and e['url']
    ]


def save(entries):
    """Escritura atómica y race-safe (mismo patrón que url_input_history).

    Devuelve True si se escribió. En Windows `os.replace` falla de forma
    transitoria si el antivirus tiene el destino abierto; devolver éxito sin
    haber escrito hacía que la UI confirmara un marcador que no existía.
    """
    _ensure_dir()
    try:
        fd, tmp = tempfile.mkstemp(prefix='url_bookmarks_', suffix='.tmp', dir=_PROFILE)
    except OSError as e:
        log.warning(f'[url_bookmarks] mkstemp falló: {e!r}')
        return False
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(entries[:_MAX_ENTRIES], f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, _BOOKMARKS_PATH)
        return True
    except OSError as e:
        log.warning(f'[url_bookmarks] save falló: {e!r}')
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def add(url, name, thumb=''):
    """Añade un marcador nuevo. No-op si la URL ya existía (preserva el
    nombre custom que el usuario pueda haber puesto).

    True si se añadió Y quedó guardado. False si ya estaba o si no se pudo
    escribir.
    """
    url = (url or '').strip()
    if not url:
        return False
    entries = load()
    if any(e.get('url') == url for e in entries):
        return False
    name = (name or url)[:_NAME_MAX]
    entries.insert(0, {
        'url': url,
        'name': name,
        'thumb': thumb or '',
        'ts': int(time.time()),
    })
    return save(entries)


def remove(url):
    """Elimina marcador por URL. True si se eliminó Y se guardó."""
    url = (url or '').strip()
    if not url:
        return False
    entries = load()
    new = [e for e in entries if e.get('url') != url]
    if len(new) == len(entries):
        return False
    return save(new)


def rename(url, new_name):
    """Cambia el `name` del marcador. True si lo encontró Y lo guardó."""
    url = (url or '').strip()
    new_name = (new_name or '').strip()[:_NAME_MAX]
    if not url or not new_name:
        return False
    entries = load()
    found = False
    for e in entries:
        if e.get('url') == url:
            e['name'] = new_name
            found = True
            break
    if not found:
        return False
    return save(entries)


def get(url):
    url = (url or '').strip()
    if not url:
        return None
    for e in load():
        if e.get('url') == url:
            return e
    return None


def count():
    return len(load())


def clear():
    if not os.path.isfile(_BOOKMARKS_PATH):
        return True
    try:
        os.remove(_BOOKMARKS_PATH)
    except OSError as e:
        log.warning(f'[url_bookmarks] clear falló: {e!r}')
        return False
    return True
