"""
Campo estelar animado
"""
import os
import random
import xbmcgui
import xbmcaddon

_ID = xbmcaddon.Addon().getAddonInfo("id")
_ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
_MEDIA_URI = f"special://home/addons/{_ID}/resources/media/"

_SKIN_BASE = os.path.join(_ADDON_PATH, "resources", "skins", "Default", "1080i")
XML_NAME = "script-stars-v5.xml"
XML_PATH = os.path.join(_SKIN_BASE, XML_NAME)

_ROWS = [
    " .       *             +          .   x          .          *    .         +       ",
    "       +        .            .              *           +            x             ",
    "  x              +      .       .             +               .        x   *       ",
    "      .      *               +          x            *         .            +      ",
    "  .               +                   .          *             +       .           ",
    "       x       .           *               .         .           +        *        ",
    " .                   +               x           .          *           +          ",
    "         +                 .                .          +              *       .     "
]


def _build_xml():
    rng = random.Random()

    label_controls = []
    y = 0
    line_height = 42

    for _pass in range(2):
        for _ in range(25):
            row = "    ".join(rng.choice(_ROWS) for _ in range(5))
            row = row.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            label_controls.append(
                f'            <control type="label">\n'
                f'                <left>0</left>\n'
                f'                <top>{y}</top>\n'
                f'                <width>3000</width>\n'
                f'                <height>{line_height}</height>\n'
                f'                <font>font12</font>\n'
                f'                <textcolor>AABBFFFF</textcolor>\n'
                f'                <label>{row}</label>\n'
                f'            </control>'
            )
            y += line_height

    labels_xml = "\n".join(label_controls)
    half_h = (25 * line_height)

    xml = f"""<?xml version="1.0" encoding="utf-8"?>
<window>
    <defaultcontrol>2</defaultcontrol>
    <controls>
        <control type="image">
            <left>0</left>
            <top>0</top>
            <width>1920</width>
            <height>1080</height>
            <texture>{_MEDIA_URI}white.png</texture>
            <colordiffuse>F2030610</colordiffuse>
        </control>

        <control type="group">
            <left>0</left>
            <top>-{half_h}</top>
            <width>1920</width>

            <!-- Palpitacion -->
            <animation effect="fade" start="35" end="100" time="2000" pulse="true" condition="true">Conditional</animation>

            <!-- Caida vertical lenta -->
            <animation effect="slide" start="0,0" end="0,{half_h}" time="45000" loop="true" condition="true">Conditional</animation>

{labels_xml}
        </control>

        <control type="button" id="2">
            <left>0</left>
            <top>1200</top>
            <width>1</width>
            <height>1</height>
            <label> </label>
            <visible>false</visible>
        </control>
    </controls>
</window>
"""
    return xml


class AsciiMatrixXML(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def onInit(self):
        pass

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()


def _ensure_xml():
    if not os.path.exists(_SKIN_BASE):
        os.makedirs(_SKIN_BASE)
    if not os.path.exists(XML_PATH):
        xml = _build_xml()
        with open(XML_PATH, "w", encoding="utf-8") as f:
            f.write(xml)


def show():
    _ensure_xml()
    dlg = AsciiMatrixXML(XML_NAME, _ADDON_PATH, "Default", "1080i")
    dlg.doModal()
    del dlg


def get_bg_dialog():
    _ensure_xml()
    dlg = AsciiMatrixXML(XML_NAME, _ADDON_PATH, "Default", "1080i")
    return dlg
